# Version history for `cardano-ledger-shelley`

## 1.0.0.0

* First properly versioned release.
