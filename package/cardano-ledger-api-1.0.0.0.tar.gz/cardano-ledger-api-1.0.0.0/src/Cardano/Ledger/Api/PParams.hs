module Cardano.Ledger.Api.PParams (
  EraPParams (..),
)
where

import Cardano.Ledger.Core (EraPParams (..))
