module Cardano.Ledger.Api.Tx.AuxData (
  EraTxAuxData (..),
)
where

import Cardano.Ledger.Core (EraTxAuxData (..))
