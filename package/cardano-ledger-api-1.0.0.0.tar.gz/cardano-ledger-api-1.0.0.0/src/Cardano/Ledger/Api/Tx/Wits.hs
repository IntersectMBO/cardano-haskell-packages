module Cardano.Ledger.Api.Tx.Wits (
  EraTxWits (..),
)
where

import Cardano.Ledger.Core (EraTxWits (..))
