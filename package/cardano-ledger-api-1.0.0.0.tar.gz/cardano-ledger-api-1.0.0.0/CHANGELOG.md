# Version history for `cardano-ledger-api`

## 1.0.0.0

* Initial release
