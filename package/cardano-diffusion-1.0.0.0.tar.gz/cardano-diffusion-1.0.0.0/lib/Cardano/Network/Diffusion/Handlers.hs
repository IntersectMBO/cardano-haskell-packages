{-# LANGUAGE CPP #-}

#if !defined(mingw32_HOST_OS)
#define POSIX
#else
{-# OPTIONS_GHC -Wno-redundant-constraints #-}
#endif

module Cardano.Network.Diffusion.Handlers where

import Control.Concurrent.Class.MonadSTM.Strict
import Control.Monad.Class.MonadTime.SI

import Cardano.Network.LedgerStateJudgement
import Cardano.Network.PeerSelection.Bootstrap (UseBootstrapPeers)
import Cardano.Network.PeerSelection.Governor.PeerSelectionState qualified as Cardano

import Ouroboros.Network.ConnectionManager.Types
import Ouroboros.Network.Diffusion.Types (Tracers (..))
import Ouroboros.Network.PeerSelection.Governor
import Ouroboros.Network.PeerSelection.LedgerPeers.Type (UseLedgerPeers)
import Ouroboros.Network.PeerSelection.PeerMetric
import Ouroboros.Network.PeerSelection.PeerSharing (PeerSharing)

#ifdef POSIX
import Control.Tracer (traceWith)

import Cardano.Network.PeerSelection.Governor.Types qualified as Cardano
import Ouroboros.Network.ConnectionManager.Core (Trace (..))
import Ouroboros.Network.PeerSelection.Governor.Types
           (makeDebugPeerSelectionState)
import System.Posix.Signals qualified as Signals
#endif

sigUSR1Handler
  :: Ord ntnAddr
  => Tracers ntnAddr ntnVersion ntnVersionData
             ntcAddr ntcVersion ntcVersionData
             extraState
             Cardano.DebugPeerSelectionState
             extraFlags extraPeers
             IO
  -> STM IO UseLedgerPeers
  -> PeerSharing
  -> STM IO UseBootstrapPeers
  -> STM IO LedgerStateJudgement
  -> PeerMetrics IO ntnAddr
  -> (peerconn -> STM IO (Maybe Time))
  -- ^ return time when an active peer was promoted to a hot peer.
  -> ConnectionManager muxMode socket ntnAddr
                       handle handleError IO
  -> StrictTVar IO (PeerSelectionState
                   Cardano.ExtraState
                   extraFlags extraPeers ntnAddr
                   peerconn)
  -> IO ()
#ifdef POSIX
sigUSR1Handler tracersExtra getUseLedgerPeers ownPeerSharing getBootstrapPeers
               getLedgerStateJudgement metrics getPromotedHotTime connectionManager dbgStateVar = do
  _ <- Signals.installHandler
         Signals.sigUSR1
         (Signals.Catch
           (do now <- getMonotonicTime
               (state, up, bp, lsj, am, ps) <- atomically $ do
                  useBootstrapPeers <- getBootstrapPeers
                  (,,,,,) <$> readState connectionManager
                          <*> upstreamyness metrics
                          <*> fetchynessBlocks metrics
                          <*> (Cardano.DebugPeerSelectionState <$> getLedgerStateJudgement)
                          <*> Cardano.readAssociationMode
                                getUseLedgerPeers
                                ownPeerSharing
                                useBootstrapPeers
                          <*> readTVar dbgStateVar

               dbgState <- makeDebugPeerSelectionState ps up bp lsj am getPromotedHotTime now

               traceWith (dtConnectionManagerTracer tracersExtra)
                         (TrState state)
               traceWith (dtTracePeerSelectionTracer tracersExtra)
                         (TraceDebugState now dbgState)
           )
         )
         Nothing
  return ()
#else
sigUSR1Handler _ _ _ _ _ _ _ _ _ = pure ()
#endif
