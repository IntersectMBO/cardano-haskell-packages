{-# LANGUAGE DerivingVia #-}
{-# LANGUAGE FlexibleContexts #-}
{-# LANGUAGE FlexibleInstances #-}
{-# LANGUAGE GeneralisedNewtypeDeriving #-}
{-# LANGUAGE MonoLocalBinds #-}
{-# LANGUAGE StandaloneDeriving #-}
{-# LANGUAGE UndecidableInstances #-}
{-# OPTIONS_GHC -Wno-orphans #-}

module Test.Cardano.Protocol.Binary.Annotator (
  module Test.Cardano.Ledger.Conway.Binary.Annotator,
) where

import Test.Cardano.Ledger.Conway.Binary.Annotator
import Test.Cardano.Protocol.TPraos.BlockHeader.Arbitrary ()
