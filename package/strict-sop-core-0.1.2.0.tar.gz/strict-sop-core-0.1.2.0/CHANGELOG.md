# Strict sop-core Changelog

# Changelog entries

<a id='changelog-0.1.2.0'></a>
## 0.1.1.0 — 2024-08-26

### Non-Breaking

- Bump to `nothunks` 0.2

<a id='changelog-0.1.1.0'></a>
## 0.1.1.0 — 2024-05-13

### Non-Breaking

- Add `PolyKinds` to the `Data.SOP.Strict` module.

<a id='changelog-0.1.0.0'></a>
## 0.1.0.0 — 2023-08-25

* First version. Released on an unsuspecting world.
