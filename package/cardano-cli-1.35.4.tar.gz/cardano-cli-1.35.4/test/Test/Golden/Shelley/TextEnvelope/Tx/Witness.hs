{-# LANGUAGE OverloadedStrings #-}

module Test.Golden.Shelley.TextEnvelope.Tx.Witness
  ( golden_shelleyWitness
  ) where

import           Cardano.Prelude
import           Hedgehog (Property)

{- HLINT ignore "Use camelCase" -}

golden_shelleyWitness :: Property
golden_shelleyWitness = panic "TODO"
