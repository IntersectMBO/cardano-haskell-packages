# cardano-cli

A CLI utility to support a variety of key material operations (genesis, migration, pretty-printing..) for different system generations.

