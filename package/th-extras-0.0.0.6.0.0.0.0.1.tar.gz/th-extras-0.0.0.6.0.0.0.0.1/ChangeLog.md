# Revision history for th-extras

## 0.0.0.6 - 2022-01-04

* Fix GHC 8.0 build

* Support GHC 9.0 and 9.2

## 0.0.0.5 - 2019-05-13

* Improve support for various corner cases

* Ensure works with a range of GHCs.

## 0.0.0.4 - 2016-05-10

* Support GHC 8.0

## 0.0.0.2 - 2012-01-13

* Added some more utility functions

## 0.0.0.1 - 2011-11-15

* Initial release
