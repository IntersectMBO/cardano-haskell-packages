{-# LANGUAGE ApplicativeDo #-}
{-# LANGUAGE LambdaCase #-}
{-# LANGUAGE RecordWildCards #-}

-- | Common option parsers for executables
module PlutusCore.Executable.Parsers where

import PlutusCore.AstSize (AstSize (..))
import PlutusCore.Default (BuiltinSemanticsVariant (..), DefaultFun)
import PlutusCore.Executable.Types
import UntypedPlutusCore qualified as UPLC

import Control.Lens ((^.))
import Data.Maybe
import Options.Applicative

{-| Parser for an input stream. If none is specified,
default to stdin for ease of use in pipeline. -}
input :: Parser Input
input = fileInput <|> stdInput <|> pure StdInput

fileInput :: Parser Input
fileInput =
  FileInput
    <$> strOption
      ( long "input"
          <> short 'i'
          <> metavar "FILENAME"
          <> help "Input file"
      )

stdInput :: Parser Input
stdInput =
  flag'
    StdInput
    ( long "stdin"
        <> help "Read from stdin (default)"
    )

{-| Parser for an output stream. If none is specified,
default to stdout for ease of use in pipeline. -}
output :: Parser Output
output = fileOutput <|> stdOutput <|> noOutput <|> pure StdOutput

fileOutput :: Parser Output
fileOutput =
  FileOutput
    <$> strOption
      ( long "output"
          <> short 'o'
          <> metavar "FILENAME"
          <> help "Output file"
      )

stdOutput :: Parser Output
stdOutput =
  flag'
    StdOutput
    ( long "stdout"
        <> help "Write to stdout (default)"
    )

noOutput :: Parser Output
noOutput =
  flag'
    NoOutput
    ( long "silent"
        <> short 's'
        <> help "Don't output the evaluation result"
    )

formatHelp :: String
formatHelp =
  "textual, "
    <> "serialised (cbor + flat, with de Bruijn indices), "
    <> "hex (hex + cbor + flat), "
    <> "flat-named (names), flat (de Bruijn indices), "
    <> "flat-namedDeBruijn (names and de Bruijn indices), "
    <> "or blueprint."

formatReader :: String -> Maybe Format
formatReader =
  \case
    "textual" -> Just Textual
    "serialised" -> Just Serialised
    "hex" -> Just Hex
    "flat-named" -> Just (Flat Named)
    "flat" -> Just (Flat DeBruijn)
    "flat-deBruijn" -> Just (Flat DeBruijn)
    "flat-namedDeBruijn" -> Just (Flat NamedDeBruijn)
    "blueprint" -> Just Blueprint
    _ -> Nothing

inputformat :: Parser Format
inputformat =
  option
    (maybeReader formatReader)
    ( long "if"
        <> long "input-format"
        <> metavar "FORMAT"
        <> value Textual
        <> showDefault
        <> help ("Input format: " ++ formatHelp)
    )

outputformat :: Parser Format
outputformat =
  option
    (maybeReader formatReader)
    ( long "of"
        <> long "output-format"
        <> metavar "FORMAT"
        <> value Textual
        <> showDefault
        <> help ("Output format: " ++ formatHelp)
    )

tracemode :: Parser TraceMode
tracemode =
  option
    auto
    ( long "trace-mode"
        <> metavar "MODE"
        <> value None
        <> showDefault
        <> help "Mode for trace output."
    )

files :: Parser Files
files = some (argument str (metavar "[FILES...]"))

applyOpts :: Parser ApplyOptions
applyOpts = ApplyOptions <$> files <*> inputformat <*> output <*> outputformat <*> printmode

printmode :: Parser PrintMode
printmode =
  option
    auto
    ( long "print-mode"
        <> metavar "MODE"
        <> value Classic
        <> showDefault
        <> help
          ( "Print mode for textual output (ignored elsewhere): Classic -> plcPrettyClassic, "
              <> "Simple -> plcPrettyClassicSimple, "
              <> "Readable -> prettyPlcReadable, ReadableSimple -> prettyPlcReadableSimple"
          )
    )

nameformat :: Parser NameFormat
nameformat =
  flag
    IdNames
    DeBruijnNames
    ( long "debruijn"
        <> short 'j'
        <> help "Output evaluation result with de Bruijn indices (default: show textual names)"
    )

certifier :: Parser Certifier
certifier =
  optional $
    strOption
      ( long "certify"
          <> help
            ( "[EXPERIMENTAL] Produce a certificate ARG.agda proving that the program"
                <> " transformaton is correct; the certificate is an Agda proof object, which"
                <> " can be checked using the Agda proof assistant"
            )
      )

printOpts :: Parser PrintOptions
printOpts = PrintOptions <$> input <*> output <*> printmode

convertOpts :: Parser ConvertOptions
convertOpts = ConvertOptions <$> input <*> inputformat <*> output <*> outputformat <*> printmode

certifierOutputMode :: Parser CertifierOutputMode
certifierOutputMode =
  asum
    [ flag'
        CertBasic
        ( long "certifier-basic"
            <> help "Certifier produces basic output"
        )
    , CertReport
        <$> strOption
          ( long "certifier-report"
              <> metavar "REPORT_FILE"
              <> help "Certifier writes a report to the given file"
          )
    , flag
        CertProject
        CertProject
        ( long "certifier-project"
            <> help "Certifier produces an Agda project that can be type checked (default)"
        )
    ]

optimizeOpts :: Parser (UPLC.OptimizeOpts name a)
optimizeOpts = do
  _ooMaxSimplifierIterations <-
    option
      auto
      ( long "opt-simplifier-iterations"
          <> metavar "INT"
          <> value (UPLC.defaultOptimizeOpts ^. UPLC.ooMaxSimplifierIterations)
          <> showDefault
          <> help "Number of simplifier iterations"
      )
  _ooMaxCseIterations <-
    option
      auto
      ( long "opt-cse-iterations"
          <> metavar "INT"
          <> value (UPLC.defaultOptimizeOpts ^. UPLC.ooMaxCseIterations)
          <> showDefault
          <> help "Number of CSE iterations"
      )
  _ooCseWhichSubterms <-
    option
      ( maybeReader
          ( \case
              "all" -> Just UPLC.AllSubterms
              "exclude-work-free" -> Just UPLC.ExcludeWorkFree
              _ -> Nothing
          )
      )
      ( long "opt-cse-which-subterms"
          <> metavar "MODE"
          <> value UPLC.ExcludeWorkFree
          <> showDefaultWith (\case UPLC.AllSubterms -> "all"; UPLC.ExcludeWorkFree -> "exclude-work-free")
          <> help "CSE subterm selection: all | exclude-work-free"
      )
  _ooConservativeOpts <-
    switch
      ( long "opt-conservative"
          <> help "Use conservative optimisation options. May result in less optimized code."
      )
  let _ooInlineHints = UPLC.defaultOptimizeOpts ^. UPLC.ooInlineHints
  _ooInlineConstants <-
    flag
      True
      False
      ( long "opt-no-inline-constants"
          <> help "Disable constant inlining"
      )
  _ooInlineUnconditionalGrowth <-
    option
      (AstSize <$> auto)
      ( long "opt-inline-unconditional-growth"
          <> metavar "INT"
          <> value (UPLC.defaultOptimizeOpts ^. UPLC.ooInlineUnconditionalGrowth)
          <> showDefault
          <> help "Maximum allowed AST growth for unconditional inlining"
      )
  _ooInlineCallsiteGrowth <-
    option
      (AstSize <$> auto)
      ( long "opt-inline-callsite-growth"
          <> metavar "INT"
          <> value (UPLC.defaultOptimizeOpts ^. UPLC.ooInlineCallsiteGrowth)
          <> showDefault
          <> help "Maximum allowed AST growth for callsite inlining"
      )
  _ooPreserveLogging <-
    switch
      ( long "opt-preserve-logging"
          <> help
            ( "Prevent optimizations from removing or reordering log messages."
                <> " May result in less optimized code."
            )
      )
  _ooApplyToCase <-
    flag
      True
      False
      ( long "opt-no-apply-to-case"
          <> help "Disable apply-to-case optimization"
      )
  _ooHoistPolyBuiltins <-
    flag
      True
      False
      ( long "opt-no-hoist-polymorphic-builtins"
          <> help "Disable hoist-polymorphic-builtins optimization"
      )
  _ooCertifiedOptsOnly <-
    flag
      False
      True
      ( long "certified-opts-only"
          <> help
            "Run only those optimisation passes which are certified to preserve the functional behavior of the original program."
      )
  pure UPLC.OptimizeOpts {..}

optimiseEvalOpts :: Parser OptimiseEvalOpts
optimiseEvalOpts =
  mkOpts
    <$> switch
      ( long "eval"
          <> help
            "Evaluate the program (using the CEK machine) at every stage of \
            \the optimization pipeline.  CPU and memory costs are then shown \
            \in the optimization report, alongside AST sizes, for every pass. \
            \With --certify, the same costs and sizes are also recorded in the \
            \certifier report.  Use --eval-apply or --eval-args-dir to supply \
            \arguments, if any."
      )
    <*> many
      ( strOption
          ( long "eval-apply"
              <> metavar "FILE"
              <> help
                "Apply program to this argument file before evaluating \
                \(repeatable).  Implies --eval."
          )
      )
    <*> option
      ( maybeReader
          ( \case
              "prog" -> Just ArgProg
              "data" -> Just ArgData
              _ -> Nothing
          )
      )
      ( long "eval-arg-kind"
          <> metavar "prog|data"
          <> value ArgData
          <> showDefaultWith (\case ArgProg -> "prog"; ArgData -> "data")
          <> help
            "Whether --eval-apply arguments are UPLC programs or Data objects"
      )
    <*> optional
      ( strOption
          ( long "eval-args-dir"
              <> metavar "DIR"
              <> help
                "Directory with per-validator argument files for blueprint \
                \optimisation.  For each validator titled T, it looks for \
                \files DIR/T/1, DIR/T/2, ... containing arguments to apply. \
                \Implies --eval."
          )
      )
  where
    -- If the user supplied any --eval-apply or --eval-args-dir,
    -- treat --eval as implied even if they didn't pass it explicitly.
    mkOpts eval argFiles argKind argsDir =
      OptimiseEvalOpts
        { oeEval =
            eval
              || not (null argFiles)
              || isJust argsDir
        , oeArgFiles = argFiles
        , oeArgKind = argKind
        , oeBlueprintArgsDir = argsDir
        }

optimiseOpts :: Parser (OptimiseOptions name a)
optimiseOpts =
  OptimiseOptions
    <$> input
    <*> inputformat
    <*> output
    <*> outputformat
    <*> printmode
    <*> certifier
    <*> certifierOutputMode
    <*> optimizeOpts
    <*> optimiseEvalOpts

exampleMode :: Parser ExampleMode
exampleMode = exampleAvailable <|> exampleSingle

exampleAvailable :: Parser ExampleMode
exampleAvailable =
  flag'
    ExampleAvailable
    ( long "available"
        <> short 'a'
        <> help "Show available examples"
    )

exampleName :: Parser ExampleName
exampleName =
  strOption
    ( long "single"
        <> metavar "NAME"
        <> short 's'
        <> help "Show a single example"
    )

exampleSingle :: Parser ExampleMode
exampleSingle = ExampleSingle <$> exampleName

exampleOpts :: Parser ExampleOptions
exampleOpts = ExampleOptions <$> exampleMode

builtinSemanticsVariantReader :: String -> Maybe (BuiltinSemanticsVariant DefaultFun)
builtinSemanticsVariantReader =
  \case
    "A" -> Just DefaultFunSemanticsVariantA
    "B" -> Just DefaultFunSemanticsVariantB
    "C" -> Just DefaultFunSemanticsVariantC
    "D" -> Just DefaultFunSemanticsVariantD
    "E" -> Just DefaultFunSemanticsVariantE
    _ -> Nothing

-- This is used to make the help message show you what you actually need to type.
showBuiltinSemanticsVariant :: BuiltinSemanticsVariant DefaultFun -> String
showBuiltinSemanticsVariant =
  \case
    DefaultFunSemanticsVariantA -> "A"
    DefaultFunSemanticsVariantB -> "B"
    DefaultFunSemanticsVariantC -> "C"
    DefaultFunSemanticsVariantD -> "D"
    DefaultFunSemanticsVariantE -> "E"

builtinSemanticsVariant :: Parser (BuiltinSemanticsVariant DefaultFun)
builtinSemanticsVariant =
  option
    (maybeReader builtinSemanticsVariantReader)
    ( long "builtin-semantics-variant"
        <> short 'S'
        <> metavar "VARIANT"
        <> value DefaultFunSemanticsVariantE
        <> showDefaultWith showBuiltinSemanticsVariant
        <> help
          ( "Builtin semantics variant: A -> DefaultFunSemanticsVariantA, "
              <> "B -> DefaultFunSemanticsVariantB, "
              <> "C -> DefaultFunSemanticsVariantC, "
              <> "D -> DefaultFunSemanticsVariantD, "
              <> "E -> DefaultFunSemanticsVariantE"
          )
    )

-- Specialised parsers for PIR, which only supports ASTs over the Textual and
-- Named types.

pirFormatHelp :: String
pirFormatHelp =
  "textual or flat-named (names)"

pirFormatReader :: String -> Maybe PirFormat
pirFormatReader =
  \case
    "textual" -> Just TextualPir
    "flat-named" -> Just FlatNamed
    _ -> Nothing

pPirInputFormat :: Parser PirFormat
pPirInputFormat =
  option
    (maybeReader pirFormatReader)
    ( long "if"
        <> long "input-format"
        <> metavar "PIR-FORMAT"
        <> value TextualPir
        <> showDefault
        <> help ("Input format: " ++ pirFormatHelp)
    )

pPirOutputFormat :: Parser PirFormat
pPirOutputFormat =
  option
    (maybeReader pirFormatReader)
    ( long "of"
        <> long "output-format"
        <> metavar "PIR-FORMAT"
        <> value TextualPir
        <> showDefault
        <> help ("Output format: " ++ pirFormatHelp)
    )

-- Which language: PLC or UPLC?

languageReader :: String -> Maybe Language
languageReader =
  \case
    "plc" -> Just PLC
    "uplc" -> Just UPLC
    _ -> Nothing

pLanguage :: Parser Language
pLanguage =
  option
    (maybeReader languageReader)
    ( long "language"
        <> short 'l'
        <> metavar "LANGUAGE"
        <> value UPLC
        <> showDefaultWith (\case PLC -> "plc"; UPLC -> "uplc")
        <> help ("Target language: plc or uplc")
    )
