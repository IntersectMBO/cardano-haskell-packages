{-# LANGUAGE DataKinds #-}
{-# LANGUAGE FlexibleContexts #-}
{-# LANGUAGE NumericUnderscores #-}
{-# LANGUAGE OverloadedStrings #-}
{-# LANGUAGE ScopedTypeVariables #-}
{-# LANGUAGE TypeApplications #-}
{-# LANGUAGE TypeFamilies #-}
{-# LANGUAGE TypeOperators #-}

-- | The example transactions in this module are not valid transactions. We
-- don't care, we are only interested in serialisation, not validation.
module Test.Cardano.Ledger.Alonzo.Examples (
  ledgerExamples,
  mkAlonzoBasedLedgerExamples,
  exampleAlonzoTx,
  exampleAlonzoBasedTx,
  exampleAlonzoBasedTopTx,
  exampleAlonzoOnwardsEraPParams,
  exampleAlonzoOnwardsEraPParamsUpdate,
  exampleAlonzoPParams,
  exampleAlonzoPParamsUpdate,
  addAlonzoToConwayExampleReqSigners,
  exampleDatum,
) where

import Cardano.Ledger.Alonzo (AlonzoEra, ApplyTxError (AlonzoApplyTxError))
import Cardano.Ledger.Alonzo.Core
import Cardano.Ledger.Alonzo.Genesis (AlonzoGenesis (..))
import Cardano.Ledger.Alonzo.Plutus.Context (EraPlutusTxInfo)
import Cardano.Ledger.Alonzo.Scripts (
  ExUnits (..),
  Prices (..),
 )
import Cardano.Ledger.Alonzo.TxWits (Redeemers (..), TxDats (..))
import Cardano.Ledger.BaseTypes (Nonce (..), ProtVer (..), StrictMaybe (..))
import Cardano.Ledger.Coin (Coin (..))
import Cardano.Ledger.Mary.Value (MaryValue)
import Cardano.Ledger.Plutus.Data (Data (..), hashData)
import Cardano.Ledger.Plutus.Language (Language (..), plutusBinary)
import Cardano.Ledger.Shelley.API (
  Credential (..),
  Network (..),
  NewEpochState (..),
  ProposedPPUpdates (..),
 )
import qualified Cardano.Ledger.Shelley.Rules as Shelley
import Data.Default (def)
import qualified Data.List.NonEmpty as NE
import qualified Data.Map.Strict as Map
import qualified Data.MapExtras as Map
import qualified Data.Sequence.Strict as StrictSeq
import qualified Data.Set as Set
import Data.Typeable (Typeable)
import Lens.Micro
import qualified PlutusLedgerApi.Common as P
import Test.Cardano.Ledger.Alonzo.Arbitrary (alwaysSucceeds)
import Test.Cardano.Ledger.Core.KeyPair (mkAddr)
import Test.Cardano.Ledger.Core.Rational (IsRatio (..))
import Test.Cardano.Ledger.Core.Utils (mkDummySafeHash, unsafeBoundRational)
import Test.Cardano.Ledger.Mary.Examples (
  exampleMaryBasedTx,
  exampleMultiAssetValue,
 )
import Test.Cardano.Ledger.Plutus (alwaysFailsPlutus, testingCostModels, zeroTestingCostModelV1)
import Test.Cardano.Ledger.Shelley.Examples (
  LedgerExamples (..),
  addShelleyBasedTopTxExampleFee,
  addShelleyToBabbageExampleProposedPUpdates,
  addShelleyToBabbageTxCerts,
  addShelleyToConwayTxCerts,
  exampleNewEpochState,
  exampleNonMyopicRewards,
  examplePayKey,
  examplePoolDistr,
  exampleShelleyOnwardsEraPParams,
  exampleShelleyOnwardsEraPParamsUpdate,
  exampleStakeKey,
  exampleTxIns,
  mkKeyHash,
  mkScriptHash,
  testShelleyGenesis,
 )

ledgerExamples :: LedgerExamples AlonzoEra
ledgerExamples =
  mkAlonzoBasedLedgerExamples
    ( AlonzoApplyTxError $
        pure $
          Shelley.DelegsFailure $
            Shelley.DelplFailure $
              Shelley.DelegFailure $
                Shelley.DelegateeNotRegisteredDELEG @AlonzoEra (mkKeyHash 1)
    )
    exampleAlonzoNewEpochState
    exampleAlonzoTx
    exampleAlonzoGenesis
  where
    exampleAlonzoGenesis =
      AlonzoGenesis
        { agCoinsPerUTxOWord = CoinPerWord $ Coin 1
        , agPlutusV1CostModel = zeroTestingCostModelV1
        , agPrices = Prices (unsafeBoundRational 90) (unsafeBoundRational 91)
        , agMaxTxExUnits = ExUnits 123 123
        , agMaxBlockExUnits = ExUnits 223 223
        , agMaxValSize = 1234
        , agCollateralPercentage = 20
        , agMaxCollateralInputs = 30
        , agExtraConfig = SNothing
        }

exampleAlonzoTx :: Tx TopTx AlonzoEra
exampleAlonzoTx =
  exampleAlonzoBasedTopTx
    & addShelleyBasedTopTxExampleFee
    & addShelleyToBabbageExampleProposedPUpdates
    & addShelleyToBabbageTxCerts
    & addShelleyToConwayTxCerts
    & addAlonzoToConwayExampleReqSigners

mkAlonzoBasedLedgerExamples ::
  forall era.
  AlonzoEraPParams era =>
  ApplyTxError era ->
  NewEpochState era ->
  Tx TopTx era ->
  TranslationContext era ->
  LedgerExamples era
mkAlonzoBasedLedgerExamples
  applyTxError
  newEpochState
  tx
  translationContext =
    LedgerExamples
      { leTx = tx
      , leApplyTxError = applyTxError
      , lePParams = def
      , leProposedPPUpdates =
          ProposedPPUpdates $
            Map.singleton
              (mkKeyHash 0)
              (emptyPParamsUpdate & ppuCollateralPercentageL .~ SJust 150)
      , leNewEpochState = newEpochState
      , lePoolDistr = examplePoolDistr
      , leRewardsCredentials =
          Set.fromList
            [ Left (Coin 100)
            , Right (ScriptHashObj (mkScriptHash 1))
            , Right (KeyHashObj (mkKeyHash 2))
            ]
      , leNonMyopicRewards = exampleNonMyopicRewards
      , leTranslationContext = translationContext
      , leShelleyGenesis = testShelleyGenesis
      }

exampleAlonzoNewEpochState :: NewEpochState AlonzoEra
exampleAlonzoNewEpochState =
  exampleNewEpochState
    (exampleMultiAssetValue 1)
    emptyPParams
    (emptyPParams & ppCoinsPerUTxOWordL .~ CoinPerWord (Coin 1))

exampleAlonzoBasedTopTx ::
  forall era.
  ( AlonzoEraTx era
  , EraPlutusTxInfo 'PlutusV1 era
  , Value era ~ MaryValue
  ) =>
  Tx TopTx era
exampleAlonzoBasedTopTx =
  exampleAlonzoBasedTx
    & addAlonzoBasedTopTxFeatureExamples

exampleAlonzoBasedTx ::
  forall era l.
  ( AlonzoEraTx era
  , EraPlutusTxInfo 'PlutusV1 era
  , Value era ~ MaryValue
  , Typeable l
  ) =>
  Tx l era
exampleAlonzoBasedTx =
  exampleMaryBasedTx
    & addAlonzoBasedTxFeatureExamples

addAlonzoBasedTopTxFeatureExamples ::
  forall era.
  AlonzoEraTx era =>
  Tx TopTx era ->
  Tx TopTx era
addAlonzoBasedTopTxFeatureExamples tx =
  tx
    & isPhase2ValidTxL .~ Phase2Valid
    & bodyTxL . collateralInputsTxBodyL <>~ exampleTxIns

addAlonzoBasedTxFeatureExamples ::
  forall era l.
  ( AlonzoEraTx era
  , EraPlutusTxInfo 'PlutusV1 era
  , Value era ~ MaryValue
  ) =>
  Tx l era ->
  Tx l era
addAlonzoBasedTxFeatureExamples tx =
  tx
    & witsTxL
      <>~ ( mkBasicTxWits
              & scriptTxWitsL <>~ Map.fromElems hashScript [alwaysSucceeds @'PlutusV1 3]
              & datsTxWitsL <>~ TxDats (Map.fromElems hashData [exampleDatum])
              & rdmrsTxWitsL <>~ redeemers
          )
    & modifyTxAuxData
      ( plutusScriptsTxAuxDataL
          %~ Map.insertWith
            (<>)
            PlutusV1
            (NE.singleton (plutusBinary (alwaysFailsPlutus @'PlutusV1 2)))
      )
    & bodyTxL . outputsTxBodyL
      <>~ StrictSeq.fromList
        [ mkBasicTxOut
            (mkAddr examplePayKey exampleStakeKey)
            (exampleMultiAssetValue 3)
            & dataHashTxOutL .~ SJust (mkDummySafeHash 1)
        ]
    & bodyTxL . scriptIntegrityHashTxBodyL .~ SJust (mkDummySafeHash 42)
    & bodyTxL . networkIdTxBodyL .~ SJust Mainnet
  where
    redeemers =
      Redeemers $
        Map.fromList
          [ (SpendingPurpose $ AsIx 0, (redeemerData, ExUnits 5000 5000))
          , (MintingPurpose $ AsIx 1, (redeemerData, ExUnits 5000 5000))
          , (CertifyingPurpose $ AsIx 2, (redeemerData, ExUnits 5000 5000))
          , (WithdrawingPurpose $ AsIx 3, (redeemerData, ExUnits 5000 5000))
          ]
    redeemerData = Data (P.Constr 1 [P.List [P.I 1], P.Map [(P.I 2, P.B "2")]])

addAlonzoToConwayExampleReqSigners ::
  forall era l.
  ( AlonzoEraTxBody era
  , AtMostEra "Conway" era
  , EraTx era
  ) =>
  Tx l era ->
  Tx l era
addAlonzoToConwayExampleReqSigners tx =
  tx & bodyTxL . reqSignerHashesTxBodyL <>~ Set.singleton (mkKeyHash 212)

exampleDatum :: Era era => Data era
exampleDatum = Data (P.Constr 0 [P.List [P.I 0], P.Map [(P.I 1, P.B "1")]])

exampleAlonzoOnwardsEraPParams :: AlonzoEraPParams era => PParams era
exampleAlonzoOnwardsEraPParams =
  exampleShelleyOnwardsEraPParams
    & ppCostModelsL .~ testingCostModels [PlutusV1]
    & ppPricesL
      .~ Prices
        { prMem = 577 %! 10_000
        , prSteps = 721 %! 10_000_000
        }
    & ppMaxTxExUnitsL .~ ExUnits 14_000_000 10_000_000_000
    & ppMaxBlockExUnitsL .~ ExUnits 62_000_000 20_000_000_000
    & ppMaxValSizeL .~ 5_000
    & ppCollateralPercentageL .~ 150
    & ppMaxCollateralInputsL .~ 3

exampleAlonzoOnwardsEraPParamsUpdate :: AlonzoEraPParams era => PParamsUpdate era
exampleAlonzoOnwardsEraPParamsUpdate =
  exampleShelleyOnwardsEraPParamsUpdate
    & ppuCostModelsL .~ SJust (testingCostModels [PlutusV1])
    & ppuPricesL
      .~ SJust
        Prices
          { prMem = 577 %! 10_000
          , prSteps = 721 %! 10_000_000
          }
    & ppuMaxTxExUnitsL .~ SJust (ExUnits 14_000_000 10_000_000_000)
    & ppuMaxBlockExUnitsL .~ SJust (ExUnits 62_000_000 20_000_000_000)
    & ppuMaxValSizeL .~ SJust 5_000
    & ppuCollateralPercentageL .~ SJust 150
    & ppuMaxCollateralInputsL .~ SJust 3

exampleAlonzoPParams ::
  forall era.
  (AlonzoEraPParams era, AtMostEra "Alonzo" era, ExactEra AlonzoEra era) =>
  PParams era
exampleAlonzoPParams =
  exampleAlonzoOnwardsEraPParams
    & ppDL .~ 1 %! 2
    & ppExtraEntropyL .~ NeutralNonce
    & ppCoinsPerUTxOWordL .~ CoinPerWord (Coin 34_482)

exampleAlonzoPParamsUpdate ::
  forall era.
  ( AlonzoEraPParams era
  , AtMostEra "Alonzo" era
  , AtMostEra "Babbage" era
  , ExactEra AlonzoEra era
  ) =>
  PParamsUpdate era
exampleAlonzoPParamsUpdate =
  exampleAlonzoOnwardsEraPParamsUpdate
    & ppuDL .~ SJust (1 %! 2)
    & ppuExtraEntropyL .~ SJust NeutralNonce
    & ppuCoinsPerUTxOWordL .~ SJust (CoinPerWord (Coin 34_482))
    & ppuProtocolVersionL .~ SJust (ProtVer (eraProtVerHigh @era) 0)
