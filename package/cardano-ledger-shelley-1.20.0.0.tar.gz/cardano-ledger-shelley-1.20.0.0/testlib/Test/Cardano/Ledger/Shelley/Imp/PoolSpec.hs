{-# LANGUAGE DataKinds #-}
{-# LANGUAGE FlexibleContexts #-}
{-# LANGUAGE NumericUnderscores #-}
{-# LANGUAGE OverloadedLists #-}
{-# LANGUAGE ScopedTypeVariables #-}
{-# LANGUAGE TypeApplications #-}
{-# LANGUAGE TypeOperators #-}

module Test.Cardano.Ledger.Shelley.Imp.PoolSpec (spec) where

import Cardano.Crypto.Hash.Class (hashSize)
import Cardano.Ledger.BaseTypes
import Cardano.Ledger.Coin
import Cardano.Ledger.Core
import Cardano.Ledger.Credential
import Cardano.Ledger.Keys (asWitness, witVKeyHash)
import Cardano.Ledger.Shelley.LedgerState
import Cardano.Ledger.Shelley.Rewards
import Cardano.Ledger.Shelley.Rules
import Cardano.Ledger.State
import Control.State.Transition (Event)
import Data.Coerce
import qualified Data.Map.Strict as Map
import Data.Proxy
import qualified Data.Set as Set
import qualified Data.Set.NonEmpty as NES
import Data.Typeable (cast)
import Lens.Micro
import Test.Cardano.Base.Bytes (genByteArray)
import Test.Cardano.Ledger.Core.KeyPair
import Test.Cardano.Ledger.Imp.Common
import Test.Cardano.Ledger.Shelley.ImpTest

spec ::
  forall era.
  ( ShelleyEraImp era
  , Event (EraRule "RUPD" era) ~ RupdEvent
  ) =>
  SpecWith (ImpInit (LedgerSpec era))
spec = describe "POOL" $ do
  describe "Register and re-register pools" $ do
    it "register a pool with too low cost" $ do
      (kh, vrf) <- (,) <$> freshKeyHash <*> freshKeyHashVRF
      minPoolCost <- getsPParams ppMinPoolCostL
      tooLowCost <- Coin <$> choose (0, unCoin minPoolCost)
      pps <- poolParams kh vrf
      let tx = registerPoolTx (pps & sppCostL .~ tooLowCost)
      submitFailingTx
        tx
        [injectFailure $ StakePoolCostTooLowPOOL $ Mismatch tooLowCost minPoolCost]

    it "re-register a pool with too low cost" $ do
      (kh, vrf) <- registerNewPool
      pps <- poolParams kh vrf
      minPoolCost <- getsPParams ppMinPoolCostL
      tooLowCost <- Coin <$> choose (0, unCoin minPoolCost)
      let tx = registerPoolTx (pps & sppCostL .~ tooLowCost)
      submitFailingTx
        tx
        [injectFailure $ StakePoolCostTooLowPOOL $ Mismatch tooLowCost minPoolCost]

    it "register a pool with a staking address having the wrong network id" $ do
      pv <- getsPParams ppProtocolVersionL
      accountCredential <- KeyHashObj <$> freshKeyHash
      let badAccountAddress =
            AccountAddress
              { aaNetworkId = Mainnet
              , aaId = AccountId accountCredential
              }
      kh <- freshKeyHash
      pps <- freshPoolParams kh badAccountAddress
      let tx = registerPoolTx pps
      if pvMajor pv < natVersion @5
        then
          submitTx_ tx
        else
          submitFailingTx tx [injectFailure $ WrongNetworkPOOL (Mismatch Mainnet Testnet) kh]

    it "register a pool with an owner w/o a vkey witness" $ do
      poolKeyHash <- freshKeyHash
      ownerKeyHash <- freshKeyHash
      let ownerKeyHashW = asWitness ownerKeyHash
          dropWitness =
            pure
              . (witsTxL . addrTxWitsL %~ Set.filter ((/= ownerKeyHashW) . witVKeyHash))
              . (witsTxL . bootAddrTxWitsL .~ mempty)
      accountAddress <- registerStakeCredential . KeyHashObj =<< freshKeyHash
      pps <- freshPoolParams poolKeyHash accountAddress
      withPostFixup dropWitness $
        submitFailingTx
          ( mkBasicTx $
              mkBasicTxBody
                & certsTxBodyL
                  .~ [RegPoolTxCert pps {sppOwners = Set.singleton ownerKeyHash}]
          )
          [injectFailure . MissingVKeyWitnessesUTXOW @era $ NES.singleton ownerKeyHashW]

    -- https://github.com/IntersectMBO/formal-ledger-specifications/issues/1293
    -- TODO: Re-enable after issue is resolved, by removing this override
    disableInConformanceIt "register a pool with too big metadata" $ do
      pv <- getsPParams ppProtocolVersionL
      let maxMetadataSize = hashSize (Proxy :: Proxy HASH)
      tooBigSize <- choose (maxMetadataSize + 1, maxMetadataSize + 50)
      metadataHash <- liftGen $ genByteArray $ fromIntegral tooBigSize
      url <- arbitrary
      let metadata = PoolMetadata url metadataHash
      (kh, vrf) <- (,) <$> freshKeyHash <*> freshKeyHashVRF
      pps <- poolParams kh vrf
      let tx = registerPoolTx (pps & sppMetadataL .~ SJust metadata)
      if pvMajor pv < natVersion @5
        then
          submitTx_ tx
        else
          submitFailingTx tx [injectFailure $ PoolMedataHashTooBig kh (fromIntegral tooBigSize)]

    it "register a new pool with an already registered VRF" $ do
      pv <- getsPParams ppProtocolVersionL
      (kh, vrf) <- registerNewPool
      khNew <- freshKeyHash
      registerPoolTx <$> poolParams khNew vrf >>= \tx ->
        if pvMajor pv < natVersion @11
          then do
            submitTx_ tx
            expectPool khNew (Just vrf)
          else do
            submitFailingTx tx [injectFailure $ VRFKeyHashAlreadyRegistered khNew vrf]
            expectPool khNew Nothing
      expectPool kh (Just vrf)

    it "new pool parameters are adopted at the epoch boundary after re-registration" $ do
      (kh, vrf) <- registerNewPool
      -- Read the initial cost
      pools <- psStakePools <$> getPState
      initialCost <- case Map.lookup kh pools of
        Just sps -> pure $ spsCost sps
        Nothing -> assertFailure "Pool not found after registration"
      -- Re-register with a different cost
      pps <- poolParams kh vrf
      let newCost = initialCost <> Coin 100
          newPps = pps & sppCostL .~ newCost
      submitTx_ $ registerPoolTx newPps
      -- Before epoch boundary, current pool still has old cost
      pools' <- psStakePools <$> getPState
      spsCost <$> Map.lookup kh pools' `shouldBe` Just initialCost
      -- Future pool params should have the new cost
      fps <- psFutureStakePoolParams <$> getPState
      sppCost <$> Map.lookup kh fps `shouldBe` Just newCost
      passEpoch
      -- After epoch boundary, pool should have adopted the new cost
      adoptedPools <- psStakePools <$> getPState
      spsCost <$> Map.lookup kh adoptedPools `shouldBe` Just newCost
      -- Future params should be cleared
      fps' <- psFutureStakePoolParams <$> getPState
      Map.lookup kh fps' `shouldBe` Nothing

    it "re-register a pool and change its delegations in the same epoch" $ do
      (poolKh, _) <- registerNewPool
      (poolKh2, _) <- registerNewPool
      stakeCred <- KeyHashObj <$> freshKeyHash
      _ <- registerStakeCredential stakeCred
      stakeCred2 <- KeyHashObj <$> freshKeyHash
      _ <- registerStakeCredential stakeCred2
      delegateStake stakeCred poolKh
      vrf1 <- freshKeyHashVRF
      registerPoolTx <$> poolParams poolKh vrf1 >>= \tx -> do
        submitTx_ tx
        expectPoolDelegs poolKh (Just [stakeCred])
        delegateStake stakeCred2 poolKh
        expectPoolDelegs poolKh (Just [stakeCred, stakeCred2])
        passEpoch
        expectPoolDelegs poolKh (Just [stakeCred, stakeCred2])

      vrf2 <- freshKeyHashVRF
      registerPoolTx <$> poolParams poolKh vrf2 >>= \tx -> do
        submitTx_ tx
        expectPoolDelegs poolKh (Just [stakeCred, stakeCred2])

        unRegTxCert <- genUnRegTxCert stakeCred2
        submitTx_ $
          mkBasicTx mkBasicTxBody
            & bodyTxL . certsTxBodyL
              .~ [unRegTxCert]
        expectPoolDelegs poolKh (Just [stakeCred])
        delegateStake stakeCred poolKh2
        expectPoolDelegs poolKh (Just [])
        passEpoch
        expectPoolDelegs poolKh (Just [])

    it "re-register a pool with an already registered VRF" $ do
      pv <- getsPParams ppProtocolVersionL
      (kh1, vrf1) <- registerNewPool
      (kh2, vrf2) <- registerNewPool
      registerPoolTx <$> poolParams kh1 vrf2 >>= \tx ->
        if pvMajor pv < natVersion @11
          then do
            submitTx_ tx
            expectPool kh1 (Just vrf1)
            expectFuturePool kh1 (Just vrf2)
            passEpoch
            expectPool kh1 (Just vrf2)
            expectPool kh2 (Just vrf2)
          else do
            submitFailingTx tx [injectFailure $ VRFKeyHashAlreadyRegistered kh1 vrf2]
            expectPool kh1 (Just vrf1)
            expectFuturePool kh1 Nothing

    it "re-register a pool with its own VRF" $ do
      (kh, vrf) <- registerNewPool
      registerPoolTx <$> poolParams kh vrf >>= submitTx_
      expectPool kh (Just vrf)
      expectFuturePool kh (Just vrf)
      passEpoch
      expectPool kh (Just vrf)
      expectFuturePool kh Nothing

    it "re-register a pool with a fresh VRF" $ do
      (kh, vrf) <- registerNewPool
      vrfNew <- freshKeyHashVRF
      registerPoolTx <$> poolParams kh vrfNew >>= submitTx_
      expectPool kh (Just vrf)
      expectFuturePool kh (Just vrfNew)
      passEpoch
      expectPool kh (Just vrfNew)
      expectVRFs [vrfNew]
      -- now the original VRF can be reused
      khNew <- freshKeyHash
      registerPoolTx <$> poolParams khNew vrf >>= submitTx_
      expectVRFs [vrf, vrfNew]

    it "register a new pool with the VRF of a re-registered pool " $ do
      pv <- getsPParams ppProtocolVersionL
      (kh, _) <- registerNewPool
      vrfNew <- freshKeyHashVRF
      -- re-register pool with a new vrf
      registerPoolTx <$> poolParams kh vrfNew >>= submitTx_
      passEpoch
      -- try to register a new pool with the new vrf
      khNew <- freshKeyHash
      registerPoolTx <$> poolParams khNew vrfNew >>= \tx ->
        if pvMajor pv < natVersion @11
          then do
            submitTx_ tx
            expectPool kh (Just vrfNew)
            expectPool khNew (Just vrfNew)
          else
            submitFailingTx tx [injectFailure $ VRFKeyHashAlreadyRegistered khNew vrfNew]

    it "after the epoch changes, reuse VRFs that get overwritten" $ do
      (kh, vrf) <- registerNewPool
      vrf1 <- freshKeyHashVRF
      registerPoolTx <$> poolParams kh vrf1 >>= submitTx_
      expectVRFs [vrf, vrf1]
      vrf2 <- freshKeyHashVRF
      registerPoolTx <$> poolParams kh vrf2 >>= submitTx_
      expectVRFs [vrf, vrf2]
      vrf3 <- freshKeyHashVRF
      registerPoolTx <$> poolParams kh vrf3 >>= submitTx_
      expectVRFs [vrf, vrf3]
      passEpoch
      expectPool kh (Just vrf3)
      expectVRFs [vrf3]
      -- reuse VRFs that didn't get used
      khNew <- freshKeyHash
      registerPoolTx <$> poolParams khNew vrf1 >>= submitTx_
      expectPool khNew (Just vrf1)
      expectVRFs [vrf1, vrf3]
      -- the original pool can be re-registered with one of the discarded VRFs too
      registerPoolTx <$> poolParams kh vrf2 >>= submitTx_
      expectVRFs [vrf1, vrf2, vrf3]
      passEpoch
      expectVRFs [vrf1, vrf2]
      -- the original pool can be re-registered with the original VRF too
      registerPoolTx <$> poolParams kh vrf >>= submitTx_
      expectVRFs [vrf, vrf1, vrf2]
      passEpoch
      expectVRFs [vrf, vrf1]

    it "before the epoch changes, try to reuse VRFs that get overwritten" $ do
      pv <- getsPParams ppProtocolVersionL
      (kh, vrf) <- registerNewPool
      vrfNew <- freshKeyHashVRF
      registerPoolTx <$> poolParams kh vrfNew >>= submitTx_
      -- try to register a pool with the original VRF that got overwritten
      khNew <- freshKeyHash
      registerPoolTx <$> poolParams khNew vrf >>= \tx ->
        if pvMajor pv < natVersion @11
          then do
            submitTx_ tx
            expectPool kh (Just vrf)
            expectPool khNew (Just vrf)
            passEpoch
            expectPool kh (Just vrfNew)
            expectPool khNew (Just vrf)
          else do
            submitFailingTx tx [injectFailure $ VRFKeyHashAlreadyRegistered khNew vrf]

  describe "Retiring pools" $ do
    it "retire an unregistered pool" $ do
      khNew <- freshKeyHash
      retirePoolTx khNew (EpochInterval 10) >>= \tx ->
        submitFailingTx tx [injectFailure $ StakePoolNotRegisteredOnKeyPOOL khNew]

    it "retire a pool with too high a retirement epoch" $ do
      (kh, _) <- registerNewPool
      maxRetireInterval <- getsPParams ppEMaxL
      curEpochNo <- getsNES nesELL
      let maxRetireIntervalPlus =
            EpochInterval $ fromIntegral $ unEpochInterval maxRetireInterval + 1
      let supplied = addEpochInterval curEpochNo maxRetireIntervalPlus

      retirePoolTx kh maxRetireIntervalPlus >>= \tx ->
        submitFailingTx
          tx
          [ injectFailure $
              StakePoolRetirementWrongEpochPOOL
                (Mismatch supplied curEpochNo)
                (Mismatch supplied (addEpochInterval curEpochNo maxRetireInterval))
          ]
      expectRetiring False kh

    it "retire a pool with too low a retirement epoch" $ do
      (kh, _) <- registerNewPool
      curEpochNo <- getsNES nesELL
      maxRetireInterval <- getsPParams ppEMaxL
      retirePoolTx kh (EpochInterval 0) >>= \tx ->
        submitFailingTx
          tx
          [ injectFailure $
              StakePoolRetirementWrongEpochPOOL
                (Mismatch curEpochNo curEpochNo)
                (Mismatch curEpochNo (addEpochInterval curEpochNo maxRetireInterval))
          ]
      expectRetiring False kh

    it "re-register a retiring pool with an already registered vrf" $ do
      pv <- getsPParams ppProtocolVersionL
      (kh1, _) <- registerNewPool
      (_, vrf2) <- registerNewPool
      retirePoolTx kh1 (EpochInterval 10) >>= submitTx_
      registerPoolTx <$> poolParams kh1 vrf2 >>= \tx ->
        if pvMajor pv < natVersion @11
          then do
            submitTx_ tx
            expectRetiring False kh1
            expectFuturePool kh1 (Just vrf2)
            passEpoch
            expectPool kh1 (Just vrf2)
          else do
            submitFailingTx tx [injectFailure $ VRFKeyHashAlreadyRegistered kh1 vrf2]
            expectRetiring True kh1
            expectFuturePool kh1 Nothing

    it "re-register retiring pool with its own VRF" $ do
      (kh, vrf) <- registerNewPool
      retirePoolTx kh (EpochInterval 10) >>= submitTx_
      expectRetiring True kh
      registerPoolTx <$> poolParams kh vrf >>= submitTx_
      expectPool kh (Just vrf)
      expectRetiring False kh

    it "re-register a retiring pool with a fresh VRF" $ do
      (kh, vrf) <- registerNewPool
      retirePoolTx kh (EpochInterval 10) >>= submitTx_
      vrfNew <- freshKeyHashVRF
      registerPoolTx <$> poolParams kh vrfNew >>= submitTx_
      expectRetiring False kh
      expectFuturePool kh (Just vrfNew)
      passEpoch
      expectPool kh (Just vrfNew)
      expectVRFs [vrfNew]
      -- now the original VRF can be reused
      khNew <- freshKeyHash
      registerPoolTx <$> poolParams khNew vrf >>= submitTx_

    it "register a pool with the VRF of a retiring pool" $ do
      pv <- getsPParams ppProtocolVersionL
      (kh, vrf) <- registerNewPool
      let retirement = 1
      retirePoolTx kh (EpochInterval retirement) >>= submitTx_
      khNew <- freshKeyHash
      registerPoolTx <$> poolParams khNew vrf >>= \tx ->
        if pvMajor pv < natVersion @11
          then do
            submitTx_ tx
            expectPool khNew (Just vrf)
          else do
            submitFailingTx tx [injectFailure $ VRFKeyHashAlreadyRegistered khNew vrf]
            expectPool khNew Nothing
      expectRetiring True kh
      passNEpochs (fromIntegral retirement)
      expectRetiring False khNew
      expectPool kh Nothing

    it "retiring a pool clears its delegations" $ do
      (poolKh, _) <- registerNewPool
      let retirement = 1
      stakeCred1 <- do
        cred <- KeyHashObj <$> freshKeyHash
        _ <- registerStakeCredential cred
        delegateStake cred poolKh
        pure cred

      retirePoolTx poolKh (EpochInterval retirement) >>= submitTx_
      expectPoolDelegs poolKh (Just [stakeCred1])
      stakeCred2 <- do
        cred <- KeyHashObj <$> freshKeyHash
        _ <- registerStakeCredential cred
        delegateStake cred poolKh
        pure cred
      expectPoolDelegs poolKh (Just [stakeCred1, stakeCred2])

      passNEpochs (fromIntegral retirement)
      expectPoolDelegs poolKh Nothing

  describe "Retired pools" $ do
    it "re-register a pool with the same keyhash and VRF " $ do
      (kh, vrf) <- registerNewPool
      let retirement = 1
      retirePoolTx kh (EpochInterval retirement) >>= submitTx_
      passNEpochs (fromIntegral retirement)
      expectPool kh Nothing
      registerPoolTx <$> poolParams kh vrf >>= submitTx_
      expectPool kh (Just vrf)
      expectVRFs [vrf]

    it "register a pool with the VRF of a retired pool" $ do
      (kh, vrf) <- registerNewPool
      let retirement = 1
      retirePoolTx kh (EpochInterval retirement) >>= submitTx_
      expectRetiring True kh
      passNEpochs (fromIntegral retirement)
      expectRetiring False kh
      khNew <- freshKeyHash
      registerPoolTx <$> poolParams khNew vrf >>= submitTx_
      expectPool khNew (Just vrf)
      expectRetiring False khNew
      expectVRFs [vrf]
  -- \| Example demonstrating a particular delegation scenario involving two pools.
  -- Both pools select an account address which is *not* a pool owner, and which
  -- delegates to one of the pools.
  it "Two Pools" $ do
    let aliceInitCoin = Coin 10_000_000_000
        bobInitCoin = Coin 1_000_000_000
        carlInitCoin = Coin 5_000_000_000
    [acpk, bcpk] <- replicateM 2 freshKeyHash
    [aliceSHK, bobSHK, carlSHK] <- replicateM 3 (KeyHashObj <$> freshKeyHash)
    [alicePay, bobPay, carlPay] <- replicateM 3 (freshKeyHash @Payment)
    let aliceAddr = mkAddr alicePay aliceSHK
        bobAddr = mkAddr bobPay bobSHK
        carlAddr = mkAddr carlPay carlSHK
        carlAccAddr = AccountAddress Testnet (AccountId carlSHK)

    -- === Block 1, Epoch 0
    --
    -- In the first block, Alice, Bob, and Carl register stake credentials,
    -- Alice and Bob register stake pools (both pointing to Carl's account
    -- address), Alice and Carl delegate to Alice's pool, and Bob delegates
    -- to Bob's pool.  This is the only block that includes a transaction.
    withTxsInBlock_ $ do
      void $ registerStakeCredential aliceSHK
      void $ registerStakeCredential bobSHK
      void $ registerStakeCredential carlSHK
      registerPoolWithZeroPledge acpk carlAccAddr
      registerPoolWithZeroPledge bcpk carlAccAddr
      delegateStake aliceSHK acpk
      delegateStake bobSHK bcpk
      delegateStake carlSHK acpk
      sendCoinTo_ aliceAddr aliceInitCoin
      sendCoinTo_ bobAddr bobInitCoin
      sendCoinTo_ carlAddr carlInitCoin

    expectRegisteredAccountAddress carlAccAddr
    expectStakeCredRegistered aliceSHK
    expectStakeCredRegistered bobSHK
    expectStakeCredRegistered carlSHK
    expectDelegatedToPool aliceSHK acpk
    expectDelegatedToPool bobSHK bcpk
    expectDelegatedToPool carlSHK acpk

    -- === Epoch 1
    evs1 <- impEventsFrom passEpoch
    logDoc $ ansiExpr evs1

    -- === Block 2, Epoch 1
    --
    -- Block 2 is produced by Alice's pool — this creates the first
    -- non-empty pool distribution heading into epoch 2.
    withIssuerAndTxsInBlock_ (coerce acpk) $ pure ()

    -- === Epoch 2
    evs2 <- impEventsFrom passEpoch
    logDoc $ ansiExpr evs2

    -- Verify the pool distribution reflects all delegated stake.
    pd <- getsNES nesPdL
    unNonZero (pdTotalActiveStake pd) `shouldBe` (aliceInitCoin <> bobInitCoin <> carlInitCoin)

    -- === Blocks 3–4, Epoch 2
    --
    -- Alice's pool produces a second block; Bob's pool produces one block;
    -- The reward pulser will use these
    -- three blocks (2 Alice, 1 Bob) when computing rewards for epoch 3.
    withIssuerAndTxsInBlock_ (coerce acpk) $ pure ()
    withIssuerAndTxsInBlock_ (coerce bcpk) $ pure ()

    -- === Epoch 3
    --
    -- The reward pulser is built during epoch 3 using the block production
    -- record from epoch 2 (two blocks from Alice's pool, one from Bob's).
    evs3 <- impEventsFrom passEpoch
    logDoc $ ansiExpr evs3

    -- Pass epochs 3→4 and 4→5. The reward update is computed via the
    -- pulser during one of these epochs and applied at the boundary.
    evs4 <- impEventsFrom $ passNEpochs 2

    let extractRupdMap (SomeSTSEvent ev)
          | Just (TickRupdEvent (RupdEvent _ m)) <- cast ev :: Maybe (ShelleyTickEvent era) =
              m
        extractRupdMap _ = mempty

    let rewardMap =
          foldr (Map.unionWith Set.union . extractRupdMap) Map.empty evs4
    rewardMap `shouldSatisfy` (not . Map.null)

    -- Carl is the account address for both pools, so Carl receives a leader
    -- reward from each pool.  Carl also delegates to acpk and is not a pool
    -- owner, so carl additionally receives a member reward from acpk.
    carlRewards <- expectJust $ Map.lookup carlSHK rewardMap
    Set.size carlRewards `shouldBe` 3

    let leaderRews = Set.filter ((== LeaderReward) . rewardType) carlRewards
        memberRews = Set.filter ((== MemberReward) . rewardType) carlRewards

    -- Carl has exactly two leader rewards (one from each pool) and one member reward.
    Set.size leaderRews `shouldBe` 2
    Set.size memberRews `shouldBe` 1
    Set.map rewardPool leaderRews `shouldBe` Set.fromList [acpk, bcpk]
    rewardPool (Set.findMin memberRews) `shouldBe` acpk

    -- Aggregated rewards — legacy behavior (pv <= 2): only the minimum
    -- Reward (by Ord) is kept. Ord Reward: LeaderReward < MemberReward;
    -- among LeaderRewards, ordered by pool hash. So the aggregate is the
    -- amount of the LeaderReward with the smaller pool hash.
    let legacyAgg = aggregateRewards (ProtVer (natVersion @2) 0) rewardMap
    Map.lookup carlSHK legacyAgg `shouldBe` Just (rewardAmount (Set.findMin carlRewards))

    -- For pv >= 3 all rewards are summed, which is strictly more than
    -- the legacy aggregate; for pv <= 2 the behavior is identical.
    let eraAgg = aggregateRewards (ProtVer (eraProtVerHigh @era) 0) rewardMap
    if eraProtVerHigh @era >= natVersion @3
      then do
        Map.lookup carlSHK eraAgg `shouldBe` Just (foldMap rewardAmount carlRewards)
        (eraAgg Map.! carlSHK) `shouldSatisfy` (> legacyAgg Map.! carlSHK)
      else
        Map.lookup carlSHK eraAgg `shouldBe` Just (rewardAmount (Set.findMin carlRewards))
  where
    registerNewPool = do
      (kh, vrf) <- (,) <$> freshKeyHash <*> freshKeyHashVRF
      submitTx_ . registerPoolTx =<< poolParams kh vrf
      expectPool kh (Just vrf)
      pure (kh, vrf)
    registerPoolTx pps =
      mkBasicTx mkBasicTxBody
        & bodyTxL . certsTxBodyL .~ [RegPoolTxCert pps]
    retirePoolTx kh retirementInterval = do
      curEpochNo <- getsNES nesELL
      let retirement = addEpochInterval curEpochNo retirementInterval
      pure $
        mkBasicTx mkBasicTxBody
          & bodyTxL . certsTxBodyL .~ [RetirePoolTxCert kh retirement]
    expectPool poolKh mbVrf = do
      pps <- psStakePools <$> getPState
      spsVrf <$> Map.lookup poolKh pps `shouldBe` mbVrf
    expectFuturePool poolKh mbVrf = do
      fps <- psFutureStakePoolParams <$> getPState
      sppVrf <$> Map.lookup poolKh fps `shouldBe` mbVrf
    expectPoolDelegs poolKh delegs = do
      pps <- psStakePools <$> getPState
      spsDelegators <$> Map.lookup poolKh pps `shouldBe` delegs
    expectRetiring isRetiring poolKh = do
      retiring <- psRetiring <$> getPState
      assertBool
        ("Expected 'retiring' status of: " <> show poolKh <> " to be: " <> show isRetiring)
        $ Map.member poolKh retiring == isRetiring
    expectVRFs vrfs = do
      whenMajorVersionAtLeast @11 $
        Map.keysSet . psVRFKeyHashes <$> getPState `shouldReturn` vrfs
    poolParams ::
      KeyHash StakePool ->
      VRFVerKeyHash StakePoolVRF ->
      ImpTestM era (StakePoolParams era)
    poolParams kh vrf = do
      pps <- registerAccountAddress >>= freshPoolParams kh
      pure $ pps & sppVrfL .~ vrf
    -- Pledge 0 makes the (pledge <= ownerStake) check in mkPoolRewardInfo
    -- trivially true, guaranteeing rewards flow. A nonzero pledge exceeding
    -- the owners' delegated stake would zero out the pool's rewards.
    registerPoolWithZeroPledge pk accAddr = do
      pps <- freshPoolParams pk accAddr
      submitTx_ $
        mkBasicTx mkBasicTxBody
          & bodyTxL . certsTxBodyL .~ [RegPoolTxCert pps {sppPledge = Coin 0}]
    getPState = getsNES @era $ nesEsL . esLStateL . lsCertStateL . certPStateL
