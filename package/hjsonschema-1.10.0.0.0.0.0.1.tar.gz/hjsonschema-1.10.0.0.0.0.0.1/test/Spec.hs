{-# OPTIONS_GHC -fforce-recomp -F -pgmF hspec-discover #-}
