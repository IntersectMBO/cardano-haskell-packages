-- | JSON Schemas for the configuration components, derived directly from the
-- autodocodec codecs (so they cannot drift from the parsers).
--
-- Each schema records which keys are required, which are optional, and the
-- defaults applied at parse time (e.g. the @Backend@ or @EnableCSJ@ defaults).
-- Keys that are merely left unset for the node to default appear as optional
-- without a value.
--
-- The raw codec schemas are post-processed (see 'publish') to be as useful as
-- possible to validators, editors and documentation generators:
--
--   * autodocodec's @$comment@ annotations become @description@s;
--   * file-path strings (tagged via 'filePathFormatMarker') gain a
--     @"format": "path"@ annotation, so a path is distinguishable from an
--     arbitrary string;
--   * string-enumeration @oneOf@\/@anyOf@s (of bare @const@s) collapse to a
--     @{ "type": "string", "enum": [..] }@, so every such field declares a type;
--   * every schema and property gains a @title@, and every document an @$id@, so
--     tools that key off them (e.g. @jsonschema2md@) render names rather than
--     @Untitled@\/@undefined@.
--
-- Tracing is not a component of its own: it is surfaced only as the single
-- top-level @HermodTracing@ key, a path to a separate file that the node's
-- tracing system (hermod/@trace-dispatcher@) reads. Its contents are neither
-- parsed nor described here; the authoritative tracing schema lives in that
-- package.
module Cardano.Configuration.Schema
  ( -- * Whole configuration
    splitConfigSchema
  , legacyOneFileConfigSchema
  , recognisedKeys
  , componentPropertyNames

    -- * Default values
  , splitConfigSchemaWithDefaults
  , legacyOneFileConfigSchemaWithDefaults
  , configurationSchemasWithDefaults

    -- * Individual components
  , configurationSchemas
  , storageSchema
  , consensusSchema
  , protocolSchema
  , networkSchema
  , localConnectionsSchema
  , mempoolSchema
  , testingSchema

    -- * Versioning
  , currentFormatVersion
  , packageFormatVersion
  , schemaTag
  , schemaId
  ) where

import Autodocodec.Schema (jsonSchemaViaCodec)
import Cardano.Configuration.Common (filePathFormatMarker)
import Cardano.Configuration.File.Consensus (ConsensusConfiguration)
import Cardano.Configuration.File.Mempool (MempoolConfiguration)
import Cardano.Configuration.File.Network (LocalConnectionsConfig, NetworkConfiguration)
import Cardano.Configuration.File.Protocol (ProtocolConfiguration)
import Cardano.Configuration.File.Storage (StorageConfiguration)
import Cardano.Configuration.File.Testing (TestingConfiguration)
import Cardano.Configuration.File.Tracing (TracingConfiguration)
import Cardano.Ledger.BaseTypes (StrictMaybe)
import Data.Aeson (Value (..), object, toJSON, (.=))
import qualified Data.Aeson.Key as K
import qualified Data.Aeson.KeyMap as KM
import Data.Foldable (toList)
import Data.List (nub)
import qualified Data.Map.Strict as Map
import Data.Text (Text)
import qualified Data.Text as T
import Data.Version (versionBranch)
import Paths_cardano_config (version)

storageSchema :: Value
storageSchema = component "StorageConfig" rawStorageSchema

consensusSchema :: Value
consensusSchema = component "ConsensusConfig" rawConsensusSchema

protocolSchema :: Value
protocolSchema = component "ProtocolConfig" rawProtocolSchema

networkSchema :: Value
networkSchema = component "NetworkConfig" rawNetworkSchema

localConnectionsSchema :: Value
localConnectionsSchema = component "LocalConnectionsConfig" rawLocalConnectionsSchema

mempoolSchema :: Value
mempoolSchema = component "MempoolConfig" rawMempoolSchema

testingSchema :: Value
testingSchema = component "TestingConfig" rawTestingSchema

-- The raw schemas as emitted by autodocodec-schema (descriptions in @$comment@,
-- no @$schema@). Used internally for merging; 'publish' makes them public.
rawStorageSchema, rawConsensusSchema, rawProtocolSchema, rawNetworkSchema :: Value
rawLocalConnectionsSchema, rawMempoolSchema, rawTestingSchema, rawTracingSchema :: Value
rawStorageSchema = toJSON (jsonSchemaViaCodec @(StorageConfiguration StrictMaybe))
rawConsensusSchema = toJSON (jsonSchemaViaCodec @(ConsensusConfiguration StrictMaybe))
rawProtocolSchema = toJSON (jsonSchemaViaCodec @(ProtocolConfiguration StrictMaybe))
rawNetworkSchema = toJSON (jsonSchemaViaCodec @(NetworkConfiguration StrictMaybe))
rawLocalConnectionsSchema = toJSON (jsonSchemaViaCodec @(LocalConnectionsConfig StrictMaybe))
rawMempoolSchema = toJSON (jsonSchemaViaCodec @(MempoolConfiguration StrictMaybe))
rawTestingSchema = toJSON (jsonSchemaViaCodec @(TestingConfiguration StrictMaybe))
rawTracingSchema = toJSON (jsonSchemaViaCodec @TracingConfiguration)

-- The components that are sections of their own (given inline, as a sub-file, or
-- as a list). Tracing is deliberately absent: it is not a section, only the
-- single top-level @HermodTracing@ key (see 'hermodTracingProps').
rawComponentSchemas :: [(Text, Value)]
rawComponentSchemas =
  [ ("StorageConfig", rawStorageSchema)
  , ("ConsensusConfig", rawConsensusSchema)
  , ("ProtocolConfig", rawProtocolSchema)
  , ("NetworkConfig", rawNetworkSchema)
  , ("LocalConnectionsConfig", rawLocalConnectionsSchema)
  , ("MempoolConfig", rawMempoolSchema)
  , ("TestingConfig", rawTestingSchema)
  ]

-- | Tracing is not a component/section of its own; it contributes exactly one
-- top-level key, @HermodTracing@ — a path to a separate file that the node's
-- tracing system reads (and which @cardano-config@ neither parses nor describes
-- further). We take that key's schema straight from the TracingConfiguration
-- codec so it stays in step with the parser.
hermodTracingProps :: KM.KeyMap Value
hermodTracingProps = properties rawTracingSchema

-- | The JSON Schema of each configuration component, keyed by name. Each carries
-- a @$schema@ property so a split sub-file can declare which schema it follows.
configurationSchemas :: [(Text, Value)]
configurationSchemas = [(name, withSchemaProp name (component name s)) | (name, s) <- rawComponentSchemas]

-- | The JSON Schema of the whole configuration in the /split-file/ form — the
-- recommended form, and the one the @schema@ subcommand prints by default: each
-- component is given under its section key (e.g. @StorageConfig@) as a path to a
-- sub-file or an inline object.
--
-- The whole document may additionally be wrapped in a @{ Version, Configuration
-- }@ envelope. Tracing is not a section; it is just the top-level @HermodTracing@
-- key (a path to a file the node's tracing system reads), whose contents are
-- neither parsed nor described here.
--
-- Keeping this form free of the flat top-level keys (which live in
-- 'legacyOneFileConfigSchema') is what lets it drop the per-component
-- \"section key /xor/ top-level keys\" exclusivity rules entirely, so it is much
-- simpler than a schema covering both forms at once.
splitConfigSchema :: Value
splitConfigSchema = splitConfigSchemaFrom rawComponentSchemas

-- | 'splitConfigSchema', built from the given component schemas, so the
-- defaulted variant ('splitConfigSchemaWithDefaults') can feed in component
-- schemas already carrying their @default@s.
splitConfigSchemaFrom :: [(Text, Value)] -> Value
splitConfigSchemaFrom components =
  publish "Cardano node configuration" "config.schema.json" $
    object
      [ "$comment" .= splitDescription
      , "type" .= ("object" :: Text)
      , "properties" .= Object (sectionRefProps <> hermodTracingProps <> envelopeProps)
      ]
 where
  -- Each component reachable under its section key (inline, sub-file, or list).
  sectionRefProps =
    KM.fromList [(K.fromText name, sectionRef name raw) | (name, raw) <- components]
  envelopeProps =
    KM.fromList
      [ ("$schema", schemaRef)
      , ("Version", versionRef)
      , ("MinNodeVersion", minNodeVersionRef)
      , ("Configuration", configurationRef)
      ]

-- | The JSON Schema of the whole configuration in the /legacy single-file/ form:
-- every component reads its keys directly from the top-level object, so all keys
-- appear flat at the top level. New configurations should prefer the split-file
-- form ('splitConfigSchema'); this form is retained for compatibility and is
-- printed only under @schema --legacy-one-file@.
--
-- The lone top-level @HermodTracing@ key may appear here too. The legacy form
-- predates the @{ Version, Configuration }@ envelope, so it does not offer it;
-- use the split-file form for an enveloped configuration.
legacyOneFileConfigSchema :: Value
legacyOneFileConfigSchema =
  publish
    "Cardano node configuration (legacy single-file form)"
    "config.legacy-one-file.schema.json"
    $ object
      [ "$comment" .= legacyDescription
      , "type" .= ("object" :: Text)
      , "properties" .= Object singleFileProps
      ]
 where
  -- Every component's keys, flat at the top level, plus the lone top-level
  -- HermodTracing key and the optional top-level MinNodeVersion annotation.
  singleFileProps =
    KM.insert "MinNodeVersion" minNodeVersionRef $
      foldr (KM.union . properties) hermodTracingProps (map snd rawComponentSchemas)

splitDescription :: Text
splitDescription =
  T.unwords
    [ "The cardano-node configuration (split-file form, recommended)."
    , "Each component is given under its section key (e.g. StorageConfig) as a path to a"
    , "sub-file or an inline object."
    , "The whole document may also be wrapped in a { Version, Configuration } envelope."
    , "The mandatory genesis files are supplied through the ProtocolConfig section."
    , "For the older form with every key at the top level, see config.legacy-one-file.schema.json."
    ]

legacyDescription :: Text
legacyDescription =
  T.unwords
    [ "The cardano-node configuration (legacy single-file form)."
    , "Every component's keys are given directly at the top level."
    , "New configurations should prefer the split-file form (config.schema.json);"
    , "this form is retained for compatibility and predates the { Version, Configuration } envelope."
    , "Mandatory keys: ByronGenesisFile, ShelleyGenesisFile, AlonzoGenesisFile,"
    , "ConwayGenesisFile."
    ]

-- | A component's section key in the split-file form: an inline object (the
-- component schema) or a path to a sub-file.
sectionRef :: Text -> Value -> Value
sectionRef name raw =
  object
    [ "$comment"
        .= ( "The "
               <> name
               <> " section, given inline (an object) or as a path to a sub-file."
           )
    , "anyOf" .= [pathRef desc, withTitle name raw]
    ]
 where
  desc = "Path to a file holding the " <> name <> " section"

-- | A JSON string that is a filesystem path (tagged so 'publish' adds the
-- @path@ format).
pathRef :: Text -> Value
pathRef desc =
  object
    [ "type" .= ("string" :: Text)
    , "title" .= ("File path" :: Text)
    , "$comment" .= (desc <> "\n" <> filePathFormatMarker)
    ]

-- | Insert a @title@ into a schema object unless it already has one.
withTitle :: Text -> Value -> Value
withTitle t (Object o) = Object (KM.insertWith (\_new old -> old) "title" (String t) o)
withTitle _ v = v

versionRef :: Value
versionRef =
  object
    [ "type" .= ("integer" :: Text)
    , "minimum" .= (1 :: Int)
    , "$comment"
        .= ( "The configuration format version (currently "
               <> T.pack (show currentFormatVersion)
               <> "). It is the first component of the cardano-config version, which states how far"
               <> " the parser goes: cardano-config-"
               <> T.pack (show currentFormatVersion)
               <> ".y.z.v parses every version up to and including "
               <> T.pack (show currentFormatVersion)
               <> ", and writes "
               <> T.pack (show currentFormatVersion)
               <> "." ::
               Text
           )
    ]

minNodeVersionRef :: Value
minNodeVersionRef =
  object
    [ "type" .= ("string" :: Text)
    , "$comment"
        .= ( "The minimum cardano-node version expected to run this configuration."
               <> " A top-level annotation (a sibling of Version), recorded for a consumer to check." ::
               Text
           )
    ]

configurationRef :: Value
configurationRef =
  object
    [ "type" .= ("object" :: Text)
    , "$comment"
        .= ( "When using the { Version, Configuration } envelope, the configuration object goes here"
               <> " (the same shape as this schema)." ::
               Text
           )
    ]

-- | The @$schema@ annotation: the URL of the schema this configuration follows,
-- a sibling of @Version@. Lets editors and validators pick up the schema, and
-- lets a file declare which schema it conforms to. Defaults to this schema's own
-- published URL, pinned to the tag of the format version it describes (see
-- 'schemaTag').
schemaRef :: Value
schemaRef =
  object
    [ "type" .= ("string" :: Text)
    , "default" .= schemaId "config.schema.json"
    , "$comment"
        .= ( "URL of the JSON Schema this configuration follows (the standard $schema annotation),"
               <> " a sibling of Version, for editors and validators."
               <> " Pinned to the vN tag of the format version it describes, so it identifies one"
               <> " exact schema; point it at a later vN to validate against that version." ::
               Text
           )
    ]

-- | Every key the parsers recognise at the @Configuration@ level: the section
-- keys (used to reference each component, inline or as a split sub-file), the
-- tracing keys and the envelope keys. Used to detect unrecognised keys (typos, or
-- a component property placed flat here rather than under its section — such a key
-- is reported and ignored, not resolved). A component's own property names are
-- recognised only inside its section, so they are deliberately /not/ listed here.
recognisedKeys :: [Text]
recognisedKeys =
  nub $
    envelopeKeys <> sectionKeys <> tracingKeys
 where
  envelopeKeys = ["$schema", "Version", "MinNodeVersion", "Configuration"]
  sectionKeys = map fst componentPropertyNames
  tracingKeys = map K.toText (KM.keys hermodTracingProps)

-- | The property names of each component (the keys it reads at the top level in
-- the single-file form), keyed by the component's section name. Used to detect
-- top-level keys shadowed by a section supplied separately. Every property name
-- belongs to exactly one component.
componentPropertyNames :: [(Text, [Text])]
componentPropertyNames =
  [(name, map K.toText (KM.keys (properties s))) | (name, s) <- rawComponentSchemas]

--------------------------------------------------------------------------------
-- Post-processing

-- | The JSON Schema draft these schemas target. autodocodec-schema emits
-- draft-07-compatible schemas, and the keywords we add here (@enum@, @format@,
-- @title@, @$id@) are likewise draft-07 core, so validators such as ajv accept
-- them by default.
draftURI :: Text
draftURI = "http://json-schema.org/draft-07/schema#"

-- | The newest configuration format version: the @Version@ that
-- 'Cardano.Configuration.File.Migrate.migrate' stamps on a document, and the
-- version of the schemas under @schemas\/@.
--
-- It is the /first component/ of the package version, and that component states
-- how far the parser goes: @cardano-config-X.y.z.v@ parses every format version up
-- to and including @X@, and writes @X@. The other three components carry changes
-- to the Haskell code alone, so the schemas are not changed without bumping the
-- first. 'packageFormatVersion' and the test suite keep the two from drifting.
--
-- Note this is the /newest/ version, not the whole accepted set: versions @1@
-- through @X@ all stay parseable, and the parser's dispatch
-- (@parseConfigurationFiles@) enumerates them literally rather than deriving them
-- from here — which is also why bumping this constant is a deliberate act with a
-- new parse path attached, rather than a consequence of a version bump.
currentFormatVersion :: Int
currentFormatVersion = 1

-- | The newest format version implied by the package version: its first
-- component, with the pre-1.0 series (@0.x.x.x@) counting as heading for version
-- 1. Should equal 'currentFormatVersion'; the test suite asserts it, so bumping
-- the package's first component fails the build until the format version and its
-- parse path follow.
packageFormatVersion :: Int
packageFormatVersion = case versionBranch version of
  major : _ -> max 1 major
  [] -> 1

-- | The git tag the published schema URLs point at: @v\<n\>@ for format version
-- @n@, so version 1's schemas are served from the @v1@ tag.
--
-- These tags are their own family, one per format version, cut alongside the
-- major release that introduces the version (@v2@ with @cardano-config-2.0.0.0@).
-- Keying the URL on the format version rather than on a release version is what
-- gives a schema one canonical address: every @cardano-config-1.x.x.x@ release
-- serves the same version-1 document, so it should not have a different URL per
-- release. The tag makes it immutable, so a configuration's @$schema@ identifies
-- exactly one schema, for good.
--
-- The tag must exist for the URL to resolve, so while the package is still
-- @0.x.x.x@ this points at the not-yet-created @v1@ tag.
schemaTag :: Text
schemaTag = "v" <> T.pack (show currentFormatVersion)

-- | The @$id@ for a committed schema file: where it is published in the repo, at
-- the tag of the format version it describes (see 'schemaTag').
schemaId :: FilePath -> Text
schemaId file =
  "https://raw.githubusercontent.com/IntersectMBO/cardano-config/"
    <> schemaTag
    <> "/schemas/"
    <> T.pack file

-- | Post-process a component's raw schema into its published form.
component :: Text -> Value -> Value
component name = publish name (T.unpack name <> ".schema.json")

-- | Add a @$schema@ property to a (published) component schema, so a split
-- sub-file may declare which schema it follows, pointing at that component's own
-- schema. Mirrors the whole configuration's top-level @$schema@, and defaults to
-- the component's schema URL. Applied only to the standalone component schemas,
-- not to the inline section branches of the whole-configuration schema (an
-- inline component relies on the document's top-level @$schema@).
withSchemaProp :: Text -> Value -> Value
withSchemaProp name (Object o) =
  Object (KM.insert "properties" (Object (KM.insert "$schema" prop (properties (Object o)))) o)
 where
  prop =
    object
      [ "type" .= ("string" :: Text)
      , "title" .= ("$schema" :: Text)
      , "default" .= schemaId (T.unpack name <> ".schema.json")
      , "description"
          .= ( "URL of the JSON Schema this "
                 <> name
                 <> " file follows (the $schema annotation), for editors and validators."
                 <> " Pinned to the vN tag of the format version it describes." ::
                 Text
             )
      ]
withSchemaProp _ v = v

-- | Make a raw codec schema friendly to validators, editors and documentation
-- generators. See the module header for the full list of transformations.
publish :: Text -> FilePath -> Value -> Value
publish title idFile raw =
  case transform raw of
    Object o ->
      Object $
        KM.insert "$schema" (String draftURI) $
          KM.insert "$id" (String (schemaId idFile)) $
            KM.insertWith keepExisting "title" (String title) o
    other -> other
 where
  keepExisting _new old = old

-- | The recursive transformation applied throughout a schema tree.
transform :: Value -> Value
transform = \case
  Object o ->
    Object . titleBranches . collapseStringEnum . typeConst . extractPathFormat . titleProperties $
      KM.fromList [(rename k, transform v) | (k, v) <- KM.toList o]
  Array a -> Array (transform <$> a)
  other -> other
 where
  rename k = if k == "$comment" then "description" else k

-- | Give each member of a @properties@ map a @title@ equal to its key (unless it
-- already has one), so documentation tools name it rather than show "Untitled".
titleProperties :: KM.KeyMap Value -> KM.KeyMap Value
titleProperties o =
  case KM.lookup "properties" o of
    Just (Object props) -> KM.insert "properties" (Object (KM.mapWithKey addTitle props)) o
    _ -> o
 where
  addTitle k (Object c) | not (KM.member "title" c) = Object (KM.insert "title" (String (K.toText k)) c)
  addTitle _ v = v

-- | Lift the file-path sentinel ('filePathFormatMarker') carried in a
-- @description@ into a @"format": "path"@ annotation, stripping the sentinel.
extractPathFormat :: KM.KeyMap Value -> KM.KeyMap Value
extractPathFormat o =
  case KM.lookup "description" o of
    Just (String d)
      | let ls = T.splitOn "\n" d
      , filePathFormatMarker `elem` ls ->
          let kept = filter (/= filePathFormatMarker) ls
              withFormat = KM.insert "format" (String "path") o
           in if null kept
                then KM.delete "description" withFormat
                else KM.insert "description" (String (T.intercalate "\n" kept)) withFormat
    _ -> o

-- | Give each branch of a @oneOf@\/@anyOf@ union a @title@ (unless it already has
-- one) derived from its @const@ value or its @type@, so documentation tools name
-- the alternatives rather than show "Untitled".
titleBranches :: KM.KeyMap Value -> KM.KeyMap Value
titleBranches o = foldr titleUnion o ["anyOf", "oneOf"]
 where
  titleUnion key m = case KM.lookup key m of
    Just (Array bs) -> KM.insert key (Array (fmap addTitle bs)) m
    _ -> m
  addTitle (Object b)
    | not (KM.member "title" b)
    , Just t <- branchTitle b =
        Object (KM.insert "title" (String t) b)
  addTitle v = v
  -- Name a branch by its const value or its type; leave structural branches
  -- (e.g. a bare @{ required: [..] }@ constraint) untitled.
  branchTitle b = case KM.lookup "const" b of
    Just (String s) -> Just s
    _ -> case KM.lookup "type" b of
      Just (String t) -> Just (T.toTitle t)
      _ -> Nothing

-- | Give a bare @const@ schema the @type@ implied by its value, so even a single
-- enumerated alternative (e.g. the @"NoOverride"@ branch of a union) declares a
-- type rather than leaving it undefined.
typeConst :: KM.KeyMap Value -> KM.KeyMap Value
typeConst o =
  case KM.lookup "const" o of
    Just v | not (KM.member "type" o), Just t <- constType v -> KM.insert "type" (String t) o
    _ -> o
 where
  constType (String _) = Just "string"
  constType (Bool _) = Just "boolean"
  constType (Number _) = Just "number"
  constType _ = Nothing

-- | Collapse a @oneOf@\/@anyOf@ whose branches are all bare string @const@s into
-- @{ "type": "string", "enum": [..] }@, so the field declares a single type.
collapseStringEnum :: KM.KeyMap Value -> KM.KeyMap Value
collapseStringEnum o =
  case branches >>= traverse stringConst of
    Just consts@(_ : _) ->
      KM.insert "type" (String "string") $
        KM.insert "enum" (toJSON consts) $
          KM.delete "oneOf" (KM.delete "anyOf" o)
    _ -> o
 where
  branches = case (KM.lookup "oneOf" o, KM.lookup "anyOf" o) of
    (Just (Array a), _) -> Just (toList a)
    (_, Just (Array a)) -> Just (toList a)
    _ -> Nothing
  stringConst (Object b)
    | Just (String s) <- KM.lookup "const" b
    , all (\k -> k == "const" || k == "type") (KM.keys b) =
        Just s
  stringConst _ = Nothing

-- | The @properties@ map of a schema object, if any.
properties :: Value -> KM.KeyMap Value
properties (Object o) | Just (Object p) <- KM.lookup "properties" o = p
properties _ = KM.empty

--------------------------------------------------------------------------------
-- Default values
--
-- Defaults are not part of the codecs; they live entirely in the @defaults\/@
-- data files (the base layer the resolver merges). The schema therefore takes
-- them as input — the caller loads the per-component @defaults\/<Component>.json@
-- and passes them in — so the documented defaults are exactly the ones the
-- library applies, with a single source of truth.

-- | 'splitConfigSchema' with the @default@ of every key filled in from the
-- per-component defaults (keyed by component name). The defaults are applied to
-- each component's inline-object form, matching the per-component schemas.
splitConfigSchemaWithDefaults :: [(Text, Value)] -> Value
splitConfigSchemaWithDefaults defs =
  let defsMap = Map.fromList defs
   in splitConfigSchemaFrom
        [ (name, maybe raw (`withDefaults` raw) (Map.lookup name defsMap))
        | (name, raw) <- rawComponentSchemas
        ]

-- | 'legacyOneFileConfigSchema' with the @default@ of every key filled in from
-- the per-component defaults. Components share a flat top-level key space, so
-- their defaults are merged into one overlay.
legacyOneFileConfigSchemaWithDefaults :: [(Text, Value)] -> Value
legacyOneFileConfigSchemaWithDefaults defs =
  withDefaults (foldr (deepMerge . snd) (Object KM.empty) defs) legacyOneFileConfigSchema

-- | Each component schema with its @default@s filled in from its
-- @defaults\/<Component>.json@ (when one is supplied).
configurationSchemasWithDefaults :: [(Text, Value)] -> [(Text, Value)]
configurationSchemasWithDefaults defs =
  let defsMap = Map.fromList defs
   in [ (name, maybe s (`withDefaults` s) (Map.lookup name defsMap))
      | (name, s) <- configurationSchemas
      ]

-- | Fill in the @default@ keywords of a schema from a defaults object (a config
-- object keyed by the configuration keys). Each value is placed at
-- @properties.<key>.default@, recursing into nested objects so leaf defaults
-- land on leaf properties.
withDefaults :: Value -> Value -> Value
withDefaults defaultsObj schema = deepMerge schema (defaultsOverlay defaultsObj)

-- | Turn a defaults object into a schema overlay carrying only @default@s, to be
-- deep-merged into a schema.
defaultsOverlay :: Value -> Value
defaultsOverlay = \case
  Object o -> object ["properties" .= Object (KM.map leaf o)]
  v -> object ["default" .= v]
 where
  leaf v@(Object _) = defaultsOverlay v
  leaf v = object ["default" .= v]

-- | Deep, right-biased merge of two JSON values (objects merge key by key).
deepMerge :: Value -> Value -> Value
deepMerge (Object a) (Object b) = Object (KM.unionWith deepMerge a b)
deepMerge _ b = b
