{-# LANGUAGE DataKinds #-}
{-# LANGUAGE FlexibleContexts #-}
{-# LANGUAGE GADTs #-}
{-# LANGUAGE LambdaCase #-}
{-# LANGUAGE NumericUnderscores #-}
{-# LANGUAGE OverloadedStrings #-}
{-# LANGUAGE ScopedTypeVariables #-}
{-# LANGUAGE TypeApplications #-}
{-# OPTIONS_GHC -Wno-deprecations #-}

module Test.Cardano.Api.Transaction.Body.Plutus.Scripts
  ( tests
  )
where

import Cardano.Api (AlonzoEraOnwards (..), proxyToAsType)
import Cardano.Api qualified as Api
import Cardano.Api.Experimental
import Cardano.Api.Experimental.AnyScriptWitness
import Cardano.Api.Experimental.Plutus hiding (AnyPlutusScript (..))
import Cardano.Api.Experimental.Plutus qualified as Plutus
import Cardano.Api.Experimental.Tx qualified as Exp
import Cardano.Api.Ledger qualified as L
import Cardano.Api.Plutus qualified as Script
import Cardano.Api.Serialise.Cbor (SerialiseAsCBOR (..))

import Cardano.Ledger.Binary qualified as CBOR
import Cardano.Ledger.Conway qualified as L
import Cardano.Ledger.Conway.Scripts qualified as L
import Cardano.Ledger.Dijkstra.Scripts qualified as L
import Cardano.Ledger.Plutus.Language qualified as L

import Prelude

import Data.Bifunctor (second)
import Data.Function
import Data.List qualified as List
import Data.Map.Strict qualified as Map
import Data.Proxy (Proxy (..))
import Data.Text qualified as Text
import Data.Word (Word32)
import GHC.Exts (IsList (..))
import Lens.Micro ((^.))

import Test.Gen.Cardano.Api.Experimental qualified as Exp
import Test.Gen.Cardano.Api.Typed
  ( genAddressInEra
  , genIndexedPlutusScriptWitness
  , genMintWitnessable
  , genPlutusScript
  , genPlutusScriptInEra
  , genSimpleScriptMintWitness
  , genTxIn
  , genWitnessable
  )

import Test.Cardano.Api.Experimental (exampleProtocolParams)
import Test.Cardano.Api.Orphans ()

import Hedgehog
import Hedgehog.Extras qualified as H
import Hedgehog.Gen qualified as Gen
import Hedgehog.Range qualified as Range
import Test.Tasty (TestTree, testGroup)
import Test.Tasty.Hedgehog (testProperty)

prop_compare_plutus_script_hashes :: Property
prop_compare_plutus_script_hashes = property $ do
  scriptInEra <- forAll genPlutusScriptInEra

  let anyScript = AnyPlutusScript scriptInEra
      anyScriptHash = hashAnyScript anyScript

  let script = plutusScriptInEraToScript scriptInEra
  let hash = L.hashScript script

  hash === anyScriptHash

prop_roundtrip_plutus_script_in_era_cbor :: Property
prop_roundtrip_plutus_script_in_era_cbor = property $ do
  scriptInEra <- forAll genPlutusScriptInEra
  tripping
    scriptInEra
    serialiseToCBOR
    (deserialiseFromCBOR (proxyToAsType (Proxy @(PlutusScriptInEra L.PlutusV3 (LedgerEra ConwayEra)))))

prop_roundtrip_any_plutus_script_text_envelope :: Property
prop_roundtrip_any_plutus_script_text_envelope = property $ do
  scriptInEra <- forAll genPlutusScriptInEra
  let anyScript = Plutus.AnyPlutusScript scriptInEra
  tripping
    anyScript
    (serialiseAnyPlutusScriptToTextEnvelope Nothing)
    (deserialiseAnyPlutusScriptFromTextEnvelope @(LedgerEra ConwayEra))

-- | This property checks that the redeemer pointer map is constructed correctly.
-- Previously identical script purposes were being created and overwriting each other
-- in the redeemer pointer map.
prop_getAnyWitnessRedeemerPointerMap :: Property
prop_getAnyWitnessRedeemerPointerMap = property $ do
  l <- forAll $ Gen.int (Range.linear 2 5)
  witnessables <- forAll $ Gen.list (Range.singleton l) $ genWitnessable @L.ConwayEra
  wits <-
    forAll $
      Gen.list (Range.singleton l) $
        genIndexedPlutusScriptWitness @ConwayEra
  let anyWits =
        [ AnyPlutusScriptWitness swit
        | IndexedPlutusScriptWitness _ _ swit <- wits
        ]

      zipped = zip witnessables anyWits
      expectedRedeemerPointerMapLength = length zipped
      finalWits = take expectedRedeemerPointerMapLength wits

      L.Redeemers constructedRedeemerPointerMap = getAnyWitnessRedeemerPointerMap zipped

  annotate "Constructed redeemer pointer map"
  annotateShow constructedRedeemerPointerMap
  let redeemerPointerMapSize = Map.size constructedRedeemerPointerMap

  cover 30 "Redeemer pointer map size more than 1" $ redeemerPointerMapSize > 1

  -- Confirm we have the expected number of redeemers
  Map.size constructedRedeemerPointerMap === expectedRedeemerPointerMapLength

  let initialRedeemers =
        [ redeemer
        | IndexedPlutusScriptWitness _ _ swit <- finalWits
        , let redeemer = getAnyPlutusScriptWitnessRedeemer swit
        ]

      ledgerRedeemers :: [L.Data L.ConwayEra]
      ledgerRedeemers = map fst $ Map.elems constructedRedeemerPointerMap

      convertedRedeemers = map Api.fromAlonzoData ledgerRedeemers

  annotate "Initial Indexed Script Witnesses"
  annotateShow wits

  -- Confirm we have idential redeemers
  List.sort initialRedeemers === List.sort convertedRedeemers

-- | Previously toAnyWitness was not handling simple scripts correctly resulting
-- in their exclusion in the resultant transaction.
prop_toAnyWitness :: Property
prop_toAnyWitness =
  property $ do
    let eon = AlonzoEraOnwardsConway
    l <- forAll $ Gen.int (Range.linear 2 5)
    witnessables <-
      fmap List.nub $ forAll $ Gen.list (Range.singleton l) $ genMintWitnessable @L.ConwayEra

    simpleScripts <-
      fmap List.nub $
        forAll $
          Gen.list (Range.singleton l) $
            genSimpleScriptMintWitness Api.ShelleyBasedEraConway

    let excludeReferenceScripts = filter (not . isReferenceScript) simpleScripts
        finalLength = List.length zipped
        zipped = zip witnessables excludeReferenceScripts

    res <-
      evalEither $
        legacyWitnessConversion eon $
          zip witnessables (map Api.BuildTxWith excludeReferenceScripts)

    annotateShow (extractSimpleScripts res)

    cover 30 "More than one script generated" $ length res > 1

    finalLength === length (extractSimpleScripts res) + length (extractPlutusScripts res)

-- | Confirm `extractAllIndexedPlutusScriptWitnesses` extracts all expected script
-- witnesses from a given transaction.
prop_extractAllIndexedPlutusScriptWitnesses :: Property
prop_extractAllIndexedPlutusScriptWitnesses =
  property $ do
    let era :: Era ConwayEra = ConwayEra
    -- Generate plutus script witnesses for each possible plutus purpose
    plutusScriptwitnessedTxIns <-
      forAll $ Gen.list (Range.linear 0 3) $ Exp.genScriptWitnessedTxIn @(LedgerEra ConwayEra)
    plutusScriptWitnessedMint <- forAll $ Exp.genScriptWitnessedTxMintValue @(LedgerEra ConwayEra)
    plutusScriptWitnessedTxCerts <- forAll $ Exp.genScriptWitnessedTxCertificates @(LedgerEra ConwayEra)
    plutusScriptWitnessesTxWithdrawals <-
      forAll $ Exp.genScriptWitnessedTxWithdrawals @(LedgerEra ConwayEra)
    plutusScriptWitnesssedTxVotingProcedures <-
      forAll $ Exp.genScriptWitnesssedTxVotingProcedures @(LedgerEra ConwayEra)
    plutusScriptWitnessedTxProposalProcedures <-
      forAll $ Exp.genScriptWitnessedTxProposals @(LedgerEra ConwayEra)

    -- Populate the stripped `TxBodyContent` value with our generated plutus script
    -- witnesses
    let txBodyContentWithPlutusWitnesses =
          Exp.defaultTxBodyContent
            & Exp.setTxIns plutusScriptwitnessedTxIns
            & Exp.setTxMintValue plutusScriptWitnessedMint
            & Exp.setTxCertificates plutusScriptWitnessedTxCerts
            & Exp.setTxWithdrawals plutusScriptWitnessesTxWithdrawals
            & Exp.setTxVotingProcedures plutusScriptWitnesssedTxVotingProcedures
            & Exp.setTxProposalProcedures plutusScriptWitnessedTxProposalProcedures

    extractedPlutusScriptWitnesses <-
      evalEither $ Exp.extractAllIndexedPlutusScriptWitnesses era txBodyContentWithPlutusWitnesses

    let generatedTxInWits = plutusScriptwitnessedTxIns
        generatedTxMintWits = plutusScriptWitnessedMint
        generatedTxCertWits = plutusScriptWitnessedTxCerts
        generatedTxWithdrawals = plutusScriptWitnessesTxWithdrawals
        generatedTxVotingprocedures = plutusScriptWitnesssedTxVotingProcedures
        generatedTxProposalProcedures = plutusScriptWitnessedTxProposalProcedures

    let allGeneratedPlutusScriptWitnesses =
          mconcat
            [ createIndexedPlutusScriptWitnesses $ Exp.extractWitnessableTxIns generatedTxInWits
            , createIndexedPlutusScriptWitnesses $
                map (second anyScriptWitnessToAnyWitness) $
                  Exp.extractWitnessableMints generatedTxMintWits
            , createIndexedPlutusScriptWitnesses $ Exp.extractWitnessableCertificates generatedTxCertWits
            , createIndexedPlutusScriptWitnesses $ Exp.extractWitnessableWithdrawals generatedTxWithdrawals
            , createIndexedPlutusScriptWitnesses $ Exp.extractWitnessableVotes (Just generatedTxVotingprocedures)
            , createIndexedPlutusScriptWitnesses $
                Exp.extractWitnessableProposals (Just generatedTxProposalProcedures)
            ]

    H.note_ "All generated script witnesses"
    H.noteShow_ allGeneratedPlutusScriptWitnesses
    H.note_ "Extracted indexed plutus script witnesses"
    H.noteShow_ extractedPlutusScriptWitnesses

    length allGeneratedPlutusScriptWitnesses === length extractedPlutusScriptWitnesses

-- | V4 bytes must not decode in Conway when the language only arrives at runtime.
prop_deserialise_rejects_unsupported_plutus_language :: Property
prop_deserialise_rejects_unsupported_plutus_language = property $ do
  v3ScriptInEra <- forAll genPlutusScriptInEra
  let v4Bytes = serialiseToCBOR v3ScriptInEra
  case decodeAnyPlutusScript @L.ConwayEra v4Bytes (AnyPlutusScriptLanguage L.SPlutusV4) of
    Left (CBOR.DecoderErrorCustom "PlutusScriptInEra" msg)
      | "Conway" `Text.isInfixOf` msg -> success
    other -> annotateShow other >> failure

-- | A reference witness only records the language and redeemer in the body,
-- so 'Exp.makeUnsignedTx' must accept it even where the era forbids an inline witness of that language.
prop_makeUnsignedTx_accepts_reference_plutus_v4_witness :: Property
prop_makeUnsignedTx_accepts_reference_plutus_v4_witness = property $ do
  srcTxIn <- forAll genTxIn
  refTxIn <- forAll genTxIn
  let dummyRedeemer = Script.unsafeHashableScriptData $ Script.ScriptDataConstructor 0 []
      plutusWit =
        Exp.AnyPlutusScriptWitness $
          AnyPlutusSpendingScriptWitness $
            PlutusSpendingScriptWitnessV4 $
              PlutusScriptWitness
                L.SPlutusV4
                (PReferenceScript refTxIn)
                NoScriptDatum
                dummyRedeemer
                (Script.ExecutionUnits 0 0)
      txBodyContent =
        Exp.defaultTxBodyContent
          & Exp.setTxProtocolParams exampleProtocolParams
          & Exp.setTxIns [(srcTxIn, plutusWit)]
          & Exp.setTxFee 0
  _ <- H.leftFail $ Exp.makeUnsignedTx ConwayEra txBodyContent
  success

-- | A PlutusV4 reference script in a Conway output must make 'createTransactionBody'
-- fail instead of silently dropping the script from the ledger output.
prop_createTransactionBody_rejects_unsupported_reference_script_language :: Property
prop_createTransactionBody_rejects_unsupported_reference_script_language = property $ do
  srcTxIn <- forAll genTxIn
  destAddress <- forAll $ genAddressInEra Api.ShelleyBasedEraConway
  v4PlutusScript <- forAll $ genPlutusScript Script.PlutusScriptV4
  let v4Script = Script.PlutusScript Script.PlutusScriptV4 v4PlutusScript
      scriptInAnyLang =
        Script.ScriptInAnyLang (Script.PlutusScriptLanguage Script.PlutusScriptV4) v4Script
      refScript = Script.ReferenceScript Api.BabbageEraOnwardsConway scriptInAnyLang
      txBodyContent =
        Api.defaultTxBodyContent Api.ShelleyBasedEraConway
          & Api.setTxIns [(srcTxIn, Api.BuildTxWith (Api.KeyWitness Api.KeyWitnessForSpending))]
          & Api.setTxOuts
            [ Api.TxOut
                destAddress
                (Api.lovelaceToTxOutValue Api.ShelleyBasedEraConway 10_000_000)
                Api.TxOutDatumNone
                refScript
            ]
          & Api.setTxFee (Api.TxFeeExplicit Api.ShelleyBasedEraConway 2_000_000)

  Api.createTransactionBody Api.ShelleyBasedEraConway txBodyContent
    === Left
      ( Api.TxBodyOutputError $
          Api.TxOutputReferenceScriptLanguageNotSupportedInEra
            scriptInAnyLang
            (Api.AnyCardanoEra Api.ConwayEra)
      )

-- | The same PlutusV4 reference script in a Dijkstra output is accepted and
-- kept on the ledger output.
prop_createTransactionBody_accepts_supported_reference_script_language :: Property
prop_createTransactionBody_accepts_supported_reference_script_language = property $ do
  srcTxIn <- forAll genTxIn
  destAddress <- forAll $ genAddressInEra Api.ShelleyBasedEraDijkstra
  v4PlutusScript <- forAll $ genPlutusScript Script.PlutusScriptV4
  let v4Script = Script.PlutusScript Script.PlutusScriptV4 v4PlutusScript
      refScript =
        Script.ReferenceScript Api.BabbageEraOnwardsDijkstra $
          Script.ScriptInAnyLang (Script.PlutusScriptLanguage Script.PlutusScriptV4) v4Script
      txBodyContent =
        Api.defaultTxBodyContent Api.ShelleyBasedEraDijkstra
          & Api.setTxIns [(srcTxIn, Api.BuildTxWith (Api.KeyWitness Api.KeyWitnessForSpending))]
          & Api.setTxOuts
            [ Api.TxOut
                destAddress
                (Api.lovelaceToTxOutValue Api.ShelleyBasedEraDijkstra 10_000_000)
                Api.TxOutDatumNone
                refScript
            ]
          & Api.setTxFee (Api.TxFeeExplicit Api.ShelleyBasedEraDijkstra 2_000_000)

  Api.ShelleyTxBody _ ledgerBody _ _ _ _ <-
    H.leftFail $ Api.createTransactionBody Api.ShelleyBasedEraDijkstra txBodyContent

  case toList (ledgerBody ^. L.outputsTxBodyL) of
    [ledgerTxOut] ->
      H.assertWith (ledgerTxOut ^. L.referenceScriptTxOutL) $ \case
        L.SJust _ -> True
        L.SNothing -> False
    outs -> annotateShow outs >> failure

-- | 'toPlutusScriptPurposeIndex' classifies ledger redeemer pointers the same
-- way as the older 'Api.toScriptIndex', for every purpose category the two
-- share, at every era with plutus scripts. 'GuardingScript' (Dijkstra's new
-- purpose) has no old-API counterpart -- 'Api.toScriptIndex' errors on it --
-- so it is checked separately in 'prop_toPlutusScriptPurposeIndex_guarding'.
prop_toPlutusScriptPurposeIndex_matches_toScriptIndex :: Property
prop_toPlutusScriptPurposeIndex_matches_toScriptIndex = property $ do
  ix <- forAll $ Gen.word32 (Range.linear 0 1000)
  checkAlonzoFamily AlonzoEraOnwardsAlonzo ix
  checkAlonzoFamily AlonzoEraOnwardsBabbage ix
  checkConwayFamily AlonzoEraOnwardsConway ix
  checkConwayFamily AlonzoEraOnwardsDijkstra ix
 where
  verify
    :: AlonzoEraOnwards era
    -> L.PlutusPurpose L.AsIx (Api.ShelleyLedgerEra era)
    -> PropertyT IO ()
  verify eon purpose =
    Api.toScriptIndex eon purpose
      === toOldEquivalent (toPlutusScriptPurposeIndex (Api.convert eon) purpose)

  checkAlonzoFamily
    :: forall era
     . L.AlonzoEraScript (Api.ShelleyLedgerEra era)
    => AlonzoEraOnwards era -> Word32 -> PropertyT IO ()
  checkAlonzoFamily eon ix = do
    verify eon (L.mkSpendingPurpose @(Api.ShelleyLedgerEra era) (L.AsIx ix))
    verify eon (L.mkMintingPurpose @(Api.ShelleyLedgerEra era) (L.AsIx ix))
    verify eon (L.mkCertifyingPurpose @(Api.ShelleyLedgerEra era) (L.AsIx ix))
    verify eon (L.mkWithdrawingPurpose @(Api.ShelleyLedgerEra era) (L.AsIx ix))

  checkConwayFamily
    :: forall era
     . L.ConwayEraScript (Api.ShelleyLedgerEra era)
    => AlonzoEraOnwards era -> Word32 -> PropertyT IO ()
  checkConwayFamily eon ix = do
    checkAlonzoFamily eon ix
    verify eon (L.mkVotingPurpose @(Api.ShelleyLedgerEra era) (L.AsIx ix))
    verify eon (L.mkProposingPurpose @(Api.ShelleyLedgerEra era) (L.AsIx ix))

  toOldEquivalent :: (PlutusScriptPurpose, Word32) -> Api.ScriptWitnessIndex
  toOldEquivalent (SpendingScript, i) = Api.ScriptWitnessIndexTxIn i
  toOldEquivalent (MintingScript, i) = Api.ScriptWitnessIndexMint i
  toOldEquivalent (CertifyingScript, i) = Api.ScriptWitnessIndexCertificate i
  toOldEquivalent (WithdrawingScript, i) = Api.ScriptWitnessIndexWithdrawal i
  toOldEquivalent (VotingScript, i) = Api.ScriptWitnessIndexVoting i
  toOldEquivalent (ProposingScript, i) = Api.ScriptWitnessIndexProposing i
  toOldEquivalent (GuardingScript, i) =
    error $ "no old-API equivalent for GuardingScript " <> show i

-- | The Dijkstra-only 'GuardingScript' purpose has no 'Api.toScriptIndex'
-- counterpart ('Api.toScriptIndexDijkstra' errors on it), so it is checked
-- directly here instead of alongside the shared categories above.
prop_toPlutusScriptPurposeIndex_guarding :: Property
prop_toPlutusScriptPurposeIndex_guarding = property $ do
  ix <- forAll $ Gen.word32 (Range.linear 0 1000)
  let purpose = L.mkGuardingPurpose @(Api.ShelleyLedgerEra Api.DijkstraEra) (L.AsIx ix)
  toPlutusScriptPurposeIndex Api.ShelleyBasedEraDijkstra purpose === (GuardingScript, ix)

-- | We exclude reference scripts because they do not end up in the resulting transaction.
isReferenceScript :: Api.Witness witctx era -> Bool
isReferenceScript (Api.ScriptWitness _ (Api.SimpleScriptWitness _ (Api.SReferenceScript{}))) = True
isReferenceScript (Api.ScriptWitness _ (Api.PlutusScriptWitness _ _ (Api.PReferenceScript{}) _ _ _)) = False
isReferenceScript _ = False

extractSimpleScripts
  :: [(Witnessable 'MintItem era, AnyWitness era)]
  -> [SimpleScriptOrReferenceInput era]
extractSimpleScripts wits =
  [s | (_, AnySimpleScriptWitness s) <- wits]

extractPlutusScripts :: [(Witnessable witctz era, AnyWitness era)] -> [AnyWitness era]
extractPlutusScripts wits =
  [AnyPlutusScriptWitness s | (_, AnyPlutusScriptWitness s) <- wits]

tests :: TestTree
tests =
  testGroup
    "Test.Cardano.Api.Transaction.Body.Plutus.Scripts"
    [ testProperty "prop_compare_plutus_script_hashes" prop_compare_plutus_script_hashes
    , testProperty
        "prop_roundtrip_plutus_script_in_era_cbor"
        prop_roundtrip_plutus_script_in_era_cbor
    , testProperty
        "prop_roundtrip_any_plutus_script_text_envelope"
        prop_roundtrip_any_plutus_script_text_envelope
    , testProperty
        "prop_extractAllIndexedPlutusScriptWitnesses"
        prop_extractAllIndexedPlutusScriptWitnesses
    , testProperty
        "prop_deserialise_rejects_unsupported_plutus_language"
        prop_deserialise_rejects_unsupported_plutus_language
    , testProperty
        "prop_makeUnsignedTx_accepts_reference_plutus_v4_witness"
        prop_makeUnsignedTx_accepts_reference_plutus_v4_witness
    , testProperty
        "prop_createTransactionBody_rejects_unsupported_reference_script_language"
        prop_createTransactionBody_rejects_unsupported_reference_script_language
    , testProperty
        "prop_createTransactionBody_accepts_supported_reference_script_language"
        prop_createTransactionBody_accepts_supported_reference_script_language
    , testProperty "prop_getAnyWitnessRedeemerPointerMap" prop_getAnyWitnessRedeemerPointerMap
    , testProperty "prop_toAnyWitness" prop_toAnyWitness
    , testProperty
        "prop_toPlutusScriptPurposeIndex_matches_toScriptIndex"
        prop_toPlutusScriptPurposeIndex_matches_toScriptIndex
    , testProperty
        "prop_toPlutusScriptPurposeIndex_guarding"
        prop_toPlutusScriptPurposeIndex_guarding
    ]
