{-# OPTIONS_GHC -Wno-orphans #-}

module Cardano.CLI.Orphans () where

import           Cardano.Api ()

