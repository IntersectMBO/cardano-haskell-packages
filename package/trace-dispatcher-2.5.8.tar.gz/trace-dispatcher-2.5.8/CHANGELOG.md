# Revision history for trace-dispatcher

## 2.5.7

* With a prometheus metric with key label pairs. The value will always be "1"

## 2.5.2 -- Dec 2023

* ForHuman Color, Increased Consistency Checks, and Non-empty Inner Workspace Validation

## 2.5.1 -- Dec 2023

* Rewrite of examples as unit tests

## 2.4.1 -- Nov 2023

* Updated to `ouroboros-network-0.10`

## 2.1.0 -- Sep 2023

* Updated to `ouroboros-network-0.9.1.0`

## 2.0.0 -- May 2023

* First version that diverges from caradno-node versioning scheme

* GHC-9.2 support

* Many undocumented changes

## 1.35.4 -- November 2022

* Undocumented changes

## 1.29.0 -- September 2021

* Initial version.
