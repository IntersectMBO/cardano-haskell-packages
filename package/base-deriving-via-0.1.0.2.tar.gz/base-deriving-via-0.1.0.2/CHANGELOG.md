## 0.1.0.1

* Remove `development` flag: #372

## 0.1.0.1

* Initial release

