# Changelog for ledegr-state

## Unreleased changes
