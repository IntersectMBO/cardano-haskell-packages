# Version history for `cardano-ledger-allegra`

## 1.0.0.0

* First properly versioned release.
