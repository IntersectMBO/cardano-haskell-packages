module Main where

import Hydra.ChainObserver qualified
import Hydra.Prelude

main :: IO ()
main = Hydra.ChainObserver.main
