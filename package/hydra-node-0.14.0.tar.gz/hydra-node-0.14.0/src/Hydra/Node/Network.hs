{-# LANGUAGE DuplicateRecordFields #-}

-- | Concrete `Hydra.Network` stack dedicated to running a hydra-node.
--
-- This module provides a `withNetwork` function which is the composition of several layers in order to provide various capabilities:
--
--   * `withHeartbeat` maintains knowledge about peers' connectivity,
--   * `withReliability` deals with connections reliability, handling the case
--     of messages being dropped (but not node crash in general),
--   * `withAuthentication` handles messages' authentication and signature verification,
--   * `withOuroborosNetwork` deals with maintaining individual connections to peers and the nitty-gritty details of messages sending and retrieval.
--
-- The following diagram details the various types of messages each layer is
-- exchanging with its predecessors and successors.
--
-- @
--
--          ▲                                    │
--          │ Authenticate msg                   │ msg
--          │                                    │
-- ┌────────┴────────────────────────────────────▼──────┐
-- │                                                    │
-- │                   Heartbeat                        │
-- │        ▲                                           │
-- └────────┬────────────────────────────────────┼──────┘
--          │                                    │
--          │ Heartbeat (Authenticate msg)       │ Heartbeat msg
--          │                                    │
-- ┌────────┴───────────────┐                    │
-- │                        │                    │
-- │    FlipHeartbeats      │                    │
-- │                        │                    │
-- └────────▲───────────────┘                    │
--          │                                    │
--          │ Authenticate (Heartbeat msg)       │
--          │                                    │
-- ┌────────┴────────────────────────────────────▼──────┐
-- │                                                    │
-- │                   Reliability                      │
-- │                                                    │
-- └─────────▲───────────────────────────────────┼──────┘
--           │                                   │
--      Authenticated (ReliableMsg (Heartbeat msg))    ReliableMsg (Heartbeat msg)
--           │                                   │
-- ┌─────────┼───────────────────────────────────▼──────┐
-- │                                                    │
-- │                  Authenticate                      │
-- │                                                    │
-- └─────────▲───────────────────────────────────┼──────┘
--           │                                   │
--           │                                   │
--       Signed (ReliableMsg (Heartbeat msg))       Signed (ReliableMsg (Heartbeat msg))
--           │                                   │
-- ┌─────────┼───────────────────────────────────▼──────┐
-- │                                                    │
-- │                  Ouroboros                         │
-- │                                                    │
-- └─────────▲───────────────────────────────────┼──────┘
--           │                                   │
--           │           (bytes)                 │
--           │                                   ▼
--
-- @
module Hydra.Node.Network (
  NetworkConfiguration (..),
  withNetwork,
  withFlipHeartbeats,
  configureMessagePersistence,
  acksFile,
) where

import Hydra.Prelude hiding (fromList, replicate)

import Control.Tracer (Tracer)
import Hydra.Crypto (HydraKey, SigningKey)
import Hydra.Logging (traceWith)
import Hydra.Logging.Messages (HydraLog (..))
import Hydra.Network (Host (..), IP, NetworkComponent, NodeId, PortNumber)
import Hydra.Network.Authenticate (Authenticated (Authenticated), Signed, withAuthentication)
import Hydra.Network.Heartbeat (ConnectionMessages, Heartbeat (..), withHeartbeat)
import Hydra.Network.Ouroboros (TraceOuroborosNetwork, WithHost, withOuroborosNetwork)
import Hydra.Network.Reliability (MessagePersistence, ReliableMsg, mkMessagePersistence, withReliability)
import Hydra.Node (HydraNodeLog (..))
import Hydra.Node.ParameterMismatch (ParamMismatch (..), ParameterMismatch (..))
import Hydra.Party (Party, deriveParty)
import Hydra.Persistence (Persistence (..), createPersistence, createPersistenceIncremental)
import System.FilePath ((</>))

-- | An alias for logging messages output by network component.
-- The type is made complicated because the various subsystems use part of the tracer only.
type LogEntry tx msg = HydraLog tx (WithHost (TraceOuroborosNetwork (Signed (ReliableMsg (Heartbeat msg)))))

-- | Configuration for a `Node` network layer.
data NetworkConfiguration m = NetworkConfiguration
  { persistenceDir :: FilePath
  -- ^ Persistence directory
  , signingKey :: SigningKey HydraKey
  -- ^ This node's signing key. This is used to sign messages sent to peers.
  , otherParties :: [Party]
  -- ^ The list of peers `Party` known to this node.
  , host :: IP
  -- ^ IP address to listen on for incoming connections.
  , port :: PortNumber
  -- ^ Port to listen on.
  , peers :: [Host]
  -- ^ Addresses and ports of remote peers.
  , nodeId :: NodeId
  -- ^ This node's id.
  }

-- | Starts the network layer of a node, passing configured `Network` to its continuation.
withNetwork ::
  (ToCBOR msg, ToJSON msg, FromJSON msg, FromCBOR msg) =>
  -- | Tracer to use for logging messages.
  Tracer IO (LogEntry tx msg) ->
  -- | Callback/observer for connectivity changes in peers.
  ConnectionMessages IO ->
  -- | The network configuration
  NetworkConfiguration IO ->
  -- | Produces a `NetworkComponent` that can send `msg` and consumes `Authenticated` @msg@.
  NetworkComponent IO (Authenticated msg) msg ()
withNetwork tracer connectionMessages configuration callback action = do
  let localhost = Host{hostname = show host, port}
      me = deriveParty signingKey
      numberOfParties = length $ me : otherParties
  messagePersistence <- configureMessagePersistence (contramap Node tracer) persistenceDir numberOfParties

  let reliability =
        withFlipHeartbeats $
          withReliability (contramap Reliability tracer) messagePersistence me otherParties $
            withAuthentication (contramap Authentication tracer) signingKey otherParties $
              withOuroborosNetwork (contramap Network tracer) localhost peers

  withHeartbeat nodeId connectionMessages reliability callback $ \network ->
    action network
 where
  NetworkConfiguration{persistenceDir, signingKey, otherParties, host, port, peers, nodeId} = configuration

-- | Create `MessagePersistence` handle to be used by `Reliability` network layer.
--
-- This function will `throw` a `ParameterMismatch` exception if:
--
--   * Some state already exists and is loaded,
--   * The number of parties is not the same as the number of acknowledgments saved.
configureMessagePersistence ::
  (MonadIO m, MonadThrow m, FromJSON msg, ToJSON msg) =>
  Tracer m (HydraNodeLog tx) ->
  FilePath ->
  Int ->
  m (MessagePersistence m msg)
configureMessagePersistence tracer persistenceDir numberOfParties = do
  msgPersistence <- createPersistenceIncremental $ storedMessagesFile persistenceDir
  ackPersistence@Persistence{load} <- createPersistence $ acksFile persistenceDir
  mAcks <- load
  ackPersistence' <- case fmap (\acks -> length acks == numberOfParties) mAcks of
    Just False -> do
      let paramsMismatch = [SavedNetworkPartiesInconsistent{numberOfParties}]
      traceWith tracer (Misconfiguration paramsMismatch)
      throwIO $ ParameterMismatch paramsMismatch
    _ -> pure ackPersistence
  pure $ mkMessagePersistence numberOfParties msgPersistence ackPersistence'

withFlipHeartbeats ::
  NetworkComponent m (Authenticated (Heartbeat msg)) msg1 a ->
  NetworkComponent m (Heartbeat (Authenticated msg)) msg1 a
withFlipHeartbeats withBaseNetwork callback =
  withBaseNetwork unwrapHeartbeats
 where
  unwrapHeartbeats = \case
    Authenticated (Data nid msg) party -> callback $ Data nid (Authenticated msg party)
    Authenticated (Ping nid) _ -> callback $ Ping nid

-- | Where are the messages stored, relative to given directory.
storedMessagesFile :: FilePath -> FilePath
storedMessagesFile = (</> "network-messages")

-- | Where is the acknowledgments vector stored, relative to given directory.
acksFile :: FilePath -> FilePath
acksFile = (</> "acks")
