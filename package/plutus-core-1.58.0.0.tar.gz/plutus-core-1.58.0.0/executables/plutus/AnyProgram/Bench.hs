module AnyProgram.Bench
  ( runBench
  ) where

import Types

runBench :: SLang s -> FromLang s -> IO ()
runBench = error "Not implemented yet"
