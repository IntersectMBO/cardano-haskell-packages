# Revision history for ouroboros-network-protocols

## 0.4.0.0 -- 2023-04-19

- Release

## 0.3.0.0 -- 2023-02-24

### Breaking

* Modified type `chain-sync` `Client`: `points` method now returns `Either` (PR #4385)

### Non-Breaking

* Expanded documentation about CDDL (PR #4351)

## 0.1.0.0 -- 2022-11-17

* Initial release
