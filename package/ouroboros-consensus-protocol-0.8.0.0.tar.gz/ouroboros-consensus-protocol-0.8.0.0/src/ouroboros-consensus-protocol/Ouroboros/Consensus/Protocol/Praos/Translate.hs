{-# LANGUAGE GADTs                 #-}
{-# LANGUAGE MultiParamTypeClasses #-}
{-# LANGUAGE NamedFieldPuns        #-}
{-# LANGUAGE ScopedTypeVariables   #-}
{-# LANGUAGE TypeApplications      #-}
{-# LANGUAGE TypeOperators         #-}
{-# OPTIONS_GHC -Wno-orphans #-}

module Ouroboros.Consensus.Protocol.Praos.Translate () where

import           Cardano.Crypto.DSIGN (VerKeyDSIGN)
import           Cardano.Crypto.VRF (VerKeyVRF)
import qualified Cardano.Ledger.Chain as SL
import           Cardano.Ledger.Crypto (ADDRHASH, HASH)
import qualified Cardano.Ledger.PoolDistr as SL
import qualified Cardano.Protocol.TPraos.API as SL
import qualified Cardano.Protocol.TPraos.Rules.Prtcl as SL
import qualified Cardano.Protocol.TPraos.Rules.Tickn as SL
import           Data.Coerce (coerce)
import qualified Data.Map.Strict as Map
import           Ouroboros.Consensus.Protocol.Praos (Praos, PraosState (..))
import           Ouroboros.Consensus.Protocol.Praos.Views
                     (LedgerView (lvMaxBodySize, lvMaxHeaderSize, lvProtocolVersion))
import qualified Ouroboros.Consensus.Protocol.Praos.Views as Views
import           Ouroboros.Consensus.Protocol.TPraos (TPraos,
                     TPraosState (tpraosStateChainDepState, tpraosStateLastSlot))
import           Ouroboros.Consensus.Protocol.Translate (TranslateProto (..))

{-------------------------------------------------------------------------------
  Translation from transitional Praos
-------------------------------------------------------------------------------}

-- | We can translate between TPraos and Praos, provided:
--
-- - They share the same HASH algorithm
-- - They share the same ADDRHASH algorithm
-- - They share the same DSIGN verification keys
-- - They share the same VRF verification keys
instance
  ( HASH c1 ~ HASH c2,
    ADDRHASH c1 ~ ADDRHASH c2,
    VerKeyDSIGN c1 ~ VerKeyDSIGN c2,
    VerKeyVRF c1 ~ VerKeyVRF c2
  ) =>
  TranslateProto (TPraos c1) (Praos c2)
  where
  translateLedgerView SL.LedgerView {SL.lvPoolDistr, SL.lvChainChecks} =
      Views.LedgerView
        { Views.lvPoolDistr = coercePoolDistr lvPoolDistr,
          lvMaxHeaderSize = SL.ccMaxBHSize lvChainChecks,
          lvMaxBodySize = SL.ccMaxBBSize lvChainChecks,
          lvProtocolVersion = SL.ccProtocolVersion lvChainChecks
        }
      where
        coercePoolDistr :: SL.PoolDistr c1 -> SL.PoolDistr c2
        coercePoolDistr (SL.PoolDistr m) =
          SL.PoolDistr
            . Map.mapKeysMonotonic coerce
            . Map.map coerceIndividualPoolStake
            $ m
        coerceIndividualPoolStake :: SL.IndividualPoolStake c1 -> SL.IndividualPoolStake c2
        coerceIndividualPoolStake (SL.IndividualPoolStake stake vrf) =
          SL.IndividualPoolStake stake $ coerce vrf

  translateChainDepState tpState =
    PraosState
      { praosStateLastSlot = tpraosStateLastSlot tpState,
        praosStateOCertCounters = Map.mapKeysMonotonic coerce certCounters,
        praosStateEvolvingNonce = evolvingNonce,
        praosStateCandidateNonce = candidateNonce,
        praosStateEpochNonce = SL.ticknStateEpochNonce csTickn,
        praosStateLabNonce = csLabNonce,
        praosStateLastEpochBlockNonce = SL.ticknStatePrevHashNonce csTickn
      }
    where
      SL.ChainDepState {SL.csProtocol, SL.csTickn, SL.csLabNonce} =
        tpraosStateChainDepState tpState
      SL.PrtclState certCounters evolvingNonce candidateNonce =
        csProtocol
