module Cardano.Ledger.ShelleyMA.TxBody
  {-# DEPRECATED "Use `Cardano.Ledger.Allegra.TxBody` from 'cardano-ledger-allegra' or `Cardano.Ledger.Mary.TxBody` from 'cardano-ledger-mary' packages instead" #-}
  ()
where
