module Cardano.Ledger.ShelleyMA.TxWits
  {-# DEPRECATED "Should not have been exposed in the first place" #-} (
  )
where
