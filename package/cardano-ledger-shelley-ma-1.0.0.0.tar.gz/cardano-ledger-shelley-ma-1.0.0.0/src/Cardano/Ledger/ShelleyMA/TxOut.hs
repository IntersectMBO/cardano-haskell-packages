module Cardano.Ledger.ShelleyMA.TxOut
  {-# DEPRECATED "Use `Cardano.Ledger.Mary.TxOut` from 'cardano-ledger-mary' package instead" #-} (
  module Cardano.Ledger.Mary.TxOut,
)
where

import Cardano.Ledger.Mary.TxOut
