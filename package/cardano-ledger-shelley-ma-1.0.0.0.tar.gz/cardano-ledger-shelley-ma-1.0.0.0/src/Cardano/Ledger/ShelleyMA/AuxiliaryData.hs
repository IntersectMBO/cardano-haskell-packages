module Cardano.Ledger.ShelleyMA.AuxiliaryData
  {-# DEPRECATED "Use `Cardano.Ledger.Allegra.TxAuxData` from 'cardano-ledger-allegra' package instead" #-} (
  module Cardano.Ledger.Allegra.TxAuxData,
)
where

import Cardano.Ledger.Allegra.TxAuxData
