# Changelog

## 0.4.0

* Updated to `ouroboros-network-framework-0.8`.

## 0.1.0

* Initially created.
