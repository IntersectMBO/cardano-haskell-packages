{-# LANGUAGE DataKinds             #-}
{-# LANGUAGE EmptyDataDeriving     #-}
{-# LANGUAGE FlexibleInstances     #-}
{-# LANGUAGE GADTs                 #-}
{-# LANGUAGE MultiParamTypeClasses #-}
{-# LANGUAGE RankNTypes            #-}
{-# LANGUAGE StandaloneDeriving    #-}
{-# LANGUAGE TypeFamilies          #-}

module Ouroboros.Network.Diffusion.Types
  ( DiffusionTracer (..)
  , Failure (..)
  , Tracers (..)
  , nullTracers
  , Configuration (..)
  , Applications (..)
  , Arguments (..)
  , Interfaces (..)
    -- * Plain Ouroboros Network
    -- $plain-ouroboros-network
  , NoExtraFlags (..)
  , NoExtraState (..)
  , NoExtraDebugState (..)
  , NoExtraPeers (..)
  , NoExtraConfig (..)
  , NoExtraAPI (..)
  , NoExtraChurnArgs (..)
  , ViewExtraPeers (..)
  , OuroborosPeerSelectionCounters
  , OuroborosDebugPeerSelection
  , OuroborosTracePeerSelection
    -- * ForkPolicy
  , Mx.ForkPolicy
  , Mx.noBindForkPolicy
  , Mx.responderForkPolicy
    -- * NodeToClient type aliases
  , NodeToClientHandle
  , NodeToClientHandleError
  , NodeToClientHandlerError
  , MkNodeToClientConnectionHandler
    -- * NodeToNode type aliases
  , NodeToNodeHandle
  , NodeToNodeConnectionManager
  , NodeToNodePeerConnectionHandle
  , NodeToNodePeerSelectionActions
    -- * Re-exports
  , AbstractTransitionTrace
  , IG.RemoteTransitionTrace
  , SRVPrefix
  , DiffusionMode (..)
  ) where


import Control.Concurrent.Class.MonadSTM.Strict
import Control.Exception (Exception, SomeException)
import Control.Monad.Class.MonadTimer.SI
import Control.Tracer (Tracer, nullTracer)

import Codec.CBOR.Term qualified as CBOR
import Data.ByteString.Lazy (ByteString)
import Data.List.NonEmpty (NonEmpty)
import Data.Map (Map)
import Data.Maybe.Strict
import Data.Set (Set)
import Data.Typeable (Typeable)
import Data.Void (Void)
import Data.Word (Word32)
import System.Random (StdGen)

import Network.Mux qualified as Mx
import Network.Mux.Types (ReadBuffer)
import Network.Socket qualified as Socket

import Ouroboros.Network.Mux (OuroborosApplicationWithMinimalCtx,
           OuroborosBundleWithExpandedCtx)

import Ouroboros.Network.PeerSharing (PeerSharingRegistry (..))

import Ouroboros.Network.ConnectionHandler
import Ouroboros.Network.ConnectionManager.Core qualified as CM
import Ouroboros.Network.ConnectionManager.State qualified as CM
import Ouroboros.Network.ConnectionManager.Types
import Ouroboros.Network.Context
import Ouroboros.Network.DiffusionMode
import Ouroboros.Network.Driver.Simple (TraceSendRecv)
import Ouroboros.Network.ExitPolicy
import Ouroboros.Network.InboundGovernor qualified as IG
import Ouroboros.Network.Mux qualified as Mx
import Ouroboros.Network.PeerSelection.Governor.Types
import Ouroboros.Network.Protocol.Handshake (Handshake, HandshakeArguments,
           Versions)
import Ouroboros.Network.RethrowPolicy
import Ouroboros.Network.Server qualified as Server
import Ouroboros.Network.Snocket (FileDescriptor, Snocket)
import Ouroboros.Network.Socket (SystemdSocketTracer)

import Ouroboros.Network.PeerSelection as PeerSelection
import Ouroboros.Network.PeerSelection.Churn as PeerSelection
import Ouroboros.Network.PeerSelection.State.LocalRootPeers qualified as LocalRootPeers
import Ouroboros.Network.Server.RateLimiting (AcceptedConnectionsLimit)

-- | The 'DiffusionTracer' logs
--
-- * diffusion initialisation messages
-- * terminal errors thrown by diffusion
--
-- TODO: rename as `DiffusionTrace`
data DiffusionTracer ntnAddr ntcAddr
  = RunServer (NonEmpty ntnAddr)
  | RunLocalServer ntcAddr
  | UsingSystemdSocket ntcAddr
  -- Rename as 'CreateLocalSocket'
  | CreateSystemdSocketForSnocketPath ntcAddr
  | CreatedLocalSocket ntcAddr
  | ConfiguringLocalSocket ntcAddr FileDescriptor
  | ConfiguredLocalSocket ntcAddr FileDescriptor
  | ListeningLocalSocket ntcAddr FileDescriptor
  | LocalSocketUp  ntcAddr FileDescriptor
  -- | The parent directory of the local socket has @group@ or @other@ write
  -- bits set.  This is a warning, not a failure: the socket itself is
  -- mode @0600@, but the parent directory's permissions may still allow
  -- another local user to rename or unlink the socket file.  The 'Word32'
  -- is the parent directory's POSIX mode.
  | InsecureLocalSocketDirectory ntcAddr Word32
  | InsecureLocalSocketPermissions ntcAddr Word32
  -- Rename as 'CreateServerSocket'
  | CreatingServerSocket ntnAddr
  | ConfiguringServerSocket ntnAddr
  | ListeningServerSocket ntnAddr
  | ServerSocketUp ntnAddr
  -- Rename as 'UnsupportedLocalSocketType'
  | UnsupportedLocalSystemdSocket ntnAddr
  -- Remove (this is impossible case), there's no systemd on Windows
  | UnsupportedReadySocketCase
  | DiffusionErrored SomeException
  | SystemdSocketConfiguration SystemdSocketTracer
    deriving Show

-- TODO: add a tracer for these misconfiguration
data Failure where
  UnsupportedReadySocket :: Failure
  UnexpectedIPv4Address  :: forall ntnAddr. (Show ntnAddr, Typeable ntnAddr) => ntnAddr -> Failure
  UnexpectedIPv6Address  :: forall ntnAddr. (Show ntnAddr, Typeable ntnAddr) => ntnAddr -> Failure
  NoSocket               :: Failure
  DiffusionError         :: SomeException -> Failure

deriving instance Show Failure
instance Exception Failure


-- $plain-ouroboros-network
--
-- Convenience types for plain Ouroboros Network instantiation without any
-- extra peers configured. This is supported by the bundled trace-dispatcher
-- instances in the tracing libraries.

data NoExtraFlags = NoExtraFlags
  deriving (Eq, Show)
data NoExtraState = NoExtraState
  deriving (Eq, Show)
data NoExtraDebugState = NoExtraDebugState
  deriving (Eq, Show)
data NoExtraPeers peeraddr = NoExtraPeers
  deriving (Eq, Show)
data NoExtraConfig = NoExtraConfig
  deriving (Eq, Show)
data NoExtraAPI = NoExtraAPI
  deriving (Eq, Show)
data NoExtraChurnArgs = NoExtraChurnArgs
  deriving (Eq, Show)

instance Monoid (NoExtraPeers peeraddr) where
  mempty = NoExtraPeers

instance Semigroup (NoExtraPeers peeraddr) where
  _ <> _ = NoExtraPeers

instance ( Ord peeraddr
         , Show peeraddr
         ) => SupportsPeerSelectionState (NoExtraPeers peeraddr) peeraddr where
  data ToExtraTrace (NoExtraPeers peeraddr)
    deriving Show
  data ViewExtraPeers (NoExtraPeers peeraddr) = NoExtraView
    deriving Eq

  publicExtraPeersAPI = nullPublicExtraPeersAPI

  mkViewExtraPeers _ = NoExtraView

type OuroborosPeerSelectionCounters peeraddr =
  PeerSelectionCounters (ViewExtraPeers (NoExtraPeers peeraddr))

type OuroborosDebugPeerSelection extraState extraFlags peeraddr =
  DebugPeerSelection extraState extraFlags (NoExtraPeers peeraddr) peeraddr

type OuroborosTracePeerSelection extraDebugState extraFlags peeraddr =
  TracePeerSelection extraDebugState extraFlags (NoExtraPeers peeraddr) peeraddr


-- | Diffusion Tracers
--
data Tracers ntnAddr ntnVersion ntnVersionData
             ntcAddr ntcVersion ntcVersionData
             extraState extraDebugState
             extraFlags extraPeers m = Tracers {
      -- | Mux tracer
      dtMuxTracer
        :: Tracer m (Mx.WithBearer (ConnectionId ntnAddr) Mx.Trace)

      -- | Mux's channel tracer
      --
    , dtChannelTracer
        :: Tracer m (Mx.WithBearer (ConnectionId ntnAddr) Mx.ChannelTrace)

      -- | Bearer tracer
      --
    , dtBearerTracer
        :: Tracer m (Mx.WithBearer (ConnectionId ntnAddr) Mx.BearerTrace)


      -- | Handshake protocol tracer
    , dtHandshakeTracer
        :: Tracer m (Mx.WithBearer (ConnectionId ntnAddr) (TraceSendRecv (Handshake ntnVersion CBOR.Term)))

      --
      -- NodeToClient tracers
      --

      -- | Mux tracer for local clients
      --
    , dtLocalMuxTracer
        :: Tracer m (Mx.WithBearer (ConnectionId ntcAddr) Mx.Trace)

      -- | Mux's channel tracer for local clients
      --
    , dtLocalChannelTracer
        :: Tracer m (Mx.WithBearer (ConnectionId ntcAddr) Mx.ChannelTrace)

      -- | Bearer tracer for local clients
      --
    , dtLocalBearerTracer
        :: Tracer m (Mx.WithBearer (ConnectionId ntcAddr) Mx.BearerTrace)

      -- | Handshake protocol tracer for local clients
    , dtLocalHandshakeTracer
        :: Tracer m (Mx.WithBearer (ConnectionId ntcAddr) (TraceSendRecv (Handshake ntcVersion CBOR.Term)))

      -- | Diffusion initialisation tracer
    , dtDiffusionTracer
        :: Tracer m (DiffusionTracer ntnAddr ntcAddr)

    , dtTraceLocalRootPeersTracer
        :: Tracer m (TraceLocalRootPeers extraFlags ntnAddr)

    , dtTracePublicRootPeersTracer
        :: Tracer m TracePublicRootPeers

      -- | Ledger Peers tracer
    , dtTraceLedgerPeersTracer
        :: Tracer m TraceLedgerPeers

    , dtTracePeerSelectionTracer
        :: Tracer m (TracePeerSelection extraDebugState extraFlags extraPeers ntnAddr)

    , dtDebugPeerSelectionTracer
        :: Tracer m (DebugPeerSelection extraState extraFlags extraPeers ntnAddr)

    , dtTracePeerSelectionCounters
        :: Tracer m (PeerSelectionCounters (ViewExtraPeers extraPeers))

    , dtPeerSelectionActionsTracer
        :: Tracer m (PeerSelectionActionsTrace ntnAddr ntnVersion)

    , dtConnectionManagerTracer
        :: Tracer m (CM.Trace
                      ntnAddr
                      (ConnectionHandlerTrace
                         ntnVersion
                         ntnVersionData))

    , dtConnectionManagerTransitionTracer
        :: Tracer m (AbstractTransitionTrace CM.ConnStateId)

    , dtServerTracer
        :: Tracer m (Server.Trace ntnAddr)

    , dtInboundGovernorTracer
        :: Tracer m (IG.Trace ntnAddr)

    , dtInboundGovernorTransitionTracer
        :: Tracer m (IG.RemoteTransitionTrace ntnAddr)

    , dtDnsTracer :: Tracer m DNSTrace

      --
      -- NodeToClient tracers
      --

      -- | Connection manager tracer for local clients
    , dtLocalConnectionManagerTracer
        :: Tracer m (CM.Trace
                       ntcAddr
                       (ConnectionHandlerTrace
                          ntcVersion
                          ntcVersionData))

      -- | Server tracer for local clients
    , dtLocalServerTracer
        :: Tracer m (Server.Trace ntcAddr)

      -- | Inbound protocol governor tracer for local clients
    , dtLocalInboundGovernorTracer
        :: Tracer m (IG.Trace ntcAddr)
    }


nullTracers :: Monad m
            => Tracers ntnAddr ntnVersion ntnVersionData
                       ntcAddr ntcVersion ntcVersionData
                       extraState extraDebugState
                       extraFlags extraPeers
                       m
nullTracers = Tracers {
    dtMuxTracer                                  = nullTracer
  , dtChannelTracer                              = nullTracer
  , dtBearerTracer                               = nullTracer
  , dtHandshakeTracer                            = nullTracer
  , dtLocalMuxTracer                             = nullTracer
  , dtLocalChannelTracer                         = nullTracer
  , dtLocalBearerTracer                          = nullTracer
  , dtLocalHandshakeTracer                       = nullTracer
  , dtDiffusionTracer                            = nullTracer
  , dtTraceLocalRootPeersTracer                  = nullTracer
  , dtTracePublicRootPeersTracer                 = nullTracer
  , dtTraceLedgerPeersTracer                     = nullTracer
  , dtTracePeerSelectionTracer                   = nullTracer
  , dtDebugPeerSelectionTracer                   = nullTracer
  , dtTracePeerSelectionCounters                 = nullTracer
  , dtPeerSelectionActionsTracer                 = nullTracer
  , dtConnectionManagerTracer                    = nullTracer
  , dtConnectionManagerTransitionTracer          = nullTracer
  , dtServerTracer                               = nullTracer
  , dtInboundGovernorTracer                      = nullTracer
  , dtInboundGovernorTransitionTracer            = nullTracer
  , dtLocalConnectionManagerTracer               = nullTracer
  , dtLocalServerTracer                          = nullTracer
  , dtLocalInboundGovernorTracer                 = nullTracer
  , dtDnsTracer                                  = nullTracer
  }

-- | Diffusion arguments which allow to instantiate a completely different
-- diffusion layer. These differ from
--
data Arguments extraState extraDebugState extraFlags extraPeers
               extraAPI extraChurnArgs
               exception resolver m
               ntnFd ntnAddr ntnVersion ntnVersionData
               ntcAddr ntcVersion ntcVersionData =
  Arguments {

    -- | node-to-node data flow used by connection manager to classify
    -- negotiated connections
    --
    daNtnDataFlow
      :: ntnVersionData -> DataFlow

    -- | remote side peer sharing information used by peer selection governor
    -- to decide which peers are available for performing peer sharing
  , daNtnPeerSharing
      :: ntnVersionData -> PeerSharing

    -- | Update `ntnVersionData` for initiator-only local roots.
  , daUpdateVersionData
      :: ntnVersionData -> DiffusionMode -> ntnVersionData

    -- | node-to-node handshake configuration
    --
  , daNtnHandshakeArguments
      :: HandshakeArguments (ConnectionId ntnAddr) ntnVersion ntnVersionData m

    -- | node-to-client handshake configuration
    --
  , daNtcHandshakeArguments
      :: HandshakeArguments (ConnectionId ntcAddr) ntcVersion ntcVersionData m

    -- | Interface used to get peers from the current ledger.
    --
  , daLedgerPeersCtx :: LedgerPeersConsensusInterface extraAPI m

    -- | Extra State empty value
    --
  , daEmptyExtraState        :: extraState

    -- | Extra Counters empty value
    --
  , daEmptyExtraCounters     :: ViewExtraPeers extraPeers

    -- | Provide Public Extra Actions for extraPeers to be
    --
  , daExtraPeersAPI          :: PublicExtraPeersAPI extraPeers ntnAddr

    -- | callback which is used to register @SIGUSR1@ signal handler.
  , daInstallSigUSR1Handler
      :: forall mode x y.
         NodeToNodeConnectionManager mode ntnFd ntnAddr
                                     extraFlags ntnVersionData
                                     ntnVersion m x y
      -> StrictTVar m
           (PeerSelectionState extraState extraFlags extraPeers
                               ntnAddr
                               (NodeToNodePeerConnectionHandle
                                   mode ntnAddr extraFlags
                                   ntnVersionData m x y))
      -> m ()

  , daPeerSelectionGovernorArgs
      :: forall muxMode responderCtx bytes a b .
         PeerSelectionGovernorArgs
           extraState extraDebugState extraFlags extraPeers
           extraAPI ntnAddr
           (PeerConnectionHandle muxMode responderCtx ntnAddr
                                 extraFlags ntnVersionData bytes m a b)
           exception m

    -- | Function that constructs a 'extraPeers' set from a map of dns
    -- lookup results.
    --
  , daToExtraPeers :: Map ntnAddr PeerAdvertise -> extraPeers

    -- | Request Public Root Peers.
    --
    -- If no custom public root peers is provided (i.e. Nothing) just the
    -- default one from
    -- 'Ouroboros.Network.PeerSelection.PeerSelectionActions.getPublicRootPeers'
    --
  , daRequestPublicRootPeers
      :: Maybe (    PeerActionsDNS ntnAddr resolver m
                 -> DNSSemaphore m
                 -> (Map ntnAddr PeerAdvertise -> extraPeers)
                 -> (NumberOfPeers -> SomeLedgerPeersKind -> m (Maybe (Set ntnAddr, DiffTime)))
                 -> SomeLedgerPeersKind
                 -> StdGen
                 -> Int
                 -> m (PublicRootPeers extraPeers ntnAddr, DiffTime))

    -- | Peer Churn Governor if no custom churn governor is required just
    -- use the default one from
    -- 'Ouroboros.Network.PeerSelection.Churn.peerChurnGovernor'
    --
  , daPeerChurnGovernor
      :: PeerSelection.PeerChurnArgs
           m
           extraChurnArgs
           extraDebugState
           extraFlags
           extraPeers
           extraAPI
           ntnAddr
      -> m Void

    -- | Provide extraChurnArgs to be passed to churn governor
    --
  , daExtraChurnArgs :: extraChurnArgs

    -- | SRV Prefix, as defined in CIP#0155
    --
  , daSRVPrefix :: SRVPrefix
  }

-- | Required Diffusion Arguments to run network layer
--
data Configuration extraFlags m ntnFd ntnAddr ntcFd ntcAddr = Configuration {
      -- | an @IPv4@ socket ready to accept connections or an @IPv4@ addresses
      --
      dcIPv4Address              :: Maybe (Either ntnFd ntnAddr)

      -- | an @IPv6@ socket ready to accept connections or an @IPv6@ addresses
      --
    , dcIPv6Address              :: Maybe (Either ntnFd ntnAddr)

      -- | an @AF_UNIX@ socket ready to accept connections or an @AF_UNIX@
      -- socket path or name of `named-pipe` on `Windows`.
      --
      -- __Windows Named Pipes__
      -- Names of named-pipes must follow
      -- https://learn.microsoft.com/en-us/windows/win32/ipc/pipe-names, in
      -- particular:
      --
      -- * It must be well formed, e.g. @\\.\pipe\PipeName@
      -- * The pipe name string specified by @PipeName@ can include any character
      --   other than a backslash, including numbers and special characters.
      -- * The entire pipe name string can be up to 256 characters long. Pipe
      --   names are not case-sensitive.
      --  * @PipeName@ has to include an app name to avoid clashes with other
      --    applications, e.g. @cardano-node-mainnet@.
      --  * @PipeName@ should be different for different parallel-installable
      --    instances, e.g. mainnet vs testnet.
      --  * default file permissions should be right: it will be accessible to
      --    the same user.
      --
    , dcLocalAddress             :: Maybe (Either ntcFd ntcAddr)

      -- | parameters for limiting number of accepted connections
      --
    , dcAcceptedConnectionsLimit :: AcceptedConnectionsLimit

      -- | run in initiator only mode
      --
    , dcMode                     :: DiffusionMode

      -- | public peer selection state
      --
      -- It is created outside of diffusion, since it is needed to create some
      -- apps (e.g. peer sharing).
      --
    , dcPublicPeerSelectionVar   :: StrictTVar m (PublicPeerSelectionState ntnAddr)

      -- | selection targets for the peer governor
      --
    , dcPeerSelectionTargets   :: PeerSelectionTargets
    , dcReadLocalRootPeers     :: STM m (LocalRootPeers.Config extraFlags RelayAccessPoint)
    , dcReadPublicRootPeers    :: STM m (Map RelayAccessPoint PeerAdvertise)

    -- | Depending on configuration, node may provide us with
    -- a snapshot of big ledger peers taken at some slot on the chain.
    -- These peers may be selected by ledgerPeersThread when requested
    -- by the peer selection governor when the node is syncing up.
    -- This is especially useful for Genesis consensus mode.
    , dcReadLedgerPeerSnapshot :: STM m (Maybe (LedgerPeerSnapshot BigLedgerPeers))

    -- | `UseLedgerPeers` from topology file.
    --
    , dcReadUseLedgerPeers     :: STM m UseLedgerPeers

    -- | Peer's own PeerSharing value.
    --
    -- This value comes from the node's configuration file and is static.
    , dcPeerSharing            :: PeerSharing

      -- | Timeout which starts once all responder protocols are idle. If the
      -- responders stay idle for duration of the timeout, the connection will
      -- be demoted, if it wasn't used by the p2p-governor it will be closed.
      --
      -- Applies to 'Unidirectional' as well as 'Duplex' /node-to-node/
      -- connections.
      --
      -- See 'serverProtocolIdleTimeout'.
      --
    , dcProtocolIdleTimeout    :: DiffTime

      -- | Time for which /node-to-node/ connections are kept in
      -- 'TerminatingState', it should correspond to the OS configured @TCP@
      -- @TIME_WAIT@ timeout.
      --
      -- This timeout will apply to after a connection has been closed, its
      -- purpose is to be resilient for delayed packets in the same way @TCP@
      -- is using @TIME_WAIT@.
      --
    , dcTimeWaitTimeout        :: DiffTime

      -- | Churn interval between churn events in deadline mode.  A small fuzz
      -- is added (max 10 minutes) so that not all nodes churn at the same time.
      --
      -- By default it is set to 3300 seconds.
      --
    , dcDeadlineChurnInterval  :: DiffTime

      -- | Churn interval between churn events in bulk sync mode.  A small fuzz
      -- is added (max 1 minute) so that not all nodes churn at the same time.
      --
      -- By default it is set to 300 seconds.
      --
    , dcBulkChurnInterval      :: DiffTime

      -- | A fork policy for node-to-node mini-protocol threads spawn by mux.
      --
    , dcMuxForkPolicy :: Mx.ForkPolicy ntnAddr

    -- | A fork policy for node-to-client mini-protocols threads spawn by mux.
    --
    , dcLocalMuxForkPolicy :: Mx.ForkPolicy ntcAddr

    -- | Mux egress queue's poll interval
    , dcEgressPollInterval :: DiffTime

  }


-- | Versioned mini-protocol bundles run on a negotiated connection.
--
data Applications ntnAddr ntnVersion ntnVersionData
                  ntcAddr ntcVersion ntcVersionData
                  extraFlags m a =
  Applications {
      -- | NodeToNode initiator applications for initiator only mode.
      --
      -- TODO: we should accept one or the other, but not both:
      -- 'daApplicationInitiatorMode', 'daApplicationInitiatorResponderMode'.
      --
      daApplicationInitiatorMode
        :: Versions ntnVersion
                    ntnVersionData
                      (OuroborosBundleWithExpandedCtx
                      Mx.InitiatorMode ntnAddr extraFlags
                      ByteString m a Void)

      -- | NodeToNode initiator & responder applications for bidirectional mode.
      --
    , daApplicationInitiatorResponderMode
           -- Peer Sharing result computation callback
        :: Versions ntnVersion
                    ntnVersionData
                    (OuroborosBundleWithExpandedCtx
                      Mx.InitiatorResponderMode ntnAddr extraFlags
                      ByteString m a ())

      -- | NodeToClient responder application (server role)
      --
      -- Because p2p mode does not infect local connections we we use non-p2p
      -- apps.
    , daLocalResponderApplication
        :: Versions ntcVersion
                    ntcVersionData
                     (OuroborosApplicationWithMinimalCtx
                      Mx.ResponderMode ntcAddr
                      ByteString m Void ())

      -- | /node-to-node/ rethrow policy.
      --
      -- TODO: should it be part of `ExitPolicy`?
      --
    , daRethrowPolicy       :: RethrowPolicy

      -- | /node-to-node/ return policy
      --
      -- Internally packed into `ExitPolicy` record.
      --
    , daReturnPolicy        :: ReturnPolicy a

      -- | /node-to-node/ error delay.
      --
      -- Internally packed into `ExitPolicy` record.
    , daRepromoteErrorDelay :: RepromoteDelay

      -- | /node-to-client/ rethrow policy
      --
    , daLocalRethrowPolicy  :: RethrowPolicy

      -- | 'PeerSelectionPolicy' used by the outbound governor to pick peers to
      -- promote/demote ((see 'simplePeerSelectionPolicy').
      --
    , daPeerSelectionPolicy :: PeerSelectionPolicy ntnAddr m

      -- | Used for peer sharing protocol
      --
    , daPeerSharingRegistry :: PeerSharingRegistry ntnAddr m
  }


--
-- Node-To-Client type aliases
--
-- Node-To-Client diffusion is only used in 'ResponderMode'.
--

type NodeToClientHandle ntcAddr versionData m =
    HandleWithMinimalCtx Mx.ResponderMode ntcAddr versionData ByteString m Void ()

type NodeToClientHandleError ntcVersion =
    HandlerError ntcVersion
{-# DEPRECATED NodeToClientHandleError "Use NodeToClientHandlerError" #-}

type NodeToClientHandlerError ntcVersion =
    HandlerError ntcVersion

type MkNodeToClientConnectionHandler
      ntcFd ntcAddr ntcVersion ntcVersionData m =
       (   StrictTVar m (StrictMaybe IG.ResponderCounters)
        -> Tracer m (Mx.WithBearer (ConnectionId ntcAddr) Mx.Trace))
    -> ConnectionHandler
         Mx.ResponderMode
         (ConnectionHandlerTrace ntcVersion ntcVersionData)
         ntcFd
         ntcAddr
         (NodeToClientHandle ntcAddr ntcVersionData m)
         (NodeToClientHandlerError ntcVersion)
         ntcVersion
         ntcVersionData
         m

--
-- Node-To-Node type aliases
--
-- Node-To-Node diffusion runs in either 'InitiatorMode' or 'InitiatorResponderMode'.
--

type NodeToNodeHandle
       (mode :: Mx.Mode)
       ntnAddr extraFlags ntnVersionData m a b =
    HandleWithExpandedCtx mode ntnAddr extraFlags ntnVersionData ByteString m a b

type NodeToNodeConnectionManager
       (mode :: Mx.Mode)
       ntnFd ntnAddr extraFlags ntnVersionData ntnVersion m a b =
    ConnectionManager
      mode
      ntnFd
      ntnAddr
      (NodeToNodeHandle mode ntnAddr extraFlags ntnVersionData m a b)
      (HandlerError ntnVersion)
      m

--
-- Governor type aliases
--

type NodeToNodePeerConnectionHandle (mode :: Mx.Mode) ntnAddr extraFlags ntnVersionData m a b =
    PeerConnectionHandle
      mode
      (ResponderContext ntnAddr)
      ntnAddr
      extraFlags
      ntnVersionData
      ByteString
      m a b

type NodeToNodePeerSelectionActions extraState extraFlags extraPeers extraAPI
                                    (mode :: Mx.Mode) ntnAddr ntnVersionData m a b =
    PeerSelectionActions
      extraState extraFlags extraPeers extraAPI
      ntnAddr
      (NodeToNodePeerConnectionHandle mode ntnAddr extraFlags ntnVersionData m a b)
      m


data Interfaces ntnFd ntnAddr ntcFd ntcAddr
                resolver m =
    Interfaces {
        -- | node-to-node snocket
        --
        diNtnSnocket
          :: Snocket m ntnFd ntnAddr,

        -- | node-to-node 'Mx.MakeBearer' callback
        --
        diNtnBearer
          :: Mx.MakeBearer m ntnFd,

        -- | readbuffer
        diWithBuffer
          :: (Maybe (ReadBuffer m) -> m ()) -> m (),

        -- | node-to-node socket configuration
        --
        diNtnConfigureSocket
          :: ntnFd -> Maybe ntnAddr -> m (),

        -- | node-to-node systemd socket configuration
        --
        diNtnConfigureSystemdSocket
          :: ntnFd -> ntnAddr -> m (),

        -- | node-to-node address type
        --
        diNtnAddressType
          :: ntnAddr -> Maybe AddressType,

        -- | node-to-node peer address
        --
        diNtnToPeerAddr
          :: IP -> Socket.PortNumber -> ntnAddr,

        -- | node-to-client snocket
        --
        diNtcSnocket
          :: Snocket m ntcFd ntcAddr,

        -- | node-to-client 'Mx.MakeBearer' callback
        --
        diNtcBearer
          :: Mx.MakeBearer m ntcFd,

        -- | node-to-client file descriptor
        --
        diNtcGetFileDescriptor
          :: ntcFd -> m FileDescriptor,

        -- | configure node-to-client socket file (called between
        -- `bind` and `listen`).
        diNtcConfigureSocketFile
          :: ntcAddr -> m (),

        -- | diffusion pseudo random generator. It is split between various
        -- components that need randomness, e.g. inbound governor, peer
        -- selection, policies, etc.
        --
        diRng
          :: StdGen,

        -- | diffusion dns actions
        --
        diDnsActions
          :: Tracer m DNSTrace
          -> DNSLookupType
          -> (IP -> Socket.PortNumber -> ntnAddr)
          -> DNSActions ntnAddr resolver m,

        -- | `ConnStateIdSupply` used by the connection-manager for this node.
        --
        -- This is exposed for testing, where we use a global
        -- `ConnStateIdSupply`.
        --
        diConnStateIdSupply
          :: CM.ConnStateIdSupply m
      }
