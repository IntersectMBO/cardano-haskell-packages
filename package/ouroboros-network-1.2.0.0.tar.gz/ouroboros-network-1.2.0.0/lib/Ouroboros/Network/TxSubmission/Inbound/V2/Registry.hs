{-# LANGUAGE BangPatterns        #-}
{-# LANGUAGE NamedFieldPuns      #-}
{-# LANGUAGE ScopedTypeVariables #-}

module Ouroboros.Network.TxSubmission.Inbound.V2.Registry
  ( SharedTxStateVar
  , PeerTxRegistry
  , PeerTxAPI (..)
  , TxSubmissionCountersVar
  , newSharedTxStateVar
  , newPeerTxRegistry
  , newTxSubmissionCountersVar
  , txCountersThreadV2
  , withPeer
    -- re-exports
  , RegisteredDelay
  ) where

import Control.Concurrent.Class.MonadSTM.Strict
import Control.Monad (when)
import Control.Monad.Class.MonadThrow
import Control.Monad.Class.MonadTime.SI
import Control.Monad.Class.MonadTimer.SI
import Control.Tracer (Tracer, traceWith)
import Data.IntMap.Strict qualified as IntMap
import Data.IntSet (IntSet)
import Data.IntSet qualified as IntSet
import Data.Map.Strict (Map)
import Data.Map.Strict qualified as Map
import Data.Void (Void)
import Data.Word (Word64)
import GHC.Stack (HasCallStack)

import Ouroboros.Network.Protocol.TxSubmission2.Type
import Ouroboros.Network.RegisteredDelay (RegisteredDelay)
import Ouroboros.Network.RegisteredDelay qualified as RegisteredDelay
import Ouroboros.Network.Tx (HasRawTxId)
import Ouroboros.Network.TxSubmission.Inbound.V2.Policy (TxDecisionPolicy (..))
import Ouroboros.Network.TxSubmission.Inbound.V2.State qualified as State
import Ouroboros.Network.TxSubmission.Inbound.V2.Types
import Ouroboros.Network.TxSubmission.Mempool.Reader

-- | Shared STM handle for V2 coordination state.
type SharedTxStateVar m peeraddr txid = StrictTVar m (SharedTxState peeraddr txid)

-- | STM handle for V2 monotonic counters.  Used both for each peer's
-- private counters cell and for the shared retired-peers accumulator
-- (see 'withPeer' and 'txCountersThreadV2').
type TxSubmissionCountersVar m = StrictTVar m TxSubmissionCounters

-- | Per-peer in-flight TVar.
type PeerTxInFlightVar m = StrictTVar m PeerTxInFlight

-- | Registry of every live peer's coordination TVars: its in-flight
-- contributions and its private counters cell.
--
-- 'withPeer' adds the pair on bracket-enter and removes it on
-- bracket-exit (after scrubbing any contributions the peer still has
-- to shared state and flushing its counters into the retired
-- accumulator).  'snapshotLiveReferences' reads the in-flight vars to
-- compute the @liveAdvertised@ union; 'snapshotCounters' reads the
-- counter cells to aggregate for emission.
type PeerTxRegistry m peeraddr =
       StrictTVar m (Map peeraddr (PeerTxInFlightVar m, TxSubmissionCountersVar m))

newSharedTxStateVar
  :: MonadSTM m
  => SharedTxState peeraddr txid
  -> m (SharedTxStateVar m peeraddr txid)
newSharedTxStateVar = newTVarIO

newTxSubmissionCountersVar
  :: MonadSTM m
  => TxSubmissionCounters
  -> m (TxSubmissionCountersVar m)
newTxSubmissionCountersVar = newTVarIO

newPeerTxRegistry
  :: MonadSTM m
  => m (PeerTxRegistry m peeraddr)
newPeerTxRegistry = newTVarIO Map.empty

-- | Central bookkeeping thread for V2.
--
-- Wakes every @'bufferedTxsMinLifetime' policy \/ 4@ seconds (capped
-- between 100 ms and 1 s) to run 'State.sweepSharedState' on the
-- shared tx state.  The sweep needs the union of every live peer's
-- 'pifAdvertised' to decide which entries are still wanted; the
-- registry is read inside the same STM transaction as the sweep so
-- the snapshot is coherent.  On a slower cadence (every
-- 'countersInterval' seconds of elapsed time) it also emits the
-- aggregated counters -- the retired-peers accumulator plus every
-- live peer's cell -- when they differ from the last emission, and a
-- 'TraceSharedTxState' snapshot when @sharedRevision@ or
-- @sharedGeneration@ has moved since the last emission.
txCountersThreadV2
  :: forall m peeraddr txid tx.
     (MonadDelay m, MonadSTM m, HasRawTxId txid)
  => TxDecisionPolicy
  -> Tracer m TxSubmissionCounters
  -> Tracer m (TraceTxLogic peeraddr txid tx)
  -> TxSubmissionCountersVar m
  -> SharedTxStateVar m peeraddr txid
  -> PeerTxRegistry m peeraddr
  -> m Void
txCountersThreadV2 policy countersTracer sharedStateTracer retiredCountersVar
                   sharedStateVar registry = do
    now <- getMonotonicTime
    initialSt <- readTVarIO sharedStateVar
    go mempty
       (sharedRevision   initialSt)
       (sharedGeneration initialSt)
       (addTime countersInterval now)
  where
    sweepInterval :: DiffTime
    sweepInterval = max 0.1 (min 1 (bufferedTxsMinLifetime policy / 4))

    countersInterval :: DiffTime
    countersInterval = 7

    go !previous !lastRev !lastGen !nextEmitAt = do
      threadDelay sweepInterval
      now <- getMonotonicTime
      atomically $ do
        liveReferences <- snapshotLiveReferences registry
        st <- readTVar sharedStateVar
        let st' = State.sweepSharedState now liveReferences st
        when (sharedRevision st' /= sharedRevision st) $
          writeTVar sharedStateVar st'
      if now >= nextEmitAt
         then do
           current <- atomically (snapshotCounters retiredCountersVar registry)
           when (current /= previous) $ traceWith countersTracer current
           st <- readTVarIO sharedStateVar
           let curRev = sharedRevision   st
               curGen = sharedGeneration st
           (lastRev', lastGen') <-
             if curRev /= lastRev || curGen /= lastGen
                then do
                  traceWith sharedStateTracer (TraceSharedTxState st)
                  pure (curRev, curGen)
                else pure (lastRev, lastGen)
           go current lastRev' lastGen' (addTime countersInterval now)
         else go previous lastRev lastGen nextEmitAt

-- | Read every live peer's 'pifAcksPending' and union them.  This is the
-- set of keys still referenced by some peer (advertised for fetch, or
-- held in @peerUnacknowledgedTxIds@ awaiting ack) and is used by the
-- sweep to know which lookup table entries can be safely reclaimed.
--
-- 'pifAcksPending' is a superset of 'pifAdvertised', so the advertised
-- set need not be unioned in separately.
snapshotLiveReferences
  :: MonadSTM m
  => PeerTxRegistry m peeraddr
  -> STM m IntSet
snapshotLiveReferences registry = do
    peers <- readTVar registry
    pifs  <- traverse (readTVar . fst) (Map.elems peers)
    pure $! IntSet.unions (map pifAcksPending pifs)

-- | Aggregate the V2 counters for emission: the retired-peers
-- accumulator plus every live peer's private counters cell.
--
-- Read in a single STM transaction so the snapshot is coherent with
-- 'withPeer' disconnect flushes (which move a peer's counters into the
-- retired accumulator and drop it from the registry atomically),
-- keeping the emitted aggregate monotonic.  The transaction is
-- read-only, so the hot-path per-peer writers never block on it; only
-- this reader (at the 'countersInterval' cadence) retries on conflict.
snapshotCounters
  :: MonadSTM m
  => TxSubmissionCountersVar m
  -> PeerTxRegistry m peeraddr
  -> STM m TxSubmissionCounters
snapshotCounters retiredCountersVar registry = do
    retired <- readTVar retiredCountersVar
    peers   <- readTVar registry
    live    <- traverse (readTVar . snd) (Map.elems peers)
    pure $! mconcat (retired : live)

-- | Peer-facing coordination API.
--
-- The peer thread keeps its local protocol state in a local
-- variable. Registry helpers operate only on the shared STM state
-- and the per-peer 'PeerTxInFlight' TVar (closure-captured); any
-- helper that needs peer-local state should take it explicitly as an
-- argument.
data PeerTxAPI m txid tx = PeerTxAPI {
    -- | Wait until either 'sharedGeneration' moves past the given
    -- value or the optional timeout expires.
    awaitSharedChange    :: Word64
                         -> Maybe (RegisteredDelay m)
                         -> STM m (),

    -- | Compute the next action for this peer in non-pipelined mode.
    runNextPeerAction    :: Time
                         -> PeerTxLocalState tx
                         -> m (PeerAction, PeerTxLocalState tx),

    -- | Compute the next action for this peer in pipelined mode.
    runNextPeerActionPipelined :: Time
                               -> PeerTxLocalState tx
                               -> m (PeerAction, PeerTxLocalState tx),

    -- | Process a batch of txids received from this peer.
    applyReceivedTxIds   :: Time
                         -> NumTxIdsToReq
                         -> [(txid, SizeInBytes)]
                         -> PeerTxLocalState tx
                         -> m (PeerTxLocalState tx),

    -- | Process a batch of tx bodies received from this peer.
    applyReceivedTxs     :: Time
                         -> [(txid, tx)]
                         -> PeerTxLocalState tx
                         -> m (Int, PeerTxLocalState tx),

    -- | Mark txs as submitted to the mempool and update shared state.
    applySubmittedTxs    :: Time
                         -> [TxKey]
                         -> [TxKey]
                         -> PeerTxLocalState tx
                         -> m (PeerTxLocalState tx),

    -- | Resolve txids and advertised sizes for a batch of tx keys to request.
    resolveTxRequest     :: PeerTxLocalState tx
                         -> [TxKey]
                         -> m (Map txid SizeInBytes),
    -- | Resolve buffered tx bodies into full submission records.
    --
    -- pre-condition: the list of keys is in `peerDownloadedTxs` field of
    -- `PeerTxLocalState`.  It is ensured by `pickSubmitAction`.
    resolveBufferedTxs   :: PeerTxLocalState tx
                         -> [TxKey]
                         -> m [(TxKey, txid, tx)],

    -- | Add a delta to the V2 monotonic counters.
    addCounters          :: TxSubmissionCounters -> m ()
  }

--
-- | A bracket function which registers / de-registers a new peer in
-- `SharedTxStateVar`,  which exposes `PeerTxStateAPI`.
-- `PeerTxStateAPI` is only safe inside the  `withPeer` scope.
--
withPeer
  :: forall peeraddr txid tx idx m a.
     ( MonadMask m
     , MonadTimer m
     , Ord peeraddr
     , Show peeraddr
     , Ord txid
     , HasRawTxId txid
     )
  => TxDecisionPolicy
  -> TxSubmissionMempoolReader txid tx idx m
  -> SharedTxStateVar m peeraddr txid
  -> PeerTxRegistry m peeraddr
  -> TxSubmissionCountersVar m
  -> peeraddr
  -> (PeerTxAPI m txid tx -> m a)
  -> m a
withPeer policy TxSubmissionMempoolReader { mempoolGetSnapshot }
         sharedStateVar registry retiredCountersVar peeraddr io =
    bracket acquire release run
  where
    acquire = do
      peerInFlightVar <- newTVarIO emptyPeerTxInFlight
      peerCountersVar <- newTVarIO mempty
      atomically $ modifyTVar registry
                     (Map.insert peeraddr (peerInFlightVar, peerCountersVar))
      pure (peerInFlightVar, peerCountersVar)

    -- On exit: reverse this peer's in-flight contributions to shared
    -- state, flush its accumulated counters into the retired
    -- accumulator (so the emitted aggregate stays monotonic across
    -- disconnects), then drop it from the registry.  Flush and removal
    -- commit in one transaction so 'snapshotCounters' counts this peer
    -- exactly once: via its live cell before exit, via the retired
    -- accumulator after.
    release (peerInFlightVar, peerCountersVar) = do
      now <- getMonotonicTime
      atomically $ do
        pif <- readTVar peerInFlightVar
        modifyTVar sharedStateVar (scrubFromPeerInFlight peeraddr now pif)
        peerCounters <- readTVar peerCountersVar
        modifyTVar retiredCountersVar (<> peerCounters)
        modifyTVar registry (Map.delete peeraddr)

    run (peerInFlightVar, peerCountersVar) = io PeerTxAPI {
          awaitSharedChange = awaitSharedChangeImp sharedStateVar
        , runNextPeerAction = runNextPeerActionImp policy sharedStateVar
                                peerInFlightVar peerCountersVar peeraddr
        , runNextPeerActionPipelined = runNextPeerActionPipelinedImp policy
                                         sharedStateVar peerInFlightVar
                                         peerCountersVar peeraddr
        , applyReceivedTxIds = applyReceivedTxIdsImp policy mempoolGetSnapshot
                                 sharedStateVar peerInFlightVar peerCountersVar
        , applyReceivedTxs = applyReceivedTxsImp policy mempoolGetSnapshot
                               sharedStateVar peerInFlightVar peerCountersVar peeraddr
        , applySubmittedTxs = applySubmittedTxsImp policy sharedStateVar
                                peerInFlightVar peerCountersVar peeraddr
        , resolveTxRequest = resolveTxRequestImp sharedStateVar
        , resolveBufferedTxs = resolveBufferedTxsImp sharedStateVar
        , addCounters = \delta -> atomically $ modifyTVar peerCountersVar (<> delta)
        }

-- | Reverse this peer's still-outstanding contributions to the shared
-- 'TxEntry' counters.  Run by the bracket finalizer; uses the per-peer
-- TVar snapshot taken at exit time.
--
-- 'pifLeased' is best-effort (another peer can steal the lease in the
-- meantime), so the lease release verifies the entry still names this
-- peer as owner before claiming.
scrubFromPeerInFlight
  :: Eq peeraddr
  => peeraddr
  -> Time
  -> PeerTxInFlight
  -> SharedTxState peeraddr txid
  -> SharedTxState peeraddr txid
scrubFromPeerInFlight peeraddr now pif st
  | nothingToDo = st
  | otherwise   = st {
        sharedTxTable    = sharedTxTable',
        sharedGeneration = sharedGeneration st + 1
      }
  where
    -- 'pifAdvertised' and 'pifAcksPending' are not checked here: the
    -- bracket releaser also removes the peer from the registry, so the
    -- next sweep no longer sees this peer's keys in @liveReferences@ and
    -- reclaims the lookup tables itself.  Only the per-tx counters on
    -- 'sharedTxTable' need active scrubbing.
    nothingToDo =
         IntSet.null (pifLeased pif)
      && IntSet.null (pifAttempting pif)
      && IntSet.null (pifSubmitting pif)

    -- Walk each unique key once and apply all three modifications in a
    -- single 'IntMap.adjust'.  Keys typically appear in two of the
    -- three sets ('pifLeased' is a subset of 'pifAttempting ∪
    -- pifSubmitting').
    allKeys = pifLeased pif
        `IntSet.union` pifAttempting pif
        `IntSet.union` pifSubmitting pif

    sharedTxTable' = IntSet.foldl' scrubOne (sharedTxTable st) allKeys

    scrubOne tbl k = IntMap.adjust (modifyEntry k) k tbl

    modifyEntry k =
        applyIf (IntSet.member k (pifSubmitting pif)) clearSubmission
      . applyIf (IntSet.member k (pifAttempting pif)) decAttempt
      . applyIf (IntSet.member k (pifLeased     pif)) releaseLease

    applyIf True  f = f
    applyIf False _ = id

    releaseLease entry = case txLease entry of
      TxLeased owner _ | owner == peeraddr -> entry { txLease = TxClaimable now }
      _                                    -> entry

    decAttempt entry = entry { txAttempt = max 0 (txAttempt entry - 1) }

    clearSubmission entry = entry { txInSubmission = False }

-- | Wait until either 'sharedGeneration' moves past the given value or the
-- optional timeout expires.
--
-- Used by idle peers to avoid busy-waiting while still being woken when
-- shared state changes (lease expiries, new tx advertisements, mempool
-- resolutions).  A spurious wake on a change that doesn't grant this peer
-- new work is harmless: the peer immediately re-runs 'nextPeerAction',
-- selects 'PeerDoNothing' again, and goes back to sleep on the new
-- generation value.
awaitSharedChangeImp :: MonadTimer m
                     => SharedTxStateVar m peeraddr txid
                     -> Word64
                     -> Maybe (RegisteredDelay m)
                     -> STM m ()
awaitSharedChangeImp sharedStateVar generation mRegisteredDelay =
  case mRegisteredDelay of
       Nothing -> do
         sharedState <- readTVar sharedStateVar
         check (sharedGeneration sharedState /= generation)
       Just registeredDelay -> do
         sharedState <- readTVar sharedStateVar
         expired <- RegisteredDelay.read registeredDelay
         check (sharedGeneration sharedState /= generation || expired)

-- | Avoid rewriting the shared TVar when the pure state step made no shared
-- change. Callers use 'sharedGeneration' as the dirty bit for shared state.
writeSharedStateIfChanged :: MonadSTM m
                          => SharedTxStateVar m peeraddr txid
                          -> Word64                 -- ^ pre-step 'sharedGeneration'
                          -> Word64                 -- ^ pre-step 'sharedRevision'
                          -> SharedTxState peeraddr txid
                          -> STM m ()
writeSharedStateIfChanged sharedStateVar sharedGeneration0 sharedRevision0 sharedState'
  | sharedGeneration sharedState' == sharedGeneration0
  , sharedRevision   sharedState' == sharedRevision0
  = pure ()
  | otherwise = writeTVar sharedStateVar sharedState'

-- | Avoid rewriting the per-peer TVar when nothing changed.
writePeerInFlightIfChanged :: MonadSTM m
                           => PeerTxInFlightVar m
                           -> PeerTxInFlight
                           -> PeerTxInFlight
                           -> STM m ()
writePeerInFlightIfChanged var before after
  | before == after = pure ()
  | otherwise       = writeTVar var after

-- | Update the counters for the action chosen by the peer scheduler.
--
updateCountersForAction :: MonadSTM m
                        => TxSubmissionCountersVar m
                        -> PeerAction
                        -> STM m ()
updateCountersForAction countersVar peerAction =
  case peerAction of
    PeerRequestTxIds txIdsToAck txIdsToReq
      | txIdsToAck /= 0 || txIdsToReq /= 0 ->
          modifyTVar countersVar (<> mempty
            { txIdMessagesSent = 1
            , txIdsRequested   = fromIntegral txIdsToReq
            })
    PeerRequestTxs txKeys ->
      modifyTVar countersVar (<> mempty { txMessagesSent = 1
                                        , txsRequested   = fromIntegral (length txKeys) })
    _ -> pure ()

-- | Compute the next action for this peer in non-pipelined mode.
runNextPeerActionImp :: ( MonadSTM m
                        , Ord peeraddr )
                     => TxDecisionPolicy
                     -> SharedTxStateVar m peeraddr txid
                     -> PeerTxInFlightVar m
                     -> TxSubmissionCountersVar m
                     -> peeraddr
                     -> Time
                     -> PeerTxLocalState tx
                     -> m (PeerAction, PeerTxLocalState tx)
runNextPeerActionImp policy sharedStateVar peerInFlightVar countersVar peeraddr
                     now peerState = atomically $ do
  sharedState <- readTVar sharedStateVar
  peerInFlight <- readTVar peerInFlightVar
  let sharedGeneration0 = sharedGeneration sharedState
      sharedRevision0   = sharedRevision   sharedState
      (peerAction, peerState', peerInFlight', sharedState') =
        State.nextPeerAction now policy peeraddr peerState peerInFlight sharedState
  writeSharedStateIfChanged sharedStateVar sharedGeneration0 sharedRevision0 sharedState'
  writePeerInFlightIfChanged peerInFlightVar peerInFlight peerInFlight'
  updateCountersForAction countersVar peerAction
  return (peerAction, peerState')

-- | Compute the next action for this peer in pipelined mode.
runNextPeerActionPipelinedImp :: ( MonadSTM m
                                  , Ord peeraddr )
                              => TxDecisionPolicy
                              -> SharedTxStateVar m peeraddr txid
                              -> PeerTxInFlightVar m
                              -> TxSubmissionCountersVar m
                              -> peeraddr
                              -> Time
                              -> PeerTxLocalState tx
                              -> m (PeerAction, PeerTxLocalState tx)
runNextPeerActionPipelinedImp policy sharedStateVar peerInFlightVar countersVar
                              peeraddr now peerState =
    atomically $ do
      sharedState <- readTVar sharedStateVar
      peerInFlight <- readTVar peerInFlightVar
      let sharedGeneration0 = sharedGeneration sharedState
          sharedRevision0   = sharedRevision   sharedState
          (peerAction, peerState', peerInFlight', sharedState') =
            State.nextPeerActionPipelined now policy peeraddr peerState
                                          peerInFlight sharedState
      writeSharedStateIfChanged sharedStateVar sharedGeneration0 sharedRevision0 sharedState'
      writePeerInFlightIfChanged peerInFlightVar peerInFlight peerInFlight'
      updateCountersForAction countersVar peerAction
      return (peerAction, peerState')

-- | Process a batch of txids received from this peer.
applyReceivedTxIdsImp :: ( MonadSTM m
                         , HasRawTxId txid )
                      => TxDecisionPolicy
                      -> STM m (MempoolSnapshot txid tx idx)
                      -> SharedTxStateVar m peeraddr txid
                      -> PeerTxInFlightVar m
                      -> TxSubmissionCountersVar m
                      -> Time
                      -> NumTxIdsToReq
                      -- ^ number of requested txid's
                      -> [(txid, SizeInBytes)]
                      -- ^ actually received txid's with sizes
                      -> PeerTxLocalState tx
                      -> m (PeerTxLocalState tx)
applyReceivedTxIdsImp policy mempoolGetSnapshot sharedStateVar peerInFlightVar
                      countersVar now txIdsToReq txidsAndSizes peerState = do
  -- Snapshot the mempool outside the per-peer STM transaction so mempool
  -- writers don't kick the hot path into retries.  Stale answers are
  -- benign: a false positive delays re-fetch by 'bufferedTxsMinLifetime'
  -- via the retained set; a false negative wastes one body fetch that
  -- 'handleReceivedTxs' will reclassify as late.
  MempoolSnapshot { mempoolHasTx } <- atomically mempoolGetSnapshot
  atomically $ do
    sharedState <- readTVar sharedStateVar
    peerInFlight <- readTVar peerInFlightVar
    let sharedGeneration0 = sharedGeneration sharedState
        sharedRevision0   = sharedRevision   sharedState
        (peerState', peerInFlight', sharedState') =
          State.handleReceivedTxIds mempoolHasTx now policy txIdsToReq txidsAndSizes
                                    peerState peerInFlight sharedState
    writeSharedStateIfChanged sharedStateVar sharedGeneration0 sharedRevision0 sharedState'
    writePeerInFlightIfChanged peerInFlightVar peerInFlight peerInFlight'
    modifyTVar countersVar (<> mempty { txIdRepliesReceived = 1
                                      , txIdsReceived       = fromIntegral (length txidsAndSizes) })
    return peerState'

-- | Process a batch of tx bodies received from this peer.
applyReceivedTxsImp :: ( MonadSTM m
                       , Eq peeraddr
                       , Show peeraddr
                       , HasRawTxId txid )
                    => TxDecisionPolicy
                    -> STM m (MempoolSnapshot txid tx idx)
                    -> SharedTxStateVar m peeraddr txid
                    -> PeerTxInFlightVar m
                    -> TxSubmissionCountersVar m
                    -> peeraddr
                    -> Time
                    -> [(txid, tx)]
                    -> PeerTxLocalState tx
                    -> m (Int, PeerTxLocalState tx)
applyReceivedTxsImp policy mempoolGetSnapshot sharedStateVar peerInFlightVar
                    countersVar peeraddr now txs peerState = do
  -- Mempool snapshot taken in its own STM tx; see 'applyReceivedTxIdsImp'.
  MempoolSnapshot { mempoolHasTx } <- atomically mempoolGetSnapshot
  atomically $ do
    sharedState <- readTVar sharedStateVar
    peerInFlight <- readTVar peerInFlightVar
    let sharedGeneration0 = sharedGeneration sharedState
        sharedRevision0   = sharedRevision   sharedState
        (omittedCount, lateCount, peerState', peerInFlight', sharedState') =
          State.handleReceivedTxs mempoolHasTx now policy peeraddr txs
                                  peerState peerInFlight sharedState
    writeSharedStateIfChanged sharedStateVar sharedGeneration0 sharedRevision0 sharedState'
    writePeerInFlightIfChanged peerInFlightVar peerInFlight peerInFlight'
    modifyTVar countersVar (<> mempty {
                        txRepliesReceived = 1,
                        txsReceived       = fromIntegral (length txs),
                        txsOmitted        = fromIntegral omittedCount,
                        lateBodies        = fromIntegral lateCount
                      })
    return (omittedCount + lateCount, peerState')

-- | Mark txs as submitted to the mempool and update shared state.
applySubmittedTxsImp :: ( MonadSTM m
                       , Eq peeraddr )
                     => TxDecisionPolicy
                     -> SharedTxStateVar m peeraddr txid
                     -> PeerTxInFlightVar m
                     -> TxSubmissionCountersVar m
                     -> peeraddr
                     -> Time
                     -> [TxKey]
                     -> [TxKey]
                     -> PeerTxLocalState tx
                     -> m (PeerTxLocalState tx)
applySubmittedTxsImp policy sharedStateVar peerInFlightVar countersVar peeraddr
                     now acceptedTxs rejectedTxs peerState =
  atomically $ do
    sharedState <- readTVar sharedStateVar
    peerInFlight <- readTVar peerInFlightVar
    let sharedGeneration0 = sharedGeneration sharedState
        sharedRevision0   = sharedRevision   sharedState
        (peerState', peerInFlight', sharedState') =
          State.handleSubmittedTxs now policy peeraddr acceptedTxs
                                   rejectedTxs peerState peerInFlight sharedState
    writeSharedStateIfChanged sharedStateVar sharedGeneration0 sharedRevision0 sharedState'
    writePeerInFlightIfChanged peerInFlightVar peerInFlight peerInFlight'
    modifyTVar countersVar (<> mempty { txsAccepted = fromIntegral (length acceptedTxs)
                                      , txsRejected = fromIntegral (length rejectedTxs) })
    return peerState'

-- | Resolve txids and advertised sizes for a batch of tx keys to request.
resolveTxRequestImp :: ( HasCallStack
                       , MonadSTM m
                       , Ord txid )
                    => SharedTxStateVar m peeraddr txid
                    -> PeerTxLocalState tx
                    -> [TxKey]
                    -> m (Map txid SizeInBytes)
resolveTxRequestImp sharedStateVar peerState txKeys = do
  sharedState <- readTVarIO sharedStateVar
  return $ Map.fromList (fmap (resolveOne sharedState) txKeys)
  where
    resolveOne sharedState key@(TxKey k) =
      ( resolveTxKey sharedState key
      , case IntMap.lookup k (peerAvailableTxIds peerState) of
             Just txSize -> txSize
             Nothing     -> error $
               "TxSubmission.V2.resolveTxRequestImp: missing tx size for key "
               ++ show k
      )

-- | Resolve buffered tx bodies into full submission records.
resolveBufferedTxsImp :: ( HasCallStack
                         , MonadSTM m
                         )
                       => SharedTxStateVar m peeraddr txid
                       -> PeerTxLocalState tx
                       -> [TxKey]
                       -> m [(TxKey, txid, tx)]
resolveBufferedTxsImp sharedStateVar peerState txKeys = do
  sharedState <- readTVarIO sharedStateVar
  return $ fmap (resolveOne sharedState) txKeys
  where
    resolveOne sharedState key@(TxKey k) =
      ( key
      , resolveTxKey sharedState key
      , case IntMap.lookup k (peerDownloadedTxs peerState) of
             Just tx -> tx
             Nothing -> error $
               "TxSubmission.V2.resolveBufferedTxsImp: missing buffered tx for key "
               ++ show k
      )
