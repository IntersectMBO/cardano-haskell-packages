module Hydra.Cardano.Api.Network (
  Network (..),
) where

import Cardano.Ledger.BaseTypes (Network (..))
