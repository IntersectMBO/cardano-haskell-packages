{-# LANGUAGE GADTs #-}
{-# LANGUAGE NamedFieldPuns #-}
{-# LANGUAGE OverloadedStrings #-}

module Test.Cardano.Ledger.Binary.Cuddle.GenerateCBOR (
  generateCBORMain,
) where

import Codec.CBOR.Cuddle.CBOR.Gen
import Codec.CBOR.Cuddle.CBOR.Validator
import Codec.CBOR.Cuddle.CBOR.Validator.Trace
import Codec.CBOR.Cuddle.CDDL
import Codec.CBOR.Cuddle.CDDL.Custom.Generator
import qualified Codec.CBOR.Cuddle.Huddle as Cuddle
import Codec.CBOR.Cuddle.IndexMappable
import qualified Codec.CBOR.Term as CBOR
import qualified Codec.CBOR.Write as CBOR
import Control.Monad (forM_, when)
import qualified Data.ByteString as BS
import qualified Data.ByteString.Base16 as Base16
import qualified Data.ByteString.Char8 as BS8
import Data.List (intercalate)
import Data.Map.Strict (Map)
import qualified Data.Map.Strict as Map
import Data.Maybe (fromMaybe, isJust)
import qualified Data.Text as T
import Options.Applicative ((<**>))
import qualified Options.Applicative as Opt
import System.Exit (die)
import System.IO
import Test.AntiGen
import Test.Cardano.Ledger.Binary.Cuddle
import Test.QuickCheck (generate)
import Test.QuickCheck.Gen (unGen)
import Test.QuickCheck.Random (mkQCGen)

data GenerateCBOROpts = GenerateCBOROpts
  { gcboEra :: !T.Text
  , gcboRuleNames :: ![T.Text]
  , gcboZap :: !(Maybe Int)
  , gcboCount :: !Int
  , gcboSeed :: !(Maybe Int)
  , gcboBinary :: !Bool
  }

optsParser :: [String] -> Opt.Parser GenerateCBOROpts
optsParser eras =
  GenerateCBOROpts
    <$> Opt.strOption
      ( Opt.long "era"
          <> Opt.metavar "ERA"
          <> Opt.help ("Era to generate CBOR for. One of: " <> intercalate ", " eras)
      )
    <*> Opt.some
      ( Opt.strArgument $
          Opt.metavar "RULE_NAME..."
            <> Opt.help "CDDL rule names to generate CBOR for"
      )
    <*> Opt.optional
      ( Opt.option Opt.auto $
          Opt.long "zap"
            <> Opt.metavar "N"
            <> Opt.help "Generate corrupted (zapped) CBOR with N mistakes"
      )
    <*> Opt.option
      Opt.auto
      ( Opt.long "count"
          <> Opt.short 'n'
          <> Opt.metavar "N"
          <> Opt.value 1
          <> Opt.showDefault
          <> Opt.help "Number of samples to generate per rule"
      )
    <*> Opt.optional
      ( Opt.option Opt.auto $
          Opt.long "seed"
            <> Opt.metavar "SEED"
            <> Opt.help "Fixed random seed for reproducibility"
      )
    <*> Opt.switch
      ( Opt.long "binary"
          <> Opt.help "Output raw CBOR bytes instead of hex encoding"
      )

generateCBORMain :: Map T.Text Cuddle.Huddle -> IO ()
generateCBORMain eraCDDLs = do
  opts <-
    Opt.execParser $
      Opt.info
        (optsParser eraNames <**> Opt.helper)
        ( Opt.fullDesc
            <> Opt.progDesc "Generate CBOR data from Cardano Ledger CDDL rules"
            <> Opt.header "generate-cbor - CBOR data generator from Cardano Ledger CDDL specifications"
        )
  huddle <- case Map.lookup (gcboEra opts) eraCDDLs of
    Nothing ->
      die $
        "Unknown era: "
          <> T.unpack (gcboEra opts)
          <> "\nSupported eras: "
          <> intercalate ", " eraNames
    Just h -> pure h
  case resolveHuddle huddle of
    Left err -> die $ "Failed to resolve CDDL: " <> err
    Right root -> do
      when (gcboBinary opts) $ hSetBinaryMode stdout True
      let env = HuddleEnv {heTwiddle = True, heRoot = root}
          multipleRules = length (gcboRuleNames opts) > 1
      forM_ (gcboRuleNames opts) $ \ruleName -> do
        when (multipleRules && not (gcboBinary opts)) $
          hPutStrLn stderr $
            "# " <> T.unpack ruleName
        forM_ [0 .. gcboCount opts - 1] $ emitSample opts env ruleName
  where
    eraNames = map T.unpack (Map.keys eraCDDLs)

emitSample :: GenerateCBOROpts -> HuddleEnv -> T.Text -> Int -> IO ()
emitSample opts env ruleName sampleIx = do
  let cborGen = runCBORGen (toGenConfig env) (generateFromName (Name ruleName))
      gen = zapAntiGenResult (fromMaybe 0 (gcboZap opts)) cborGen
  result <- case gcboSeed opts of
    Nothing -> generate gen
    Just seed -> pure $ unGen gen (mkQCGen (seed + sampleIx)) 30
  writeSample opts env ruleName sampleIx result

writeSample :: GenerateCBOROpts -> HuddleEnv -> T.Text -> Int -> ZapResult CBOR.Term -> IO ()
writeSample opts env ruleName sampleIx ZapResult {zrValue, zrZapped}
  | isJust (gcboZap opts) =
      if zrZapped == 0
        then warn "produced no corruptions"
        else case validation of
          Left e -> warn $ "could not run validation because of malformed bytes\n" <> show e
          Right (Evidenced SValid _) -> warn "produced a value that is still valid"
          Right (Evidenced SInvalid _) -> outputBinary
  | otherwise = outputBinary
  where
    outputBinary
      | gcboBinary opts = BS.hPut stdout bs
      | otherwise = BS8.putStrLn (Base16.encode bs)
    bs = CBOR.toStrictByteString (CBOR.encodeTerm zrValue)
    validation = validateCBOR bs (Name ruleName) (mapIndex (heRoot env))
    warn reason =
      hPutStrLn stderr $
        "Warning: zap "
          <> reason
          <> " for rule "
          <> T.unpack ruleName
          <> " (sample "
          <> show sampleIx
          <> ")"
