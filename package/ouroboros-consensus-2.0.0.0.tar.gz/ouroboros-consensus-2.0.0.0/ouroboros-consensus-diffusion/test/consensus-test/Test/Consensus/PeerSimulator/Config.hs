{-# LANGUAGE TypeFamilies #-}
{-# LANGUAGE TypeOperators #-}
-- Necessary to give the 'HasPointScheduleTestParams' instance for 'TestBlockWith'.
{-# OPTIONS_GHC -Wno-orphans #-}

module Test.Consensus.PeerSimulator.Config (defaultCfg) where

import Cardano.Crypto.DSIGN (SignKeyDSIGN (..), VerKeyDSIGN (..))
import Cardano.Slotting.Time (SlotLength, slotLengthFromSec)
import qualified Data.Map.Strict as Map
import Data.Maybe.Strict (StrictMaybe (..))
import Ouroboros.Consensus.Config
  ( SecurityParam
  , TopLevelConfig (..)
  , emptyCheckpointsMap
  )
import Ouroboros.Consensus.HardFork.History
  ( EraParams (eraGenesisWin)
  )
import qualified Ouroboros.Consensus.HardFork.History.EraParams as HardFork
import Ouroboros.Consensus.Ledger.SupportsProtocol (GenesisWindow)
import Ouroboros.Consensus.Node.ProtocolInfo
  ( NumCoreNodes (NumCoreNodes)
  , ProtocolInfo (..)
  )
import Ouroboros.Consensus.NodeId
  ( CoreNodeId (CoreNodeId)
  , NodeId (CoreId)
  )
import Ouroboros.Consensus.Protocol.BFT
  ( BftParams (BftParams, bftNumNodes, bftSecurityParam)
  , ConsensusConfig (BftConfig, bftParams, bftSignKey, bftVerKeys)
  )
import Test.Consensus.PointSchedule
  ( ForecastRange (ForecastRange)
  , HasPointScheduleTestParams (..)
  )
import Test.Util.ChainDB (mkTestChunkInfo)
import Test.Util.Orphans.IOLike ()
import Test.Util.TestBlock
  ( BlockConfig (TestBlockConfig)
  , CodecConfig (TestBlockCodecConfig)
  , StorageConfig (TestBlockStorageConfig)
  , TestBlock
  , TestBlockLedgerConfig (..)
  , TestBlockWith (..)
  , testInitExtLedger
  )

-- REVIEW: this has not been deliberately chosen
defaultCfg :: SecurityParam -> ForecastRange -> GenesisWindow -> TopLevelConfig TestBlock
defaultCfg secParam (ForecastRange sfor) sgen =
  TopLevelConfig
    { topLevelConfigProtocol =
        BftConfig
          { bftParams =
              BftParams
                { bftSecurityParam = secParam
                , bftNumNodes = NumCoreNodes 2
                }
          , bftSignKey = SignKeyMockDSIGN 0
          , bftVerKeys =
              Map.fromList
                [ (CoreId (CoreNodeId 0), VerKeyMockDSIGN 0)
                , (CoreId (CoreNodeId 1), VerKeyMockDSIGN 1)
                ]
          }
    , topLevelConfigLedger = TestBlockLedgerConfig eraParams (SJust (fromIntegral sfor))
    , topLevelConfigBlock = TestBlockConfig numCoreNodes
    , topLevelConfigCodec = TestBlockCodecConfig
    , topLevelConfigStorage = TestBlockStorageConfig
    , topLevelConfigCheckpoints = emptyCheckpointsMap
    }
 where
  -- REVIEW: Make it 1s or a parameter?
  slotLength :: SlotLength
  slotLength = slotLengthFromSec 20

  eraParams :: HardFork.EraParams
  eraParams = (HardFork.defaultEraParams secParam slotLength){eraGenesisWin = sgen}

  numCoreNodes = NumCoreNodes 2

-- | If you are here because you tried to implement `HasPointScheduleTestParams` for
-- some type `TestBlockWith Foo` and got an overlapping instance warning, the `a ~ ()`
-- constraint is only here to get your attention. The tests should remain as block
-- polymorphic as possible, so /maybe/ there should be a class for the types `a` that
-- can appear in `TestBlockWith a`. But we in the past do not know what that class
-- should look like! So the choice is yours: if what you need from this class can be
-- made polymorphic in `a`, consider adding a class. If not, specialize this instance.
instance a ~ () => HasPointScheduleTestParams (TestBlockWith a) where
  data ProtocolInfoArgs (TestBlockWith a) = TestBlockProtocolInfoArgs
  getProtocolInfoArgs = pure TestBlockProtocolInfoArgs
  mkProtocolInfo k forecast window _ =
    ProtocolInfo
      { pInfoConfig = defaultCfg k forecast window
      , pInfoInitLedger = testInitExtLedger
      }
  getChunkInfoFromTopLevelConfig = mkTestChunkInfo
