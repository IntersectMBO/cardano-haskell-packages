# Ouroboros-consensus-protocol Changelog

# Changelog entries

<a id='changelog-0.13.0.0'></a>
## 0.13.0.0 -- 2025-09-29

### Patch

- Bump `cardano-protocol-tpraos` to 1.4.1

### Non-Breaking

- Added `SafeToHash` instance for `BHeader`

### Breaking

- Use new mlocked KES API for all internal KES sign key handling.
- Add finalizers to all block forgings (required by `ouroboros-consensus`).
- Change `HotKey` to manage not only KES sign keys, but also the corresponding
  OpCerts. This is in preparation for KES agent connectivity: with the new
  design, the KES agent will provide both KES sign keys and matching OpCerts
  together, and we need to be able to dynamically replace them both together.
- Add finalizer to `HotKey`. This takes care of securely forgetting any KES
  keys the HotKey may still hold, and will be called automatically when the
  owning block forging terminates.
- Change `PraosCanBeLeader` to not contain the KES sign key itself anymore.
  Instead, it now contains a `PraosCredentialsSource` field, which
  specifies how to obtain the actual credentials (OpCert and KES SignKey). For
  now, the only supported method is passing an OpCert and an
  UnsoundPureSignKeyKES, presumably loaded from disk
  (`PraosCredentialsUnsound`); future iterations will add support for
  connecting to a KES agent.

- Encode the slot number in the TPraos state as `[] / [slot]` instead of `[0] / [1, slot]`.

- Add new `HasMaxMajorProtVer` class for consensus protocols.

- Removed `PraosChainSelectView`, use `SelectView (TPraos c)`/`SelectView (Praos
  c)` instead.

<a id='changelog-0.12.0.0'></a>
## 0.12.0.0 -- 2025-04-21

### Breaking

- Restrict `ouroboros-consensus` to UTxO-HD versions (>=0.25).

<a id='changelog-0.11.0.0'></a>
## 0.11.0.0 -- 2025-03-25

### Breaking

- Adapt to Ledger's Crypto monomorphization. Many types and fields have lost their `c/crypto` type variable as now `StandardCrypto` is used by the Ledger everywhere.
- `KESKey` now uses `UnsoundPureSignKeyKES` in preparation of the `kes-agent` feature.

### Non-Breaking

- Bump upper bound on `base` dependency.

<a id='changelog-0.10.0.0'></a>
## 0.10.0.0 -- 2025-01-08

### Patch

- Expose functions to simplify thorough testing of header validation
  logic, and introduce generators and properties to actually test it.

* Use the `VRFVerKeyHash` type from `cardano-ledger-core-1.16`

### Breaking

- Removed unused fields from `PraosParams`.

<a id='changelog-0.9.0.2'></a>
## 0.9.0.2 -- 2024-10-14

### Patch

- Updated dependencies, but no changes to the interface.

<a id='changelog-0.9.0.1'></a>
## 0.9.0.1 -- 2024-06-19

### Patch

- Updated dependencies, but no changes to the interface.

<a id='changelog-0.9.0.0'></a>
## 0.9.0.0 -- 2024-05-13

### Non-Breaking

- Adapted to introduction of new `ChainOrder` type class.

- Changed the Praos chain order such that for two blocks `A` and `B` by the same
  issuer with the same block number, `A` is now preferred over `B` only if `A`
  has a higher issue number *and* (new) `A` and `B` are in the same slot.

  This is in line with the motiviation for the issue number tiebreaker, and
  fixes the transitivity of the `Ord PraosChainSelectView` instance in a special
  case.

### Breaking

- Allowed to configure Praos chain order to restrict the VRF tiebreaker based on
  slot distance.

- Delete `Ouroboros.Consensus.Protocol.Praos.Translate`, moving the orphan
  instance to `Ouroboros.Consensus.Protocol.Praos`.
- Delete `Ouroboros.Consensus.Protocol.Translate`, moving `TranslateProto`
  to `Ouroboros.Consensus.Protocol.Abstract`.

<a id='changelog-0.8.0.0'></a>
## 0.8.0.0 -- 2024-04-03

### Breaking

- Remove unused `translateConsensusConfig` from `TranslateProto`.

- Add `praosRandomnessStabilisationWindow` to `PraosParams`, allowing to
  configure in which slot the epoch nonce is snapshotted (which can now vary
  between different eras).

<a id='changelog-0.7.0.0'></a>
## 0.7.0.0 -- 2024-01-29

### Patch

- Fix imports and type mismatches caused by `ouroboros-consensus` bumping
  `strict-checked-vars` to `^>= 0.2`.

### Breaking

- Praos' `LedgerView.lvMaxHeaderSize` type changed from `Natural` to `Word16`.
- Praos' `LedgerView.lvMaxBoxySize` type changed from `Natural` to `Word32`.

<a id='changelog-0.6.0.0'></a>
## 0.6.0.0 -- 2023-10-26

### Breaking

- Replace all occurrences of `Ticked (LedgerView X)` with `LedgerView X`.
- Remove `Ticked (LedgerView X)` data family instances.
- Rename `translateTickedLedgerView` to `translateLedgerView`.

<a id='changelog-0.5.0.7'></a>
## 0.5.0.7 -- 2023-09-27

### Patch

- Update upper bound on `ouroboros-consensus`

<a id='changelog-0.5.0.6'></a>
## 0.5.0.6 -- 2023-08-21

### Patch

- Removed the `expose-sublibs` cabal flag, since Cabal/Nix handled it poorly.
- Instead, added a `unstable-` prefix to the name of each sublibrary, to
  strongly indicate that we ignore them when evolving the package's version.

<a id='changelog-0.5.0.5></a>
## 0.5.0.5 -- 2023-08-18

### Non-Breaking

- Relax upper bound on `ouroboros-consensus`

<a id='changelog-0.5.0.4'></a>
## 0.5.0.4 -- 2023-07-06

### Non-Breaking

- Relax upper bound on `ouroboros-consensus`

<a id='changelog-0.5.0.3'></a>
## 0.5.0.3 -- 2023-06-23

### Patch

- Rename `StrictMVar` to `StrictSVar`

<a id='changelog-0.5.0.2'></a>
## 0.5.0.2 -- 2023-05-19

### Patch

- Relax bounds on `ouroboros-consensus`

<a id='changelog-0.5.0.1'></a>
## 0.5.0.1 -- 2023-04-28

### Patch

- Relax bounds on `ouroboros-consensus`

<a id='changelog-0.5.0.0'></a>
## 0.5.0.0 -- 2023-04-24

### Breaking

- Apply new organization of Consensus packages.

## Before 0.4.0.0

Before this version, `ouroboros-consensus-protocol` lived in a bundle of
packages with `ouroboros-consensus`, thus the changelog was the same.

---

### Archaeological remark

Before following a more structured release process, we tracked most significant
changes affecting downstream users in the
[interface-CHANGELOG.md](https://github.com/IntersectMBO/ouroboros-consensus/blob/8d8329e4dd41404439b7cd30629fcce427679212/docs/website/docs/interface-CHANGELOG.md).
