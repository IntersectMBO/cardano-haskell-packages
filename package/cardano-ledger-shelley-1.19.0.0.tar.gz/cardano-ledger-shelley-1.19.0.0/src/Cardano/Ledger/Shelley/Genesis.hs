{-# LANGUAGE BangPatterns #-}
{-# LANGUAGE DataKinds #-}
{-# LANGUAGE DeriveAnyClass #-}
{-# LANGUAGE DeriveGeneric #-}
{-# LANGUAGE DerivingVia #-}
{-# LANGUAGE FlexibleContexts #-}
{-# LANGUAGE FlexibleInstances #-}
{-# LANGUAGE GeneralizedNewtypeDeriving #-}
{-# LANGUAGE LambdaCase #-}
{-# LANGUAGE NamedFieldPuns #-}
{-# LANGUAGE NumericUnderscores #-}
{-# LANGUAGE OverloadedStrings #-}
{-# LANGUAGE RankNTypes #-}
{-# LANGUAGE ScopedTypeVariables #-}
{-# LANGUAGE StandaloneDeriving #-}
{-# LANGUAGE TypeApplications #-}
{-# LANGUAGE TypeFamilies #-}
{-# LANGUAGE UndecidableInstances #-}
{-# OPTIONS_GHC -Wno-orphans #-}

module Cardano.Ledger.Shelley.Genesis (
  ShelleyGenesisStaking (..),
  ShelleyExtraConfig (..),
  ShelleyGenesis (..),
  ValidationErr (..),
  NominalDiffTimeMicro (..),
  emptyGenesisStaking,
  sgActiveSlotCoeff,
  genesisUTxO,
  initialFundsPseudoTxIn,
  validateGenesis,
  describeValidationErr,
  mkShelleyGlobals,
  nominalDiffTimeMicroToMicroseconds,
  nominalDiffTimeMicroToSeconds,
  toNominalDiffTimeMicro,
  toNominalDiffTimeMicroWithRounding,
  fromNominalDiffTimeMicro,
  secondsToNominalDiffTimeMicro,
  sgInitialFundsL,
  sgStakingL,
  sgExtraConfigL,

  -- * Streaming injection
  InjectionData (..),
  foldInjectionData,
  InjectionError (..),
) where

import Cardano.Base.Aeson (fromJSONKeyText)
import Cardano.Crypto.DSIGN (Ed25519DSIGN)
import Cardano.Crypto.Hash (Blake2b_256)
import qualified Cardano.Crypto.Hash.Class as H
import Cardano.Crypto.KES (Sum6KES, totalPeriodsKES)
import Cardano.Ledger.Address (serialiseAddr)
import Cardano.Ledger.BaseTypes (
  ActiveSlotCoeff,
  BoundedRational (boundRational, unboundRational),
  EpochSize (..),
  Globals (..),
  KeyValuePairs (..),
  Network,
  NonZero (..),
  Nonce (..),
  PositiveUnitInterval,
  StrictMaybe (..),
  ToKeyValuePairs (..),
  maybeToStrictMaybe,
  mkActiveSlotCoeff,
 )
import Cardano.Ledger.Binary (
  DecCBOR (..),
  Decoder,
  DecoderError (..),
  EncCBOR (..),
  Encoding,
  FromCBOR (..),
  ToCBOR (..),
  cborError,
  decodeRational,
  decodeRecordNamed,
  decodeRecordSum,
  encodeListLen,
  enforceDecoderVersion,
  enforceEncodingVersion,
  shelleyProtVer,
  toPlainEncoding,
 )
import Cardano.Ledger.Binary.Coders (Decode (..), Encode (..), decode, encode, (!>), (<!))
import Cardano.Ledger.Coin (Coin)
import Cardano.Ledger.Core
import Cardano.Ledger.Genesis
import Cardano.Ledger.Hashes (unsafeMakeSafeHash)
import Cardano.Ledger.Keys (GenDelegPair (..))
import Cardano.Ledger.Shelley.Era (ShelleyEra)
import Cardano.Ledger.Shelley.PParams (ShelleyPParams (..))
import Cardano.Ledger.Shelley.StabilityWindow
import Cardano.Ledger.State (StakePoolParams (..), UTxO (UTxO))
import Cardano.Ledger.TxIn (TxId (..), TxIn (..))
import qualified Cardano.Ledger.Val as Val
import Cardano.Slotting.EpochInfo (EpochInfo)
import Cardano.Slotting.Time (SystemStart (SystemStart))
import Control.DeepSeq (NFData)
import Control.Exception (Exception (..))
import Control.Monad (unless, when)
import Control.Monad.Class.MonadST (MonadST)
import Control.Monad.Class.MonadThrow (MonadThrow (throwIO))
import Control.Monad.Identity (Identity)
import Control.Monad.Trans.Class (lift)
import Data.Aeson (
  FromJSON (..),
  FromJSONKey,
  ToJSON (..),
  fromJSON,
  object,
  withObject,
  (.!=),
  (.:),
  (.:?),
  (.=),
 )
import qualified Data.Aeson as Aeson
import Data.Aeson.Types (Parser, Value (..), typeMismatch)
import qualified Data.ByteString as BS
import Data.Default (Default (..))
import Data.Fixed (Fixed (..), Micro, Pico)
import qualified Data.Foldable as F
import Data.JsonStream.Parser (ParseOutput (..), runParser)
import qualified Data.JsonStream.Parser as JsonStream
import Data.ListMap (ListMap)
import qualified Data.ListMap as LM
import Data.Map.Strict (Map)
import qualified Data.Map.Strict as Map
import Data.Maybe (catMaybes)
import Data.Proxy (Proxy (..))
import Data.Text (Text)
import qualified Data.Text as Text
import Data.Time.Clock (
  NominalDiffTime,
  UTCTime (..),
  nominalDiffTimeToSeconds,
  secondsToNominalDiffTime,
 )
import Data.Unit.Strict (forceElemsToWHNF)
import Data.Word (Word32, Word64)
import GHC.Generics (Generic)
import Lens.Micro (Lens', lens)
import NoThunks.Class (AllowThunksIn (..), NoThunks (..))
import Streaming (Of (..), Stream)
import qualified Streaming.Prelude as Streaming
import System.FS.API (
  FsPath,
  Handle,
  HasFS (..),
  OpenMode (..),
  fsPathFromList,
  fsPathToList,
  withFile,
 )

-- | Genesis Shelley staking configuration.
--
-- This allows us to configure some initial stake pools and delegation to them,
-- in order to test Praos in a static configuration, without requiring on-chain
-- registration and delegation.
--
-- For simplicity, pools defined in the genesis staking do not pay deposits for
-- their registration.
data ShelleyGenesisStaking = ShelleyGenesisStaking
  { sgsPools :: LM.ListMap (KeyHash StakePool) StakePoolParams
  -- ^ Pools to register
  --
  --   The key in this map is the hash of the public key of the _pool_. This
  --   need not correspond to any payment or staking key, but must correspond
  --   to the cold key held by 'TPraosIsCoreNode'.
  , sgsStake :: LM.ListMap (KeyHash Staking) (KeyHash StakePool)
  -- ^ Stake-holding key hash credentials and the pools to delegate that stake
  -- to. We require the raw staking key hash in order to:
  --
  -- - Avoid pointer addresses, which would be tricky when there's no slot or
  --   transaction to point to.
  -- - Avoid script credentials.
  }
  deriving stock (Eq, Show, Generic)
  deriving (ToJSON) via KeyValuePairs ShelleyGenesisStaking

instance NFData ShelleyGenesisStaking

instance NoThunks ShelleyGenesisStaking

instance Semigroup ShelleyGenesisStaking where
  (<>) (ShelleyGenesisStaking p1 s1) (ShelleyGenesisStaking p2 s2) =
    ShelleyGenesisStaking (p1 <> p2) (s1 <> s2)

instance Monoid ShelleyGenesisStaking where
  mempty = ShelleyGenesisStaking mempty mempty

instance EncCBOR ShelleyGenesisStaking where
  encCBOR (ShelleyGenesisStaking pools stake) =
    encodeListLen 2 <> encCBOR pools <> encCBOR stake

instance DecCBOR ShelleyGenesisStaking where
  decCBOR = do
    decodeRecordNamed "ShelleyGenesisStaking" (const 2) $ do
      pools <- decCBOR
      stake <- decCBOR
      pure $ ShelleyGenesisStaking pools stake

-- | Empty genesis staking
emptyGenesisStaking :: ShelleyGenesisStaking
emptyGenesisStaking = mempty

-- | Extra configuration for injecting Genesis data
data ShelleyExtraConfig = ShelleyExtraConfig
  { secInitialFunds :: !(InjectionData Addr Coin)
  -- ^ Initial funds to inject.
  , secStakePools :: !(InjectionData (KeyHash StakePool) StakePoolParams)
  -- ^ Stake pools to register.
  , secStakeCredentials :: !(InjectionData (KeyHash Staking) (KeyHash StakePool))
  -- ^ Stake credential delegations to stake pools.
  }
  deriving stock (Eq, Show, Generic)
  deriving (ToJSON) via KeyValuePairs ShelleyExtraConfig

instance NFData ShelleyExtraConfig

instance NoThunks ShelleyExtraConfig

instance Default ShelleyExtraConfig where
  def = ShelleyExtraConfig NoInjection NoInjection NoInjection

instance EncCBOR ShelleyExtraConfig where
  encCBOR (ShelleyExtraConfig funds pools creds) =
    encode $
      Rec ShelleyExtraConfig
        !> To funds
        !> To pools
        !> To creds

instance DecCBOR ShelleyExtraConfig where
  decCBOR =
    decode $
      RecD ShelleyExtraConfig
        <! From
        <! From
        <! From

instance ToKeyValuePairs ShelleyExtraConfig where
  toKeyValuePairs ShelleyExtraConfig {secInitialFunds, secStakePools, secStakeCredentials} =
    [ "initialFunds" .= secInitialFunds
    , "stakePools" .= secStakePools
    , "stakeCredentials" .= secStakeCredentials
    ]

instance FromJSON ShelleyExtraConfig where
  parseJSON = Aeson.withObject "ShelleyExtraConfig" $ \obj ->
    ShelleyExtraConfig
      <$> obj .:? "initialFunds" .!= NoInjection
      <*> obj .:? "stakePools" .!= NoInjection
      <*> obj .:? "stakeCredentials" .!= NoInjection

-- | Unlike @'NominalDiffTime'@ that supports @'Pico'@ precision, this type
-- only supports @'Micro'@ precision.
newtype NominalDiffTimeMicro = NominalDiffTimeMicro Micro
  deriving (Show, Eq, Generic)
  deriving anyclass (NoThunks)
  deriving newtype (Ord, Num, Fractional, Real, ToJSON, FromJSON, EncCBOR, DecCBOR, NFData)

-- | There is no loss of resolution in this conversion
microToPico :: Micro -> Pico
microToPico micro = fromRational @Pico $ toRational micro

-- | Loss of resolution occurs in this conversion
picoToMicro :: Pico -> Micro
picoToMicro pico = fromRational @Micro $ toRational pico

fromNominalDiffTimeMicro :: NominalDiffTimeMicro -> NominalDiffTime
fromNominalDiffTimeMicro =
  secondsToNominalDiffTime . microToPico . nominalDiffTimeMicroToMicroseconds

toNominalDiffTimeMicroWithRounding :: NominalDiffTime -> NominalDiffTimeMicro
toNominalDiffTimeMicroWithRounding =
  secondsToNominalDiffTimeMicro . picoToMicro . nominalDiffTimeToSeconds

toNominalDiffTimeMicro :: NominalDiffTime -> Maybe NominalDiffTimeMicro
toNominalDiffTimeMicro ndt
  | fromNominalDiffTimeMicro ndtm == ndt = Just ndtm
  | otherwise = Nothing
  where
    ndtm = toNominalDiffTimeMicroWithRounding ndt

secondsToNominalDiffTimeMicro :: Micro -> NominalDiffTimeMicro
secondsToNominalDiffTimeMicro = NominalDiffTimeMicro

nominalDiffTimeMicroToMicroseconds :: NominalDiffTimeMicro -> Micro
nominalDiffTimeMicroToMicroseconds (NominalDiffTimeMicro microseconds) = microseconds

nominalDiffTimeMicroToSeconds :: NominalDiffTimeMicro -> Pico
nominalDiffTimeMicroToSeconds (NominalDiffTimeMicro microseconds) = microToPico microseconds

-- | Shelley genesis information
--
-- Note that this is needed only for a pure Shelley network, hence it being
-- defined here rather than in its own module. In mainnet, Shelley will
-- transition naturally from Byron, and thus will never have its own genesis
-- information.
data ShelleyGenesis = ShelleyGenesis
  { sgSystemStart :: !UTCTime
  , sgNetworkMagic :: !Word32
  , sgNetworkId :: !Network
  , sgActiveSlotsCoeff :: !PositiveUnitInterval
  , sgSecurityParam :: !(NonZero Word64)
  , sgEpochLength :: !EpochSize
  , sgSlotsPerKESPeriod :: !Word64
  , sgMaxKESEvolutions :: !Word64
  , sgSlotLength :: !NominalDiffTimeMicro
  , sgUpdateQuorum :: !Word64
  , sgMaxLovelaceSupply :: !Word64
  , sgProtocolParams :: !(PParams ShelleyEra)
  , sgGenDelegs :: !(Map (KeyHash GenesisRole) GenDelegPair)
  , sgInitialFunds :: LM.ListMap Addr Coin
  -- ^ 'sgInitialFunds' is intentionally kept lazy, as it can otherwise cause
  --   out-of-memory problems in testing and benchmarking.
  , sgStaking :: ShelleyGenesisStaking
  -- ^ 'sgStaking' is intentionally kept lazy, as it can otherwise cause
  --   out-of-memory problems in testing and benchmarking.
  , sgExtraConfig :: !(StrictMaybe ShelleyExtraConfig)
  -- ^ Optional extra configuration for streaming injection.
  }
  deriving stock (Generic, Show, Eq)
  deriving (ToJSON) via KeyValuePairs ShelleyGenesis

instance NFData ShelleyGenesis

sgInitialFundsL :: Lens' ShelleyGenesis (LM.ListMap Addr Coin)
sgInitialFundsL = lens sgInitialFunds (\sg x -> sg {sgInitialFunds = x})

sgStakingL :: Lens' ShelleyGenesis ShelleyGenesisStaking
sgStakingL = lens sgStaking (\sg x -> sg {sgStaking = x})

sgExtraConfigL :: Lens' ShelleyGenesis (StrictMaybe ShelleyExtraConfig)
sgExtraConfigL = lens sgExtraConfig (\sg x -> sg {sgExtraConfig = x})

deriving via
  AllowThunksIn '["sgInitialFunds", "sgStaking"] ShelleyGenesis
  instance
    NoThunks ShelleyGenesis

sgActiveSlotCoeff :: ShelleyGenesis -> ActiveSlotCoeff
sgActiveSlotCoeff = mkActiveSlotCoeff . sgActiveSlotsCoeff

instance ToKeyValuePairs ShelleyGenesis where
  toKeyValuePairs
    ShelleyGenesis
      { sgSystemStart
      , sgNetworkMagic
      , sgNetworkId
      , sgActiveSlotsCoeff
      , sgSecurityParam
      , sgEpochLength
      , sgSlotsPerKESPeriod
      , sgMaxKESEvolutions
      , sgSlotLength
      , sgUpdateQuorum
      , sgMaxLovelaceSupply
      , sgProtocolParams
      , sgGenDelegs
      , sgInitialFunds
      , sgStaking
      , sgExtraConfig
      } =
      let !strictSgInitialFunds = sgInitialFunds
          !strictSgStaking = sgStaking
       in [ "systemStart" .= sgSystemStart
          , "networkMagic" .= sgNetworkMagic
          , "networkId" .= sgNetworkId
          , "activeSlotsCoeff" .= sgActiveSlotsCoeff
          , "securityParam" .= sgSecurityParam
          , "epochLength" .= sgEpochLength
          , "slotsPerKESPeriod" .= sgSlotsPerKESPeriod
          , "maxKESEvolutions" .= sgMaxKESEvolutions
          , "slotLength" .= sgSlotLength
          , "updateQuorum" .= sgUpdateQuorum
          , "maxLovelaceSupply" .= sgMaxLovelaceSupply
          , "protocolParams" .= legacyToJSONPParams sgProtocolParams
          , "genDelegs" .= sgGenDelegs
          , "initialFunds" .= strictSgInitialFunds
          , "staking" .= strictSgStaking
          ]
            <> ["extraConfig" .= ec | SJust ec <- [sgExtraConfig]]

instance EraGenesis ShelleyEra where
  type Genesis ShelleyEra = ShelleyGenesis

--------------------------------------------------
-- Legacy JSON representation of ShelleyGenesis --
--------------------------------------------------
newtype LegacyJSONPParams = LegacyJSONPParams (PParamsHKD Identity ShelleyEra)

legacyFromJSONPParams :: LegacyJSONPParams -> PParams ShelleyEra
legacyFromJSONPParams (LegacyJSONPParams x) = PParams x

instance FromJSON LegacyJSONPParams where
  parseJSON =
    Aeson.withObject "ShelleyPParams" $ \obj -> do
      LegacyJSONPParams
        <$> ( ShelleyPParams
                <$> obj .: "minFeeA"
                <*> obj .: "minFeeB"
                <*> obj .: "maxBlockBodySize"
                <*> obj .: "maxTxSize"
                <*> obj .: "maxBlockHeaderSize"
                <*> obj .: "keyDeposit"
                <*> obj .: "poolDeposit"
                <*> obj .: "eMax"
                <*> obj .: "nOpt"
                <*> obj .: "a0"
                <*> obj .: "rho"
                <*> obj .: "tau"
                <*> obj .: "decentralisationParam"
                <*> (parseNonce =<< (obj .: "extraEntropy"))
                <*> obj .: "protocolVersion"
                <*> obj .:? "minUTxOValue" .!= mempty
                <*> obj .:? "minPoolCost" .!= mempty
            )
    where
      parseNonce :: Aeson.Value -> Parser Nonce
      parseNonce =
        Aeson.withObject
          "Nonce"
          ( \obj -> do
              tag <- (obj .: "tag" :: Parser Text)
              case tag of
                "Nonce" -> Nonce <$> obj .: "contents"
                "NeutralNonce" -> return NeutralNonce
                _ -> typeMismatch "Nonce" (Object obj)
          )

legacyToJSONPParams :: PParams ShelleyEra -> LegacyJSONPParams
legacyToJSONPParams (PParams x) = LegacyJSONPParams x

instance ToJSON LegacyJSONPParams where
  toJSON
    ( LegacyJSONPParams
        ( ShelleyPParams
            { sppTxFeePerByte
            , sppTxFeeFixed
            , sppMaxBBSize
            , sppMaxTxSize
            , sppMaxBHSize
            , sppKeyDeposit
            , sppPoolDeposit
            , sppEMax
            , sppNOpt
            , sppA0
            , sppRho
            , sppTau
            , sppD
            , sppExtraEntropy
            , sppProtocolVersion
            , sppMinUTxOValue
            , sppMinPoolCost
            }
          )
      ) =
      Aeson.object
        [ "minFeeA" .= sppTxFeePerByte
        , "minFeeB" .= sppTxFeeFixed
        , "maxBlockBodySize" .= sppMaxBBSize
        , "maxTxSize" .= sppMaxTxSize
        , "maxBlockHeaderSize" .= sppMaxBHSize
        , "keyDeposit" .= sppKeyDeposit
        , "poolDeposit" .= sppPoolDeposit
        , "eMax" .= sppEMax
        , "nOpt" .= sppNOpt
        , "a0" .= sppA0
        , "rho" .= sppRho
        , "tau" .= sppTau
        , "decentralisationParam" .= sppD
        , "extraEntropy"
            .= object
              ( case sppExtraEntropy of
                  Nonce hash ->
                    [ "tag" .= ("Nonce" :: Text)
                    , "contents" .= hash
                    ]
                  NeutralNonce -> ["tag" .= ("NeutralNonce" :: Text)]
              )
        , "protocolVersion" .= sppProtocolVersion
        , "minUTxOValue" .= sppMinUTxOValue
        , "minPoolCost" .= sppMinPoolCost
        ]

instance FromJSON ShelleyGenesis where
  parseJSON =
    Aeson.withObject "ShelleyGenesis" $ \obj ->
      ShelleyGenesis
        <$> (forceUTCTime <$> obj .: "systemStart")
        <*> obj .: "networkMagic"
        <*> obj .: "networkId"
        <*> obj .: "activeSlotsCoeff"
        <*> obj .: "securityParam"
        <*> obj .: "epochLength"
        <*> obj .: "slotsPerKESPeriod"
        <*> obj .: "maxKESEvolutions"
        <*> obj .: "slotLength"
        <*> obj .: "updateQuorum"
        <*> obj .: "maxLovelaceSupply"
        <*> (legacyFromJSONPParams <$> obj .: "protocolParams")
        <*> (forceElemsToWHNF <$> obj .: "genDelegs")
        <*> (forceElemsToWHNF <$> obj .: "initialFunds") -- TODO: disable. Move to EraTransition
        <*> obj .:? "staking" .!= emptyGenesisStaking -- TODO: remove. Move to EraTransition
        <*> (maybeToStrictMaybe <$> obj .:? "extraConfig")
    where
      forceUTCTime date =
        let !day = utctDay date
            !time = utctDayTime date
         in UTCTime day time

instance ToKeyValuePairs ShelleyGenesisStaking where
  toKeyValuePairs ShelleyGenesisStaking {sgsPools, sgsStake} =
    [ "pools" .= sgsPools
    , "stake" .= sgsStake
    ]

instance FromJSON ShelleyGenesisStaking where
  parseJSON =
    Aeson.withObject "ShelleyGenesisStaking" $ \obj ->
      ShelleyGenesisStaking
        <$> (forceElemsToWHNF <$> obj .: "pools")
        <*> (forceElemsToWHNF <$> obj .: "stake")

-- | Genesis are always encoded with the version of era they are defined in.
instance DecCBOR ShelleyGenesis where
  decCBOR =
    decodeRecordNamed "ShelleyGenesis" (const 16) $ do
      sgSystemStart <- decCBOR
      sgNetworkMagic <- decCBOR
      sgNetworkId <- decCBOR
      sgActiveSlotsCoeff <- activeSlotsCoeffDecCBOR
      sgSecurityParam <- decCBOR
      sgEpochLength <- decCBOR
      sgSlotsPerKESPeriod <- decCBOR
      sgMaxKESEvolutions <- decCBOR
      sgSlotLength <- decCBOR
      sgUpdateQuorum <- decCBOR
      sgMaxLovelaceSupply <- decCBOR
      sgProtocolParams <- decCBOR
      sgGenDelegs <- decCBOR
      sgInitialFunds <- decCBOR
      sgStaking <- decCBOR
      sgExtraConfig <- decCBOR
      pure $
        ShelleyGenesis
          sgSystemStart
          sgNetworkMagic
          sgNetworkId
          sgActiveSlotsCoeff
          sgSecurityParam
          (EpochSize sgEpochLength)
          sgSlotsPerKESPeriod
          sgMaxKESEvolutions
          sgSlotLength
          sgUpdateQuorum
          sgMaxLovelaceSupply
          sgProtocolParams
          sgGenDelegs
          sgInitialFunds
          sgStaking
          sgExtraConfig
  {-# INLINE decCBOR #-}

instance EncCBOR ShelleyGenesis

instance ToCBOR ShelleyGenesis where
  toCBOR
    ShelleyGenesis
      { sgSystemStart
      , sgNetworkMagic
      , sgNetworkId
      , sgActiveSlotsCoeff
      , sgSecurityParam
      , sgEpochLength
      , sgSlotsPerKESPeriod
      , sgMaxKESEvolutions
      , sgSlotLength
      , sgUpdateQuorum
      , sgMaxLovelaceSupply
      , sgProtocolParams
      , sgGenDelegs
      , sgInitialFunds
      , sgStaking
      , sgExtraConfig
      } =
      toPlainEncoding shelleyProtVer $
        encodeListLen 16
          <> encCBOR sgSystemStart
          <> encCBOR sgNetworkMagic
          <> encCBOR sgNetworkId
          <> activeSlotsCoeffEncCBOR sgActiveSlotsCoeff
          <> encCBOR sgSecurityParam
          <> encCBOR (unEpochSize sgEpochLength)
          <> encCBOR sgSlotsPerKESPeriod
          <> encCBOR sgMaxKESEvolutions
          <> encCBOR sgSlotLength
          <> encCBOR sgUpdateQuorum
          <> encCBOR sgMaxLovelaceSupply
          <> encCBOR sgProtocolParams
          <> encCBOR sgGenDelegs
          <> encCBOR sgInitialFunds
          <> encCBOR sgStaking
          <> encCBOR sgExtraConfig

instance FromCBOR ShelleyGenesis where
  fromCBOR = fromEraCBOR @ShelleyEra

-- | Serialize `PositiveUnitInterval` type in the same way `Rational` is serialized,
-- however ensure there is no usage of tag 30 by enforcing Shelley protocol version.
activeSlotsCoeffEncCBOR :: PositiveUnitInterval -> Encoding
activeSlotsCoeffEncCBOR = enforceEncodingVersion shelleyProtVer . encCBOR . unboundRational

-- | Deserialize `PositiveUnitInterval` type using `Rational` deserialization and fail
-- when bounds are violated. Also, ensure there is no usage of tag 30 by enforcing Shelley
-- protocol version.
activeSlotsCoeffDecCBOR :: Decoder s PositiveUnitInterval
activeSlotsCoeffDecCBOR = do
  r <- enforceDecoderVersion shelleyProtVer $ decodeRational
  case boundRational r of
    Nothing ->
      cborError $ DecoderErrorCustom "ActiveSlotsCoeff (PositiveUnitInterval)" (Text.pack $ show r)
    Just u -> pure u

{-------------------------------------------------------------------------------
  Genesis UTxO
-------------------------------------------------------------------------------}

genesisUTxO ::
  forall era.
  EraTxOut era =>
  ShelleyGenesis ->
  UTxO era
genesisUTxO genesis =
  UTxO $
    Map.fromList
      [ (txIn, txOut)
      | (addr, amount) <- LM.unListMap (sgInitialFunds genesis)
      , let txIn = initialFundsPseudoTxIn addr
            txOut = mkBasicTxOut addr (Val.inject amount)
      ]

-- | Compute the 'TxIn' of the initial UTxO pseudo-transaction corresponding
-- to the given address in the genesis initial funds.
--
-- The Shelley initial UTxO is constructed from the 'sgInitialFunds' which
-- is not a full UTxO but just a map from addresses to coin values.
--
-- This gets turned into a UTxO by making a pseudo-transaction for each address,
-- with the 0th output being the coin value. So to spend from the initial UTxO
-- we need this same 'TxIn' to use as an input to the spending transaction.
initialFundsPseudoTxIn :: Addr -> TxIn
initialFundsPseudoTxIn addr =
  TxIn (pseudoTxId addr) minBound
  where
    pseudoTxId =
      TxId
        . unsafeMakeSafeHash
        . ( H.castHash ::
              H.Hash HASH Addr ->
              H.Hash HASH EraIndependentTxBody
          )
        . H.hashWith serialiseAddr

{-------------------------------------------------------------------------------
  Genesis validation
-------------------------------------------------------------------------------}

data ValidationErr
  = EpochNotLongEnough EpochSize Word64 Rational EpochSize
  | MaxKESEvolutionsUnsupported Word64 Word
  | QuorumTooSmall Word64 Word64 Word64
  deriving (Eq, Show)

describeValidationErr :: ValidationErr -> Text
describeValidationErr (EpochNotLongEnough es secParam asc minEpochSize) =
  mconcat
    [ "Epoch length is too low. Your epoch length of "
    , Text.pack (show es)
    , " does not meet the minimum epoch length of "
    , Text.pack (show minEpochSize)
    , " required by your choice of parameters for k and f: "
    , Text.pack (show secParam)
    , " and "
    , Text.pack (show asc)
    , ". Epochs should be at least 10k/f slots long."
    ]
describeValidationErr (MaxKESEvolutionsUnsupported reqKES supportedKES) =
  mconcat
    [ "You have specified a 'maxKESEvolutions' higher"
    , " than that supported by the underlying algorithm."
    , " You requested "
    , Text.pack (show reqKES)
    , " but the algorithm supports a maximum of "
    , Text.pack (show supportedKES)
    ]
describeValidationErr (QuorumTooSmall q maxTooSmal nodes) =
  mconcat
    [ "You have specified an 'updateQuorum' which is"
    , " too small compared to the number of genesis nodes."
    , " You requested "
    , Text.pack (show q)
    , ", but given "
    , Text.pack (show nodes)
    , " genesis nodes 'updateQuorum' must be greater than "
    , Text.pack (show maxTooSmal)
    ]

-- | Do some basic sanity checking on the Shelley genesis file.
validateGenesis :: ShelleyGenesis -> Either [ValidationErr] ()
validateGenesis
  ShelleyGenesis
    { sgEpochLength
    , sgActiveSlotsCoeff
    , sgMaxKESEvolutions
    , sgSecurityParam
    , sgUpdateQuorum
    , sgGenDelegs
    } =
    case catMaybes errors of
      [] -> Right ()
      xs -> Left xs
    where
      errors =
        [ checkEpochLength
        , checkKesEvolutions
        , checkQuorumSize
        ]
      checkEpochLength =
        let activeSlotsCoeff = unboundRational sgActiveSlotsCoeff
            minLength =
              EpochSize . ceiling $
                fromIntegral @_ @Double (3 * unNonZero sgSecurityParam)
                  / fromRational activeSlotsCoeff
         in if minLength > sgEpochLength
              then
                Just $
                  EpochNotLongEnough
                    sgEpochLength
                    (unNonZero sgSecurityParam)
                    activeSlotsCoeff
                    minLength
              else Nothing
      kesPeriods = totalPeriodsKES (Proxy @(Sum6KES Ed25519DSIGN Blake2b_256))
      checkKesEvolutions =
        if sgMaxKESEvolutions <= fromIntegral kesPeriods
          then Nothing
          else Just $ MaxKESEvolutionsUnsupported sgMaxKESEvolutions kesPeriods
      checkQuorumSize =
        let numGenesisNodes = fromIntegral $ length sgGenDelegs
            maxTooSmal = numGenesisNodes `div` 2
         in if numGenesisNodes == 0 || sgUpdateQuorum > maxTooSmal
              then Nothing
              else Just $ QuorumTooSmall sgUpdateQuorum maxTooSmal numGenesisNodes

{-------------------------------------------------------------------------------
  Construct 'Globals' using 'ShelleyGenesis'
-------------------------------------------------------------------------------}

mkShelleyGlobals :: ShelleyGenesis -> EpochInfo (Either Text) -> Globals
mkShelleyGlobals genesis epochInfoAc =
  Globals
    { activeSlotCoeff = sgActiveSlotCoeff genesis
    , epochInfo = epochInfoAc
    , maxKESEvo = sgMaxKESEvolutions genesis
    , maxLovelaceSupply = sgMaxLovelaceSupply genesis
    , networkId = sgNetworkId genesis
    , quorum = sgUpdateQuorum genesis
    , randomnessStabilisationWindow
    , securityParameter = k
    , slotsPerKESPeriod = sgSlotsPerKESPeriod genesis
    , stabilityWindow
    , systemStart
    }
  where
    systemStart = SystemStart $ sgSystemStart genesis
    k = sgSecurityParam genesis
    stabilityWindow =
      computeStabilityWindow (unNonZero k) (sgActiveSlotCoeff genesis)
    randomnessStabilisationWindow =
      computeRandomnessStabilisationWindow (unNonZero k) (sgActiveSlotCoeff genesis)

{-------------------------------------------------------------------------------
  Streaming injection
-------------------------------------------------------------------------------}

-- | Source for injectable data
data InjectionData k v
  = -- | No injection data
    NoInjection
  | -- | Load data from a JSON file with hash verification
    InjectionFromFile !FsPath !(H.Hash Blake2b_256 BS.ByteString)
  | -- | Embedded data from memory
    EmbeddedInjection !(ListMap k v)
  deriving (Show, Eq, Generic, NFData, NoThunks)

instance Default (InjectionData k v) where
  def = NoInjection

instance (EncCBOR k, EncCBOR v) => EncCBOR (InjectionData k v) where
  encCBOR NoInjection = encodeListLen 1 <> encCBOR (0 :: Word)
  encCBOR (InjectionFromFile fp h) =
    encodeListLen 3 <> encCBOR (1 :: Word) <> encCBOR (fsPathToList fp) <> encCBOR h
  encCBOR (EmbeddedInjection lm) =
    encodeListLen 2 <> encCBOR (2 :: Word) <> encCBOR lm

instance (DecCBOR k, DecCBOR v) => DecCBOR (InjectionData k v) where
  decCBOR = decodeRecordSum "InjectionData" $ \case
    0 -> pure (1, NoInjection)
    1 -> do
      fp <- fsPathFromList <$> decCBOR
      h <- decCBOR
      pure (3, InjectionFromFile fp h)
    2 -> do
      lm <- decCBOR
      pure (2, EmbeddedInjection lm)
    k -> cborError $ DecoderErrorUnknownTag "InjectionData" (fromIntegral k)

instance (ToJSON k, ToJSON v, Aeson.ToJSONKey k) => ToJSON (InjectionData k v) where
  toJSON = \case
    NoInjection -> object []
    InjectionFromFile fp h -> object ["file" .= fsPathToList fp, "hash" .= H.hashToTextAsHex h]
    EmbeddedInjection lm -> object ["data" .= lm]

instance (FromJSON k, FromJSON v, Aeson.FromJSONKey k, Ord k) => FromJSON (InjectionData k v) where
  parseJSON = withObject "InjectionData" $ \o -> do
    mFile <- o .:? "file"
    mData <- o .:? "data"
    case (mFile, mData) of
      (Just segments, Nothing) -> do
        hashText <- o .: "hash"
        case H.hashFromTextAsHex hashText of
          Nothing -> fail $ "Invalid hash format: " <> show hashText
          Just h -> pure $ InjectionFromFile (fsPathFromList segments) h
      (Nothing, Just d) -> pure $ EmbeddedInjection d
      (Nothing, Nothing) -> pure NoInjection
      (Just _, Just _) ->
        fail "InjectionData: cannot specify both \"file\" and \"data\" fields"

-- | Errors that can occur during injection source resolution
data InjectionError
  = InjectionHashMismatch !FsPath !Text !Text
  | InjectionParseError !FsPath !String
  | InjectionNotAllowedOnMainnet
  | InjectionConflictingSources !String
  deriving (Show, Eq)

instance Exception InjectionError where
  displayException (InjectionHashMismatch fp expected actual) =
    "Hash mismatch for injection file "
      <> show fp
      <> ": expected "
      <> Text.unpack expected
      <> ", got "
      <> Text.unpack actual
  displayException (InjectionParseError fp err) =
    "Parse error in injection file " <> show fp <> ": " <> err
  displayException InjectionNotAllowedOnMainnet =
    "Injection of initial data is not allowed on Mainnet"
  displayException (InjectionConflictingSources msg) =
    "Conflicting injection sources: " <> msg

-- | Fold over a source of injected data: for EmbeddedInjection the data is
-- folded in memory, while for InjectionFromFile the data is streamed, hashed,
-- and parsed incrementally, with content hash verification at the end.
foldInjectionData ::
  forall k v m h acc.
  (MonadST m, MonadThrow m, FromJSON v, FromJSONKey k) =>
  HasFS m h ->
  InjectionData k v ->
  (acc -> (k, v) -> acc) ->
  acc ->
  m acc
foldInjectionData _ NoInjection _ acc0 = pure acc0
foldInjectionData _ (EmbeddedInjection lm) f acc0 =
  pure $ F.foldl' f acc0 (LM.toList lm)
foldInjectionData hasFS (InjectionFromFile fp expectedHash) f acc0 =
  withFile hasFS fp ReadMode $ \hdl -> do
    (result, actualHash) <- H.withHashContext $ \ctx -> do
      let chunks = hGetSomeStream hasFS hdl
          hashingChunks = Streaming.mapM (\c -> c <$ H.hashUpdate ctx c) chunks
      Streaming.fold_ f acc0 id (streamJsonObject hashingChunks)
    when (expectedHash /= actualHash) $
      throwIO $
        InjectionHashMismatch
          fp
          (H.hashToTextAsHex expectedHash)
          (H.hashToTextAsHex actualHash)
    pure result
  where
    -- stream key-value pairs from a JSON chunk stream
    streamJsonObject :: Stream (Of BS.ByteString) m () -> Stream (Of (k, v)) m ()
    streamJsonObject = go (runParser parser)
      where
        parser = JsonStream.objectItems JsonStream.value :: JsonStream.Parser (Text, Aeson.Value)

        go :: ParseOutput (Text, Aeson.Value) -> Stream (Of BS.ByteString) m () -> Stream (Of (k, v)) m ()
        go output chunksStream = case output of
          ParseYield (textKey, jsonValue) next -> do
            k <- case fromJSONKeyText textKey of
              Left err ->
                lift $
                  throwIO $
                    InjectionParseError fp ("Failed to parse key from text: " <> Text.unpack textKey <> ": " <> err)
              Right key -> pure key
            v <- case fromJSON jsonValue of
              Aeson.Error err ->
                lift $
                  throwIO $
                    InjectionParseError fp ("Failed to parse value for key " <> Text.unpack textKey <> ": " <> err)
              Aeson.Success val -> pure val
            Streaming.yield (k, v)
            go next chunksStream
          ParseNeedData cont -> do
            result <- lift $ Streaming.uncons chunksStream
            case result of
              Nothing -> go (cont BS.empty) (pure ())
              Just (chunk, rest) -> go (cont chunk) rest
          ParseFailed err ->
            lift $ throwIO $ InjectionParseError fp ("JSON parse error: " <> err)
          ParseDone _ -> pure ()

-- | Stream ByteString chunks from a file handle using 'hGetSome'.
hGetSomeStream :: Monad m => HasFS m h -> Handle h -> Stream (Of BS.ByteString) m ()
hGetSomeStream fs handle = go
  where
    go = do
      chunk <- lift $ hGetSome fs handle 65_536 -- 64KB
      unless (BS.null chunk) $ Streaming.yield chunk >> go
