{-# LANGUAGE RankNTypes #-}
{-# LANGUAGE ScopedTypeVariables #-}

module Hermod.Tracing.Tracer.EKG (
  ekgTracer
) where

import           Hermod.Tracing.DocuGenerator
import           Hermod.Tracing.Formatter (FormattedMessage (..))
import           Hermod.Tracing.Types
import           Hermod.Tracing.Utils (showTReal, tryEvalNF)

import           Control.Concurrent.MVar
import           Control.Exception (SomeException, displayException)
import           Control.Monad.IO.Class (MonadIO, liftIO)
import qualified Control.Tracer as T
import qualified Data.HashMap.Strict as Map
import           Data.Maybe (fromMaybe)
import           Data.Text (Text, intercalate)
import           System.IO (hPutStrLn, stderr)
import qualified System.Metrics as Metrics
import qualified System.Metrics.Counter as Counter
import qualified System.Metrics.Gauge as Gauge
import qualified System.Metrics.Label as Label


-- Using a hashmap, as metrics names typically contain long common prefixes, which is suboptimal for key lookup based on Ord
type Map = Map.HashMap

-- | It is mandatory to construct only one standard tracer in any application!
-- Throwing away a standard tracer and using a new one will result in an exception
ekgTracer :: MonadIO m => TraceConfig -> Metrics.Store -> m (Trace m FormattedMessage)
ekgTracer TraceConfig{tcMetricsPrefix} store = liftIO $ do
    rgsGauges   <- newMVar Map.empty
    rgsLabels   <- newMVar Map.empty
    rgsCounters <- newMVar Map.empty
    pure $ Trace $ T.arrow $ T.emit $
      output rgsGauges rgsLabels rgsCounters
  where
    metricsPrefix = fromMaybe mempty tcMetricsPrefix

    output :: MonadIO m =>
         MVar (Map Text Gauge.Gauge)
      -> MVar (Map Text Label.Label)
      -> MVar (Map Text Counter.Counter)
      -> (LoggingContext, Either TraceControl FormattedMessage)
      -> m ()
    output rgsGauges rgsLabels rgsCounters
      (_, Right (FormattedMetrics m)) =
        liftIO $ mapM_
          (setIt rgsGauges rgsLabels rgsCounters) m
    output _ _ _ p@(_, Left TCDocument {}) =
      docIt EKGBackend p
    output _ _ _ (LoggingContext{}, _) =
      pure ()

    setIt ::
         MVar (Map Text Gauge.Gauge)
      -> MVar (Map Text Label.Label)
      -> MVar (Map Text Counter.Counter)
      -> Metric
      -> IO ()
    setIt rgsGauges rgsLabels rgsCounters metric =
      tryEvalNF metric >>= either (\(ex :: SomeException) -> errorInPureCode $ displayException ex) go
      where
        errorInPureCode err = hPutStrLn stderr $ "Error evaluating metric " ++ show (getMetricName metric) ++ ": " ++ err
        go = \case
          IntM name theInt -> do
            let fullName = metricsPrefix <> name <> "_int"
            gauge <- modifyMVar rgsGauges (setFunc Metrics.createGauge fullName)
            Gauge.set gauge (fromIntegral theInt)
          DoubleM name theDouble -> do
            let fullName = metricsPrefix <> name <> "_real"
            label <- modifyMVar rgsLabels (setFunc Metrics.createLabel fullName)
            Label.set label (showTReal theDouble)
          LabelSetM name keyLabels -> do
            let fullName = metricsPrefix <> name
            label <- modifyMVar rgsLabels (setFunc Metrics.createLabel fullName)
            Label.set label (presentLabelSetM keyLabels)
          CounterM name action -> do
            let fullName = metricsPrefix <> name <> "_counter"
            counter <- modifyMVar rgsCounters (setFunc Metrics.createCounter fullName)
            case action of
              CounterIncrement -> Counter.inc counter
              CounterAdd i     -> Counter.add counter (fromIntegral i)

    setFunc ::
         (Text -> Metrics.Store -> IO m)
      -> Text
      -> Map Text m
      -> IO (Map Text m, m)
    setFunc createAction name rgsMap =
        case Map.lookup name rgsMap of
          Just metric -> pure (rgsMap, metric)
          Nothing -> do
            metric <- createAction name store
            let rgsMap' = Map.insert name metric rgsMap
            pure (rgsMap', metric)

    presentLabelSetM :: [(Text, Text)] -> Text
    presentLabelSetM =
      label . map pair
      where
        label pairs = "{" <> intercalate "," pairs <> "} 1"
        pair (k, v) = k <> "=\"" <> v <> "\""
