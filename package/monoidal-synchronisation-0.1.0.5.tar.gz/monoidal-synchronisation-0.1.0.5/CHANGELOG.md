# Revision history for monoidal-synchronisation

## next version

### Breaking changes

### Non-breaking changes

## 0.1.0.5

### Non-breaking changes

* ghc-9.8 support.

## 0.1.0.4

### Non-breaking changes

* Fixed cabal-fmt warnings.

## 0.1.0.3

### Non-breaking changes

* Use `io-classes-1.1`

### Non-breaking changes

* `ghc-9.4` and `ghc-9.6` compatibility.

## 0.1.0.2

* Version compatible with `ghc-9.2`

## 0.1.0.1

## 0.1.0.0 -- YYYY-mm-dd

* First version. Released on an unsuspecting world.
