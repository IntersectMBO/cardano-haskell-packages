{-# LANGUAGE TemplateHaskell #-}
{-# LANGUAGE TypeApplications #-}

-- | Golden-ish tests: every example configuration must parse through the
-- autodocodec-derived parsers (and the full file pipeline). This is the most
-- reliable validation we have, since the parser shares its codec with the
-- schema.
--
-- The @test/examples/@ and @schemas/@ fixtures are read from the source tree,
-- resolved against 'packageRoot' (the package directory, baked in at compile
-- time) rather than against the current working directory, so the tests work
-- under @cabal test@, Nix and a source distribution alike. Unlike the files the
-- library itself needs, which are compiled into it (see
-- "Cardano.Configuration.Embedded"), the fixtures are read as files: most of
-- them are fed to the file pipeline, which resolves sub-file references
-- relative to the file's own directory.
--
-- The cases form a tasty 'TestTree' of @tasty-hunit@ assertions; 'defaultMain'
-- runs them and sets the process exit code.
module Main (main) where

import Cardano.Configuration (resolveConfiguration)
import qualified Cardano.Configuration as C
import Cardano.Configuration.CliArgs (CliArgs, parseCliArgs)
import Cardano.Configuration.File
import Cardano.Configuration.File.Migrate (migrate)
import Cardano.Configuration.File.Storage
  ( LedgerDbBackendSelector (..)
  , LedgerDbConfiguration (..)
  , SnapshotOptions (..)
  , SnapshotPolicy (..)
  , resolveSnapshotPolicy
  )
import Cardano.Configuration.Genesis (GenesisReadError (..), readGenesisFile)
import Cardano.Configuration.Genesis.Byron (readByronGenesisConfig)
import Cardano.Configuration.Genesis.Injection
  ( InjectionSlot (..)
  , InjectionSource (..)
  , fileInjections
  , injectionSlots
  , missingInjectionFiles
  , renderInjectionSlot
  )
import Cardano.Configuration.Render (GenesisRendering (..), nodeConfigurationToJSON)
import Cardano.Configuration.Schema
  ( configurationSchemasWithDefaults
  , currentFormatVersion
  , legacyOneFileConfigSchemaWithDefaults
  , packageFormatVersion
  , schemaId
  , splitConfigSchemaWithDefaults
  )
import Cardano.Crypto.Hash (Blake2b_256, Hash, hashFromTextAsHex)
import Cardano.Crypto.ProtocolMagic (RequiresNetworkMagic (RequiresNoMagic))
import Cardano.Ledger.Alonzo.Genesis (AlonzoGenesis)
import Cardano.Ledger.BaseTypes (StrictMaybe (..), strictMaybeToMaybe)
import Cardano.Ledger.Conway.Genesis (ConwayGenesis)
import Cardano.Ledger.Dijkstra.Genesis (DijkstraGenesis)
import Cardano.Ledger.Shelley.Genesis (ShelleyGenesis)
import Control.Exception (SomeException, evaluate, try)
import Data.Aeson (FromJSON, Result (..), Value (..), eitherDecodeFileStrict', fromJSON, toJSON)
import qualified Data.Aeson.Key as K
import qualified Data.Aeson.KeyMap as KM
import Data.FileEmbed (makeRelativeToProject)
import Data.Functor.Identity (runIdentity)
import Data.List (isInfixOf)
import Data.Maybe (fromJust)
import qualified Data.Text as T
import Data.Word (Word64)
import Language.Haskell.TH.Syntax (lift)
import Options.Applicative (defaultPrefs, execParserPure, getParseResult, info)
import System.FS.API (fsPathToList)
import System.FilePath (takeDirectory, takeFileName, (</>))
import Test.Tasty (TestTree, defaultMain, testGroup)
import Test.Tasty.HUnit (Assertion, assertBool, assertFailure, testCase)

-- | The package directory (the one holding the @.cabal@ file), resolved at
-- compile time by @file-embed@. The fixtures live under it.
packageRoot :: FilePath
packageRoot = $(makeRelativeToProject "." >>= lift)

-- | Resolve a fixture path relative to the package root. This replaces the
-- @Paths_cardano_config@ function of the same name, which resolved the same
-- files through the Cabal data directory the package no longer installs.
getDataFileName :: FilePath -> IO FilePath
getDataFileName p = pure (packageRoot </> p)

main :: IO ()
main = do
  schema <- schemaTests
  defaultMain $ testGroup "cardano-config" (cases <> [schema])

-- | The example/parser/resolver cases, in the order they used to be checked.
cases :: [TestTree]
cases =
  [ decodeCase
      "test/examples/storage.json"
      (decodeData "test/examples/storage.json" :: IO (Either String (StorageConfiguration StrictMaybe)))
  , decodeCase
      "test/examples/consensus.json"
      (decodeData "test/examples/consensus.json" :: IO (Either String (ConsensusConfiguration StrictMaybe)))
  , decodeCase
      "test/examples/protocol.json"
      (decodeData "test/examples/protocol.json" :: IO (Either String (ProtocolConfiguration StrictMaybe)))
  , decodeCase
      "test/examples/network.json"
      (decodeData "test/examples/network.json" :: IO (Either String (NetworkConfiguration StrictMaybe)))
  , decodeCase
      "test/examples/localconnections.json"
      ( decodeData "test/examples/localconnections.json" ::
          IO (Either String (LocalConnectionsConfig StrictMaybe))
      )
  , parseCase "test/examples/fullconfig.json"
  , parseCase "test/examples/split.json"
  , parseCase "test/examples/split-all.json"
  , tracingCase
  , tracingDefaultParityCase
  , misplacedKeyCase
  , migrationWarningCase
  , migrationErrorCase
  , splitSubfileSchemaCase
  , formatVersionCase
  , migrateCase
  , migrateRenameCase
  , migrateTracingCase
  , migrateApplicationNameCase
  , migrateLedgerDbSnapshotsCase
  , migrateLedgerDbBackendCase
  , backendRoundTripCase
  , migrateSiblingCase
  , migrateEnvelopeCollisionCase
  , migrateEnvelopedRenameCase
  , migrateRenameCollisionCase
  , subfilePathConfinementCase
  , minNodeVersionCase
  , resolveCase
  , genesisRenderCase
  , roleVariantParityCase
  , roleSelectionCase
  , rolePrecedenceCase
  , roleBeatsBaseDefaultCase
  , mempoolAllUnsetCase
  , mempoolAllSetCase
  , mempoolMixedCase
  , mempoolMixedResolveCase
  , snapshotMithrilResolveCase
  , snapshotResolvePolicyCase
  , mithrilRequiresExportCase
  , lsmDatabasePathDefaultCase
  , injectionRootCase
  , injectionSlotsCase
  , injectionConflictCase
  , injectionMainnetCase
  , injectionMissingFileCase
  , dijkstraGenesisDecodeCase
  , dijkstraGenesisHashMismatchCase
  , genesisHashRequiredCase
  , genesisHashPresentCase
  , decodeCase
      "test/examples/mainnet-shelley-genesis.json (decodes via the ledger instances)"
      (decodeData "test/examples/mainnet-shelley-genesis.json" :: IO (Either String ShelleyGenesis))
  , decodeCase
      "test/examples/mainnet-alonzo-genesis.json (decodes via the ledger instances)"
      (decodeData "test/examples/mainnet-alonzo-genesis.json" :: IO (Either String AlonzoGenesis))
  , decodeCase
      "test/examples/mainnet-conway-genesis.json (decodes via the ledger instances)"
      (decodeData "test/examples/mainnet-conway-genesis.json" :: IO (Either String ConwayGenesis))
  , byronGenesisDecodeCase
  ]

-- | Fail the assertion with the message when one is present, otherwise pass.
expectOk :: Maybe String -> Assertion
expectOk = maybe (pure ()) assertFailure

-- | Decode a packaged data file (resolved via 'getDataFileName') through its
-- 'FromJSON' instance.
decodeData :: FromJSON a => FilePath -> IO (Either String a)
decodeData p = getDataFileName p >>= eitherDecodeFileStrict'

-- | Build a JSON object from string-keyed pairs (test convenience, mirroring the
-- @KM.fromList . map (first K.fromString)@ used by the inline fixtures).
obj :: [(String, Value)] -> Value
obj = Object . KM.fromList . map (\(k, v) -> (K.fromString k, v))

-- | Decode a single example via its 'FromJSON' instance, forcing the result.
decodeCase :: Show a => String -> IO (Either String a) -> TestTree
decodeCase label act =
  testCase label $ do
    res <- act
    case res of
      Left err -> assertFailure err
      Right v -> () <$ evaluate (length (show v))

-- | Parse a full configuration file (exercising sub-files).
parseCase :: FilePath -> TestTree
parseCase fp =
  testCase fp $ do
    path <- getDataFileName fp
    res <- try (parseConfigurationFiles path >>= \c -> evaluate (length (show c)))
    expectOk $ case res of
      Left (e :: SomeException) -> Just (show e)
      Right _ -> Nothing

-- | A section sub-file path must be a relative path that resolves to a file
-- within the configuration directory. An absolute path (@\/etc\/passwd@) and one
-- that climbs out of the directory with @..@ are both rejected as invalid paths,
-- so a configuration cannot pull in arbitrary files.
subfilePathConfinementCase :: TestTree
subfilePathConfinementCase =
  testCase "section sub-file paths are confined to the config directory (no absolute, no escaping)" $ do
    absolute <- rejectionMessage "test/examples/subfile-absolute.json"
    escaping <- rejectionMessage "test/examples/subfile-escapes.json"
    expectOk $ case (absolute, escaping) of
      (Just a, Just e)
        | "invalid configuration file path" `isInfixOf` a
        , "invalid configuration file path" `isInfixOf` e ->
            Nothing
      _ ->
        Just ("expected both paths rejected as invalid, got " <> show (absolute, escaping))
 where
  -- The error message if parsing was rejected, or 'Nothing' if it wrongly
  -- succeeded.
  rejectionMessage fp = do
    path <- getDataFileName fp
    res <- try (parseConfigurationFiles path)
    pure $ case res of
      Left (e :: SomeException) -> Just (show e)
      Right _ -> Nothing

-- | A component property placed flat under @Configuration@ (here a
-- @DijkstraGenesisFile@ alongside the @TestingConfig@ section that owns it) is not
-- resolved into that section: it is an unrecognised key. Parsing still succeeds
-- (the component is read from its section) and an 'UnrecognisedKeys' warning names
-- the misplaced key.
misplacedKeyCase :: TestTree
misplacedKeyCase =
  testCase "test/examples/shadow.json (a misplaced component key is unrecognised, still parses)" $ do
    path <- getDataFileName "test/examples/shadow.json"
    res <- try (parseConfigurationFiles path)
    expectOk $ case res of
      Left (e :: SomeException) -> Just (show e)
      Right (_, warnings)
        | any mentionsDijkstra warnings -> Nothing
        | otherwise ->
            Just ("expected an UnrecognisedKeys warning for DijkstraGenesisFile, got " <> show warnings)
 where
  mentionsDijkstra (UnrecognisedKeys ks) = "DijkstraGenesisFile" `elem` ks
  mentionsDijkstra _ = False

-- | Every document is migrated before parsing. One that migration changes (here a
-- legacy flat config, reshaped into the envelope) yields a 'MigratedToCurrentFormat'
-- warning; one already in the canonical form (an enveloped config with current
-- field names) migrates to itself and so does not warn.
migrationWarningCase :: TestTree
migrationWarningCase =
  testCase "a config that migration changes warns MigratedToCurrentFormat; a canonical one does not" $ do
    legacyPath <- getDataFileName "test/examples/fullconfig.json"
    envPath <- getDataFileName "test/examples/min-node-version.json"
    (_, legacyWarnings) <- parseConfigurationFiles legacyPath
    (_, envWarnings) <- parseConfigurationFiles envPath
    expectOk $
      if MigratedToCurrentFormat `elem` legacyWarnings && MigratedToCurrentFormat `notElem` envWarnings
        then Nothing
        else
          Just $
            "expected MigratedToCurrentFormat only for the non-canonical config: legacy="
              <> show legacyWarnings
              <> " enveloped="
              <> show envWarnings

-- | A document that is not in the Version1 format /and/ whose migration still
-- does not yield a parseable configuration is rejected (the parse error
-- surfaces). Here a legacy document with an ill-typed @ConsensusMode@ migrates to
-- a Version1 envelope, but the component codec then rejects the value.
migrationErrorCase :: TestTree
migrationErrorCase =
  testCase "a non-Version1 document whose migration is still unparseable is rejected" $ do
    path <- getDataFileName "test/examples/migration-unparseable.json"
    res <- try (parseConfigurationFiles path >>= \c -> evaluate (length (show c)))
    expectOk $ case res of
      Left (_ :: SomeException) -> Nothing
      Right _ -> Just "expected a parse error for a document whose migration is unparseable"

-- | Each per-component split sub-file declares a @$schema@ pointing to that
-- component's schema, and the component schema in turn declares a @$schema@
-- property — so the annotation is recognised. Guards both the fixtures and the
-- schema generation.
splitSubfileSchemaCase :: TestTree
splitSubfileSchemaCase =
  testCase "split sub-files declare $schema; component schemas have the property" $ do
    results <- mapM check pairs
    expectOk (case [m | Just m <- results] of [] -> Nothing; (m : _) -> Just m)
 where
  pairs =
    [ ("storage.json", "StorageConfig")
    , ("consensus.json", "ConsensusConfig")
    , ("protocol.json", "ProtocolConfig")
    , ("network.json", "NetworkConfig")
    , ("localconnections.json", "LocalConnectionsConfig")
    , ("mempool.json", "MempoolConfig")
    , ("testing.json", "TestingConfig")
    ]
  schemaKey = K.fromString "$schema"
  check (file, comp) = do
    sub <- decodeData ("test/examples/" <> file) :: IO (Either String Value)
    sch <- decodeData ("schemas/" <> comp <> ".schema.json") :: IO (Either String Value)
    let url = String (schemaId (comp <> ".schema.json"))
    pure $ case (sub, sch) of
      (Left e, _) -> Just (file <> ": " <> e)
      (_, Left e) -> Just (comp <> ".schema.json: " <> e)
      (Right (Object o), Right schObj)
        | KM.lookup schemaKey o /= Just url ->
            Just (file <> ": $schema is " <> show (KM.lookup schemaKey o) <> ", expected " <> show url)
        | not (KM.member schemaKey (properties schObj)) ->
            Just (comp <> ".schema.json: missing a $schema property")
        | otherwise -> Nothing
      _ -> Just (file <> ": not a JSON object")
  properties (Object o) | Just (Object p) <- KM.lookup (K.fromString "properties") o = p
  properties _ = KM.empty

-- | The newest configuration format version is the first component of the package
-- version: @cardano-config-X.y.z.v@ parses every version up to and including @X@,
-- so the schemas are not changed without bumping it. Bumping it therefore has to
-- be deliberate — a new parse path in 'parseConfigurationFiles', a new @schemas\/@
-- generation and a new @vX@ tag for the @$schema@ URLs — so this guards against
-- the package's first component moving on its own (or against the format version
-- moving without it). Pre-1.0 the package is @0.x.x.x@ while the format is already
-- 1, which 'packageFormatVersion' accounts for.
formatVersionCase :: TestTree
formatVersionCase =
  testCase "the format version matches the package version's first component" $
    expectOk $
      if currentFormatVersion == packageFormatVersion
        then Nothing
        else
          Just $
            "currentFormatVersion is "
              <> show currentFormatVersion
              <> " but the package version implies "
              <> show packageFormatVersion

-- | 'migrate' reshapes a legacy flat config into the Version1 envelope: the
-- envelope keys appear at the top, each component's flat keys are grouped under
-- its section (e.g. ConsensusMode under ConsensusConfig), a removed key
-- (MaxKnownMajorProtocolVersion) is dropped, and the result is idempotent.
migrateCase :: TestTree
migrateCase =
  testCase "migrate test/examples/fullconfig.json (legacy flat -> Version1 envelope)" $ do
    res <- decodeData "test/examples/fullconfig.json" :: IO (Either String Value)
    expectOk $ case res of
      Left err -> Just ("could not read fixture: " <> err)
      Right raw -> case fst (migrate raw) of
        m@(Object top)
          | not (all (`KM.member` top) (map K.fromString envelopeKeys)) ->
              Just ("missing envelope keys; got " <> show (KM.keys top))
          | otherwise -> case KM.lookup (K.fromString "Configuration") top of
              Just (Object cfg)
                | not (nested cfg "ProtocolConfig" "ByronGenesisFile") ->
                    Just "ProtocolConfig.ByronGenesisFile not grouped"
                | not (nested cfg "ConsensusConfig" "ConsensusMode") ->
                    Just "ConsensusConfig.ConsensusMode not grouped"
                | not (nested cfg "StorageConfig" "LedgerDB") ->
                    Just "StorageConfig.LedgerDB not grouped"
                | KM.member (K.fromString "MaxKnownMajorProtocolVersion") cfg ->
                    Just "removed key MaxKnownMajorProtocolVersion survived (should be dropped)"
                | fst (migrate m) /= m -> Just "migrate is not idempotent"
                | otherwise -> Nothing
              _ -> Just "Configuration is not an object"
        _ -> Just "migrate did not produce an object"
 where
  envelopeKeys = ["$schema", "Version", "MinNodeVersion", "Configuration"]
  nested cfg section key = case KM.lookup (K.fromString section) cfg of
    Just (Object s) -> KM.member (K.fromString key) s
    _ -> False

-- | 'migrate' rewrites the renamed fields to their current names and drops the
-- removed ones. Renamed flat keys must end up grouped under their section using
-- the /new/ name (a peer target under NetworkConfig, EnableGrpc under
-- LocalConnectionsConfig); AcceptedConnectionsLimit's sub-keys are renamed in
-- place, but that rename is scoped — a stray @delay@ elsewhere is left alone;
-- no removed key survives anywhere (including @Protocol@ and
-- @MaxKnownMajorProtocolVersion@); a genuinely-unrecognised key is kept; and the
-- result is still idempotent.
migrateRenameCase :: TestTree
migrateRenameCase =
  testCase "migrate rewrites renamed fields and drops removed ones" $ do
    res <- decodeData "test/examples/legacy-renamed-fields.json" :: IO (Either String Value)
    expectOk $ case res of
      Left err -> Just ("could not read fixture: " <> err)
      Right raw -> case fst (migrate raw) of
        m@(Object top)
          | any (`elem` removed) (allKeys m) ->
              Just ("a removed key survived; keys: " <> show (allKeys m))
          | any (`elem` oldNames) (allKeys m) ->
              Just ("an old name survived; keys: " <> show (allKeys m))
          | otherwise -> case KM.lookup (K.fromString "Configuration") top of
              Just (Object cfg)
                | not (nested cfg "NetworkConfig" "DeadlineTargetNumberOfRootPeers") ->
                    Just "renamed peer target not grouped under NetworkConfig"
                | not (nested cfg "LocalConnectionsConfig" "EnableGrpc") ->
                    Just "EnableGrpc not grouped under LocalConnectionsConfig"
                | not (deepNested cfg "NetworkConfig" "AcceptedConnectionsLimit" "HardLimit") ->
                    Just "AcceptedConnectionsLimit.HardLimit not renamed in place"
                | deepNested cfg "NetworkConfig" "AcceptedConnectionsLimit" "hardLimit" ->
                    Just "AcceptedConnectionsLimit.hardLimit not renamed"
                -- The rename is scoped: a stray top-level "delay" is not touched.
                | not (KM.member (K.fromString "delay") cfg) ->
                    Just "a stray 'delay' outside AcceptedConnectionsLimit was renamed (should be scoped)"
                -- A genuinely-unrecognised key (a typo) is kept, not dropped.
                | not (KM.member (K.fromString "SomeUnrecognisedKey") cfg) ->
                    Just "a genuinely-unrecognised key was dropped (should be kept)"
                | fst (migrate m) /= m -> Just "migrate is not idempotent"
                | otherwise -> Nothing
              _ -> Just "Configuration is not an object"
        _ -> Just "migrate did not produce an object"
 where
  removed =
    [ "PBftSignatureThreshold"
    , "LastKnownBlockVersion-Major"
    , "LastKnownBlockVersion-Minor"
    , "LastKnownBlockVersion-Alt"
    , "ApplicationVersion"
    , "EnableP2P"
    , "Protocol"
    , "MaxKnownMajorProtocolVersion"
    ]
  -- Globally-unique old names that must never survive (the generic
  -- AcceptedConnectionsLimit sub-keys are checked in place above, since a stray
  -- one is deliberately left unchanged).
  oldNames = ["EnableRpc", "RpcSocketPath", "TargetNumberOfRootPeers"]
  nested cfg section key = case KM.lookup (K.fromString section) cfg of
    Just (Object s) -> KM.member (K.fromString key) s
    _ -> False
  deepNested cfg section sub key = case KM.lookup (K.fromString section) cfg of
    Just (Object s) -> nested s sub key
    _ -> False
  -- Every object key appearing anywhere in the document.
  allKeys (Object o) = map K.toString (KM.keys o) <> concatMap allKeys (KM.elems o)
  allKeys (Array a) = concatMap allKeys a
  allKeys _ = []

-- | 'migrate' gathers the flat trace-dispatcher keys /verbatim/ into an inline
-- @HermodTracing@ object under @Configuration@ (keeping the flat names — including
-- @TraceOptionResourceFrequency@, which has no inner form), and drops the obsolete
-- iohk-monitoring keys (@UseTraceDispatcher@, @minSeverity@, …). Idempotent.
migrateTracingCase :: TestTree
migrateTracingCase =
  testCase
    "migrate gathers trace-dispatcher keys verbatim under HermodTracing and drops obsolete logging keys"
    $ expectOk
    $ case fst (migrate legacyTracing) of
      m@(Object top)
        | any (`elem` obsolete) (allKeys m) ->
            Just ("an obsolete logging key survived; keys: " <> show (allKeys m))
        | otherwise -> case KM.lookup (K.fromString "Configuration") top of
            Just (Object cfg) -> case KM.lookup (K.fromString "HermodTracing") cfg of
              Just (Object h)
                | not (all (\k -> KM.member (K.fromString k) h) tracingKeys) ->
                    Just ("HermodTracing is missing a trace-dispatcher key; has: " <> show (KM.keys h))
                -- The trace-dispatcher keys moved into HermodTracing, not left flat.
                | any (\k -> KM.member (K.fromString k) cfg) tracingKeys ->
                    Just "a trace-dispatcher key was left flat under Configuration"
                | fst (migrate m) /= m -> Just "migrate is not idempotent"
                | otherwise -> Nothing
              _ -> Just "HermodTracing was not created as an object"
            _ -> Just "Configuration is not an object"
      _ -> Just "migrate did not produce an object"
 where
  -- The flat trace-dispatcher keys that must end up (verbatim) inside HermodTracing,
  -- including the no-inner frequency key which must be kept, not dropped.
  tracingKeys =
    [ "TraceOptions"
    , "TraceOptionForwarder"
    , "TraceOptionMetricsPrefix"
    , "TraceOptionResourceFrequency"
    ]
  -- The obsolete iohk-monitoring keys that must not survive anywhere.
  obsolete =
    [ "UseTraceDispatcher"
    , "TurnOnLogging"
    , "TurnOnLogMetrics"
    , "minSeverity"
    , "defaultScribes"
    , "options"
    ]
  -- A minimal legacy flat config carrying both tracing families.
  legacyTracing =
    Object $
      KM.fromList
        [ (K.fromString "TraceOptions", Object (KM.fromList [(K.fromString "", Object KM.empty)]))
        , (K.fromString "TraceOptionForwarder", Object KM.empty)
        , (K.fromString "TraceOptionMetricsPrefix", String (T.pack "cardano.node.metrics."))
        , (K.fromString "TraceOptionResourceFrequency", Number 1000)
        , (K.fromString "UseTraceDispatcher", Bool True)
        , (K.fromString "TurnOnLogging", Bool True)
        , (K.fromString "TurnOnLogMetrics", Bool True)
        , (K.fromString "minSeverity", String (T.pack "Critical"))
        , (K.fromString "defaultScribes", Array mempty)
        , (K.fromString "options", Object KM.empty)
        ]
  allKeys (Object o) = map K.toString (KM.keys o) <> concatMap allKeys (KM.elems o)
  allKeys (Array a) = concatMap allKeys a
  allKeys _ = []

-- | 'migrate' collapses a top-level @ApplicationName@ (the obsolete Byron
-- software-version name, now repurposed as the tracing node name) into
-- @HermodTracing.TraceOptionNodeName@, and drops the Byron @ApplicationVersion@.
-- The result is idempotent.
migrateApplicationNameCase :: TestTree
migrateApplicationNameCase =
  testCase
    "migrate collapses top-level ApplicationName to HermodTracing.TraceOptionNodeName, drops ApplicationVersion"
    $ expectOk
    $ case fst (migrate legacyByron) of
      m@(Object top)
        | "ApplicationVersion" `elem` allKeys m -> Just "ApplicationVersion survived"
        | "ApplicationName" `elem` allKeys m -> Just "top-level ApplicationName was not collapsed"
        | otherwise -> case KM.lookup (K.fromString "Configuration") top of
            Just (Object cfg) -> case KM.lookup (K.fromString "HermodTracing") cfg of
              Just (Object h) -> case KM.lookup (K.fromString "TraceOptionNodeName") h of
                Just (String n)
                  | n /= T.pack "cardano-sl" -> Just ("TraceOptionNodeName has wrong value: " <> show n)
                  | fst (migrate m) /= m -> Just "migrate is not idempotent"
                  | otherwise -> Nothing
                _ -> Just "HermodTracing.TraceOptionNodeName is missing"
              _ -> Just "HermodTracing was not created as an object"
            _ -> Just "Configuration is not an object"
      _ -> Just "migrate did not produce an object"
 where
  -- A legacy flat config with the Byron software version at the top level, plus
  -- TraceOptions so the resulting HermodTracing is a valid tracing object.
  legacyByron =
    Object $
      KM.fromList
        [ (K.fromString "ApplicationName", String (T.pack "cardano-sl"))
        , (K.fromString "ApplicationVersion", Number 0)
        , (K.fromString "TraceOptions", Object (KM.fromList [(K.fromString "", Object KM.empty)]))
        ]
  allKeys (Object o) = map K.toString (KM.keys o) <> concatMap allKeys (KM.elems o)
  allKeys (Array a) = concatMap allKeys a
  allKeys _ = []

-- | 'migrate' gathers the flat snapshot-option keys directly under @LedgerDB@
-- (which legacy configs and the node parser accept there) into a nested
-- @LedgerDB.Snapshots@ object — the form cardano-config's @LedgerDB@ codec reads.
-- @Backend@/@QueryBatchSize@ stay at the @LedgerDB@ level. Idempotent.
migrateLedgerDbSnapshotsCase :: TestTree
migrateLedgerDbSnapshotsCase =
  testCase "migrate gathers flat LedgerDB snapshot options into LedgerDB.Snapshots" $
    expectOk $ case fst (migrate legacyLedgerDB) of
      m@Object{} -> case navigate m ["Configuration", "StorageConfig", "LedgerDB"] of
        Just (Object ldb)
          | any (\k -> KM.member (K.fromString k) ldb) snapOpts ->
              Just ("a flat snapshot key stayed at the LedgerDB level; keys: " <> show (KM.keys ldb))
          | not (KM.member (K.fromString "Backend") ldb && KM.member (K.fromString "QueryBatchSize") ldb) ->
              Just "Backend/QueryBatchSize were not kept at the LedgerDB level"
          | otherwise -> case KM.lookup (K.fromString "Snapshots") ldb of
              Just (Object snaps)
                | not (all (\k -> KM.member (K.fromString k) snaps) snapOpts) ->
                    Just ("LedgerDB.Snapshots is missing a moved key; has: " <> show (KM.keys snaps))
                | fst (migrate m) /= m -> Just "migrate is not idempotent"
                | otherwise -> Nothing
              _ -> Just "LedgerDB.Snapshots was not created as an object"
        _ -> Just "Configuration.StorageConfig.LedgerDB not found"
      _ -> Just "migrate did not produce an object"
 where
  snapOpts = ["SnapshotInterval", "NumOfDiskSnapshots"]
  legacyLedgerDB =
    Object $
      KM.fromList
        [
          ( K.fromString "LedgerDB"
          , Object $
              KM.fromList
                [ (K.fromString "Backend", String (T.pack "V2InMemory"))
                , (K.fromString "QueryBatchSize", Number 100000)
                , (K.fromString "SnapshotInterval", Number 864)
                , (K.fromString "NumOfDiskSnapshots", Number 2)
                ]
          )
        ]
  navigate v [] = Just v
  navigate (Object o) (k : ks) = KM.lookup (K.fromString k) o >>= \v -> navigate v ks
  navigate _ _ = Nothing

-- | 'migrate' folds the legacy flat @V2LSM@ backend keys under @LedgerDB@ into the
-- tagged @Backend: { "LSM": { "DatabasePath": …, "ExportPath": … } }@ form.
migrateLedgerDbBackendCase :: TestTree
migrateLedgerDbBackendCase =
  testCase "migrate folds the flat V2LSM backend into Backend.LSM" $
    expectOk $ case fst (migrate legacyLedgerDB) of
      m@Object{} -> case navigate m ["Configuration", "StorageConfig", "LedgerDB"] of
        Just (Object ldb)
          | any (\k -> KM.member (K.fromString k) ldb) ["LSMDatabasePath", "LSMExportPath"] ->
              Just ("a flat LSM key stayed at the LedgerDB level; keys: " <> show (KM.keys ldb))
          | otherwise -> case KM.lookup (K.fromString "Backend") ldb of
              Just (Object be) -> case KM.lookup (K.fromString "LSM") be of
                Just (Object lsm)
                  | KM.lookup (K.fromString "DatabasePath") lsm == Just (String (T.pack "lsm"))
                      && KM.lookup (K.fromString "ExportPath") lsm == Just (String (T.pack "lsm-export")) ->
                      if fst (migrate m) == m then Nothing else Just "migrate is not idempotent"
                  | otherwise -> Just ("Backend.LSM has wrong contents: " <> show (KM.toList lsm))
                _ -> Just "Backend.LSM was not created as an object"
              other -> Just ("Backend was not folded into an object: " <> show other)
        _ -> Just "Configuration.StorageConfig.LedgerDB not found"
      _ -> Just "migrate did not produce an object"
 where
  legacyLedgerDB =
    Object $
      KM.fromList
        [
          ( K.fromString "LedgerDB"
          , Object $
              KM.fromList
                [ (K.fromString "Backend", String (T.pack "V2LSM"))
                , (K.fromString "LSMDatabasePath", String (T.pack "lsm"))
                , (K.fromString "LSMExportPath", String (T.pack "lsm-export"))
                ]
          )
        ]
  navigate v [] = Just v
  navigate (Object o) (k : ks) = KM.lookup (K.fromString k) o >>= \v -> navigate v ks
  navigate _ _ = Nothing

-- | The @Backend@ codec round-trips both forms: the @"V2InMemory"@ string and the
-- tagged @{ "LSM": { … } }@ object.
backendRoundTripCase :: TestTree
backendRoundTripCase =
  testCase "LedgerDB Backend round-trips (V2InMemory string, tagged LSM object)" $ do
    check V2InMemory
    check (V2LSM (SJust "db") (SJust "exp"))
    check (V2LSM SNothing SNothing)
 where
  check sel =
    let ldb = LedgerDbConfiguration SNothing SNothing (SJust sel)
     in case fromJSON (toJSON ldb) of
          Success ldb' ->
            assertBool
              ("round-trip changed the backend: " <> show (backendSelector ldb'))
              (backendSelector ldb' == SJust sel)
          Error e -> assertFailure ("round-trip failed to decode: " <> e)

-- | 'migrate' does not drop a top-level sibling of an existing @Configuration@
-- envelope: a stray @ByronGenesisFile@ next to the envelope is folded into the
-- body and regrouped under its owning section (@ProtocolConfig@), and the pre-existing
-- @StorageConfig@ section is preserved. (Regression test for the reviewer's
-- "enveloped file drops its siblings" concern.)
migrateSiblingCase :: TestTree
migrateSiblingCase =
  testCase "migrate keeps a top-level sibling of the Configuration envelope (regroups, not drops)" $
    expectOk $ case migrate input of
      (Object top, warnings)
        | not (null warnings) -> Just ("expected no warnings, got " <> show warnings)
        | otherwise -> case KM.lookup (K.fromString "Configuration") top of
            Just (Object cfg)
              | not (nested cfg "ProtocolConfig" "ByronGenesisFile") ->
                  Just "the sibling ByronGenesisFile was dropped, not regrouped under ProtocolConfig"
              | not (KM.member (K.fromString "StorageConfig") cfg) ->
                  Just "the pre-existing StorageConfig section was lost"
              | otherwise -> Nothing
            _ -> Just "Configuration is not an object"
      _ -> Just "migrate did not produce an object"
 where
  input =
    obj
      [ ("Version", Number 1)
      , ("Configuration", obj [("StorageConfig", String (T.pack "storage.json"))])
      , ("ByronGenesisFile", String (T.pack "byron.json"))
      ]
  nested cfg section key = case KM.lookup (K.fromString section) cfg of
    Just (Object s) -> KM.member (K.fromString key) s
    _ -> False

-- | When a key appears both as a top-level sibling and inside the @Configuration@
-- envelope, 'migrate' keeps the value inside @Configuration@ (the canonical
-- location) and raises an 'EnvelopeKeyCollision' warning naming the key.
migrateEnvelopeCollisionCase :: TestTree
migrateEnvelopeCollisionCase =
  testCase
    "migrate resolves a sibling/Configuration collision in favour of Configuration (with a warning)"
    $ expectOk
    $ case migrate input of
      (Object top, warnings)
        | EnvelopeKeyCollision (T.pack "MempoolConfig") `notElem` warnings ->
            Just ("expected an EnvelopeKeyCollision for MempoolConfig, got " <> show warnings)
        | otherwise -> case KM.lookup (K.fromString "Configuration") top of
            Just (Object cfg) -> case KM.lookup (K.fromString "MempoolConfig") cfg of
              Just (Object m)
                | KM.lookup (K.fromString "MempoolCapacityOverride") m /= Just (Number 100) ->
                    Just
                      ( "the Configuration value (100) should win, got "
                          <> show (KM.lookup (K.fromString "MempoolCapacityOverride") m)
                      )
                | otherwise -> Nothing
              _ -> Just "MempoolConfig is not an object"
            _ -> Just "Configuration is not an object"
      _ -> Just "migrate did not produce an object"
 where
  input =
    obj
      [ ("Configuration", obj [("MempoolConfig", obj [("MempoolCapacityOverride", Number 100)])])
      , ("MempoolConfig", obj [("MempoolCapacityOverride", Number 999)])
      ]

-- | 'migrate' rewrites a pre-rename field name even when the document is /already/
-- enveloped (the parser used to skip migration for enveloped documents, so an
-- enveloped @EnableRpc@ silently reverted to its default). It also carries an
-- existing @$schema@ through unchanged, rather than clobbering a user's pinned URL.
-- (Regression test for the reviewer's "enveloped legacy fields skipped" and
-- "unconditional schema replacement" concerns.)
migrateEnvelopedRenameCase :: TestTree
migrateEnvelopedRenameCase =
  testCase "migrate renames fields inside an existing envelope and carries $schema through" $
    expectOk $ case migrate input of
      (m@(Object top), _)
        | KM.lookup (K.fromString "$schema") top /= Just pinnedSchema ->
            Just
              ("the pinned $schema was not carried through, got " <> show (KM.lookup (K.fromString "$schema") top))
        | "EnableRpc" `elem` allKeys m ->
            Just "the old name EnableRpc survived the rename"
        | otherwise -> case KM.lookup (K.fromString "Configuration") top of
            Just (Object cfg)
              | not (nested cfg "LocalConnectionsConfig" "EnableGrpc") ->
                  Just "EnableRpc was not renamed to EnableGrpc under LocalConnectionsConfig"
              | otherwise -> Nothing
            _ -> Just "Configuration is not an object"
      (m, _) -> Just ("migrate did not produce an object: " <> show m)
 where
  pinnedSchema = String (T.pack "https://example.com/pinned/config.schema.json")
  input =
    obj
      [ ("$schema", pinnedSchema)
      , ("Version", Number 1)
      , ("Configuration", obj [("LocalConnectionsConfig", obj [("EnableRpc", Bool True)])])
      ]
  nested cfg section key = case KM.lookup (K.fromString section) cfg of
    Just (Object s) -> KM.member (K.fromString key) s
    _ -> False
  allKeys (Object o) = map K.toString (KM.keys o) <> concatMap allKeys (KM.elems o)
  allKeys (Array a) = concatMap allKeys a
  allKeys _ = []

-- | When both the old and the current name of a renamed field sit in the same
-- object, 'migrate' keeps the current-name value (deterministically, not by
-- iteration order), drops the old-name one, and raises a 'RenamedKeyCollision'
-- warning. (Regression test for the reviewer's "key collision during renames"
-- concern.)
migrateRenameCollisionCase :: TestTree
migrateRenameCollisionCase =
  testCase "migrate keeps the current name on an old/new rename collision (with a warning)" $
    expectOk $ case migrate input of
      (Object top, warnings)
        | expectedWarning `notElem` warnings ->
            Just ("expected a RenamedKeyCollision warning, got " <> show warnings)
        | otherwise -> case KM.lookup (K.fromString "Configuration") top of
            Just (Object cfg) -> case KM.lookup (K.fromString "NetworkConfig") cfg of
              Just (Object n)
                | KM.member (K.fromString "TargetNumberOfRootPeers") n ->
                    Just "the old name TargetNumberOfRootPeers survived (should be dropped)"
                | KM.lookup (K.fromString "DeadlineTargetNumberOfRootPeers") n /= Just (Number 2) ->
                    Just
                      ( "the current-name value (2) should win, got "
                          <> show (KM.lookup (K.fromString "DeadlineTargetNumberOfRootPeers") n)
                      )
                | otherwise -> Nothing
              _ -> Just "NetworkConfig is not an object"
            _ -> Just "Configuration is not an object"
      _ -> Just "migrate did not produce an object"
 where
  expectedWarning =
    RenamedKeyCollision (T.pack "TargetNumberOfRootPeers") (T.pack "DeadlineTargetNumberOfRootPeers")
  input =
    obj
      [
        ( "Configuration"
        , obj
            [
              ( "NetworkConfig"
              , obj
                  [ ("TargetNumberOfRootPeers", Number 1)
                  , ("DeadlineTargetNumberOfRootPeers", Number 2)
                  ]
              )
            ]
        )
      ]

-- | The optional top-level @MinNodeVersion@ annotation is read from the same
-- level as @Version@: from inside the @{ Version, Configuration }@ envelope, and
-- — when the document is not enveloped — from the top level alongside the
-- (section or flat) configuration keys. A document that omits it parses to
-- 'Nothing'.
minNodeVersionCase :: TestTree
minNodeVersionCase =
  testCase "MinNodeVersion is read at the top level (enveloped and legacy), or absent" $ do
    enveloped <- parsedMinNodeVersion "test/examples/min-node-version.json"
    legacy <- parsedMinNodeVersion "test/examples/min-node-version-legacy.json"
    absent <- parsedMinNodeVersion "test/examples/split.json"
    expectOk $
      if enveloped == SJust (T.pack "10.5.0")
        && legacy == SJust (T.pack "9.1.0")
        && absent == SNothing
        then Nothing
        else
          Just $
            "unexpected MinNodeVersion: enveloped="
              <> show enveloped
              <> " legacy="
              <> show legacy
              <> " absent="
              <> show absent
 where
  parsedMinNodeVersion fp = do
    path <- getDataFileName fp
    (cfg, _) <- parseConfigurationFiles path
    pure (minNodeVersion cfg)

-- | Resolving a parsed configuration with default CLI arguments must succeed and
-- produce a complete (@Identity@) configuration, which exercises that the base
-- defaults populate every resolved field.
resolveCase :: TestTree
resolveCase =
  testCase "resolveConfiguration examples/fullconfig.json" $ do
    path <- getDataFileName "test/examples/fullconfig.json"
    (cfg, _) <- parseConfigurationFiles path
    case cliArgs [] of
      Nothing -> assertFailure "could not build default CLI arguments"
      Just cli -> case resolveConfiguration cli cfg of
        Left err -> assertFailure (show err)
        Right (nc, _) -> () <$ evaluate (length (show nc))

-- | The top-level @HermodTracing@ key is resolved by trace-dispatcher's parser
-- into a 'TraceConfig' — whether given inline (an object) or as a path to a
-- separate file — and surfaced both on the parse result and, when the resolved
-- configuration is dumped, back under a @HermodTracing@ key. A configuration
-- without the key falls back to 'defaultCardanoTracingConfig', which is likewise
-- surfaced and rendered (so the @HermodTracing@ key always appears).
tracingCase :: TestTree
tracingCase =
  testCase "HermodTracing resolves to a TraceConfig (inline, file, default) and is always rendered" $ do
    inline <- parsed "test/examples/tracing-inline.json"
    fromFile <- parsed "test/examples/tracing-file.json"
    absent <- parsed "test/examples/fullconfig.json"
    renderedInline <- rendersTracing "test/examples/tracing-inline.json"
    renderedAbsent <- rendersTracing "test/examples/fullconfig.json"
    let asJSON = toJSON . tracingConfiguration
        deflt = toJSON defaultCardanoTracingConfig
    expectOk $
      if asJSON inline /= deflt -- the inline object was applied
        && asJSON fromFile /= deflt -- the referenced file was applied
        && asJSON absent == deflt -- no key falls back to the default
        && renderedInline == Right True
        && renderedAbsent == Right True -- rendered even without a key
        then Nothing
        else
          Just $
            "unexpected tracing resolution: inlineIsDefault="
              <> show (asJSON inline == deflt)
              <> " fileIsDefault="
              <> show (asJSON fromFile == deflt)
              <> " absentIsDefault="
              <> show (asJSON absent == deflt)
              <> " renderedInline="
              <> show renderedInline
              <> " renderedAbsent="
              <> show renderedAbsent
 where
  parsed fp = getDataFileName fp >>= fmap fst . parseConfigurationFiles
  -- Whether the resolved configuration renders a HermodTracing key.
  rendersTracing fp = do
    path <- getDataFileName fp
    (cfg, _) <- parseConfigurationFiles path
    pure $ case cliArgs [] of
      Nothing -> Left "could not build CLI arguments"
      Just cli -> case resolveConfiguration cli cfg of
        Left e -> Left ("resolve failed: " <> show e)
        Right (nc, _) -> case nodeConfigurationToJSON OmitGeneses nc of
          Object o -> Right (KM.member (K.fromString "HermodTracing") o)
          _ -> Left "rendered configuration was not an object"

-- | The committed @defaults/HermodTracing.json@ must equal the JSON of the
-- in-tree 'defaultCardanoTracingConfig' literal (encoded through
-- trace-dispatcher's own 'TraceConfig' codec), so the checked-in default cannot
-- drift from the Haskell source. Regenerate the file from
-- 'defaultCardanoTracingConfig' if this fails.
tracingDefaultParityCase :: TestTree
tracingDefaultParityCase =
  testCase "defaults/HermodTracing.json matches defaultCardanoTracingConfig" $ do
    path <- getDataFileName "defaults/HermodTracing.json"
    committed <- eitherDecodeFileStrict' path :: IO (Either String Value)
    expectOk $ case committed of
      Left e -> Just ("could not read defaults/HermodTracing.json: " <> e)
      Right v
        | toJSON defaultCardanoTracingConfig == v -> Nothing
        | otherwise ->
            Just $
              "defaults/HermodTracing.json is out of date; regenerate from defaultCardanoTracingConfig: "
                <> show (toJSON defaultCardanoTracingConfig)
                <> " /= "
                <> show v

-- | With 'IncludeGeneses' the resolved configuration renders the decoded value
-- of every era genesis (Byron via its canonical-JSON form, the rest via the
-- ledger's aeson instances), not just the file references; with 'OmitGeneses'
-- none appear. These are the files read and hash-checked at parse time.
genesisRenderCase :: TestTree
genesisRenderCase =
  testCase "resolve renders era geneses only with IncludeGeneses" $ do
    path <- getDataFileName "test/examples/fullconfig.json"
    (cfg, _) <- parseConfigurationFiles path
    expectOk $ case cliArgs [] of
      Nothing -> Just "could not build CLI arguments"
      Just cli -> case resolveConfiguration cli cfg of
        Left e -> Just ("resolve failed: " <> show e)
        Right (nc, _) ->
          let keysOf r = case nodeConfigurationToJSON r nc of
                Object o -> [k | k <- eras, maybe False nonEmpty (KM.lookup (K.fromString k) o)]
                _ -> []
              nonEmpty (Object m) = not (KM.null m)
              nonEmpty _ = False
           in if keysOf IncludeGeneses == eras && null (keysOf OmitGeneses)
                then Nothing
                else Just "geneses not gated correctly by IncludeGeneses/OmitGeneses"
 where
  eras = ["ByronGenesis", "ShelleyGenesis", "AlonzoGenesis", "ConwayGenesis"]

-- | The inline role-default partials must equal the committed variant JSON
-- (Option B parity): they are encoded through the same codec and compared to the
-- raw files, so the Haskell literals cannot drift from the data files.
roleVariantParityCase :: TestTree
roleVariantParityCase =
  testCase "network role defaults match the committed variant JSON" $ do
    bpPath <- getDataFileName "defaults/NetworkConfig/blockproducer.json"
    relayPath <- getDataFileName "defaults/NetworkConfig/relay.json"
    bp <- eitherDecodeFileStrict' bpPath :: IO (Either String Value)
    relay <- eitherDecodeFileStrict' relayPath :: IO (Either String Value)
    let dropSchema (Object km) = Object (KM.delete (K.fromString "$schema") km)
        dropSchema _ = error "Impossible"
    expectOk $ case (fmap dropSchema bp, fmap dropSchema relay) of
      (Left e, _) -> Just ("could not read blockproducer.json: " <> e)
      (_, Left e) -> Just ("could not read relay.json: " <> e)
      (Right bpV, Right relayV)
        | toJSON blockProducerRoleDefaults /= bpV ->
            Just $
              "blockProducerRoleDefaults differs from NetworkConfig.blockproducer.json: "
                <> show (toJSON blockProducerRoleDefaults)
                <> " /= "
                <> show bpV
        | toJSON relayRoleDefaults /= relayV ->
            Just $
              "relayRoleDefaults differs from NetworkConfig.relay.json: "
                <> show (toJSON relayRoleDefaults)
                <> " /= "
                <> show relayV
        | otherwise -> Nothing

-- | The networking role defaults are chosen by credential presence: a credential
-- (here a VRF key) yields the block-producer targets (root 100, known 100,
-- PeerSharing off); no credential yields the relay targets (root 60, known 150,
-- PeerSharing on). These values are the node's @defaultDeadlineTargets@ oracle.
roleSelectionCase :: TestTree
roleSelectionCase =
  testCase "network role defaults selected from credential presence" $ do
    path <- getDataFileName "test/examples/fullconfig.json"
    (cfg, _) <- parseConfigurationFiles path
    expectOk $ case (cliArgs ["--shelley-vrf-key", "vrf.skey"], cliArgs []) of
      (Just bpCli, Just relayCli) ->
        case (resolveConfiguration bpCli cfg, resolveConfiguration relayCli cfg) of
          (Left e, _) -> Just ("block-producer resolve failed: " <> show e)
          (_, Left e) -> Just ("relay resolve failed: " <> show e)
          (Right (bpNc, _), Right (relayNc, _)) ->
            let bn = C.networkConfiguration bpNc
                rn = C.networkConfiguration relayNc
                ok =
                  deadlineTargetOfRootPeers bn == SJust 100
                    && deadlineTargetOfKnownPeers bn == SJust 100
                    && peerSharing bn == SJust False
                    && deadlineTargetOfRootPeers rn == SJust 60
                    && deadlineTargetOfKnownPeers rn == SJust 150
                    && peerSharing rn == SJust True
             in if ok
                  then Nothing
                  else Just "resolved role targets do not match the expected block-producer/relay values"
      _ -> Just "could not build CLI arguments"

-- | An explicit file value for a role field wins over the role default, even
-- when credentials are present (block producer). Here PeerSharing and
-- TargetNumberOfRootPeers are set in the file; the remaining role fields still
-- come from the (block-producer) role default.
rolePrecedenceCase :: TestTree
rolePrecedenceCase =
  testCase "explicit file value overrides the role default" $ do
    path <- getDataFileName "test/examples/role-precedence.json"
    (cfg, _) <- parseConfigurationFiles path
    expectOk $ case cliArgs ["--shelley-vrf-key", "vrf.skey"] of
      Nothing -> Just "could not build CLI arguments"
      Just cli -> case resolveConfiguration cli cfg of
        Left e -> Just ("resolve failed: " <> show e)
        Right (nc, _) ->
          let n = C.networkConfiguration nc
           in if peerSharing n == SJust True -- file wins over block-producer's False
                && deadlineTargetOfRootPeers n == SJust 999 -- file wins over 100
                && deadlineTargetOfKnownPeers n == SJust 100 -- unset in file, block-producer default
                then Nothing
                else Just "explicit file values did not take precedence over the role default"

-- | The role default beats a /base/ default for a role field the user did not
-- set: resolution is @base \< role \< user@, so a value present only in the base
-- defaults must not shadow the role default. The base @Network.json@ omits the
-- role fields today, so this pins the ordering rather than relying on that.
roleBeatsBaseDefaultCase :: TestTree
roleBeatsBaseDefaultCase =
  testCase "role default overrides a base default (base < role < user)" $
    expectOk
      ( if peerSharing resolved == SJust False -- role's False beats the base's True
          && deadlineTargetOfRootPeers resolved == SJust 100 -- role's 100 beats the base's 7
          then Nothing
          else Just ("role default did not override the base default: " <> show resolved)
      )
 where
  -- A base default that sets two role fields, with the user setting nothing. The
  -- merged layer (base defaults plus the user layer) then equals the base here.
  base =
    emptyNetworkConfiguration
      { peerSharing = SJust True
      , deadlineTargetOfRootPeers = SJust 7
      }
  user = emptyNetworkConfiguration
  resolved = withRoleDefaults blockProducerRoleDefaults user base

-- | All three mempool timeouts unset resolves to the coupled default (1, 1.5, 5).
mempoolAllUnsetCase :: TestTree
mempoolAllUnsetCase =
  testCase "mempool timeouts: all-unset takes the coupled (1, 1.5, 5) default" $
    expectOk
      ( case finalizeMempool (MempoolConfiguration SNothing SNothing SNothing SNothing) of
          Left e -> Just ("unexpected rejection: " <> e)
          Right c
            | runIdentity (mempoolTimeoutSoft c) == 1
            , runIdentity (mempoolTimeoutHard c) == 1.5
            , runIdentity (mempoolTimeoutCapacity c) == 5 ->
                Nothing
            | otherwise -> Just "wrong coupled-default timeout values"
      )

-- | All three mempool timeouts set are preserved unchanged.
mempoolAllSetCase :: TestTree
mempoolAllSetCase =
  testCase "mempool timeouts: all-set are preserved" $
    expectOk
      ( case finalizeMempool (MempoolConfiguration SNothing (SJust 2) (SJust 3) (SJust 4)) of
          Left e -> Just ("unexpected rejection: " <> e)
          Right c
            | runIdentity (mempoolTimeoutSoft c) == 2
            , runIdentity (mempoolTimeoutHard c) == 3
            , runIdentity (mempoolTimeoutCapacity c) == 4 ->
                Nothing
            | otherwise -> Just "set timeout values were not preserved"
      )

-- | A mix of set and unset mempool timeouts is rejected by 'finalizeMempool'.
mempoolMixedCase :: TestTree
mempoolMixedCase =
  testCase "mempool timeouts: a partial set is rejected" $
    expectOk
      ( case finalizeMempool (MempoolConfiguration SNothing (SJust 1) SNothing SNothing) of
          Left _ -> Nothing
          Right _ -> Just "expected a partial set of timeouts to be rejected"
      )

-- | The all-or-nothing rule surfaces end-to-end: a configuration that sets only
-- one timeout makes 'resolveConfiguration' fail with a 'ConfigResolutionError'.
mempoolMixedResolveCase :: TestTree
mempoolMixedResolveCase =
  testCase "test/examples/mempool-mixed.json (partial mempool timeouts rejected on resolve)" $ do
    path <- getDataFileName "test/examples/mempool-mixed.json"
    (cfg, _) <- parseConfigurationFiles path
    expectOk $ case cliArgs [] of
      Nothing -> Just "could not build CLI arguments"
      Just cli -> case resolveConfiguration cli cfg of
        Left _ -> Nothing
        Right _ -> Just "expected resolution to reject a partial set of mempool timeouts"

-- | Parse @cardano-node@-style CLI arguments for a test (no defaults file is
-- needed; the parser supplies its own).
cliArgs :: [String] -> Maybe CliArgs
cliArgs = getParseResult . execParserPure defaultPrefs (info parseCliArgs mempty)

-- | The snapshot fields, in a fixed order, for comparison.
snapshotFields :: SnapshotOptions -> [Maybe Word64]
snapshotFields o =
  map
    strictMaybeToMaybe
    [ snapshotInterval o
    , slotOffset o
    , snapshotRateLimit o
    , minDelay o
    , maxDelay o
    , numOfDiskSnapshots o
    ]

-- | The concrete values the @"Mithril"@ policy resolves to.
mithrilFields :: [Maybe Word64]
mithrilFields = [Just 432000, Just 388800, Just 600, Just 300, Just 600, Just 2]

-- | End-to-end: a configuration that uses the base @"Mithril"@ default and one
-- that sets only a couple of snapshot options both resolve to the full concrete
-- Mithril option set (the partial one inheriting the rest).
snapshotMithrilResolveCase :: TestTree
snapshotMithrilResolveCase =
  testCase "Mithril snapshot policy resolves to concrete values (filling partial overrides)" $ do
    fromMithril <- resolvedOptions "test/examples/role-precedence.json" -- no Snapshots ⇒ base "Mithril"
    fromPartial <- resolvedOptions "test/examples/fullconfig.json" -- sets 3 of 6 (= Mithril)
    expectOk $ case (fromMithril, fromPartial) of
      (Right a, Right b)
        | a == mithrilFields && b == mithrilFields -> Nothing
        | otherwise -> Just ("unexpected resolved options: " <> show a <> " / " <> show b)
      (Left e, _) -> Just e
      (_, Left e) -> Just e
 where
  resolvedOptions cfgFile = do
    path <- getDataFileName cfgFile
    (cfg, _) <- parseConfigurationFiles path
    pure $ case cliArgs [] of
      Nothing -> Left "could not build CLI arguments"
      Just cli -> case resolveConfiguration cli cfg of
        Left e -> Left (show e)
        Right (nc, _) -> case snapshots (runIdentity (ledgerDbConfiguration (C.storageConfiguration nc))) of
          SJust (CustomSnapshotPolicy o) -> Right (snapshotFields o)
          other -> Left ("expected resolved custom snapshot options, got " <> show other)

-- | 'resolveSnapshotPolicy': @"Mithril"@ yields its values, and a partial custom
-- policy keeps the value it set (here a distinct @SnapshotInterval@) while the
-- rest are inherited from Mithril.
snapshotResolvePolicyCase :: TestTree
snapshotResolvePolicyCase =
  testCase "resolveSnapshotPolicy fills a partial custom policy from Mithril" $
    expectOk
      ( let mithril = snapshotFields (resolveSnapshotPolicy MithrilSnapshotPolicy)
            partial = SnapshotOptions (SJust 7777) SNothing SNothing SNothing SNothing SNothing
            filled = snapshotFields (resolveSnapshotPolicy (CustomSnapshotPolicy partial))
         in if mithril == mithrilFields && filled == [Just 7777, Just 388800, Just 600, Just 300, Just 600, Just 2]
              then Nothing
              else Just ("unexpected: mithril=" <> show mithril <> " filled=" <> show filled)
      )

-- | The Mithril policy under the V2LSM backend without an @LSMExportPath@ is
-- accepted, but resolution surfaces a non-fatal 'ConsistencyWarning' (the check
-- runs before the Mithril policy is resolved away).
mithrilRequiresExportCase :: TestTree
mithrilRequiresExportCase =
  testCase "Mithril + V2LSM without LSMExportPath resolves with a warning" $ do
    path <- getDataFileName "test/examples/lsm-mithril-no-export.json"
    (cfg, _) <- parseConfigurationFiles path
    expectOk $ case cliArgs [] of
      Nothing -> Just "could not build CLI arguments"
      Just cli -> case resolveConfiguration cli cfg of
        Left e -> Just ("expected acceptance with a warning, got rejection: " <> show e)
        Right (_, warnings)
          | any isConsistencyWarning warnings -> Nothing
          | otherwise -> Just ("expected a ConsistencyWarning, got: " <> show warnings)
 where
  isConsistencyWarning ConsistencyWarning{} = True
  isConsistencyWarning _ = False

-- | The V2LSM backend defaults its database path to @"lsm"@ when the
-- configuration leaves @LSMDatabasePath@ unset.
lsmDatabasePathDefaultCase :: TestTree
lsmDatabasePathDefaultCase =
  testCase "V2LSM defaults LSMDatabasePath to \"lsm\" when unset" $ do
    path <- getDataFileName "test/examples/lsm-mithril-export.json"
    (cfg, _) <- parseConfigurationFiles path
    expectOk $ case cliArgs [] of
      Nothing -> Just "could not build CLI arguments"
      Just cli -> case resolveConfiguration cli cfg of
        Left e -> Just ("resolve failed: " <> show e)
        Right (nc, _) -> case backendSelector (runIdentity (ledgerDbConfiguration (C.storageConfiguration nc))) of
          SJust (V2LSM (SJust "lsm") (SJust "export-dir")) -> Nothing
          other -> Just ("unexpected backend: " <> show other)

-- | The Dijkstra genesis example decodes through the ledger's aeson instance
-- (the pinned hash is checked, so the read verifies the file too).
--
-- Genesis initial-data injection files are resolved against the directory
-- holding the /Shelley genesis/, not the one holding the configuration file.
-- The fixture keeps its geneses (and the files they inject) in a subdirectory,
-- so the two differ and a consumer that guessed the configuration directory
-- would look in the wrong place.
injectionRootCase :: TestTree
injectionRootCase =
  testCase "the genesis injection root is the Shelley genesis directory" $ do
    path <- getDataFileName "test/examples/injection.json"
    (cfg, _) <- parseConfigurationFiles path
    let root = genesisInjectionRoot cfg
    missing <-
      missingInjectionFiles
        root
        (injectionSlots (shelleyGenesisConfig cfg) (conwayGenesisConfig cfg))
    expectOk $
      if takeFileName root /= "injection-genesis"
        then Just ("unexpected injection root: " <> root)
        else
          if root == takeDirectory path
            then Just "the injection root must not be the configuration directory"
            else case missing of
              [] -> Nothing
              ms -> Just ("injection files not found under the root: " <> show (map snd ms))

-- | Every injectable field is reported with the source it actually takes its
-- data from: the three the fixture fills come from files (with the @FsPath@ the
-- genesis named), the rest from nowhere. The configuration resolves cleanly.
injectionSlotsCase :: TestTree
injectionSlotsCase =
  testCase "injection slots report their file sources, and the config resolves" $ do
    path <- getDataFileName "test/examples/injection.json"
    (cfg, _) <- parseConfigurationFiles path
    let slots = injectionSlots (shelleyGenesisConfig cfg) (conwayGenesisConfig cfg)
        files =
          [ (slotExtraField s, map T.unpack (fsPathToList fp))
          | (s, fp) <- fileInjections slots
          ]
        expected =
          [ ("extraConfig.initialFunds", ["initial-funds.json"])
          , ("extraConfig.stakePools", ["stake-pools.json"])
          , ("extraConfig.delegs", ["delegs.json"])
          ]
        inline = [renderInjectionSlot s | s <- slots, slotSource s == InjectedInline]
    expectOk $
      if files /= expected
        then Just ("unexpected file injections: " <> show files)
        else
          if not (null inline)
            then Just ("unexpected inline injections: " <> show inline)
            else case cliArgs [] of
              Nothing -> Just "could not build CLI arguments"
              Just cli -> case resolveConfiguration cli cfg of
                Left e -> Just ("resolve failed: " <> show e)
                Right _ -> Nothing

-- | Setting both a legacy genesis field and its @extraConfig@ counterpart is
-- what @cardano-ledger@'s @resolveInjectionSource@ rejects; the parser catches
-- it first, naming the field.
injectionConflictCase :: TestTree
injectionConflictCase =
  testCase "a legacy genesis field and its extraConfig counterpart conflict" $
    expectInjectionRejection
      "test/examples/injection-conflict.json"
      "extraConfig.initialFunds (legacy initialFunds) takes its initial data from both"

-- | Injection is a test-network facility: a mainnet genesis that asks for it is
-- rejected, as the ledger would.
injectionMainnetCase :: TestTree
injectionMainnetCase =
  testCase "genesis injection is rejected on a mainnet genesis" $
    expectInjectionRejection
      "test/examples/injection-mainnet.json"
      "only allowed on a test network"

-- | A referenced injection file that does not exist is reported while the
-- configuration is read, rather than as a filesystem error thrown much later,
-- when the node builds its initial ledger state.
injectionMissingFileCase :: TestTree
injectionMissingFileCase =
  testCase "a missing genesis injection file is rejected at parse time" $
    expectInjectionRejection
      "test/examples/injection-missing.json"
      "no-such-initial-funds.json, which does not exist"

-- | Parsing the configuration must fail, with an error mentioning the given
-- text. Used for the genesis-injection problems the parser reports: they are all
-- thrown as a 'ConfigurationParsingError' attributed to the genesis key at
-- fault.
expectInjectionRejection :: FilePath -> String -> Assertion
expectInjectionRejection fixture expected = do
  path <- getDataFileName fixture
  res <- try (parseConfigurationFiles path >>= \c -> evaluate (length (show c)))
  expectOk $ case res of
    Left (e :: SomeException)
      | expected `isInfixOf` show e -> Nothing
      | otherwise -> Just ("rejected, but with an unexpected error: " <> show e)
    Right _ -> Just ("expected rejection mentioning " <> show expected)

dijkstraGenesisDecodeCase :: TestTree
dijkstraGenesisDecodeCase =
  testCase "test/examples/dijkstra-genesis.json (decodes via the ledger instance)" $ do
    path <- getDataFileName "test/examples/dijkstra-genesis.json"
    res <-
      readGenesisFile @DijkstraGenesis
        ( fromJust $
            hashFromTextAsHex (T.pack "56c06ff0f668c584fc54fa3cee92dd5e121b67696924ac3b01b5aec9ecf95b78")
        )
        path
    case res of
      Left err -> assertFailure (show err)
      Right g -> () <$ evaluate (length (show g))

-- | Reading a genesis file with a wrong expected hash is rejected.
dijkstraGenesisHashMismatchCase :: TestTree
dijkstraGenesisHashMismatchCase =
  testCase "test/examples/dijkstra-genesis.json (wrong hash is rejected)" $ do
    path <- getDataFileName "test/examples/dijkstra-genesis.json"
    let wrongHash :: Hash Blake2b_256 a
        wrongHash = fromJust $ hashFromTextAsHex (T.pack (replicate 64 '0'))
    res <- readGenesisFile @DijkstraGenesis wrongHash path
    expectOk $ case res of
      Left (GenesisHashMismatch{}) -> Nothing
      Left err -> Just ("expected a hash mismatch, got: " <> show err)
      Right _ -> Just "expected a hash mismatch, but the read succeeded"

-- | A @DijkstraGenesisFile@ without a @DijkstraGenesisHash@ is rejected at parse
-- time: a genesis file must come with a pinned hash.
genesisHashRequiredCase :: TestTree
genesisHashRequiredCase =
  testCase "test/examples/testing-dijkstra-nohash.json (genesis file requires a hash)" $ do
    res <-
      decodeData "test/examples/testing-dijkstra-nohash.json" ::
        IO (Either String (TestingConfiguration StrictMaybe))
    expectOk $ case res of
      Left err
        | "DijkstraGenesisHash" `isInfixOf` err -> Nothing
        | otherwise -> Just ("rejected, but with an unexpected error: " <> err)
      Right _ -> Just "expected rejection (missing DijkstraGenesisHash), but decoding succeeded"

-- | A @DijkstraGenesisFile@ accompanied by a @DijkstraGenesisHash@ decodes.
genesisHashPresentCase :: TestTree
genesisHashPresentCase =
  decodeCase
    "test/examples/testing-dijkstra.json (genesis file + hash decodes)"
    ( decodeData "test/examples/testing-dijkstra.json" ::
        IO (Either String (TestingConfiguration StrictMaybe))
    )

-- | The Byron genesis decodes (canonical JSON) and its hash checks out via the
-- ledger's reader. The expected hash is the real mainnet Byron genesis hash.
byronGenesisDecodeCase :: TestTree
byronGenesisDecodeCase =
  testCase "test/examples/mainnet-byron-genesis.json (decodes + hash-checks via the ledger)" $ do
    path <- getDataFileName "test/examples/mainnet-byron-genesis.json"
    case hashFromTextAsHex (T.pack "5f20df933584822601f9e3f8c024eb5eb252fe8cefb24d1317dc3d432e940ebb") of
      Nothing -> assertFailure "could not parse the expected Byron genesis hash"
      Just expected -> do
        res <- readByronGenesisConfig RequiresNoMagic expected path
        expectOk (either (Just . ("Byron read failed: " <>)) (const Nothing) res)

-- | The committed schemas under @schemas/@ (the whole configuration and one per
-- component) must match the schema derived from the codecs, so the documented
-- schema cannot drift from the parsers. Regenerate them with @scripts/gen-schemas.sh@.
schemaTests :: IO TestTree
schemaTests = do
  defs <- componentDefaults
  pure $
    testGroup "schemas" $
      schemaTest "schemas/config.schema.json" (splitConfigSchemaWithDefaults defs)
        : schemaTest
          "schemas/config.legacy-one-file.schema.json"
          (legacyOneFileConfigSchemaWithDefaults defs)
        : [ schemaTest ("schemas/" <> T.unpack name <> ".schema.json") schema
          | (name, schema) <- configurationSchemasWithDefaults defs
          ]

-- | Assert that a committed schema file equals the given derived schema.
schemaTest :: FilePath -> Value -> TestTree
schemaTest path expected =
  testCase path $ do
    full <- getDataFileName path
    res <- eitherDecodeFileStrict' full :: IO (Either String Value)
    case res of
      Left err -> assertFailure ("could not read " <> path <> ": " <> err)
      Right committed ->
        assertBool
          (path <> " is out of date; regenerate with scripts/gen-schemas.sh")
          (committed == expected)
