-- | The JSON layering engine: reading files, deep-merging configuration sources
-- and running a component's codec. This module knows nothing about which keys
-- the parsers recognise (that is "Cardano.Configuration.File.Lint") nor about the
-- overall orchestration (that is "Cardano.Configuration.File").
module Cardano.Configuration.File.Merge
  ( decodeValueFile
  , decodeValueBytes
  , runCodec
  , mergeValues
  , loadSectionSource
  , loadBaseDefault
  , sectionUserLayer
  , parseSection
  , splitEnvelope
  ) where

import Cardano.Configuration.Embedded (embeddedDefaults)
import Cardano.Configuration.File.Error (ConfigurationParsingError (..))
import Cardano.Ledger.BaseTypes (StrictMaybe (..), maybeToStrictMaybe)
import Control.Exception (throwIO)
import Data.Aeson (FromJSON, Value (..), parseJSON)
import qualified Data.Aeson.Key as K
import qualified Data.Aeson.KeyMap as KM
import Data.Aeson.Types (JSONPathElement (..), iparseEither)
import Data.ByteString (ByteString)
import qualified Data.ByteString as BS
import Data.List (isPrefixOf)
import qualified Data.Map.Strict as Map
import Data.Maybe (fromMaybe)
import Data.Scientific (toBoundedInteger)
import qualified Data.Text as T
import qualified Data.Yaml as Yaml
import System.Directory (canonicalizePath, doesFileExist)
import System.FilePath (isAbsolute, splitDirectories, (</>))

-- | Read and decode a YAML\/JSON file into a 'Value', reporting syntax errors as
-- a 'ConfigurationParsingError' that names the file and section.
decodeValueFile ::
  -- | The section being read, for error reporting.
  Maybe String ->
  -- | The file to read.
  FilePath ->
  IO Value
decodeValueFile section fp = BS.readFile fp >>= decodeValueBytes section fp

-- | Decode already-read YAML\/JSON bytes into a 'Value', reporting syntax errors
-- against the given name. Used for the files embedded into the binary (see
-- "Cardano.Configuration.Embedded"), which have no path on disk to read.
decodeValueBytes ::
  -- | The section being read, for error reporting.
  Maybe String ->
  -- | The name the bytes came from, for error reporting.
  FilePath ->
  -- | The bytes to decode.
  ByteString ->
  IO Value
decodeValueBytes section fp bytes =
  case Yaml.decodeEither' bytes of
    Left e ->
      throwIO $
        ConfigurationParsingError
          (SJust fp)
          (maybeToStrictMaybe section)
          []
          (Yaml.prettyPrintParseException e)
    Right v -> pure v

-- | Run a component parser on a 'Value', turning a failure into a structured
-- 'ConfigurationParsingError' carrying the file, section and JSON path.
runCodec ::
  FromJSON a =>
  -- | The sub-file the value came from, if any.
  Maybe FilePath ->
  -- | The section being parsed, for error reporting.
  String ->
  -- | The value to parse.
  Value ->
  IO a
runCodec mFile section value =
  case iparseEither parseJSON value of
    Left (path, msg) -> throwIO $ ConfigurationParsingError (maybeToStrictMaybe mFile) (SJust section) path msg
    Right a -> pure a

-- | Deep, right-biased merge of two JSON values: two objects are merged key by
-- key (a key present in both is merged recursively), and for anything else the
-- second (later) value wins. Used to layer a section's user-supplied value on
-- top of its always-applied base default, so the user's value wins.
mergeValues :: Value -> Value -> Value
mergeValues (Object earlier) (Object later) = Object (KM.unionWith mergeValues earlier later)
mergeValues _ later = later

-- | Resolve a single section source — a path to a sub-file (a string) or an
-- inline object — to its 'Value'.
loadSectionSource :: FilePath -> String -> Value -> IO Value
loadSectionSource root section src =
  case src of
    String path -> do
      fp <- resolveSectionPath root section (T.unpack path)
      exists <- doesFileExist fp
      if exists
        then decodeValueFile (Just section) fp
        else
          throwIO $
            ConfigurationParsingError
              (SJust fp)
              (SJust section)
              [Key (K.fromString section)]
              "the referenced configuration file does not exist"
    Object _ -> pure src
    _ ->
      throwIO $
        ConfigurationParsingError
          SNothing
          (SJust section)
          [Key (K.fromString section)]
          "expected a path to a configuration file (a string) or an inline object"

-- | Resolve a section sub-file path against the configuration directory,
-- confining it to that directory's subtree. The path must be relative, and its
-- real (symlink- and @..@-resolved) location must stay within the configuration
-- directory: a path that is absolute, climbs out with @..@, or is a symlink
-- pointing outside is rejected. This stops a configuration from pulling in
-- arbitrary files such as @\/etc\/passwd@. A symlink that stays inside the
-- subtree is allowed.
resolveSectionPath :: FilePath -> String -> String -> IO FilePath
resolveSectionPath root section path
  | isAbsolute path = reject "must be a relative path, not an absolute one"
  | otherwise = do
      -- 'canonicalizePath' resolves @..@ segments and follows symlinks, so the
      -- containment check below sees the file's real location, not the textual
      -- path. The root is canonicalized too, so the comparison is between two
      -- fully resolved paths.
      canonRoot <- canonicalizePath root
      canonTarget <- canonicalizePath (root </> path)
      if splitDirectories canonRoot `isPrefixOf` splitDirectories canonTarget
        then pure canonTarget
        else reject "must resolve to a file within the configuration directory"
 where
  reject why =
    throwIO $
      ConfigurationParsingError
        (SJust path)
        (SJust section)
        [Key (K.fromString section)]
        ("invalid configuration file path: it " <> why)

-- | The always-applied base default for a section, read from the
-- @defaults\/\<Section\>.json@ embedded into the binary (see
-- "Cardano.Configuration.Embedded"), if one ships for it.
loadBaseDefault :: String -> IO (Maybe Value)
loadBaseDefault section =
  case Map.lookup name embeddedDefaults of
    Nothing -> pure Nothing
    Just bytes -> Just <$> decodeValueBytes (Just section) ("defaults/" <> name) bytes
 where
  name = section <> ".json"

-- | The configuration layer the user supplied for a section: an inline object,
-- or a referenced sub-file. A component is read only from its own section key; a
-- section that is absent contributes no user layer (so the component takes its
-- base defaults). Component keys placed flat under @Configuration@ are /not/
-- resolved into their section — they are left unrecognised (see
-- 'Cardano.Configuration.File.Lint.checkUnknownKeys'). Non-Version1 documents,
-- where the keys are flat, are migrated (grouped into sections) before reaching
-- here.
sectionUserLayer :: FilePath -> Value -> String -> IO Value
sectionUserLayer root configValue section =
  case configValue of
    Object o ->
      case KM.lookup (K.fromString section) o of
        Nothing -> pure (Object KM.empty)
        Just source -> loadSectionSource root section source
    _ ->
      throwIO $
        ConfigurationParsingError SNothing SNothing [] "expected the configuration to be a JSON/YAML object"

-- | Parse a single component. The package's base default for the section is
-- always read as the bottom layer; the user's layer (see 'sectionUserLayer') is
-- deep-merged on top. A path to a missing file is an explicit error.
parseSection ::
  FromJSON a =>
  -- | The directory the main file lives in, against which sub-file paths are
  -- resolved.
  FilePath ->
  -- | The (unwrapped) configuration object.
  Value ->
  -- | The section name.
  String ->
  IO a
parseSection root configValue section = do
  base <- loadBaseDefault section
  user <- sectionUserLayer root configValue section
  let withBase = maybe user (`mergeValues` user) base
  runCodec Nothing section withBase

-- | Split the optional configuration envelope @{ \"Version\": N,
-- \"MinNodeVersion\": \"x.y.z\", \"Configuration\": {..} }@ into the version, the
-- optional minimum node version and the configuration object. A document that is
-- not wrapped in an envelope is treated as the legacy version-1 format, in which
-- the configuration keys sit at the top level (and the optional flat @Version@
-- and @MinNodeVersion@ keys may still appear there).
--
-- @MinNodeVersion@ is a top-level annotation (sibling of @Version@), not a
-- configuration component: it records the lowest @cardano-node@ version expected
-- to run this configuration, for a consumer to check.
splitEnvelope :: Value -> IO (Int, Maybe T.Text, Value)
splitEnvelope value =
  case value of
    Object o -> do
      version <- lookupVersion o
      minNodeVersion <- lookupMinNodeVersion o
      pure (version, minNodeVersion, fromMaybe value (KM.lookup "Configuration" o))
    _ ->
      throwIO $
        ConfigurationParsingError SNothing SNothing [] "expected the configuration to be a JSON/YAML object"
 where
  -- A missing @Version@ is the legacy version 1 — a fixed historical fact about
  -- unversioned documents, not @currentFormatVersion@: should the format ever
  -- reach 2, a document with no @Version@ is still a version-1 document. A present
  -- one must be an integer in range (not e.g. 1.4 or a huge scientific literal):
  -- the schema declares it as an integer, so anything else is a hard error.
  lookupVersion o = case KM.lookup "Version" o of
    Nothing -> pure 1
    Just (Number n) ->
      maybe (throwIO (badVersion ("expected an integer, got " <> show n))) pure (toBoundedInteger n)
    Just _ -> throwIO (badVersion "expected an integer")
  badVersion msg = ConfigurationParsingError SNothing SNothing [Key "Version"] ("invalid Version: " <> msg)
  -- @MinNodeVersion@ is optional and, when present, must be a string.
  lookupMinNodeVersion o = case KM.lookup "MinNodeVersion" o of
    Nothing -> pure Nothing
    Just (String t) -> pure (Just t)
    Just _ ->
      throwIO $
        ConfigurationParsingError
          SNothing
          SNothing
          [Key "MinNodeVersion"]
          "invalid MinNodeVersion: expected a string"
