# Changelog for `cardano-ledger-pretty`

## 1.0.0.0

* First properly versioned release.
