module Test.Util.FS.Sim.Pure {-# DEPRECATED "Use System.FS.Sim.Pure from fs-sim" #-}(
    PureSimFS
    -- opaque
  , pureHasFS
  , runPureSimFS
  ) where

import           System.FS.Sim.Pure
