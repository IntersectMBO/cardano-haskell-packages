module Test.Util.Blob {-# DEPRECATED "Use System.FS.Sim.Error instead" #-} (
    Blob (..)
  , blobFromBS
  , blobToBS
  ) where

import           System.FS.Sim.Error
