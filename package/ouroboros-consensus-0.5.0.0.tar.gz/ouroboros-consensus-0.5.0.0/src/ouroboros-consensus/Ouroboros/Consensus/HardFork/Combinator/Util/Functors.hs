module Ouroboros.Consensus.HardFork.Combinator.Util.Functors {-# DEPRECATED "Use Data.SOP.Functors" #-} (module Data.SOP.Functors) where

import Data.SOP.Functors
