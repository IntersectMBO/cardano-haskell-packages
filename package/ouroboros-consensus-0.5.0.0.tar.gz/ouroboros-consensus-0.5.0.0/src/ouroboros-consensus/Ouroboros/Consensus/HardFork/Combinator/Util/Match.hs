module Ouroboros.Consensus.HardFork.Combinator.Util.Match {-# DEPRECATED "Use Data.SOP.Match" #-} (module Data.SOP.Match) where

import Data.SOP.Match
