module Ouroboros.Consensus.Util.SOP {-# DEPRECATED "Use Data.SOP.Strict, Data.SOP.Index, Data.SOP.Lenses or Data.SOP.NonEmpty" #-} (module X) where

import Data.SOP.Strict as X
import Data.SOP.Index as X
import Data.SOP.Lenses as X
import Data.SOP.NonEmpty as X
