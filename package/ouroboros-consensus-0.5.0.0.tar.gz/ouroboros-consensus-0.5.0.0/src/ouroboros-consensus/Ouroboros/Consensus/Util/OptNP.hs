module Ouroboros.Consensus.Util.OptNP {-# DEPRECATED "Use Data.SOP.OptNP" #-} (module Data.SOP.OptNP) where

import Data.SOP.OptNP
