# Changelog

## 0.8.1

* Updated to `ouroboros-network-framework-0.16`.

## 0.8

* Updated to `network-mux-0.6` and `ouroboros-network-framework-0.15`

## 0.7 - Oct 2024

* Updated to `typed-protocols-0.3`.

## 0.6.0 - Sep 2024

* Remove potentially leaky continuation passing of `EKGForwarder`.
* Bump dependency version bounds.

## 0.5.0

* Bump dependency version bounds

## 0.4.0

* Updated to `ouroboros-network-framework-0.8`.

## 0.1.0

* Initially created.
