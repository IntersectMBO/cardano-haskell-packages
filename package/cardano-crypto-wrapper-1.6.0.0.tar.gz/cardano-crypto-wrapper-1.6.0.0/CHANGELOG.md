# Revision history for `cardano-crypto-wrapper`

## 1.6.0.0

* Switch from cryptonite library (deprecated) to crypton (a drop in replacement)

## 1.5.1.4

*

## 1.5.1.3

*

## 1.5.1.2

*

## 1.5.1.1

*

## 1.5.1.0

* Bring back `toCBORXPrv` and `fromCBORXPrv`

## 1.5.0.0

* First official release.
