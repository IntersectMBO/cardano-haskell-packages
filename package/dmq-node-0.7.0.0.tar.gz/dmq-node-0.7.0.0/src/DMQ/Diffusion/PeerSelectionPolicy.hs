module DMQ.Diffusion.PeerSelectionPolicy where

import Control.Concurrent.Class.MonadSTM.Strict
import Data.List (sortOn, unfoldr)
import Data.Map.Strict qualified as Map
import Data.Set qualified as Set
import Data.Word (Word32)
import System.Random (Random (..), StdGen, splitGen)

import DMQ.Diffusion.PeerSelection.PeerMetric (PeerMetric)
import DMQ.Diffusion.PeerSelection.PeerMetric qualified as PeerMetric

import Ouroboros.Network.PeerSelection hiding (PeerMetrics)

-- | DMQ PeerSelectionPolicy
--
policy :: forall sigId peerAddr m.
          ( MonadSTM m
          , Ord peerAddr
          )
       => StrictTVar m StdGen
       -> PeerMetric m sigId peerAddr
       -> PeerSelectionPolicy peerAddr m
policy rngVar peerMetrics =
  PeerSelectionPolicy {
    policyPickKnownPeersForPeerShare = simplePromotionPolicy,
    policyPickColdPeersToPromote     = simplePromotionPolicy,
    policyPickWarmPeersToPromote     = simplePromotionPolicy,
    policyPickInboundPeers           = simplePromotionPolicy,

    policyPickHotPeersToDemote       = hotDemotionPolicy,
    policyPickWarmPeersToDemote      = warmDemotionPolicy,
    policyPickColdPeersToForget      = coldForgetPolicy,

    policyFindPublicRootTimeout      = 5,
    policyMaxInProgressPeerShareReqs = 0,
    policyPeerShareRetryTime         = 900,  -- seconds
    policyPeerShareBatchWaitTime     = 3,    -- seconds
    policyPeerShareOverallTimeout    = 10,   -- seconds
    policyPeerShareActivationDelay   = 300,  -- seconds
    policyMaxConnectionRetries       = 5,
    policyClearFailCountDelay        = 120   -- seconds
  }
  where
    hotDemotionPolicy :: PickPolicy peerAddr (STM m)
    hotDemotionPolicy _ _ _ available pickNum = do
      available' <- addRand rngVar available (,)
      scores <- PeerMetric.announciness peerMetrics
      return $ Set.fromList
             . map fst
             . take pickNum
             . sortOn (\(peer, rn) -> (Map.findWithDefault 0 peer scores , rn))
             . Map.assocs
             $ available'

    -- Randomly pick peers to demote, peers with knownPeerTepid set are twice
    -- as likely to be demoted.
    warmDemotionPolicy :: PickPolicy peerAddr (STM m)
    warmDemotionPolicy _ _ isTepid available pickNum = do
      available' <- addRand rngVar available (tepidWeight isTepid)
      return $ Set.fromList
             . map fst
             . take pickNum
             . sortOn snd
             . Map.assocs
             $ available'

    simplePromotionPolicy :: PickPolicy peerAddr (STM m)
    simplePromotionPolicy _ _ _ available pickNum = do
      available' <- addRand rngVar available (,)
      return $ Set.fromList
             . map fst
             . take pickNum
             . sortOn snd
             . Map.assocs
             $ available'

    -- Randomly pick peers to forget, peers with failures are more likely to
    -- be forgotten.
    coldForgetPolicy :: PickPolicy peerAddr (STM m)
    coldForgetPolicy _ failCnt _ available pickNum = do
      available' <- addRand rngVar available (failWeight failCnt)
      return $ Set.fromList
             . map fst
             . take pickNum
             . sortOn snd
             . Map.assocs
             $ available'

    -- Failures lowers r
    failWeight :: (peerAddr -> Int)
                -> peerAddr
                -> Word32
                -> (peerAddr, Word32)
    failWeight failCnt peer r =
        (peer, r `div` fromIntegral (failCnt peer + 1))

    -- Tepid flag cuts r in half
    tepidWeight :: (peerAddr -> Bool)
                -> peerAddr
                -> Word32
                -> (peerAddr, Word32)
    tepidWeight isTepid peer r =
          if isTepid peer then (peer, r `div` 2)
                          else (peer, r)


 -- Add scaled random number in order to prevent ordering based on SockAddr
addRand :: ( MonadSTM m
           , Ord peerAddr
           )
        => StrictTVar m StdGen
        -> Set.Set peerAddr
        -> (peerAddr -> Word32 -> (peerAddr, Word32))
        -> STM m (Map.Map peerAddr Word32)
addRand rngVar available scaleFn = do
  inRng <- readTVar rngVar

  let (rng, rng') = splitGen inRng
      rns = take (Set.size available) $ unfoldr (Just . random)  rng :: [Word32]
      available' = Map.fromList $ zipWith scaleFn (Set.toList available) rns
  writeTVar rngVar rng'
  return available'

