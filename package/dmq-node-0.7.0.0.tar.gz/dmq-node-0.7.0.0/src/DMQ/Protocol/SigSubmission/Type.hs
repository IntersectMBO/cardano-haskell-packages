{-# LANGUAGE DerivingStrategies         #-}
{-# LANGUAGE FlexibleContexts           #-}
{-# LANGUAGE FlexibleInstances          #-}
{-# LANGUAGE GeneralizedNewtypeDeriving #-}
{-# LANGUAGE NamedFieldPuns             #-}
{-# LANGUAGE OverloadedStrings          #-}
{-# LANGUAGE PatternSynonyms            #-}
{-# LANGUAGE ScopedTypeVariables        #-}
{-# LANGUAGE StandaloneDeriving         #-}
{-# LANGUAGE TypeData                   #-}
{-# LANGUAGE TypeFamilies               #-}
{-# LANGUAGE UndecidableInstances       #-}

module DMQ.Protocol.SigSubmission.Type
  ( -- * Data types
    SigId (..)
  , SigBody (..)
  , SigKESSignature (..)
  , SigOpCertificate (..)
  , SigColdKey (..)
  , SigRaw (..)
  , SigRawWithSignedBytes (..)
  , Sig (Sig, SigWithBytes, sigRawWithSignedBytes, sigRawBytes, sigId, sigBody, sigExpiresAt, sigOpCertificate, sigKESPeriod, sigKESSignature, sigColdKey, sigSignedBytes, sigBytes)
    -- * `TxSubmission` mini-protocol
  , SigSubmission
  , module SigSubmission
  , POSIXTime
  , SigValidationError (..)
  , SigValidationTrace (..)
  , SigValidationException (..)
  , PoolId
    -- * Utilities
  , CBORBytes (..)
  , Verbose (..)
    -- * Re-exports from `kes-agent`
  , KESPeriod (..)
  ) where

import Control.DeepSeq (NFData)
import Control.Exception (Exception (..))
import Control.Monad.Class.MonadTime.SI
import Data.Aeson
import Data.ByteString (ByteString)
import Data.ByteString.Base16.Lazy as LBS.Base16
import Data.ByteString.Lazy qualified as LBS
import Data.ByteString.Lazy.Char8 qualified as LBS.Char8
import Data.Text (Text)
import Data.Time.Clock.POSIX (POSIXTime)
import Data.Typeable
import Data.Word (Word64)

import NoThunks.Class (NoThunks)

import Cardano.Crypto.DSIGN.Class (DSIGNAlgorithm, VerKeyDSIGN)
import Cardano.Crypto.Hash.Blake2b (Blake2b_256)
import Cardano.Crypto.Hash.Class (Hash)
import Cardano.Crypto.KES.Class (KESAlgorithm (..))
import Cardano.Crypto.Util (SignableRepresentation (..))
import Cardano.KESAgent.KES.Crypto as KES
import Cardano.KESAgent.KES.OCert (KESPeriod (..), OCert (..),
           OCertSignable (..))
import Cardano.Ledger.Shelley.API qualified as Ledger
import Cardano.Logging qualified as Logging

import Ouroboros.Network.Protocol.TxSubmission2.Type as SigSubmission hiding
           (TxSubmission2)
import Ouroboros.Network.Protocol.TxSubmission2.Type as TxSubmission2
import Ouroboros.Network.Tx (HasRawTxId (..))
import Ouroboros.Network.Util.ShowProxy


-- | Cardano pool id's are hashes of the cold verification key
--
type PoolId = Ledger.KeyHash Ledger.StakePool


type data SigPayload

newtype SigId = SigId { getSigId :: Hash Blake2b_256 SigPayload  }
  deriving stock (Show, Eq, Ord)
  deriving newtype (NFData, NoThunks)

instance HasRawTxId SigId where
  type RawTxId SigId = SigId
  getRawTxId = id

instance ToJSON SigId where
  toJSON (SigId sigId) = toJSON sigId

instance ShowProxy SigId where

newtype SigBody = SigBody { getSigBody :: ByteString }
  deriving stock (Show, Eq)


newtype SigKESSignature crypto = SigKESSignature { getSigKESSignature :: SigKES (KES crypto) }

deriving instance Show (SigKES (KES crypto))
               => Show (SigKESSignature crypto)
deriving instance Eq (SigKES (KES crypto))
               => Eq (SigKESSignature crypto)

newtype SigOpCertificate crypto = SigOpCertificate { getSigOpCertificate :: OCert crypto }

deriving instance ( DSIGNAlgorithm (KES.DSIGN crypto)
                  , Show (VerKeyKES (KES crypto))
                  )
                => Show (SigOpCertificate crypto)
deriving instance ( DSIGNAlgorithm (KES.DSIGN crypto)
                  , Eq (VerKeyKES (KES crypto))
                  ) => Eq (SigOpCertificate crypto)


newtype SigColdKey crypto = SigColdKey { getSigColdKey :: VerKeyDSIGN (KES.DSIGN crypto) }

deriving instance Show (VerKeyDSIGN (KES.DSIGN crypto))
               => Show (SigColdKey crypto)

deriving instance Eq (VerKeyDSIGN (KES.DSIGN crypto))
               => Eq (SigColdKey crypto)

-- | Sig type consists of payload and its KES signature.
--
data SigRaw crypto = SigRaw {
    sigRawId            :: SigId,
    sigRawBody          :: SigBody,
    sigRawKESPeriod     :: KESPeriod,
    -- ^ KES period when this signature was created.
    --
    -- NOTE: `kes-agent` library is using `Word` for KES period, CIP-137
    -- requires `Word64`, thus we're only supporting 64-bit architectures.
    sigRawOpCertificate :: SigOpCertificate crypto,
    sigRawColdKey       :: SigColdKey crypto,
    sigRawExpiresAt     :: POSIXTime,
    sigRawKESSignature  :: SigKESSignature crypto
    -- ^ KES signature of all previous fields.
    --
    -- NOTE: this field must be lazy, otherwise tests will fail.
  }

deriving instance ( DSIGNAlgorithm (KES.DSIGN crypto)
                  , Show (VerKeyKES (KES crypto))
                  , Show (SigKES (KES crypto))
                  )
               => Show (SigRaw crypto)
deriving instance ( DSIGNAlgorithm (KES.DSIGN crypto)
                  , Eq (VerKeyKES (KES crypto))
                  , Eq (SigKES (KES crypto))
                  )
               => Eq (SigRaw crypto)

instance ToJSON (SigRaw crypto) where
  toJSON SigRaw { sigRawId
                , sigRawKESPeriod
                , sigRawExpiresAt
                } =
    object [ "id"            .= sigRawId
           , "kesPeriod"     .= unKESPeriod sigRawKESPeriod
           , "expiresAt"     .= show sigRawExpiresAt
           ]

newtype Verbose a = Verbose { unVerbose :: a }

instance Crypto crypto
      => ToJSON (Verbose (SigRaw crypto)) where
  toJSON Verbose { unVerbose =
           SigRaw { sigRawId
                  , sigRawBody
                  , sigRawKESPeriod
                  , sigRawExpiresAt
                  , sigRawKESSignature
                  , sigRawOpCertificate
                  , sigRawColdKey
                  }
         } =

    object [ "id"            .= sigRawId
           , "body"          .= show (getSigBody sigRawBody)
           , "kesPeriod"     .= unKESPeriod sigRawKESPeriod
           , "expiresAt"     .= show sigRawExpiresAt
           , "kesSignature"  .= show (getSigKESSignature sigRawKESSignature)

           , "opCertificate" .= show (getSignableRepresentation signable)
           , "coldKey"       .= show (getSigColdKey sigRawColdKey)
           ]
        where
          ocert    = getSigOpCertificate sigRawOpCertificate
          signable :: OCertSignable crypto
          signable = OCertSignable (ocertVkHot ocert) (ocertN ocert) (ocertKESPeriod ocert)

data SigRawWithSignedBytes crypto = SigRawWithSignedBytes {
    sigRawSignedBytes :: LBS.ByteString,
    -- ^ bytes signed by the KES key
    sigRaw            :: SigRaw crypto
    -- ^ the `SigRaw` data type
  }

deriving instance ( DSIGNAlgorithm (KES.DSIGN crypto)
                  , Show (VerKeyKES (KES crypto))
                  , Show (SigKES (KES crypto))
                  )
               => Show (SigRawWithSignedBytes crypto)
deriving instance ( DSIGNAlgorithm (KES.DSIGN crypto)
                  , Eq (VerKeyKES (KES crypto))
                  , Eq (SigKES (KES crypto))
                  )
               => Eq (SigRawWithSignedBytes crypto)

instance ToJSON (SigRawWithSignedBytes crypto) where
  toJSON SigRawWithSignedBytes {sigRaw} = toJSON sigRaw

instance Crypto crypto
      => ToJSON (Verbose (SigRawWithSignedBytes crypto)) where
  toJSON (Verbose SigRawWithSignedBytes {sigRaw}) = toJSON (Verbose sigRaw)


data Sig crypto = SigWithBytes {
    sigRawBytes           :: LBS.ByteString,
    -- ^ encoded `SigRaw` data type
    sigRawWithSignedBytes :: SigRawWithSignedBytes crypto
    -- ^ the `SigRaw` data type along with signed bytes
  }

-- TODO: this show instance is too minimal.  Proper `Show` instance is useful
-- in `QuickCheck` tests.  This minimal instance is for example
-- useful in `TraceTxLogic` tracer.  We should move the `Verbose` wrapper to
-- `ouroboros-network` and use it in the `LogFormatting TraceTxLogic` instance.
--
--
instance Show (Sig crypto) where
  show Sig { sigId, sigKESPeriod, sigExpiresAt } =
    "Sig { sigId = " ++ show (getSigId sigId)
    ++ " , sigKESPeriod = " ++ show (unKESPeriod sigKESPeriod)
    ++ " , sigExpiresAt = " ++ show sigExpiresAt
    ++ " }"

-- deriving instance ( DSIGNAlgorithm (KES.DSIGN crypto)
--                   , Show (VerKeyKES (KES crypto))
--                   , Show (SigKES (KES crypto))
--                   )
--                => Show (Sig crypto)
deriving instance ( DSIGNAlgorithm (KES.DSIGN crypto)
                  , Eq (VerKeyKES (KES crypto))
                  , Eq (SigKES (KES crypto))
                  )
               => Eq (Sig crypto)

instance ToJSON (Sig crypto) where
  toJSON SigWithBytes {sigRawWithSignedBytes} = toJSON sigRawWithSignedBytes

instance Crypto crypto
      => ToJSON (Verbose (Sig crypto)) where
  toJSON (Verbose SigWithBytes { sigRawWithSignedBytes}) = toJSON (Verbose sigRawWithSignedBytes)

-- | A convenient bidirectional pattern synonym for the `Sig` type.
--
pattern Sig
  :: SigId
  -> SigBody
  -> SigKESSignature crypto
  -> KESPeriod
  -> SigOpCertificate crypto
  -> SigColdKey crypto
  -> POSIXTime
  -> LBS.ByteString
  -> LBS.ByteString
  -> Sig crypto
pattern
    Sig { sigId,
          sigBody,
          sigKESSignature,
          sigKESPeriod,
          sigOpCertificate,
          sigColdKey,
          sigExpiresAt,
          sigSignedBytes,
          sigBytes
        }
    <-
    SigWithBytes {
      sigRawBytes = sigBytes,
      sigRawWithSignedBytes =
        SigRawWithSignedBytes {
          sigRawSignedBytes = sigSignedBytes,
          sigRaw = SigRaw {
            sigRawId            = sigId,
            sigRawBody          = sigBody,
            sigRawKESSignature  = sigKESSignature,
            sigRawKESPeriod     = sigKESPeriod,
            sigRawOpCertificate = sigOpCertificate,
            sigRawColdKey       = sigColdKey,
            sigRawExpiresAt     = sigExpiresAt
          }
        }
      }
  where
    Sig sigRawId
        sigRawBody
        sigRawKESSignature
        sigRawKESPeriod
        sigRawOpCertificate
        sigRawColdKey
        sigRawExpiresAt
        sigRawSignedBytes
        sigRawBytes
      =
      SigWithBytes {
        sigRawBytes = sigRawBytes,
        sigRawWithSignedBytes = SigRawWithSignedBytes {
          sigRawSignedBytes,
          sigRaw = SigRaw {
            sigRawId,
            sigRawBody,
            sigRawKESPeriod,
            sigRawKESSignature,
            sigRawOpCertificate,
            sigRawColdKey,
            sigRawExpiresAt
          }
        }
      }
{-# COMPLETE Sig #-}

instance Typeable crypto => ShowProxy (Sig crypto) where


type SigSubmission crypto = TxSubmission2.TxSubmission2 SigId (Sig crypto)


data SigValidationError =
    InvalidSigId
  | InvalidKESSignature KESPeriod KESPeriod String
  | InvalidSignatureOCERT
      !Word64    -- OCert counter
      !KESPeriod -- OCert KES period
      !String    -- DSIGN error message
  | InvalidOCertCounter
      !Word64 -- last seen
      !Word64 -- received
  | KESBeforeStartOCERT KESPeriod KESPeriod
  | KESAfterEndOCERT KESPeriod KESPeriod
  | PoolNotEligible
  | UnrecognizedPool
  | NotInitialized
  | SigDuplicate
  | SigExpired
  | SigExpiresAtTooFarInTheFuture
  | SigResultOther Text
  | SigTooFrequent PoolId DiffTime
  deriving (Eq, Show)

instance ShowProxy SigValidationError where

instance ToJSON SigValidationError where
  toJSON SigDuplicate = String "duplicate"
  toJSON SigExpired   = String "expired"
  toJSON (SigResultOther txt) = object
    [ "type" .= String "other"
    , "reason" .= txt
    ]
  toJSON e = object
    [ "type" .= String "invalid"
    , "reason" .= show e
    ]

data SigValidationTrace = InvalidSignature SigId SigValidationError
  deriving Show

instance Logging.LogFormatting SigValidationTrace where
  forMachine _dtal (InvalidSignature sigid reason) = mconcat
    [ "type"   .= String "InvalidSignature"
    , "sigid"  .= sigid
    , "reason" .= reason
    ]

instance Logging.MetaTrace SigValidationTrace where
  namespaceFor InvalidSignature{} = Logging.Namespace [] ["SigValidation"]
  severityFor _ (Just InvalidSignature{}) = Just Logging.Error
  severityFor _ Nothing                   = Nothing
  documentFor _ = Nothing
  allNamespaces = [ Logging.Namespace [] ["SigValidation"] ]


data SigValidationException = SigValidationException SigId SigValidationError
  deriving Show

instance Exception SigValidationException


--
-- Utilities
--

-- | A newtype wrapper to show CBOR bytes in hex format.
--
newtype CBORBytes = CBORBytes { getCBORBytes :: LBS.ByteString }
  deriving Eq

instance Show CBORBytes where
  show = LBS.Char8.unpack . LBS.Base16.encode . getCBORBytes
