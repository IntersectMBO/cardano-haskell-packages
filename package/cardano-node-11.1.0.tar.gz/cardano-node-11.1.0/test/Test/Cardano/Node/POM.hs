{-# LANGUAGE NamedFieldPuns #-}
{-# LANGUAGE OverloadedStrings #-}
{-# LANGUAGE PatternSynonyms #-}
{-# LANGUAGE ScopedTypeVariables #-}
{-# LANGUAGE TemplateHaskell #-}

module Test.Cardano.Node.POM
  ( tests
  ) where


import           Cardano.Api (File (..))

import           Cardano.Crypto.ProtocolMagic (RequiresNetworkMagic (..))
import           Cardano.Network.ConsensusMode (ConsensusMode (..))
import           Cardano.Network.Diffusion.Configuration (defaultNumberOfBigLedgerPeers)
import           Cardano.Network.NodeToNode (AcceptedConnectionsLimit (..),
                   DiffusionMode (InitiatorAndResponderDiffusionMode))
import           Cardano.Node.Configuration.LedgerDB
import           Cardano.Node.Configuration.POM
import           Cardano.Node.Configuration.Socket
import           Cardano.Node.Handlers.Shutdown
import           Cardano.Node.Types
import           Cardano.Rpc.Server.Config (RpcConfigF (..), makeRpcConfig)
import           Ouroboros.Consensus.Node (NodeDatabasePaths (..))
import           Ouroboros.Consensus.Node.Genesis (disableGenesisConfig)
import           Ouroboros.Consensus.Storage.LedgerDB.Args
import           Ouroboros.Consensus.Storage.LedgerDB.Snapshots (SnapshotPolicyArgs,
                   defaultSnapshotPolicyArgs, mithrilSnapshotPolicyArgs)
import           Ouroboros.Network.Block (SlotNo (..))
import           Ouroboros.Network.PeerSelection.PeerSharing (PeerSharing (..))
import           Ouroboros.Network.TxSubmission.Inbound.V2.Types

import           Data.Aeson (eitherDecode)
import           Data.Bifunctor (first)
import qualified Data.ByteString.Lazy as LBS
import           Data.Functor.Identity (Identity (..))
import           Data.List (isInfixOf)
import           Data.Monoid (Last (..))
import           Data.String
import           Data.Text (Text)

import           Hedgehog (Property, discover, withTests, (===))
import qualified Hedgehog
import qualified Hedgehog.Extras as H
import           Hedgehog.Internal.Property (evalEither, failWith)


-- This is a simple test to check that the POM technique is working as intended.
-- What is entered on the command line via the cli takes precedence and this is
-- tested in the property below.
-- See: https://medium.com/@jonathangfischoff/the-partial-options-monoid-pattern-31914a71fc67

prop_sanityCheck_POM :: Property
prop_sanityCheck_POM =
   H.propertyOnce $ do
    let combinedPartials = defaultPartialNodeConfiguration
                             <> testPartialYamlConfig
                             <> testPartialCliConfig
        nc = makeNodeConfiguration combinedPartials
    expectedConfig <- evalEither eExpectedConfig
    case nc of
      Left err -> failWith Nothing $ "Partial Options Monoid sanity check failure: " <> err
      Right config -> config === expectedConfig

testNodeByronProtocolConfiguration :: NodeByronProtocolConfiguration
testNodeByronProtocolConfiguration =
  NodeByronProtocolConfiguration
    { npcByronGenesisFile                   = GenesisFile "dummmy-genesis-file"
    , npcByronGenesisFileHash               = Nothing
    , npcByronReqNetworkMagic               = RequiresNoMagic
    , npcByronPbftSignatureThresh           = Nothing
    , npcByronSupportedProtocolVersionMajor = 0
    , npcByronSupportedProtocolVersionMinor = 0
    , npcByronSupportedProtocolVersionAlt   = 0
    }

testNodeShelleyProtocolConfiguration :: NodeShelleyProtocolConfiguration
testNodeShelleyProtocolConfiguration =
  NodeShelleyProtocolConfiguration
    { npcShelleyGenesisFile     = GenesisFile "dummmy-genesis-file"
    , npcShelleyGenesisFileHash = Nothing
    }

testNodeAlonzoProtocolConfiguration :: NodeAlonzoProtocolConfiguration
testNodeAlonzoProtocolConfiguration =
  NodeAlonzoProtocolConfiguration
    { npcAlonzoGenesisFile      = GenesisFile "dummmy-genesis-file"
    , npcAlonzoGenesisFileHash  = Nothing
    }

testNodeConwayProtocolConfiguration :: NodeConwayProtocolConfiguration
testNodeConwayProtocolConfiguration =
  NodeConwayProtocolConfiguration
    { npcConwayGenesisFile      = GenesisFile "dummmy-genesis-file"
    , npcConwayGenesisFileHash  = Nothing
    }

testNodeHardForkProtocolConfiguration :: NodeHardForkProtocolConfiguration
testNodeHardForkProtocolConfiguration =
  NodeHardForkProtocolConfiguration
    { npcExperimentalHardForksEnabled  = True
    , npcTestShelleyHardForkAtEpoch    = Nothing
    , npcTestShelleyHardForkAtVersion  = Nothing
    , npcTestAllegraHardForkAtEpoch    = Nothing
    , npcTestAllegraHardForkAtVersion  = Nothing
    , npcTestMaryHardForkAtEpoch       = Nothing
    , npcTestMaryHardForkAtVersion     = Nothing
    , npcTestAlonzoHardForkAtEpoch     = Nothing
    , npcTestAlonzoHardForkAtVersion   = Nothing
    , npcTestBabbageHardForkAtEpoch    = Nothing
    , npcTestBabbageHardForkAtVersion  = Nothing
    , npcTestConwayHardForkAtEpoch     = Nothing
    , npcTestConwayHardForkAtVersion   = Nothing
    , npcTestDijkstraHardForkAtEpoch   = Nothing
    , npcTestDijkstraHardForkAtVersion = Nothing
    }

testNodeCheckpointsConfiguration :: NodeCheckpointsConfiguration
testNodeCheckpointsConfiguration =
  NodeCheckpointsConfiguration
    { npcCheckpointsFile     = Nothing
    , npcCheckpointsFileHash = Nothing
    }

testNodeProtocolConfiguration :: NodeProtocolConfiguration
testNodeProtocolConfiguration =
  NodeProtocolConfigurationCardano
    testNodeByronProtocolConfiguration
    testNodeShelleyProtocolConfiguration
    testNodeAlonzoProtocolConfiguration
    testNodeConwayProtocolConfiguration
    Nothing -- Dijkstra configuration
    testNodeHardForkProtocolConfiguration
    testNodeCheckpointsConfiguration

-- | Example partial configuration theoretically created from a
-- config yaml file.
testPartialYamlConfig :: PartialNodeConfiguration
testPartialYamlConfig =
  PartialNodeConfiguration
    { pncProtocolConfig = Last $ Just testNodeProtocolConfiguration
    , pncSocketConfig = Last . Just $ SocketConfig (Last Nothing) mempty mempty mempty
    , pncShutdownConfig = Last Nothing
    , pncStartAsNonProducingNode = Last $ Just False
    , pncDiffusionMode = Last Nothing
    , pncExperimentalProtocolsEnabled = Last Nothing
    , pncMaxConcurrencyBulkSync = Last Nothing
    , pncMaxConcurrencyDeadline = Last Nothing
    , pncTraceForwardSocket = Last Nothing
    , pncConfigFile = mempty
    , pncTopologyFile = mempty
    , pncDatabaseFile = mempty
    , pncProtocolFiles = mempty
    , pncValidateDB = mempty
    , pncMaybeMempoolCapacityOverride = mempty
    , pncProtocolIdleTimeout = mempty
    , pncTimeWaitTimeout = mempty
    , pncChainSyncIdleTimeout = mempty
    , pncMempoolTimeoutSoft = mempty
    , pncMempoolTimeoutHard = mempty
    , pncMempoolTimeoutCapacity = mempty
    , pncAcceptedConnectionsLimit = mempty
    , pncDeadlineTargetOfRootPeers = mempty
    , pncDeadlineTargetOfKnownPeers = mempty
    , pncDeadlineTargetOfEstablishedPeers = mempty
    , pncDeadlineTargetOfActivePeers = mempty
    , pncDeadlineTargetOfKnownBigLedgerPeers = mempty
    , pncDeadlineTargetOfEstablishedBigLedgerPeers = mempty
    , pncDeadlineTargetOfActiveBigLedgerPeers = mempty
    , pncSyncTargetOfRootPeers = mempty
    , pncSyncTargetOfKnownPeers = mempty
    , pncSyncTargetOfEstablishedPeers = mempty
    , pncSyncTargetOfActivePeers = mempty
    , pncSyncTargetOfKnownBigLedgerPeers = mempty
    , pncSyncTargetOfEstablishedBigLedgerPeers = mempty
    , pncSyncTargetOfActiveBigLedgerPeers = mempty
    , pncMinBigLedgerPeersForTrustedState = mempty
    , pncPeerSharing = Last (Just PeerSharingDisabled)
    , pncConsensusMode = mempty
    , pncGenesisConfigFlags = mempty
    , pncResponderCoreAffinityPolicy = mempty
    , pncLedgerDbConfig = mempty
    , pncEgressPollInterval = mempty
    , pncRpcConfig = mempty
    , pncTxSubmissionLogicVersion = mempty
    , pncTxSubmissionInitDelay = mempty
    }

-- | Example partial configuration theoretically created
-- from what was parsed on the command line.
testPartialCliConfig :: PartialNodeConfiguration
testPartialCliConfig =
  PartialNodeConfiguration
    { pncSocketConfig = Last . Just $ SocketConfig mempty mempty mempty mempty
    , pncShutdownConfig = Last . Just $ ShutdownConfig Nothing (Just . ASlot $ SlotNo 42)
    , pncStartAsNonProducingNode = Last $ Just False
    , pncConfigFile   = mempty
    , pncTopologyFile = mempty
    , pncDatabaseFile = mempty
    , pncDiffusionMode = mempty
    , pncExperimentalProtocolsEnabled = Last $ Just True
    , pncProtocolFiles = Last . Just $ ProtocolFilepaths Nothing Nothing Nothing Nothing Nothing Nothing
    , pncValidateDB = Last $ Just True
    , pncProtocolConfig = mempty
    , pncMaxConcurrencyBulkSync = mempty
    , pncMaxConcurrencyDeadline = mempty
    , pncTraceForwardSocket = mempty
    , pncMaybeMempoolCapacityOverride = mempty
    , pncProtocolIdleTimeout = mempty
    , pncTimeWaitTimeout = mempty
    , pncChainSyncIdleTimeout = mempty
    , pncMempoolTimeoutSoft = mempty
    , pncMempoolTimeoutHard = mempty
    , pncMempoolTimeoutCapacity = mempty
    , pncAcceptedConnectionsLimit = mempty
    , pncDeadlineTargetOfRootPeers = mempty
    , pncDeadlineTargetOfKnownPeers = mempty
    , pncDeadlineTargetOfEstablishedPeers = mempty
    , pncDeadlineTargetOfActivePeers = mempty
    , pncDeadlineTargetOfKnownBigLedgerPeers = mempty
    , pncDeadlineTargetOfEstablishedBigLedgerPeers = mempty
    , pncDeadlineTargetOfActiveBigLedgerPeers = mempty
    , pncSyncTargetOfRootPeers = mempty
    , pncSyncTargetOfKnownPeers = mempty
    , pncSyncTargetOfEstablishedPeers = mempty
    , pncSyncTargetOfActivePeers = mempty
    , pncSyncTargetOfKnownBigLedgerPeers = mempty
    , pncSyncTargetOfEstablishedBigLedgerPeers = mempty
    , pncSyncTargetOfActiveBigLedgerPeers = mempty
    , pncMinBigLedgerPeersForTrustedState = Last (Just defaultNumberOfBigLedgerPeers)
    , pncPeerSharing = Last (Just PeerSharingDisabled)
    , pncConsensusMode = Last (Just PraosMode)
    , pncGenesisConfigFlags = mempty
    , pncResponderCoreAffinityPolicy = mempty
    , pncLedgerDbConfig = mempty
    , pncEgressPollInterval = mempty
    , pncRpcConfig = mempty
    , pncTxSubmissionLogicVersion = mempty
    , pncTxSubmissionInitDelay = mempty
    }

-- | Expected final NodeConfiguration
eExpectedConfig :: Either Text NodeConfiguration
eExpectedConfig = do
  ncRpcConfig <- first fromString $ makeRpcConfig mempty
  return $ NodeConfiguration
    { ncSocketConfig = SocketConfig mempty mempty mempty mempty
    , ncShutdownConfig = ShutdownConfig Nothing (Just . ASlot $ SlotNo 42)
    , ncStartAsNonProducingNode = False
    , ncConfigFile = ConfigYamlFilePath "configuration/cardano/mainnet-config.json"
    , ncTopologyFile = TopologyFile "configuration/cardano/mainnet-topology.json"
    , ncDatabaseFile = OnePathForAllDbs "mainnet/db/"
    , ncProtocolFiles = ProtocolFilepaths Nothing Nothing Nothing Nothing Nothing Nothing
    , ncValidateDB = True
    , ncProtocolConfig = testNodeProtocolConfiguration
    , ncDiffusionMode = InitiatorAndResponderDiffusionMode
    , ncExperimentalProtocolsEnabled = True
    , ncEgressPollInterval = 0
    , ncMaxConcurrencyBulkSync = Nothing
    , ncMaxConcurrencyDeadline = Nothing
    , ncTraceForwardSocket = Nothing
    , ncMaybeMempoolCapacityOverride = Nothing
    , ncProtocolIdleTimeout = 5
    , ncTimeWaitTimeout = 60
    , ncChainSyncIdleTimeout = NoTimeoutOverride
    , ncMempoolTimeoutSoft = 1.0
    , ncMempoolTimeoutHard = 1.5
    , ncMempoolTimeoutCapacity = 5.0
    , ncAcceptedConnectionsLimit =
        AcceptedConnectionsLimit
          { acceptedConnectionsHardLimit = 512
          , acceptedConnectionsSoftLimit = 384
          , acceptedConnectionsDelay     = 5
          }
    , ncDeadlineTargetOfRootPeers = 60
    , ncDeadlineTargetOfKnownPeers = 150
    , ncDeadlineTargetOfEstablishedPeers = 30
    , ncDeadlineTargetOfActivePeers = 20
    , ncDeadlineTargetOfKnownBigLedgerPeers = 15
    , ncDeadlineTargetOfEstablishedBigLedgerPeers = 10
    , ncDeadlineTargetOfActiveBigLedgerPeers = 5
    , ncSyncTargetOfRootPeers = 0
    , ncSyncTargetOfKnownPeers = 150
    , ncSyncTargetOfEstablishedPeers = 10
    , ncSyncTargetOfActivePeers = 5
    , ncSyncTargetOfKnownBigLedgerPeers = 100
    , ncSyncTargetOfEstablishedBigLedgerPeers = 40
    , ncSyncTargetOfActiveBigLedgerPeers = 30
    , ncMinBigLedgerPeersForTrustedState = defaultNumberOfBigLedgerPeers
    , ncPeerSharing = PeerSharingDisabled
    , ncConsensusMode = PraosMode
    , ncGenesisConfig = disableGenesisConfig
    , ncResponderCoreAffinityPolicy = NoResponderCoreAffinity
    , ncLedgerDbConfig = LedgerDbConfiguration defaultSnapshotPolicyArgs DefaultQueryBatchSize V2InMemory noDeprecatedOptions
    , ncRpcConfig
    , ncTxSubmissionLogicVersion = TxSubmissionLogicV1
    , ncTxSubmissionInitDelay = defaultTxSubmissionInitDelay
    }

-- | Test that the legacy flat LedgerDB snapshot config format (options directly
-- under LedgerDB) parses identically to the new nested Snapshots format.
--
-- TODO: this test could be removed once the old format is deprecated.
prop_legacySnapshotFormat_POM :: Property
prop_legacySnapshotFormat_POM =
  withTests 1 . Hedgehog.property $ do
    let legacyJson = "{ " <> dummyRequiredValues <> ", "
          <> "\"LedgerDB\": {"
          <> "  \"Backend\": \"V2InMemory\","
          <> "  \"SnapshotInterval\": 4320,"
          <> "  \"NumOfDiskSnapshots\": 2"
          <> "} }"
        newJson = "{ " <> dummyRequiredValues <> ", "
          <> "\"LedgerDB\": {"
          <> "  \"Backend\": \"V2InMemory\","
          <> "  \"Snapshots\": {"
          <> "    \"SnapshotInterval\": 4320,"
          <> "    \"NumOfDiskSnapshots\": 2"
          <> "  }"
          <> "} }"
    legacyConfig :: PartialNodeConfiguration <- evalEither $ eitherDecode legacyJson
    newConfig    :: PartialNodeConfiguration <- evalEither $ eitherDecode newJson
    pncLedgerDbConfig legacyConfig === pncLedgerDbConfig newConfig

-- | Snapshot options set directly under @LedgerDB@ are never read when a
-- @LedgerDB.Snapshots@ block is also present, so the combination must be
-- rejected rather than silently resolved.  Before this was checked, each of
-- the configurations below parsed cleanly and quietly used the defaults (or
-- the @Snapshots@ value), discarding what the operator wrote.
prop_flatSnapshotOptsShadowedBySnapshots_POM :: Property
prop_flatSnapshotOptsShadowedBySnapshots_POM =
  withTests 1 . Hedgehog.property $
    mapM_ expectShadowingFailure
      [ ("SnapshotInterval",   "\"SnapshotInterval\": 111, \"Snapshots\": {}")
      , ("SnapshotInterval",   "\"SnapshotInterval\": 111, \"Snapshots\": {\"SnapshotInterval\": 999}")
      , ("NumOfDiskSnapshots", "\"NumOfDiskSnapshots\": 7, \"Snapshots\": {}")
      , ("SlotOffset",         "\"SlotOffset\": 12345, \"RateLimit\": 42, \"Snapshots\": {}")
      , ("RateLimit",          "\"SlotOffset\": 12345, \"RateLimit\": 42, \"Snapshots\": {}")
      , ("SnapshotInterval",   "\"SnapshotInterval\": 111, \"Snapshots\": \"Mithril\"")
        -- A shadowed option is not even validated: this one is rejected
        -- outright when no `Snapshots` block is present.
      , ("SnapshotInterval",   "\"SnapshotInterval\": -5, \"Snapshots\": {}")
      ]
  where
    expectShadowingFailure (key, ledgerDbBody) = do
      let json = "{ " <> dummyRequiredValues <> ", \"LedgerDB\": {" <> ledgerDbBody <> "} }"
      case eitherDecode json :: Either String PartialNodeConfiguration of
        Right _ -> failWith Nothing $
          "expected a parse failure for shadowed LedgerDB option " <> show key
            <> ", but got a successful parse of: " <> show json
        Left err -> do
          Hedgehog.annotate err
          Hedgehog.assert (key `isInfixOf` err)

-- | The deprecated top-level @SnapshotInterval@ still applies when the
-- @Snapshots@ block does not set it, and is still reported as a moved option.
-- This is the compatibility path the shadowing check above must not disturb.
prop_topLevelSnapshotIntervalFallback_POM :: Property
prop_topLevelSnapshotIntervalFallback_POM =
  withTests 1 . Hedgehog.property $ do
    let topLevelJson = "{ " <> dummyRequiredValues <> ", "
          <> "\"SnapshotInterval\": 111, "
          <> "\"LedgerDB\": {\"Snapshots\": {}} }"
        referenceJson = "{ " <> dummyRequiredValues <> ", "
          <> "\"LedgerDB\": {\"Snapshots\": {\"SnapshotInterval\": 111}} }"
    topLevelConfig  :: PartialNodeConfiguration <- evalEither $ eitherDecode topLevelJson
    referenceConfig :: PartialNodeConfiguration <- evalEither $ eitherDecode referenceJson
    fmap fst (ledgerDbPolicyAndDeprecated topLevelConfig)
      === fmap fst (ledgerDbPolicyAndDeprecated referenceConfig)
    fmap snd (ledgerDbPolicyAndDeprecated topLevelConfig)
      === Just (DeprecatedOptions ["SnapshotInterval"])

-- | When the @Snapshots@ block does set @SnapshotInterval@, it wins over the
-- deprecated top-level one -- which is still reported as a moved option even
-- though its value was discarded.
prop_snapshotsOverridesTopLevel_POM :: Property
prop_snapshotsOverridesTopLevel_POM =
  withTests 1 . Hedgehog.property $ do
    let overriddenJson = "{ " <> dummyRequiredValues <> ", "
          <> "\"SnapshotInterval\": 111, "
          <> "\"LedgerDB\": {\"Snapshots\": {\"SnapshotInterval\": 999}} }"
        referenceJson = "{ " <> dummyRequiredValues <> ", "
          <> "\"LedgerDB\": {\"Snapshots\": {\"SnapshotInterval\": 999}} }"
    overriddenConfig :: PartialNodeConfiguration <- evalEither $ eitherDecode overriddenJson
    referenceConfig  :: PartialNodeConfiguration <- evalEither $ eitherDecode referenceJson
    fmap fst (ledgerDbPolicyAndDeprecated overriddenConfig)
      === fmap fst (ledgerDbPolicyAndDeprecated referenceConfig)
    fmap snd (ledgerDbPolicyAndDeprecated overriddenConfig)
      === Just (DeprecatedOptions ["SnapshotInterval"])

-- | Project the snapshot policy and the deprecated-option list out of a parsed
-- config, so the two can be asserted on independently.
ledgerDbPolicyAndDeprecated
  :: PartialNodeConfiguration -> Maybe (SnapshotPolicyArgs, DeprecatedOptions)
ledgerDbPolicyAndDeprecated pnc =
  case getLast (pncLedgerDbConfig pnc) of
    Just (LedgerDbConfiguration spArgs _ _ depOpts) -> Just (spArgs, depOpts)
    Nothing -> Nothing

-- | Test that the named \"Mithril\" snapshot policy selects
-- 'mithrilSnapshotPolicyArgs' as a whole.
prop_mithrilSnapshotPolicy_POM :: Property
prop_mithrilSnapshotPolicy_POM =
  withTests 1 . Hedgehog.property $ do
    let json = "{ " <> dummyRequiredValues <> ", "
          <> "\"LedgerDB\": {"
          <> "  \"Backend\": \"V2InMemory\","
          <> "  \"Snapshots\": \"Mithril\""
          <> "} }"
    config :: PartialNodeConfiguration <- evalEither $ eitherDecode json
    getLast (pncLedgerDbConfig config) ===
      Just (LedgerDbConfiguration mithrilSnapshotPolicyArgs DefaultQueryBatchSize V2InMemory noDeprecatedOptions)

dummyRequiredValues :: LBS.ByteString
dummyRequiredValues = mconcat
  [ "\"ByronGenesisFile\": \"x\""
  , ", \"ShelleyGenesisFile\": \"x\""
  , ", \"AlonzoGenesisFile\": \"x\""
  , ", \"ConwayGenesisFile\": \"x\""
  , ", \"LastKnownBlockVersion-Major\": 0"
  , ", \"LastKnownBlockVersion-Minor\": 0"
  , ", \"LastKnownBlockVersion-Alt\": 0"
  ]

-- A socket config with a node socket path, needed for RPC-enabled tests
-- because makeRpcConfig validates that a node socket exists when RPC is enabled.
testSocketConfigWithPath :: Last SocketConfig
testSocketConfigWithPath =
  Last . Just $ SocketConfig mempty mempty mempty (Last . Just $ File "node.socket")

-- | CLI --grpc-enable + YAML silent -> RPC stays enabled.
-- Documents the config precedence that issue #6589 depends on: CLI flags
-- must survive a YAML-only re-read.
prop_rpcReload_cliEnabledYamlSilent :: Property
prop_rpcReload_cliEnabledYamlSilent =
  H.propertyOnce $ do
    let cliConfig = testPartialCliConfig
          { pncRpcConfig = RpcConfig (Last (Just True)) mempty mempty
          , pncSocketConfig = testSocketConfigWithPath
          }
        merged = defaultPartialNodeConfiguration <> testPartialYamlConfig <> cliConfig
    NodeConfiguration{ncRpcConfig = RpcConfig{isEnabled}} <- evalEither $ makeNodeConfiguration merged
    isEnabled === Identity True

-- | CLI silent + YAML EnableRpc -> RPC enabled.
prop_rpcReload_cliSilentYamlEnabled :: Property
prop_rpcReload_cliSilentYamlEnabled =
  H.propertyOnce $ do
    let yamlConfig = testPartialYamlConfig{pncRpcConfig = RpcConfig (Last (Just True)) mempty mempty}
        cliConfig = testPartialCliConfig{pncSocketConfig = testSocketConfigWithPath}
        merged = defaultPartialNodeConfiguration <> yamlConfig <> cliConfig
    NodeConfiguration{ncRpcConfig = RpcConfig{isEnabled}} <- evalEither $ makeNodeConfiguration merged
    isEnabled === Identity True

-- | Both CLI and YAML silent -> RPC disabled (default).
prop_rpcReload_bothSilent :: Property
prop_rpcReload_bothSilent =
  H.propertyOnce $ do
    let merged = defaultPartialNodeConfiguration <> testPartialYamlConfig <> testPartialCliConfig
    NodeConfiguration{ncRpcConfig = RpcConfig{isEnabled}} <- evalEither $ makeNodeConfiguration merged
    isEnabled === Identity False

-- | CLI --grpc-enable wins over YAML EnableRpc: false.
prop_rpcReload_cliOverridesYaml :: Property
prop_rpcReload_cliOverridesYaml =
  H.propertyOnce $ do
    let yamlConfig = testPartialYamlConfig{pncRpcConfig = RpcConfig (Last (Just False)) mempty mempty}
        cliConfig = testPartialCliConfig
          { pncRpcConfig = RpcConfig (Last (Just True)) mempty mempty
          , pncSocketConfig = testSocketConfigWithPath
          }
        merged = defaultPartialNodeConfiguration <> yamlConfig <> cliConfig
    NodeConfiguration{ncRpcConfig = RpcConfig{isEnabled}} <- evalEither $ makeNodeConfiguration merged
    isEnabled === Identity True

-- -----------------------------------------------------------------------------

tests :: IO Bool
tests =
  Hedgehog.checkParallel $$discover
