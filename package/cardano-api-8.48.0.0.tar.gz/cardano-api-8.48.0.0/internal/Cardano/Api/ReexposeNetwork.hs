module Cardano.Api.ReexposeNetwork
  (Target(..)) where

import           Ouroboros.Network.Protocol.LocalStateQuery.Type (Target (..))
