module OccName (module StubTypes) where

import StubTypes
-- data NameSpace = NameSpace

