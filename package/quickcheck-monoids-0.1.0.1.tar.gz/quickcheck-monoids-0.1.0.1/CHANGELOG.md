# Revision history for quickcheck-monoids

## Next version

## 0.1.0.1 -- 2024-08-

* Make it build with ghc-9.10
  * fix base upper bound

## 0.1.0.0 -- 2024-06-07

* First version. Released on an unsuspecting world.
