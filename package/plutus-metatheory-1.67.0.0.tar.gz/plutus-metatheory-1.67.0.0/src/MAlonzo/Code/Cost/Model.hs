{-# LANGUAGE BangPatterns #-}
{-# LANGUAGE EmptyCase #-}
{-# LANGUAGE EmptyDataDecls #-}
{-# LANGUAGE ExistentialQuantification #-}
{-# LANGUAGE NoMonomorphismRestriction #-}
{-# LANGUAGE OverloadedStrings #-}
{-# LANGUAGE PatternSynonyms #-}
{-# LANGUAGE RankNTypes #-}
{-# LANGUAGE ScopedTypeVariables #-}

{-# OPTIONS_GHC -Wno-overlapping-patterns #-}

module MAlonzo.Code.Cost.Model where

import MAlonzo.RTE (coe, erased, AgdaAny, addInt, subInt, mulInt,
                    quotInt, remInt, geqInt, ltInt, eqInt, add64, sub64, mul64, quot64,
                    rem64, lt64, eq64, word64FromNat, word64ToNat)
import qualified MAlonzo.RTE
import qualified Data.Text
import qualified MAlonzo.Code.Agda.Builtin.List
import qualified MAlonzo.Code.Agda.Builtin.Maybe
import qualified MAlonzo.Code.Agda.Builtin.Nat
import qualified MAlonzo.Code.Agda.Builtin.Sigma
import qualified MAlonzo.Code.Agda.Builtin.String
import qualified MAlonzo.Code.Builtin
import qualified MAlonzo.Code.Builtin.Signature
import qualified MAlonzo.Code.Cost.Raw
import qualified MAlonzo.Code.Data.Bool.Base
import qualified MAlonzo.Code.Data.Char.Properties
import qualified MAlonzo.Code.Data.Fin.Base
import qualified MAlonzo.Code.Data.List.Base
import qualified MAlonzo.Code.Data.List.NonEmpty.Base
import qualified MAlonzo.Code.Data.List.Relation.Binary.Pointwise.Properties
import qualified MAlonzo.Code.Data.Maybe.Base
import qualified MAlonzo.Code.Data.Nat.Base
import qualified MAlonzo.Code.Data.Nat.Properties
import qualified MAlonzo.Code.Data.String.Properties
import qualified MAlonzo.Code.Data.Vec.Base
import qualified MAlonzo.Code.Relation.Nullary.Decidable.Core
import qualified MAlonzo.Code.Relation.Nullary.Reflects
import qualified MAlonzo.Code.Utils

-- Cost.Model.Intercept
d_Intercept_4 :: ()
d_Intercept_4 = erased
-- Cost.Model.Slope
d_Slope_6 :: ()
d_Slope_6 = erased
-- Cost.Model.CostingModel
d_CostingModel_8 a0 = ()
data T_CostingModel_8
  = C_constantCost_12 Integer |
    C_linearCostIn_16 MAlonzo.Code.Data.Fin.Base.T_Fin_10 Integer
                      Integer |
    C_quadraticCostIn1_20 MAlonzo.Code.Data.Fin.Base.T_Fin_10 Integer
                          Integer Integer |
    C_quadraticCostIn2_24 MAlonzo.Code.Data.Fin.Base.T_Fin_10
                          MAlonzo.Code.Data.Fin.Base.T_Fin_10 Integer Integer Integer Integer
                          Integer Integer Integer |
    C_withInteractionIn_28 MAlonzo.Code.Data.Fin.Base.T_Fin_10
                           MAlonzo.Code.Data.Fin.Base.T_Fin_10 Integer Integer Integer
                           Integer |
    C_literalCostIn_32 MAlonzo.Code.Data.Fin.Base.T_Fin_10
                       T_CostingModel_8 |
    C_addedSizes_36 Integer Integer |
    C_multipliedSizes_40 Integer Integer |
    C_minSize_44 Integer Integer | C_maxSize_48 Integer Integer |
    C_twoArgumentsSubtractedSizes_50 Integer Integer Integer |
    C_twoArgumentsConstAboveDiagonal_52 Integer T_CostingModel_8 |
    C_twoArgumentsConstBelowDiagonal_54 Integer T_CostingModel_8 |
    C_twoArgumentsConstOffDiagonal_56 Integer T_CostingModel_8 |
    C_twoArgumentsAboveAndBelowDiagonal_58 Integer T_CostingModel_8 |
    C_twoArgumentsLinearInYAndZ_60 Integer Integer Integer |
    C_twoArgumentsLinearInMaxYZ_62 Integer Integer |
    C_threeArgumentsExpModCost_64 Integer Integer Integer
-- Cost.Model.BuiltinModel
d_BuiltinModel_68 a0 = ()
data T_BuiltinModel_68
  = C_constructor_80 T_CostingModel_8 T_CostingModel_8
-- Cost.Model.BuiltinModel.costingCPU
d_costingCPU_76 :: T_BuiltinModel_68 -> T_CostingModel_8
d_costingCPU_76 v0
  = case coe v0 of
      C_constructor_80 v1 v2 -> coe v1
      _ -> MAlonzo.RTE.mazUnreachableError
-- Cost.Model.BuiltinModel.costingMem
d_costingMem_78 :: T_BuiltinModel_68 -> T_CostingModel_8
d_costingMem_78 v0
  = case coe v0 of
      C_constructor_80 v1 v2 -> coe v2
      _ -> MAlonzo.RTE.mazUnreachableError
-- Cost.Model.prod
d_prod_84 ::
  Integer -> MAlonzo.Code.Data.Vec.Base.T_Vec_28 -> Integer
d_prod_84 v0
  = coe
      MAlonzo.Code.Data.Vec.Base.du_foldr_352 (coe v0)
      (coe (\ v1 -> mulInt)) (coe (1 :: Integer))
-- Cost.Model.maximum
d_maximum_88 ::
  Integer -> MAlonzo.Code.Data.Vec.Base.T_Vec_28 -> Integer
d_maximum_88 v0 v1
  = case coe v1 of
      MAlonzo.Code.Data.Vec.Base.C__'8759'__38 v3 v4
        -> coe
             MAlonzo.Code.Data.Vec.Base.du_foldr_352 (coe v0)
             (coe (\ v5 -> MAlonzo.Code.Data.Nat.Base.d__'8852'__208)) (coe v3)
             (coe v4)
      _ -> MAlonzo.RTE.mazUnreachableError
-- Cost.Model.minimum
d_minimum_92 ::
  Integer -> MAlonzo.Code.Data.Vec.Base.T_Vec_28 -> Integer
d_minimum_92 v0 v1
  = case coe v1 of
      MAlonzo.Code.Data.Vec.Base.C__'8759'__38 v3 v4
        -> coe
             MAlonzo.Code.Data.Vec.Base.du_foldr_352 (coe v0)
             (coe (\ v5 -> MAlonzo.Code.Data.Nat.Base.d__'8851'__236)) (coe v3)
             (coe v4)
      _ -> MAlonzo.RTE.mazUnreachableError
-- Cost.Model.runModel
d_runModel_104 ::
  Integer ->
  T_CostingModel_8 -> MAlonzo.Code.Data.Vec.Base.T_Vec_28 -> Integer
d_runModel_104 v0 v1 v2
  = case coe v1 of
      C_constantCost_12 v4 -> coe v4
      C_linearCostIn_16 v4 v5 v6
        -> coe
             addInt
             (coe
                mulInt (coe v6)
                (coe MAlonzo.Code.Data.Vec.Base.du_lookup_82 (coe v2) (coe v4)))
             (coe v5)
      C_quadraticCostIn1_20 v4 v5 v6 v7
        -> coe
             addInt
             (coe
                addInt
                (coe
                   mulInt
                   (coe
                      mulInt (coe v7)
                      (coe MAlonzo.Code.Data.Vec.Base.du_lookup_82 (coe v2) (coe v4)))
                   (coe MAlonzo.Code.Data.Vec.Base.du_lookup_82 (coe v2) (coe v4)))
                (coe
                   mulInt (coe v6)
                   (coe MAlonzo.Code.Data.Vec.Base.du_lookup_82 (coe v2) (coe v4))))
             (coe v5)
      C_quadraticCostIn2_24 v4 v5 v6 v7 v8 v9 v10 v11 v12
        -> coe
             MAlonzo.Code.Data.Nat.Base.d__'8852'__208 (coe v6)
             (coe
                addInt
                (coe
                   addInt
                   (coe
                      addInt
                      (coe
                         addInt
                         (coe
                            addInt
                            (coe
                               mulInt
                               (coe
                                  mulInt (coe v10)
                                  (coe MAlonzo.Code.Data.Vec.Base.du_lookup_82 (coe v2) (coe v4)))
                               (coe MAlonzo.Code.Data.Vec.Base.du_lookup_82 (coe v2) (coe v4)))
                            (coe
                               mulInt
                               (coe
                                  mulInt (coe v11)
                                  (coe MAlonzo.Code.Data.Vec.Base.du_lookup_82 (coe v2) (coe v4)))
                               (coe MAlonzo.Code.Data.Vec.Base.du_lookup_82 (coe v2) (coe v5))))
                         (coe
                            mulInt
                            (coe
                               mulInt (coe v12)
                               (coe MAlonzo.Code.Data.Vec.Base.du_lookup_82 (coe v2) (coe v5)))
                            (coe MAlonzo.Code.Data.Vec.Base.du_lookup_82 (coe v2) (coe v5))))
                      (coe
                         mulInt (coe v8)
                         (coe MAlonzo.Code.Data.Vec.Base.du_lookup_82 (coe v2) (coe v4))))
                   (coe
                      mulInt (coe v9)
                      (coe MAlonzo.Code.Data.Vec.Base.du_lookup_82 (coe v2) (coe v5))))
                (coe v7))
      C_withInteractionIn_28 v4 v5 v6 v7 v8 v9
        -> coe
             addInt
             (coe
                addInt
                (coe
                   addInt
                   (coe
                      mulInt
                      (coe
                         mulInt (coe v9)
                         (coe MAlonzo.Code.Data.Vec.Base.du_lookup_82 (coe v2) (coe v4)))
                      (coe MAlonzo.Code.Data.Vec.Base.du_lookup_82 (coe v2) (coe v5)))
                   (coe
                      mulInt (coe v7)
                      (coe MAlonzo.Code.Data.Vec.Base.du_lookup_82 (coe v2) (coe v4))))
                (coe
                   mulInt (coe v8)
                   (coe MAlonzo.Code.Data.Vec.Base.du_lookup_82 (coe v2) (coe v5))))
             (coe v6)
      C_literalCostIn_32 v4 v5
        -> let v6
                 = coe MAlonzo.Code.Data.Vec.Base.du_lookup_82 (coe v2) (coe v4) in
           coe
             (case coe v6 of
                0 -> coe d_runModel_104 (coe v0) (coe v5) (coe v2)
                _ -> coe v6)
      C_addedSizes_36 v4 v5
        -> coe
             addInt
             (coe
                mulInt (coe v5) (coe MAlonzo.Code.Data.Vec.Base.d_sum_420 v0 v2))
             (coe v4)
      C_multipliedSizes_40 v4 v5
        -> coe addInt (coe mulInt (coe v5) (coe d_prod_84 v0 v2)) (coe v4)
      C_minSize_44 v4 v5
        -> let v6 = subInt (coe v0) (coe (1 :: Integer)) in
           coe
             (coe
                addInt (coe mulInt (coe v5) (coe d_minimum_92 (coe v6) (coe v2)))
                (coe v4))
      C_maxSize_48 v4 v5
        -> let v6 = subInt (coe v0) (coe (1 :: Integer)) in
           coe
             (coe
                addInt (coe mulInt (coe v5) (coe d_maximum_88 (coe v6) (coe v2)))
                (coe v4))
      C_twoArgumentsSubtractedSizes_50 v3 v4 v5
        -> case coe v2 of
             MAlonzo.Code.Data.Vec.Base.C__'8759'__38 v7 v8
               -> case coe v8 of
                    MAlonzo.Code.Data.Vec.Base.C__'8759'__38 v10 v11
                      -> coe
                           addInt
                           (coe
                              mulInt (coe v4)
                              (coe
                                 MAlonzo.Code.Data.Nat.Base.d__'8852'__208 (coe v5)
                                 (coe MAlonzo.Code.Agda.Builtin.Nat.d__'45'__22 v7 v10)))
                           (coe v3)
                    _ -> MAlonzo.RTE.mazUnreachableError
             _ -> MAlonzo.RTE.mazUnreachableError
      C_twoArgumentsConstAboveDiagonal_52 v3 v4
        -> case coe v2 of
             MAlonzo.Code.Data.Vec.Base.C__'8759'__38 v6 v7
               -> case coe v7 of
                    MAlonzo.Code.Data.Vec.Base.C__'8759'__38 v9 v10
                      -> coe
                           seq (coe v10)
                           (coe
                              MAlonzo.Code.Data.Bool.Base.du_if_then_else__44
                              (coe ltInt (coe v6) (coe v9)) (coe v3)
                              (coe
                                 d_runModel_104 (coe (2 :: Integer)) (coe v4)
                                 (coe
                                    MAlonzo.Code.Data.Vec.Base.C__'8759'__38 v6
                                    (coe
                                       MAlonzo.Code.Data.Vec.Base.C__'8759'__38 v9
                                       (coe MAlonzo.Code.Data.Vec.Base.C_'91''93'_32)))))
                    _ -> MAlonzo.RTE.mazUnreachableError
             _ -> MAlonzo.RTE.mazUnreachableError
      C_twoArgumentsConstBelowDiagonal_54 v3 v4
        -> case coe v2 of
             MAlonzo.Code.Data.Vec.Base.C__'8759'__38 v6 v7
               -> case coe v7 of
                    MAlonzo.Code.Data.Vec.Base.C__'8759'__38 v9 v10
                      -> coe
                           seq (coe v10)
                           (coe
                              MAlonzo.Code.Data.Bool.Base.du_if_then_else__44
                              (coe ltInt (coe v9) (coe v6)) (coe v3)
                              (coe
                                 d_runModel_104 (coe (2 :: Integer)) (coe v4)
                                 (coe
                                    MAlonzo.Code.Data.Vec.Base.C__'8759'__38 v6
                                    (coe
                                       MAlonzo.Code.Data.Vec.Base.C__'8759'__38 v9
                                       (coe MAlonzo.Code.Data.Vec.Base.C_'91''93'_32)))))
                    _ -> MAlonzo.RTE.mazUnreachableError
             _ -> MAlonzo.RTE.mazUnreachableError
      C_twoArgumentsConstOffDiagonal_56 v3 v4
        -> case coe v2 of
             MAlonzo.Code.Data.Vec.Base.C__'8759'__38 v6 v7
               -> case coe v7 of
                    MAlonzo.Code.Data.Vec.Base.C__'8759'__38 v9 v10
                      -> coe
                           seq (coe v10)
                           (coe
                              MAlonzo.Code.Data.Bool.Base.du_if_then_else__44
                              (coe
                                 MAlonzo.Code.Data.Bool.Base.d_not_22 (coe eqInt (coe v6) (coe v9)))
                              (coe v3)
                              (coe
                                 d_runModel_104 (coe (2 :: Integer)) (coe v4)
                                 (coe
                                    MAlonzo.Code.Data.Vec.Base.C__'8759'__38 v6
                                    (coe
                                       MAlonzo.Code.Data.Vec.Base.C__'8759'__38 v9
                                       (coe MAlonzo.Code.Data.Vec.Base.C_'91''93'_32)))))
                    _ -> MAlonzo.RTE.mazUnreachableError
             _ -> MAlonzo.RTE.mazUnreachableError
      C_twoArgumentsAboveAndBelowDiagonal_58 v3 v4
        -> case coe v2 of
             MAlonzo.Code.Data.Vec.Base.C__'8759'__38 v6 v7
               -> case coe v7 of
                    MAlonzo.Code.Data.Vec.Base.C__'8759'__38 v9 v10
                      -> coe
                           seq (coe v10)
                           (coe
                              MAlonzo.Code.Data.Bool.Base.du_if_then_else__44
                              (coe ltInt (coe v9) (coe v6))
                              (coe
                                 d_runModel_104 (coe (2 :: Integer)) (coe v4)
                                 (coe
                                    MAlonzo.Code.Data.Vec.Base.C__'8759'__38 v6
                                    (coe
                                       MAlonzo.Code.Data.Vec.Base.C__'8759'__38 v9
                                       (coe MAlonzo.Code.Data.Vec.Base.C_'91''93'_32))))
                              (coe
                                 d_runModel_104 (coe (2 :: Integer)) (coe v4)
                                 (coe
                                    MAlonzo.Code.Data.Vec.Base.C__'8759'__38 v9
                                    (coe
                                       MAlonzo.Code.Data.Vec.Base.C__'8759'__38 v6
                                       (coe MAlonzo.Code.Data.Vec.Base.C_'91''93'_32)))))
                    _ -> MAlonzo.RTE.mazUnreachableError
             _ -> MAlonzo.RTE.mazUnreachableError
      C_twoArgumentsLinearInYAndZ_60 v3 v4 v5
        -> case coe v2 of
             MAlonzo.Code.Data.Vec.Base.C__'8759'__38 v7 v8
               -> case coe v8 of
                    MAlonzo.Code.Data.Vec.Base.C__'8759'__38 v10 v11
                      -> case coe v11 of
                           MAlonzo.Code.Data.Vec.Base.C__'8759'__38 v13 v14
                             -> coe
                                  addInt
                                  (coe
                                     addInt (coe mulInt (coe v4) (coe v10))
                                     (coe mulInt (coe v5) (coe v13)))
                                  (coe v3)
                           _ -> MAlonzo.RTE.mazUnreachableError
                    _ -> MAlonzo.RTE.mazUnreachableError
             _ -> MAlonzo.RTE.mazUnreachableError
      C_twoArgumentsLinearInMaxYZ_62 v3 v4
        -> case coe v2 of
             MAlonzo.Code.Data.Vec.Base.C__'8759'__38 v6 v7
               -> case coe v7 of
                    MAlonzo.Code.Data.Vec.Base.C__'8759'__38 v9 v10
                      -> case coe v10 of
                           MAlonzo.Code.Data.Vec.Base.C__'8759'__38 v12 v13
                             -> coe
                                  addInt
                                  (coe
                                     mulInt (coe v4)
                                     (coe
                                        d_maximum_88 (coe (1 :: Integer))
                                        (coe
                                           MAlonzo.Code.Data.Vec.Base.C__'8759'__38 v9
                                           (coe
                                              MAlonzo.Code.Data.Vec.Base.C__'8759'__38 v12
                                              (coe MAlonzo.Code.Data.Vec.Base.C_'91''93'_32)))))
                                  (coe v3)
                           _ -> MAlonzo.RTE.mazUnreachableError
                    _ -> MAlonzo.RTE.mazUnreachableError
             _ -> MAlonzo.RTE.mazUnreachableError
      C_threeArgumentsExpModCost_64 v3 v4 v5
        -> case coe v2 of
             MAlonzo.Code.Data.Vec.Base.C__'8759'__38 v7 v8
               -> case coe v8 of
                    MAlonzo.Code.Data.Vec.Base.C__'8759'__38 v10 v11
                      -> case coe v11 of
                           MAlonzo.Code.Data.Vec.Base.C__'8759'__38 v13 v14
                             -> coe
                                  seq (coe v14)
                                  (coe
                                     MAlonzo.Code.Data.Bool.Base.du_if_then_else__44
                                     (coe ltInt (coe v13) (coe v7))
                                     (coe
                                        addInt
                                        (coe
                                           addInt
                                           (coe
                                              addInt
                                              (coe
                                                 MAlonzo.Code.Data.Nat.Base.du__'47'__318
                                                 (coe
                                                    addInt
                                                    (coe
                                                       addInt
                                                       (coe
                                                          mulInt
                                                          (coe
                                                             mulInt (coe mulInt (coe v5) (coe v10))
                                                             (coe v13))
                                                          (coe v13))
                                                       (coe
                                                          mulInt (coe mulInt (coe v4) (coe v10))
                                                          (coe v13)))
                                                    (coe v3))
                                                 (coe (2 :: Integer)))
                                              (coe
                                                 mulInt
                                                 (coe
                                                    mulInt (coe mulInt (coe v5) (coe v10))
                                                    (coe v13))
                                                 (coe v13)))
                                           (coe mulInt (coe mulInt (coe v4) (coe v10)) (coe v13)))
                                        (coe v3))
                                     (coe
                                        addInt
                                        (coe
                                           addInt
                                           (coe
                                              mulInt
                                              (coe mulInt (coe mulInt (coe v5) (coe v10)) (coe v13))
                                              (coe v13))
                                           (coe mulInt (coe mulInt (coe v4) (coe v10)) (coe v13)))
                                        (coe v3)))
                           _ -> MAlonzo.RTE.mazUnreachableError
                    _ -> MAlonzo.RTE.mazUnreachableError
             _ -> MAlonzo.RTE.mazUnreachableError
      _ -> MAlonzo.RTE.mazUnreachableError
-- Cost.Model.convertRawModel
d_convertRawModel_294 ::
  MAlonzo.Code.Cost.Raw.T_RawModel_144 ->
  Integer -> Maybe T_CostingModel_8
d_convertRawModel_294 v0
  = case coe v0 of
      MAlonzo.Code.Cost.Raw.C_ConstantCost_146 v1
        -> coe
             (\ v2 ->
                coe
                  MAlonzo.Code.Agda.Builtin.Maybe.C_just_16
                  (coe C_constantCost_12 v1))
      MAlonzo.Code.Cost.Raw.C_AddedSizes_148 v1
        -> case coe v1 of
             MAlonzo.Code.Cost.Raw.C_mkLinearFunction_42 v2 v3
               -> coe
                    (\ v4 ->
                       coe
                         MAlonzo.Code.Agda.Builtin.Maybe.C_just_16
                         (coe C_addedSizes_36 v2 v3))
             _ -> MAlonzo.RTE.mazUnreachableError
      MAlonzo.Code.Cost.Raw.C_MultipliedSizes_150 v1
        -> case coe v1 of
             MAlonzo.Code.Cost.Raw.C_mkLinearFunction_42 v2 v3
               -> coe
                    (\ v4 ->
                       coe
                         MAlonzo.Code.Agda.Builtin.Maybe.C_just_16
                         (coe C_multipliedSizes_40 v2 v3))
             _ -> MAlonzo.RTE.mazUnreachableError
      MAlonzo.Code.Cost.Raw.C_MinSize_152 v1
        -> case coe v1 of
             MAlonzo.Code.Cost.Raw.C_mkLinearFunction_42 v2 v3
               -> coe
                    (\ v4 ->
                       let v5 = coe MAlonzo.Code.Agda.Builtin.Maybe.C_nothing_18 in
                       coe
                         (case coe v4 of
                            _ | coe geqInt (coe v4) (coe (1 :: Integer)) ->
                                coe
                                  MAlonzo.Code.Agda.Builtin.Maybe.C_just_16 (coe C_minSize_44 v2 v3)
                            _ -> coe v5))
             _ -> MAlonzo.RTE.mazUnreachableError
      MAlonzo.Code.Cost.Raw.C_MaxSize_154 v1
        -> case coe v1 of
             MAlonzo.Code.Cost.Raw.C_mkLinearFunction_42 v2 v3
               -> coe
                    (\ v4 ->
                       let v5 = coe MAlonzo.Code.Agda.Builtin.Maybe.C_nothing_18 in
                       coe
                         (case coe v4 of
                            _ | coe geqInt (coe v4) (coe (1 :: Integer)) ->
                                coe
                                  MAlonzo.Code.Agda.Builtin.Maybe.C_just_16 (coe C_maxSize_48 v2 v3)
                            _ -> coe v5))
             _ -> MAlonzo.RTE.mazUnreachableError
      MAlonzo.Code.Cost.Raw.C_LinearInX_156 v1
        -> case coe v1 of
             MAlonzo.Code.Cost.Raw.C_mkLinearFunction_42 v2 v3
               -> coe
                    (\ v4 ->
                       let v5 = coe MAlonzo.Code.Agda.Builtin.Maybe.C_nothing_18 in
                       coe
                         (case coe v4 of
                            _ | coe geqInt (coe v4) (coe (1 :: Integer)) ->
                                coe
                                  MAlonzo.Code.Agda.Builtin.Maybe.C_just_16
                                  (coe
                                     C_linearCostIn_16 (coe MAlonzo.Code.Data.Fin.Base.C_zero_12) v2
                                     v3)
                            _ -> coe v5))
             _ -> MAlonzo.RTE.mazUnreachableError
      MAlonzo.Code.Cost.Raw.C_LinearInY_158 v1
        -> case coe v1 of
             MAlonzo.Code.Cost.Raw.C_mkLinearFunction_42 v2 v3
               -> coe
                    (\ v4 ->
                       let v5 = coe MAlonzo.Code.Agda.Builtin.Maybe.C_nothing_18 in
                       coe
                         (case coe v4 of
                            _ | coe geqInt (coe v4) (coe (2 :: Integer)) ->
                                coe
                                  MAlonzo.Code.Agda.Builtin.Maybe.C_just_16
                                  (coe
                                     C_linearCostIn_16
                                     (coe
                                        MAlonzo.Code.Data.Fin.Base.C_suc_16
                                        (coe MAlonzo.Code.Data.Fin.Base.C_zero_12))
                                     v2 v3)
                            1 -> coe v5
                            _ -> coe v5))
             _ -> MAlonzo.RTE.mazUnreachableError
      MAlonzo.Code.Cost.Raw.C_LinearInZ_160 v1
        -> case coe v1 of
             MAlonzo.Code.Cost.Raw.C_mkLinearFunction_42 v2 v3
               -> coe
                    (\ v4 ->
                       let v5 = coe MAlonzo.Code.Agda.Builtin.Maybe.C_nothing_18 in
                       coe
                         (case coe v4 of
                            _ | coe geqInt (coe v4) (coe (3 :: Integer)) ->
                                coe
                                  MAlonzo.Code.Agda.Builtin.Maybe.C_just_16
                                  (coe
                                     C_linearCostIn_16
                                     (coe
                                        MAlonzo.Code.Data.Fin.Base.C_suc_16
                                        (coe
                                           MAlonzo.Code.Data.Fin.Base.C_suc_16
                                           (coe MAlonzo.Code.Data.Fin.Base.C_zero_12)))
                                     v2 v3)
                            2 -> coe v5
                            1 -> coe v5
                            _ -> coe v5))
             _ -> MAlonzo.RTE.mazUnreachableError
      MAlonzo.Code.Cost.Raw.C_LinearInU_162 v1
        -> case coe v1 of
             MAlonzo.Code.Cost.Raw.C_mkLinearFunction_42 v2 v3
               -> coe
                    (\ v4 ->
                       let v5 = coe MAlonzo.Code.Agda.Builtin.Maybe.C_nothing_18 in
                       coe
                         (case coe v4 of
                            _ | coe geqInt (coe v4) (coe (4 :: Integer)) ->
                                coe
                                  MAlonzo.Code.Agda.Builtin.Maybe.C_just_16
                                  (coe
                                     C_linearCostIn_16
                                     (coe
                                        MAlonzo.Code.Data.Fin.Base.C_suc_16
                                        (coe
                                           MAlonzo.Code.Data.Fin.Base.C_suc_16
                                           (coe
                                              MAlonzo.Code.Data.Fin.Base.C_suc_16
                                              (coe MAlonzo.Code.Data.Fin.Base.C_zero_12))))
                                     v2 v3)
                            3 -> coe v5
                            2 -> coe v5
                            1 -> coe v5
                            _ -> coe v5))
             _ -> MAlonzo.RTE.mazUnreachableError
      MAlonzo.Code.Cost.Raw.C_LinearInY2_164 v1 v2
        -> case coe v1 of
             MAlonzo.Code.Cost.Raw.C_mkLinearFunction_42 v3 v4
               -> coe
                    (\ v5 ->
                       let v6 = coe MAlonzo.Code.Agda.Builtin.Maybe.C_nothing_18 in
                       coe
                         (case coe v5 of
                            _ | coe geqInt (coe v5) (coe (2 :: Integer)) ->
                                coe
                                  MAlonzo.Code.Agda.Builtin.Maybe.C_just_16
                                  (coe
                                     C_linearCostIn_16
                                     (coe
                                        MAlonzo.Code.Data.Fin.Base.C_suc_16
                                        (coe MAlonzo.Code.Data.Fin.Base.C_zero_12))
                                     v3 v4)
                            1 -> coe v6
                            _ -> coe v6))
             _ -> MAlonzo.RTE.mazUnreachableError
      MAlonzo.Code.Cost.Raw.C_LiteralInYOrLinearInZ_166 v1
        -> case coe v1 of
             MAlonzo.Code.Cost.Raw.C_mkLinearFunction_42 v2 v3
               -> coe
                    (\ v4 ->
                       let v5 = coe MAlonzo.Code.Agda.Builtin.Maybe.C_nothing_18 in
                       coe
                         (case coe v4 of
                            _ | coe geqInt (coe v4) (coe (3 :: Integer)) ->
                                coe
                                  MAlonzo.Code.Agda.Builtin.Maybe.C_just_16
                                  (coe
                                     C_literalCostIn_32
                                     (coe
                                        MAlonzo.Code.Data.Fin.Base.C_suc_16
                                        (coe MAlonzo.Code.Data.Fin.Base.C_zero_12))
                                     (coe
                                        C_linearCostIn_16
                                        (coe
                                           MAlonzo.Code.Data.Fin.Base.C_suc_16
                                           (coe
                                              MAlonzo.Code.Data.Fin.Base.C_suc_16
                                              (coe MAlonzo.Code.Data.Fin.Base.C_zero_12)))
                                        v2 v3))
                            2 -> coe v5
                            1 -> coe v5
                            _ -> coe v5))
             _ -> MAlonzo.RTE.mazUnreachableError
      MAlonzo.Code.Cost.Raw.C_LinearInMaxYZ_168 v1
        -> case coe v1 of
             MAlonzo.Code.Cost.Raw.C_mkLinearFunction_42 v2 v3
               -> coe
                    (\ v4 ->
                       let v5 = coe MAlonzo.Code.Agda.Builtin.Maybe.C_nothing_18 in
                       coe
                         (case coe v4 of
                            3 -> coe
                                   MAlonzo.Code.Agda.Builtin.Maybe.C_just_16
                                   (coe C_twoArgumentsLinearInMaxYZ_62 (coe v2) (coe v3))
                            _ | coe geqInt (coe v4) (coe (3 :: Integer)) -> coe v5
                            2 -> coe v5
                            1 -> coe v5
                            _ -> coe v5))
             _ -> MAlonzo.RTE.mazUnreachableError
      MAlonzo.Code.Cost.Raw.C_LinearInXAndY_170 v1
        -> case coe v1 of
             MAlonzo.Code.Cost.Raw.C_mkTwoVariableLinearFunction_74 v2 v3 v4
               -> coe
                    (\ v5 ->
                       let v6 = coe MAlonzo.Code.Agda.Builtin.Maybe.C_nothing_18 in
                       coe
                         (case coe v5 of
                            _ | coe geqInt (coe v5) (coe (2 :: Integer)) ->
                                coe
                                  MAlonzo.Code.Agda.Builtin.Maybe.C_just_16
                                  (coe
                                     C_withInteractionIn_28
                                     (coe MAlonzo.Code.Data.Fin.Base.C_zero_12)
                                     (coe
                                        MAlonzo.Code.Data.Fin.Base.C_suc_16
                                        (coe MAlonzo.Code.Data.Fin.Base.C_zero_12))
                                     v2 v3 v4 (0 :: Integer))
                            1 -> coe v6
                            _ -> coe v6))
             _ -> MAlonzo.RTE.mazUnreachableError
      MAlonzo.Code.Cost.Raw.C_LinearInYAndZ_172 v1
        -> case coe v1 of
             MAlonzo.Code.Cost.Raw.C_mkTwoVariableLinearFunction_74 v2 v3 v4
               -> coe
                    (\ v5 ->
                       let v6 = coe MAlonzo.Code.Agda.Builtin.Maybe.C_nothing_18 in
                       coe
                         (case coe v5 of
                            3 -> coe
                                   MAlonzo.Code.Agda.Builtin.Maybe.C_just_16
                                   (coe C_twoArgumentsLinearInYAndZ_60 (coe v2) (coe v3) (coe v4))
                            _ | coe geqInt (coe v5) (coe (3 :: Integer)) -> coe v6
                            2 -> coe v6
                            1 -> coe v6
                            _ -> coe v6))
             _ -> MAlonzo.RTE.mazUnreachableError
      MAlonzo.Code.Cost.Raw.C_QuadraticInX_174 v1
        -> case coe v1 of
             MAlonzo.Code.Cost.Raw.C_mkOneVariableQuadraticFunction_58 v2 v3 v4
               -> coe
                    (\ v5 ->
                       let v6 = coe MAlonzo.Code.Agda.Builtin.Maybe.C_nothing_18 in
                       coe
                         (case coe v5 of
                            _ | coe geqInt (coe v5) (coe (1 :: Integer)) ->
                                coe
                                  MAlonzo.Code.Agda.Builtin.Maybe.C_just_16
                                  (coe
                                     C_quadraticCostIn1_20
                                     (coe MAlonzo.Code.Data.Fin.Base.C_zero_12) v2 v3 v4)
                            _ -> coe v6))
             _ -> MAlonzo.RTE.mazUnreachableError
      MAlonzo.Code.Cost.Raw.C_QuadraticInY_176 v1
        -> case coe v1 of
             MAlonzo.Code.Cost.Raw.C_mkOneVariableQuadraticFunction_58 v2 v3 v4
               -> coe
                    (\ v5 ->
                       let v6 = coe MAlonzo.Code.Agda.Builtin.Maybe.C_nothing_18 in
                       coe
                         (case coe v5 of
                            _ | coe geqInt (coe v5) (coe (2 :: Integer)) ->
                                coe
                                  MAlonzo.Code.Agda.Builtin.Maybe.C_just_16
                                  (coe
                                     C_quadraticCostIn1_20
                                     (coe
                                        MAlonzo.Code.Data.Fin.Base.C_suc_16
                                        (coe MAlonzo.Code.Data.Fin.Base.C_zero_12))
                                     v2 v3 v4)
                            1 -> coe v6
                            _ -> coe v6))
             _ -> MAlonzo.RTE.mazUnreachableError
      MAlonzo.Code.Cost.Raw.C_QuadraticInZ_178 v1
        -> case coe v1 of
             MAlonzo.Code.Cost.Raw.C_mkOneVariableQuadraticFunction_58 v2 v3 v4
               -> coe
                    (\ v5 ->
                       let v6 = coe MAlonzo.Code.Agda.Builtin.Maybe.C_nothing_18 in
                       coe
                         (case coe v5 of
                            _ | coe geqInt (coe v5) (coe (3 :: Integer)) ->
                                coe
                                  MAlonzo.Code.Agda.Builtin.Maybe.C_just_16
                                  (coe
                                     C_quadraticCostIn1_20
                                     (coe
                                        MAlonzo.Code.Data.Fin.Base.C_suc_16
                                        (coe
                                           MAlonzo.Code.Data.Fin.Base.C_suc_16
                                           (coe MAlonzo.Code.Data.Fin.Base.C_zero_12)))
                                     v2 v3 v4)
                            2 -> coe v6
                            1 -> coe v6
                            _ -> coe v6))
             _ -> MAlonzo.RTE.mazUnreachableError
      MAlonzo.Code.Cost.Raw.C_QuadraticInXAndY_180 v1
        -> case coe v1 of
             MAlonzo.Code.Cost.Raw.C_mkTwoVariableQuadraticFunction_106 v2 v3 v4 v5 v6 v7 v8
               -> coe
                    (\ v9 ->
                       let v10 = coe MAlonzo.Code.Agda.Builtin.Maybe.C_nothing_18 in
                       coe
                         (case coe v9 of
                            _ | coe geqInt (coe v9) (coe (2 :: Integer)) ->
                                coe
                                  MAlonzo.Code.Agda.Builtin.Maybe.C_just_16
                                  (coe
                                     C_quadraticCostIn2_24
                                     (coe MAlonzo.Code.Data.Fin.Base.C_zero_12)
                                     (coe
                                        MAlonzo.Code.Data.Fin.Base.C_suc_16
                                        (coe MAlonzo.Code.Data.Fin.Base.C_zero_12))
                                     v2 v3 v4 v5 v6 v7 v8)
                            1 -> coe v10
                            _ -> coe v10))
             _ -> MAlonzo.RTE.mazUnreachableError
      MAlonzo.Code.Cost.Raw.C_WithInteractionInXAndY_182 v1
        -> case coe v1 of
             MAlonzo.Code.Cost.Raw.C_mkTwoVariableWithInteractionFunction_126 v2 v3 v4 v5
               -> coe
                    (\ v6 ->
                       let v7 = coe MAlonzo.Code.Agda.Builtin.Maybe.C_nothing_18 in
                       coe
                         (case coe v6 of
                            _ | coe geqInt (coe v6) (coe (2 :: Integer)) ->
                                coe
                                  MAlonzo.Code.Agda.Builtin.Maybe.C_just_16
                                  (coe
                                     C_withInteractionIn_28
                                     (coe MAlonzo.Code.Data.Fin.Base.C_zero_12)
                                     (coe
                                        MAlonzo.Code.Data.Fin.Base.C_suc_16
                                        (coe MAlonzo.Code.Data.Fin.Base.C_zero_12))
                                     v2 v3 v4 v5)
                            1 -> coe v7
                            _ -> coe v7))
             _ -> MAlonzo.RTE.mazUnreachableError
      MAlonzo.Code.Cost.Raw.C_SubtractedSizes_184 v1 v2
        -> case coe v1 of
             MAlonzo.Code.Cost.Raw.C_mkLinearFunction_42 v3 v4
               -> coe
                    (\ v5 ->
                       let v6 = coe MAlonzo.Code.Agda.Builtin.Maybe.C_nothing_18 in
                       coe
                         (case coe v5 of
                            2 -> coe
                                   MAlonzo.Code.Agda.Builtin.Maybe.C_just_16
                                   (coe C_twoArgumentsSubtractedSizes_50 (coe v3) (coe v4) (coe v2))
                            _ | coe geqInt (coe v5) (coe (2 :: Integer)) -> coe v6
                            1 -> coe v6
                            _ -> coe v6))
             _ -> MAlonzo.RTE.mazUnreachableError
      MAlonzo.Code.Cost.Raw.C_ConstAboveDiagonal_186 v1 v2
        -> coe d_'46'extendedlambda15_444 (coe v1) (coe v2)
      MAlonzo.Code.Cost.Raw.C_ConstBelowDiagonal_188 v1 v2
        -> coe d_'46'extendedlambda16_450 (coe v1) (coe v2)
      MAlonzo.Code.Cost.Raw.C_ConstOffDiagonal_190 v1 v2
        -> coe d_'46'extendedlambda17_456 (coe v1) (coe v2)
      MAlonzo.Code.Cost.Raw.C_AboveAndBelowDiagonal_192 v1 v2
        -> coe d_'46'extendedlambda18_462 (coe v1) (coe v2)
      MAlonzo.Code.Cost.Raw.C_ExpModCost_194 v1
        -> case coe v1 of
             MAlonzo.Code.Cost.Raw.C_mkExpModCostingFunction_142 v2 v3 v4
               -> coe
                    (\ v5 ->
                       let v6 = coe MAlonzo.Code.Agda.Builtin.Maybe.C_nothing_18 in
                       coe
                         (case coe v5 of
                            3 -> coe
                                   MAlonzo.Code.Agda.Builtin.Maybe.C_just_16
                                   (coe C_threeArgumentsExpModCost_64 (coe v2) (coe v3) (coe v4))
                            _ | coe geqInt (coe v5) (coe (3 :: Integer)) -> coe v6
                            2 -> coe v6
                            1 -> coe v6
                            _ -> coe v6))
             _ -> MAlonzo.RTE.mazUnreachableError
      _ -> MAlonzo.RTE.mazUnreachableError
-- Cost.Model..extendedlambda15
d_'46'extendedlambda15_444 ::
  Integer ->
  MAlonzo.Code.Cost.Raw.T_RawModel_144 ->
  Integer -> Maybe T_CostingModel_8
d_'46'extendedlambda15_444 v0 v1 v2
  = let v3 = coe MAlonzo.Code.Agda.Builtin.Maybe.C_nothing_18 in
    coe
      (case coe v2 of
         2 -> coe
                MAlonzo.Code.Data.Maybe.Base.du_map_64
                (coe C_twoArgumentsConstAboveDiagonal_52 (coe v0))
                (coe d_convertRawModel_294 v1 (2 :: Integer))
         _ | coe geqInt (coe v2) (coe (2 :: Integer)) -> coe v3
         1 -> coe v3
         _ -> coe v3)
-- Cost.Model..extendedlambda16
d_'46'extendedlambda16_450 ::
  Integer ->
  MAlonzo.Code.Cost.Raw.T_RawModel_144 ->
  Integer -> Maybe T_CostingModel_8
d_'46'extendedlambda16_450 v0 v1 v2
  = let v3 = coe MAlonzo.Code.Agda.Builtin.Maybe.C_nothing_18 in
    coe
      (case coe v2 of
         2 -> coe
                MAlonzo.Code.Data.Maybe.Base.du_map_64
                (coe C_twoArgumentsConstBelowDiagonal_54 (coe v0))
                (coe d_convertRawModel_294 v1 (2 :: Integer))
         _ | coe geqInt (coe v2) (coe (2 :: Integer)) -> coe v3
         1 -> coe v3
         _ -> coe v3)
-- Cost.Model..extendedlambda17
d_'46'extendedlambda17_456 ::
  Integer ->
  MAlonzo.Code.Cost.Raw.T_RawModel_144 ->
  Integer -> Maybe T_CostingModel_8
d_'46'extendedlambda17_456 v0 v1 v2
  = let v3 = coe MAlonzo.Code.Agda.Builtin.Maybe.C_nothing_18 in
    coe
      (case coe v2 of
         2 -> coe
                MAlonzo.Code.Data.Maybe.Base.du_map_64
                (coe C_twoArgumentsConstOffDiagonal_56 (coe v0))
                (coe d_convertRawModel_294 v1 (2 :: Integer))
         _ | coe geqInt (coe v2) (coe (2 :: Integer)) -> coe v3
         1 -> coe v3
         _ -> coe v3)
-- Cost.Model..extendedlambda18
d_'46'extendedlambda18_462 ::
  Integer ->
  MAlonzo.Code.Cost.Raw.T_RawModel_144 ->
  Integer -> Maybe T_CostingModel_8
d_'46'extendedlambda18_462 v0 v1 v2
  = let v3 = coe MAlonzo.Code.Agda.Builtin.Maybe.C_nothing_18 in
    coe
      (case coe v2 of
         2 -> coe
                MAlonzo.Code.Data.Maybe.Base.du_map_64
                (coe C_twoArgumentsAboveAndBelowDiagonal_58 (coe v0))
                (coe d_convertRawModel_294 v1 (2 :: Integer))
         _ | coe geqInt (coe v2) (coe (2 :: Integer)) -> coe v3
         1 -> coe v3
         _ -> coe v3)
-- Cost.Model.convertCpuAndMemoryModel
d_convertCpuAndMemoryModel_496 ::
  Integer ->
  MAlonzo.Code.Cost.Raw.T_CpuAndMemoryModel_196 ->
  Maybe T_BuiltinModel_68
d_convertCpuAndMemoryModel_496 v0 v1
  = case coe v1 of
      MAlonzo.Code.Cost.Raw.C_mkCpuAndMemoryModel_206 v2 v3
        -> let v4 = coe d_convertRawModel_294 v2 v0 in
           coe
             (let v5 = coe d_convertRawModel_294 v3 v0 in
              coe
                (case coe v4 of
                   MAlonzo.Code.Agda.Builtin.Maybe.C_just_16 v6
                     -> case coe v5 of
                          MAlonzo.Code.Agda.Builtin.Maybe.C_just_16 v7
                            -> coe
                                 MAlonzo.Code.Agda.Builtin.Maybe.C_just_16
                                 (coe C_constructor_80 (coe v6) (coe v7))
                          _ -> coe MAlonzo.Code.Agda.Builtin.Maybe.C_nothing_18
                   _ -> coe MAlonzo.Code.Agda.Builtin.Maybe.C_nothing_18))
      _ -> MAlonzo.RTE.mazUnreachableError
-- Cost.Model.getModel
d_getModel_520 ::
  MAlonzo.Code.Builtin.T_Builtin_2 ->
  MAlonzo.Code.Utils.T_List_454
    (MAlonzo.Code.Utils.T__'215'__436
       MAlonzo.Code.Agda.Builtin.String.T_String_6
       MAlonzo.Code.Cost.Raw.T_CpuAndMemoryModel_196) ->
  Maybe MAlonzo.Code.Agda.Builtin.Sigma.T_Σ_14
d_getModel_520 v0 v1
  = case coe v1 of
      MAlonzo.Code.Utils.C_'91''93'_458
        -> coe MAlonzo.Code.Agda.Builtin.Maybe.C_nothing_18
      MAlonzo.Code.Utils.C__'8759'__460 v2 v3
        -> case coe v2 of
             MAlonzo.Code.Utils.C__'44'__450 v4 v5
               -> let v6
                        = coe
                            MAlonzo.Code.Relation.Nullary.Decidable.Core.du_isYes_132
                            (coe
                               MAlonzo.Code.Relation.Nullary.Decidable.Core.du_map'8242'_178
                               erased
                               (\ v6 ->
                                  coe
                                    MAlonzo.Code.Data.String.Properties.du_'8776''45'reflexive_8
                                    (coe MAlonzo.Code.Builtin.d_showBuiltin_492 (coe v0)))
                               (coe
                                  MAlonzo.Code.Data.List.Relation.Binary.Pointwise.Properties.du_decidable_112
                                  (coe MAlonzo.Code.Data.Char.Properties.d__'8799'__14)
                                  (coe
                                     MAlonzo.Code.Agda.Builtin.String.d_primStringToList_12
                                     (MAlonzo.Code.Builtin.d_showBuiltin_492 (coe v0)))
                                  (coe
                                     MAlonzo.Code.Agda.Builtin.String.d_primStringToList_12 v4))) in
                  coe
                    (if coe v6
                       then coe
                              MAlonzo.Code.Data.Maybe.Base.du_map_64
                              (\ v7 ->
                                 coe MAlonzo.Code.Agda.Builtin.Sigma.C__'44'__32 (coe v0) (coe v7))
                              (d_convertCpuAndMemoryModel_496
                                 (coe
                                    addInt (coe (1 :: Integer))
                                    (coe
                                       MAlonzo.Code.Data.List.Base.du_foldr_216
                                       (coe (\ v7 v8 -> addInt (coe (1 :: Integer)) (coe v8)))
                                       (coe (0 :: Integer))
                                       (coe
                                          MAlonzo.Code.Data.List.NonEmpty.Base.d_tail_32
                                          (coe
                                             MAlonzo.Code.Builtin.Signature.d_args_88
                                             (coe MAlonzo.Code.Builtin.d_signature_312 (coe v0))))))
                                 (coe v5))
                       else coe d_getModel_520 (coe v0) (coe v3))
             _ -> MAlonzo.RTE.mazUnreachableError
      _ -> MAlonzo.RTE.mazUnreachableError
-- Cost.Model.dummyModel
d_dummyModel_556 :: Integer -> T_BuiltinModel_68
d_dummyModel_556 ~v0 = du_dummyModel_556
du_dummyModel_556 :: T_BuiltinModel_68
du_dummyModel_556
  = coe
      C_constructor_80 (coe C_constantCost_12 (0 :: Integer))
      (coe C_constantCost_12 (0 :: Integer))
-- Cost.Model.lookupModel
d_lookupModel_562 ::
  [MAlonzo.Code.Agda.Builtin.Sigma.T_Σ_14] ->
  MAlonzo.Code.Builtin.T_Builtin_2 -> T_BuiltinModel_68
d_lookupModel_562 v0 v1
  = case coe v0 of
      [] -> coe du_dummyModel_556
      (:) v2 v3
        -> case coe v2 of
             MAlonzo.Code.Agda.Builtin.Sigma.C__'44'__32 v4 v5
               -> let v6
                        = coe
                            MAlonzo.Code.Relation.Nullary.Decidable.Core.du_map'8242'_178
                            erased
                            (\ v6 ->
                               coe
                                 MAlonzo.Code.Data.Nat.Properties.du_'8801''8658''8801''7495'_2786
                                 (coe MAlonzo.Code.Builtin.d_enumBuiltin_454 (coe v4)))
                            (coe
                               MAlonzo.Code.Relation.Nullary.Decidable.Core.C__because__32
                               (coe
                                  eqInt (coe MAlonzo.Code.Builtin.d_enumBuiltin_454 (coe v4))
                                  (coe MAlonzo.Code.Builtin.d_enumBuiltin_454 (coe v1)))
                               (coe
                                  MAlonzo.Code.Relation.Nullary.Reflects.d_T'45'reflects_70
                                  (coe
                                     eqInt (coe MAlonzo.Code.Builtin.d_enumBuiltin_454 (coe v4))
                                     (coe MAlonzo.Code.Builtin.d_enumBuiltin_454 (coe v1))))) in
                  coe
                    (case coe v6 of
                       MAlonzo.Code.Relation.Nullary.Decidable.Core.C__because__32 v7 v8
                         -> if coe v7
                              then let v9
                                         = seq
                                             (coe v8)
                                             (coe
                                                MAlonzo.Code.Relation.Nullary.Decidable.Core.C__because__32
                                                (coe v7)
                                                (coe
                                                   MAlonzo.Code.Relation.Nullary.Reflects.C_of'696'_22
                                                   erased)) in
                                   coe
                                     (case coe v9 of
                                        MAlonzo.Code.Relation.Nullary.Decidable.Core.C__because__32 v10 v11
                                          -> if coe v10
                                               then coe seq (coe v11) (coe v5)
                                               else coe d_lookupModel_562 (coe v3) (coe v1)
                                        _ -> MAlonzo.RTE.mazUnreachableError)
                              else (let v9
                                          = seq
                                              (coe v8)
                                              (coe
                                                 MAlonzo.Code.Relation.Nullary.Decidable.Core.C__because__32
                                                 (coe v7)
                                                 (coe
                                                    MAlonzo.Code.Relation.Nullary.Reflects.C_of'8319'_26)) in
                                    coe
                                      (case coe v9 of
                                         MAlonzo.Code.Relation.Nullary.Decidable.Core.C__because__32 v10 v11
                                           -> if coe v10
                                                then coe seq (coe v11) (coe v5)
                                                else coe d_lookupModel_562 (coe v3) (coe v1)
                                         _ -> MAlonzo.RTE.mazUnreachableError))
                       _ -> MAlonzo.RTE.mazUnreachableError)
             _ -> MAlonzo.RTE.mazUnreachableError
      _ -> MAlonzo.RTE.mazUnreachableError
-- Cost.Model.allJust
d_allJust_598 :: () -> [Maybe AgdaAny] -> Maybe [AgdaAny]
d_allJust_598 ~v0 v1 = du_allJust_598 v1
du_allJust_598 :: [Maybe AgdaAny] -> Maybe [AgdaAny]
du_allJust_598 v0
  = case coe v0 of
      [] -> coe MAlonzo.Code.Agda.Builtin.Maybe.C_just_16 (coe v0)
      (:) v1 v2
        -> case coe v1 of
             MAlonzo.Code.Agda.Builtin.Maybe.C_just_16 v3
               -> let v4 = coe du_allJust_598 (coe v2) in
                  coe
                    (case coe v4 of
                       MAlonzo.Code.Agda.Builtin.Maybe.C_just_16 v5
                         -> coe
                              MAlonzo.Code.Agda.Builtin.Maybe.C_just_16
                              (coe
                                 MAlonzo.Code.Agda.Builtin.List.C__'8759'__22 (coe v3) (coe v5))
                       MAlonzo.Code.Agda.Builtin.Maybe.C_nothing_18 -> coe v4
                       _ -> MAlonzo.RTE.mazUnreachableError)
             MAlonzo.Code.Agda.Builtin.Maybe.C_nothing_18 -> coe v1
             _ -> MAlonzo.RTE.mazUnreachableError
      _ -> MAlonzo.RTE.mazUnreachableError
-- Cost.Model.ModelAssignment
d_ModelAssignment_620 :: ()
d_ModelAssignment_620 = erased
-- Cost.Model.createMap
d_createMap_624 ::
  MAlonzo.Code.Utils.T_List_454
    (MAlonzo.Code.Utils.T__'215'__436
       MAlonzo.Code.Agda.Builtin.String.T_String_6
       MAlonzo.Code.Cost.Raw.T_CpuAndMemoryModel_196) ->
  Maybe (MAlonzo.Code.Builtin.T_Builtin_2 -> T_BuiltinModel_68)
d_createMap_624 v0
  = coe
      MAlonzo.Code.Data.Maybe.Base.du_map_64 d_lookupModel_562
      (coe
         du_allJust_598
         (coe
            MAlonzo.Code.Data.List.Base.du_map_22
            (coe (\ v1 -> d_getModel_520 (coe v1) (coe v0)))
            (coe MAlonzo.Code.Builtin.d_builtinList_494)))
