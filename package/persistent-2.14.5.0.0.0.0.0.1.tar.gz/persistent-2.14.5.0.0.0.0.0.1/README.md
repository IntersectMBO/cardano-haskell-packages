## persistent

Type-safe, data serialization. You must use a specific backend in order to make
this useful. For more information, see [the chapter in the Yesod
book](http://www.yesodweb.com/book/persistent).
