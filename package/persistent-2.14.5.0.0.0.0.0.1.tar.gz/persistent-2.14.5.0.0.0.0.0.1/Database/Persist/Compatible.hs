module Database.Persist.Compatible
    ( Compatible(..)
    , makeCompatibleInstances
    , makeCompatibleKeyInstances
    ) where

import Database.Persist.Compatible.Types
import Database.Persist.Compatible.TH

