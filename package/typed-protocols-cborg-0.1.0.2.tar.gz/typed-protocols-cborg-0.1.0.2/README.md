typed-protocols-cborg
=====================

[CBOR](https://hackage.haskell.org/package/cborg) codecs for
[typed-protocols](https://input-output-hk.github.io/ouroboros-network/typed-protocols/Network-TypedProtocol.html)
package.
