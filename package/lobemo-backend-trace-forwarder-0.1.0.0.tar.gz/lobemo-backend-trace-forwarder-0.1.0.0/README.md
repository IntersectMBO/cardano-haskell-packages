# trace forwarder

writes log items to a UNIX pipe.
