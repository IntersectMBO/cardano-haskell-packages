{-# LANGUAGE AllowAmbiguousTypes #-}
{-# LANGUAGE ConstraintKinds #-}
{-# LANGUAGE DataKinds #-}
{-# LANGUAGE DeriveGeneric #-}
{-# LANGUAGE FlexibleContexts #-}
{-# LANGUAGE FlexibleInstances #-}
{-# LANGUAGE OverloadedStrings #-}
{-# LANGUAGE ScopedTypeVariables #-}
{-# LANGUAGE StandaloneDeriving #-}
{-# LANGUAGE TypeApplications #-}
{-# LANGUAGE TypeFamilies #-}
{-# LANGUAGE UndecidableInstances #-}
{-# OPTIONS_GHC -Wno-orphans #-}

module Test.Cardano.Ledger.Alonzo.Translation.TranslationInstance (
  TranslationInstance (..),
  deserializeTranslationInstances,
  VersionedTxInfo (..),
) where

import Cardano.Ledger.Alonzo.Plutus.Context (EraPlutusContext, SupportedLanguage)
import Cardano.Ledger.Alonzo.Scripts (AlonzoEraScript, AsIx, PlutusPurpose)
import Cardano.Ledger.BaseTypes (ProtVer)
import Cardano.Ledger.Binary (
  DecCBOR (..),
  DecoderError,
  EncCBOR (..),
  decodeFull,
  decodeRecordNamed,
  encodeListLen,
  fromPlainDecoder,
  fromPlainEncoding,
 )
import Cardano.Ledger.Core
import Cardano.Ledger.State (UTxO (..))
import qualified Codec.Serialise as Cborg (Serialise (..))
import qualified Data.ByteString.Lazy as BSL
import GHC.Generics (Generic)
import qualified PlutusLedgerApi.V1 as PV1
import qualified PlutusLedgerApi.V2 as PV2
import qualified PlutusLedgerApi.V3 as PV3
import qualified PlutusLedgerApi.V4 as PV4

data VersionedTxInfo
  = TxInfoPV1 PV1.TxInfo
  | TxInfoPV2 PV2.TxInfo
  | TxInfoPV3 PV3.TxInfo
  | TxInfoPV4 PV4.TxInfo
  deriving (Show, Eq, Generic)

-- | Represents arguments passed to `alonzoTxInfo` along with the produced result.
data TranslationInstance era = TranslationInstance
  { tiProtVer :: ProtVer
  , tiLanguage :: SupportedLanguage era
  , tiUtxo :: UTxO era
  , tiTx :: Tx TopTx era
  , tiPlutusPurpose :: PlutusPurpose AsIx era
  , tiResult :: VersionedTxInfo
  }
  deriving (Generic)

deriving instance
  (AlonzoEraScript era, Eq (PParams era), Eq (UTxO era), Eq (Tx TopTx era)) =>
  Eq (TranslationInstance era)

deriving instance
  (AlonzoEraScript era, Show (PParams era), Show (UTxO era), Show (Tx TopTx era)) =>
  Show (TranslationInstance era)

instance Cborg.Serialise PV1.DCert

instance Cborg.Serialise PV1.TxInInfo

instance Cborg.Serialise PV1.TxInfo

instance Cborg.Serialise PV1.TxOut

instance Cborg.Serialise PV2.ScriptPurpose

instance Cborg.Serialise PV2.TxId

instance Cborg.Serialise PV2.TxOutRef

instance Cborg.Serialise PV2.TxInInfo

instance Cborg.Serialise PV2.TxInfo

instance Cborg.Serialise PV3.Address

instance Cborg.Serialise PV3.BuiltinData

instance Cborg.Serialise PV3.ChangedParameters

instance Cborg.Serialise PV3.ColdCommitteeCredential

instance Cborg.Serialise PV3.Committee

instance Cborg.Serialise PV3.Constitution

instance Cborg.Serialise PV3.Credential

instance Cborg.Serialise PV3.CurrencySymbol

instance Cborg.Serialise PV3.DRep

instance Cborg.Serialise PV3.DRepCredential

instance Cborg.Serialise PV3.DatumHash

instance Cborg.Serialise PV3.Delegatee

instance Cborg.Serialise PV3.GovernanceAction

instance Cborg.Serialise PV3.GovernanceActionId

instance Cborg.Serialise PV3.HotCommitteeCredential

instance Cborg.Serialise PV3.Lovelace

instance Cborg.Serialise PV3.MintValue

instance Cborg.Serialise PV3.OutputDatum

instance Cborg.Serialise PV3.POSIXTime

instance Cborg.Serialise PV3.ProposalProcedure

instance Cborg.Serialise PV3.ProtocolVersion

instance Cborg.Serialise PV3.PubKeyHash

instance Cborg.Serialise PV3.ScriptHash

instance Cborg.Serialise PV3.ScriptPurpose

instance Cborg.Serialise PV3.StakingCredential

instance Cborg.Serialise PV3.TokenName

instance Cborg.Serialise PV3.TxCert

instance Cborg.Serialise PV3.TxId

instance Cborg.Serialise PV3.TxInInfo

instance Cborg.Serialise PV3.TxInfo

instance Cborg.Serialise PV3.TxOut

instance Cborg.Serialise PV3.TxOutRef

instance Cborg.Serialise PV3.Value

instance Cborg.Serialise PV3.Vote

instance Cborg.Serialise PV3.Voter

instance (Cborg.Serialise k, Cborg.Serialise v) => Cborg.Serialise (PV3.Map k v)

instance Cborg.Serialise a => Cborg.Serialise (PV3.Extended a)

instance Cborg.Serialise a => Cborg.Serialise (PV3.Interval a)

instance Cborg.Serialise a => Cborg.Serialise (PV3.LowerBound a)

instance Cborg.Serialise a => Cborg.Serialise (PV3.UpperBound a)

instance Cborg.Serialise PV3.Rational

instance Cborg.Serialise PV4.AccountId

instance Cborg.Serialise PV4.TxCert

instance Cborg.Serialise PV4.AccountBalanceInterval

instance Cborg.Serialise PV4.AccountBalanceIntervals

instance Cborg.Serialise PV4.ScriptPurpose

instance Cborg.Serialise PV4.Address

instance Cborg.Serialise PV4.TxOut

instance Cborg.Serialise PV4.TxOutRef

instance Cborg.Serialise PV4.TxInInfo

instance Cborg.Serialise PV4.POSIXTimeRange

instance Cborg.Serialise PV4.TxInfo

instance Cborg.Serialise VersionedTxInfo

instance Cborg.Serialise PV4.ProposalProcedure

instance Cborg.Serialise PV4.GovernanceActionId

instance Cborg.Serialise PV4.GovernanceAction

instance Cborg.Serialise PV4.ProtocolVersion

instance Cborg.Serialise PV4.Rational

instance Cborg.Serialise PV4.Constitution

instance EncCBOR VersionedTxInfo where
  encCBOR = fromPlainEncoding . Cborg.encode

instance DecCBOR VersionedTxInfo where
  decCBOR = fromPlainDecoder Cborg.decode

instance
  ( AlonzoEraScript era
  , EncCBOR (UTxO era)
  , EncCBOR (Tx TopTx era)
  ) =>
  EncCBOR (TranslationInstance era)
  where
  encCBOR (TranslationInstance pp l u tx p r) =
    encodeListLen 6
      <> encCBOR pp
      <> encCBOR l
      <> encCBOR u
      <> encCBOR tx
      <> encCBOR p
      <> encCBOR r

instance
  ( DecCBOR (PParams era)
  , DecCBOR (UTxO era)
  , DecCBOR (Tx TopTx era)
  , EraPlutusContext era
  ) =>
  DecCBOR (TranslationInstance era)
  where
  decCBOR =
    decodeRecordNamed "TranslationInstance" (const 6) $
      TranslationInstance
        <$> decCBOR
        <*> decCBOR
        <*> decCBOR
        <*> decCBOR
        <*> decCBOR
        <*> decCBOR

deserializeTranslationInstances ::
  forall era.
  ( DecCBOR (PParams era)
  , DecCBOR (UTxO era)
  , DecCBOR (Tx TopTx era)
  , EraPlutusContext era
  ) =>
  BSL.ByteString ->
  Either DecoderError [TranslationInstance era]
deserializeTranslationInstances = decodeFull (eraProtVerHigh @era)
