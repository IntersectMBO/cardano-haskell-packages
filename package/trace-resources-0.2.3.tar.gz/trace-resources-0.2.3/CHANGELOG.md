# Revision history for trace-resources

## 0,2,3

* New names for metrics

## 0.2.1.0 -- Nov 2023

* Optimized resource record creation on Linux
* Add microbenchmark for resource record creation
* Add cabal flag `with-netstat` (default: False) to enable netstat values in Linux resource traces (potentially expensive)

## 0.2.0.2 -- Sep 2023

* Updated to `cardano-api-8.20`, `cardano-cli-8.8` and `ouroboros-network-0.9.1.0`

## 0.2.0.0 -- May 2023

* Undocumented changes

## 0.1.0.0 -- October 2022

* First version. Released on an unsuspecting world.
