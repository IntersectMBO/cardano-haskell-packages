-- editorconfig-checker-disable-file
{-# LANGUAGE ConstraintKinds #-}
{-# LANGUAGE DeriveAnyClass #-}
{-# LANGUAGE DerivingVia #-}
{-# LANGUAGE FlexibleInstances #-}
{-# LANGUAGE LambdaCase #-}
{-# LANGUAGE MultiParamTypeClasses #-}
{-# LANGUAGE PatternSynonyms #-}
{-# LANGUAGE PolyKinds #-}
{-# LANGUAGE StandaloneKindSignatures #-}
{-# LANGUAGE TemplateHaskell #-}
{-# LANGUAGE TypeApplications #-}
{-# LANGUAGE TypeFamilies #-}
{-# LANGUAGE UndecidableInstances #-}

-- We rely on things from this module being lazy (e.g. the PIR generators rely on types being lazy),
-- so don't use @StrictData@ in this module.

module PlutusCore.Core.Type
  ( Kind (..)
  , toPatFuncKind
  , fromPatFuncKind
  , argsFunKind
  , Type (..)
  , splitFunTyParts
  , funTyArgs
  , funTyResultType
  , Term (..)
  , Program (..)
  , HasTermLevel
  , UniOf
  , Normalized (..)
  , TyVarDecl (..)
  , VarDecl (..)
  , TyDecl (..)
  , tyDeclVar
  , HasUniques
  , Binder (..)
  , module Export

    -- * Annotations
  , HasAnn (..)
  , mapFun
  , tyVarDeclAnn
  , tyVarDeclName
  , tyVarDeclKind
  , varDeclAnn
  , varDeclName
  , varDeclType
  , tyDeclAnn
  , tyDeclType
  , tyDeclKind
  , progAnn
  , progVer
  , progTerm
  )
where

import PlutusPrelude

import PlutusCore.Evaluation.Machine.ExMemoryUsage
import PlutusCore.Name.Unique
import PlutusCore.Version as Export

import Control.Lens
import Data.Hashable
import Data.Kind qualified as GHC
import Data.List.NonEmpty qualified as NE
import Instances.TH.Lift ()
import Language.Haskell.TH.Lift
import Universe

data Kind ann
  = Type ann
  | KindArrow ann (Kind ann) (Kind ann)
  deriving stock (Eq, Show, Functor, Generic, Lift)
  deriving anyclass (NFData, Hashable)

{-| The kind of a pattern functor (the first 'Type' argument of 'TyIFix') at a given kind (of the
second 'Type' argument of 'TyIFix'):

> toPatFuncKind k = (k -> *) -> k -> * -}
toPatFuncKind :: Kind () -> Kind ()
toPatFuncKind k = KindArrow () (KindArrow () k (Type ())) (KindArrow () k (Type ()))

fromPatFuncKind :: Kind () -> Maybe (Kind ())
fromPatFuncKind (KindArrow () (KindArrow () k1 (Type ())) (KindArrow () k2 (Type ())))
  | k1 == k2 = Just k1
fromPatFuncKind _ = Nothing

-- | Extract all @a_i@ from @a_0 -> a_1 -> ... -> r@.
argsFunKind :: Kind ann -> [Kind ann]
argsFunKind Type {} = []
argsFunKind (KindArrow _ k l) = k : argsFunKind l

-- | A 'Type' assigned to expressions.
type Type :: GHC.Type -> (GHC.Type -> GHC.Type) -> GHC.Type -> GHC.Type
data Type tyname uni ann
  = -- | Type variable
    TyVar ann tyname
  | -- | Function type
    TyFun ann (Type tyname uni ann) (Type tyname uni ann)
  | -- | Fix-point type, for constructing self-recursive types
    TyIFix ann (Type tyname uni ann) (Type tyname uni ann)
  | -- | Polymorphic type
    TyForall ann tyname (Kind ann) (Type tyname uni ann)
  | -- | Builtin type
    TyBuiltin ann (SomeTypeIn uni)
  | -- | Type lambda
    TyLam ann tyname (Kind ann) (Type tyname uni ann)
  | -- | Type application
    TyApp ann (Type tyname uni ann) (Type tyname uni ann)
  | -- | Sum-of-products type
    TySOP ann [[Type tyname uni ann]]
  deriving stock (Show, Functor, Generic)
  deriving anyclass (NFData)

{-| Get recursively all the domains and codomains of a type.
@splitFunTyParts (A->B->C) = [A, B, C]@
@splitFunTyParts (X) = [X]@ -}
splitFunTyParts :: Type tyname uni a -> NE.NonEmpty (Type tyname uni a)
splitFunTyParts = \case
  TyFun _ t1 t2 -> t1 NE.<| splitFunTyParts t2
  t -> pure t

{-| Get the argument types of a function type.
@funTyArgs (A->B->C) = [A, B]@ -}
funTyArgs :: Type tyname uni a -> [Type tyname uni a]
funTyArgs = NE.init . splitFunTyParts

{-| Get the result type of a function.
If not a function, then is the same as `id`
@funResultType (A->B->C) = C@
@funResultType (X) = X@ -}
funTyResultType :: Type tyname uni a -> Type tyname uni a
funTyResultType = NE.last . splitFunTyParts

data Term tyname name uni fun ann
  = -- | a named variable
    Var ann name
  | -- | lambda abstraction
    LamAbs ann name (Type tyname uni ann) (Term tyname name uni fun ann)
  | -- | application
    Apply ann (Term tyname name uni fun ann) (Term tyname name uni fun ann)
  | -- | type abstraction
    TyAbs ann tyname (Kind ann) (Term tyname name uni fun ann)
  | -- | instantiation
    TyInst ann (Term tyname name uni fun ann) (Type tyname uni ann)
  | -- | wrapping
    IWrap ann (Type tyname uni ann) (Type tyname uni ann) (Term tyname name uni fun ann)
  | {-| unwrapping
    See Note [Constr tag type] -}
    Unwrap ann (Term tyname name uni fun ann)
  | -- | constructor
    Constr ann (Type tyname uni ann) Word64 [Term tyname name uni fun ann]
  | -- | case
    Case ann (Type tyname uni ann) (Term tyname name uni fun ann) [Term tyname name uni fun ann]
  | -- | constants
    Constant ann (Some (ValueOf uni))
  | -- | builtin functions
    Builtin ann fun
  | -- | fail with error
    Error ann (Type tyname uni ann)
  deriving stock (Functor, Generic)

deriving stock instance
  (Show tyname, Show name, GShow uni, Everywhere uni Show, Show fun, Show ann, Closed uni)
  => Show (Term tyname name uni fun ann)

deriving anyclass instance
  (NFData tyname, NFData name, NFData fun, NFData ann, Everywhere uni NFData, Closed uni)
  => NFData (Term tyname name uni fun ann)

-- See Note [ExMemoryUsage instances for non-constants].
instance ExMemoryUsage (Term tyname name uni fun ann) where
  memoryUsage = error "Internal error: 'memoryUsage' for Core 'Term' is not supposed to be forced"

-- | A 'Program' is simply a 'Term' coupled with a 'Version' of the core language.
data Program tyname name uni fun ann = Program
  { _progAnn :: ann
  , _progVer :: Version
  , _progTerm :: Term tyname name uni fun ann
  }
  deriving stock (Functor, Generic)

makeLenses ''Program

deriving stock instance
  (Show tyname, Show name, GShow uni, Everywhere uni Show, Show fun, Show ann, Closed uni)
  => Show (Program tyname name uni fun ann)

deriving anyclass instance
  (NFData tyname, NFData name, Everywhere uni NFData, NFData fun, NFData ann, Closed uni)
  => NFData (Program tyname name uni fun ann)

-- | Specifies that the given type is a built-in one and its values can be embedded into a 'Term'.
type HasTermLevel :: forall a. (GHC.Type -> GHC.Type) -> a -> GHC.Constraint
type HasTermLevel uni = Includes uni

-- | Extract the universe from a type.
type family UniOf a :: GHC.Type -> GHC.Type

type instance UniOf (Term tyname name uni fun ann) = uni

-- | A "type variable declaration", i.e. a name and a kind for a type variable.
data TyVarDecl tyname ann = TyVarDecl
  { _tyVarDeclAnn :: ann
  , _tyVarDeclName :: tyname
  , _tyVarDeclKind :: Kind ann
  }
  deriving stock (Functor, Show, Generic)

makeLenses ''TyVarDecl

-- | A "variable declaration", i.e. a name and a type for a variable.
data VarDecl tyname name uni ann = VarDecl
  { _varDeclAnn :: ann
  , _varDeclName :: name
  , _varDeclType :: Type tyname uni ann
  }
  deriving stock (Functor, Show, Generic)

makeLenses ''VarDecl

-- | A "type declaration", i.e. a kind for a type.
data TyDecl tyname uni ann = TyDecl
  { _tyDeclAnn :: ann
  , _tyDeclType :: Type tyname uni ann
  , _tyDeclKind :: Kind ann
  }
  deriving stock (Functor, Show, Generic)

makeLenses ''TyDecl

tyDeclVar :: TyVarDecl tyname ann -> TyDecl tyname uni ann
tyDeclVar (TyVarDecl ann name kind) = TyDecl ann (TyVar ann name) kind

instance HasUnique tyname TypeUnique => HasUnique (TyVarDecl tyname ann) TypeUnique where
  unique f (TyVarDecl ann tyname kind) =
    unique f tyname <&> \tyname' -> TyVarDecl ann tyname' kind

instance HasUnique name TermUnique => HasUnique (VarDecl tyname name uni ann) TermUnique where
  unique f (VarDecl ann name ty) =
    unique f name <&> \name' -> VarDecl ann name' ty

newtype Normalized a = Normalized
  { unNormalized :: a
  }
  deriving stock (Show, Eq, Functor, Foldable, Traversable, Generic)
  deriving newtype (NFData, Pretty, PrettyBy config)
  deriving (Applicative) via Identity

-- | All kinds of uniques an entity contains.
type family HasUniques a :: GHC.Constraint

type instance HasUniques (Kind ann) = ()
type instance HasUniques (Type tyname uni ann) = HasUnique tyname TypeUnique
type instance
  HasUniques (Term tyname name uni fun ann) =
    (HasUnique tyname TypeUnique, HasUnique name TermUnique)
type instance
  HasUniques (Program tyname name uni fun ann) =
    HasUniques (Term tyname name uni fun ann)

instance HasAnn (Type tyname uni) where
  getAnn (TyVar ann _)        = ann
  getAnn (TyFun ann _ _)      = ann
  getAnn (TyIFix ann _ _)     = ann
  getAnn (TyForall ann _ _ _) = ann
  getAnn (TyBuiltin ann _)    = ann
  getAnn (TyLam ann _ _ _)    = ann
  getAnn (TyApp ann _ _)      = ann
  getAnn (TySOP ann _)        = ann
  modifyAnn f (TyVar ann x)        = TyVar (f ann) x
  modifyAnn f (TyFun ann a b)      = TyFun (f ann) a b
  modifyAnn f (TyIFix ann a b)     = TyIFix (f ann) a b
  modifyAnn f (TyForall ann tn k t) = TyForall (f ann) tn k t
  modifyAnn f (TyBuiltin ann b)    = TyBuiltin (f ann) b
  modifyAnn f (TyLam ann tn k t)   = TyLam (f ann) tn k t
  modifyAnn f (TyApp ann a b)      = TyApp (f ann) a b
  modifyAnn f (TySOP ann tss)      = TySOP (f ann) tss

instance HasAnn (Term tyname name uni fun) where
  getAnn (Var ann _)           = ann
  getAnn (LamAbs ann _ _ _)   = ann
  getAnn (Apply ann _ _)      = ann
  getAnn (TyAbs ann _ _ _)    = ann
  getAnn (TyInst ann _ _)     = ann
  getAnn (IWrap ann _ _ _)    = ann
  getAnn (Unwrap ann _)       = ann
  getAnn (Constr ann _ _ _)   = ann
  getAnn (Case ann _ _ _)     = ann
  getAnn (Constant ann _)     = ann
  getAnn (Builtin ann _)      = ann
  getAnn (Error ann _)        = ann
  modifyAnn f (Var ann x)           = Var (f ann) x
  modifyAnn f (LamAbs ann n ty t)   = LamAbs (f ann) n ty t
  modifyAnn f (Apply ann t1 t2)     = Apply (f ann) t1 t2
  modifyAnn f (TyAbs ann tn k t)    = TyAbs (f ann) tn k t
  modifyAnn f (TyInst ann t ty)     = TyInst (f ann) t ty
  modifyAnn f (IWrap ann ty1 ty2 t) = IWrap (f ann) ty1 ty2 t
  modifyAnn f (Unwrap ann t)        = Unwrap (f ann) t
  modifyAnn f (Constr ann ty i ts)  = Constr (f ann) ty i ts
  modifyAnn f (Case ann ty t ts)    = Case (f ann) ty t ts
  modifyAnn f (Constant ann c)      = Constant (f ann) c
  modifyAnn f (Builtin ann b)       = Builtin (f ann) b
  modifyAnn f (Error ann ty)        = Error (f ann) ty

-- | Map a function over the set of built-in functions.
mapFun :: (fun -> fun') -> Term tyname name uni fun ann -> Term tyname name uni fun' ann
mapFun f = go
  where
    go (LamAbs ann name ty body) = LamAbs ann name ty (go body)
    go (TyAbs ann name kind body) = TyAbs ann name kind (go body)
    go (IWrap ann pat arg term) = IWrap ann pat arg (go term)
    go (Apply ann fun arg) = Apply ann (go fun) (go arg)
    go (Unwrap ann term) = Unwrap ann (go term)
    go (Error ann ty) = Error ann ty
    go (TyInst ann term ty) = TyInst ann (go term) ty
    go (Var ann name) = Var ann name
    go (Constant ann con) = Constant ann con
    go (Builtin ann fun) = Builtin ann (f fun)
    go (Constr ann ty i args) = Constr ann ty i (map go args)
    go (Case ann ty arg cs) = Case ann ty (go arg) (map go cs)

{-| This is a wrapper to mark the place where the binder is introduced (i.e. LamAbs/TyAbs)
and not where it is actually used (TyVar/Var..).
This marking allows us to skip the (de)serialization of binders at LamAbs/TyAbs positions
iff 'name' is DeBruijn-encoded (level or index). See for example the instance of  'UntypedPlutusCore.Core.Instance.Flat' -}
newtype Binder name = Binder {unBinder :: name}
  deriving stock (Eq, Show)
  -- using this generates faster code, see discussion at <https://input-output-rnd.slack.com/archives/C48HA39RS/p1687917638566799>
  deriving (Functor) via Identity

{- Note [Constr tag type]
Constructor tags are not dynamically created, they can only come from the program itself.

So we do not have to worry about e.g. overflow.

The main constraints that we have are:
1. The use of the tags in the evaluator must be fast.
2. We don't want to allow nonsensical things (e.g. negative tags)
3. We don't want the format to change unexpectedly

These are in tension. The structure we use for storing case branches is a list, which is
traditionally indexed with an 'Int' (and most of the other alternatives are the same). That
suggests using 'Int' as the tag, but 'Int' allows negative tags. A 'Word' would be more
appropriate (of fixed size to satisfy 3), but then we need to be able to index lists by
'Word's.

Well, except there's nothing that _stops_ us indexing lists by 'Word's, we just need to
write our own indexing functions. So that's what we have done.

We use 'Word64' since it's the actual machine word, so no benefit from using a smaller
one (smaller values will be serialized by flat in fewer bytes anyway).
-}
