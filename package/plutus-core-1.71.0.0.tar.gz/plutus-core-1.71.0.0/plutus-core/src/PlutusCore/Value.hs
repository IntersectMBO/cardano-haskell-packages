{-# LANGUAGE BangPatterns #-}
{-# LANGUAGE BlockArguments #-}
{-# LANGUAGE DeriveAnyClass #-}
{-# LANGUAGE FlexibleInstances #-}
{-# LANGUAGE LambdaCase #-}
{-# LANGUAGE TupleSections #-}
{-# LANGUAGE ViewPatterns #-}

module PlutusCore.Value
  ( Value -- Do not expose data constructor
  , K -- Do not expose data constructor
  , k
  , unK
  , maxKeyLen
  , Quantity -- Do not expose data constructor
  , quantity
  , unQuantity
  , zeroQuantity
  , addQuantity
  , negativeAmounts
  , negativesByPolicy
  , NestedMap
  , unpack
  , pack
  , empty
  , fromList
  , toList
  , toFlatList
  , totalSize
  , maxInnerSize
  , insertCoin
  , deleteCoin
  , scaleValue
  , lookupCoin
  , policies
  , keepPolicies
  , dropPolicies
  , valueContains
  , unionValue
  , valueData
  , valueDataMaxSize
  , policyFilterMaxSize
  , unValueData
  , buildValueWith
  ) where

import Codec.CBOR.Decoding qualified as CBOR
import Codec.Serialise qualified as CBOR
import Control.DeepSeq (NFData)
import Control.Monad.Extra
  ( replicateM
  , unless
  , when
  , whenJust
  , (>=>)
  )
import Data.Bifunctor
import Data.ByteString (ByteString)
import Data.ByteString qualified as B
import Data.ByteString.Base64 qualified as Base64
import Data.Foldable (find)
import Data.Hashable (Hashable (..))
import Data.IntMap.Strict (IntMap)
import Data.IntMap.Strict qualified as IntMap
import Data.List qualified as List
import Data.Map.Merge.Strict qualified as M
import Data.Map.Strict (Map)
import Data.Map.Strict qualified as Map
import Data.Maybe (fromMaybe, mapMaybe)
import Data.Text.Encoding qualified as Text
import GHC.Generics
import GHC.Stack
  ( HasCallStack
  , callStack
  , getCallStack
  )

import PlutusCore.Builtin.Result
import PlutusCore.Data (Data (..))
import PlutusCore.Flat qualified as Flat
import PlutusCore.Flat.Decoder qualified as Flat
import PlutusPrelude (Pretty (..))

-- Max length (in bytes) for currency symbols and token names in `Value`,
-- both of which cannot exceed 32 bytes. Currency symbols are in fact either
-- empty or 28 bytes, but for simplicity we allow anything between 0 and 32 bytes.
maxKeyLen :: Int
maxKeyLen = 32
{-# INLINE maxKeyLen #-}

----------------------------------------------------------------------------------------------------
-- Newtype-wrapper for keys used in the nested maps ------------------------------------------------

-- | A `ByteString` with maximum length of `maxKeyLen` bytes.
newtype K = UnsafeK {unK :: ByteString}
  deriving newtype (Eq, Ord, Show, Hashable, NFData)
  deriving stock (Generic)

k :: ByteString -> Maybe K
k b = if B.length b <= maxKeyLen then Just (UnsafeK b) else Nothing
{-# INLINEABLE k #-}

instance Flat.Flat K where
  encode (UnsafeK b) = Flat.encode b
  {-# INLINE encode #-}
  decode = do
    b <- Flat.decode
    maybe (fail $ "Invalid Value key: " <> show (B.unpack b)) pure (k b)
  {-# INLINEABLE decode #-}

instance CBOR.Serialise K where
  encode (UnsafeK b) = CBOR.encode b
  {-# INLINE encode #-}
  decode = do
    b <- CBOR.decode
    maybe (fail $ "Invalid Value key: " <> show (B.unpack b)) pure (k b)
  {-# INLINEABLE decode #-}

----------------------------------------------------------------------------------------------------
-- Quantity: Signed 128-bit Integer ----------------------------------------------------------------

-- | A signed 128-bit integer quantity.
newtype Quantity = UnsafeQuantity {unQuantity :: Integer}
  deriving newtype (Eq, Ord, Show, NFData, Hashable)
  deriving stock (Generic)

instance CBOR.Serialise Quantity where
  encode (UnsafeQuantity i) = CBOR.encode i
  {-# INLINE encode #-}
  decode = do
    i <- CBOR.decode
    case quantity i of
      Just q -> pure q
      Nothing -> fail $ "Quantity out of signed 128-bit integer bounds: " <> show i
  {-# INLINEABLE decode #-}

instance Flat.Flat Quantity where
  encode (UnsafeQuantity i) = Flat.encode i
  {-# INLINE encode #-}
  decode = do
    i <- Flat.decode
    case quantity i of
      Just q -> pure q
      Nothing -> fail $ "Quantity out of signed 128-bit integer bounds: " <> show i
  {-# INLINEABLE decode #-}

instance Pretty Quantity where
  pretty (UnsafeQuantity i) = pretty i

instance Bounded Quantity where
  minBound = UnsafeQuantity (-(2 ^ (127 :: Integer)))
  {-# INLINE minBound #-}
  maxBound = UnsafeQuantity (2 ^ (127 :: Integer) - 1)
  {-# INLINE maxBound #-}

-- | Smart constructor for Quantity that validates bounds.
quantity :: Integer -> Maybe Quantity
quantity i
  | i >= unQuantity minBound && i <= unQuantity maxBound = Just (UnsafeQuantity i)
  | otherwise = Nothing
{-# INLINEABLE quantity #-}

-- | The zero quantity.
zeroQuantity :: Quantity
zeroQuantity = UnsafeQuantity 0
{-# INLINE zeroQuantity #-}

-- | Safely add two quantities, checking for overflow.
addQuantity :: Quantity -> Quantity -> Maybe Quantity
addQuantity (UnsafeQuantity x) (UnsafeQuantity y) = quantity (x + y)
{-# INLINEABLE addQuantity #-}

-- | Safely scale a quantity with given integer, checking for overflow.
scaleQuantity :: Integer -> Quantity -> Maybe Quantity
scaleQuantity x (UnsafeQuantity y) = quantity (x * y)
{-# INLINEABLE scaleQuantity #-}

----------------------------------------------------------------------------------------------------
-- Builtin Value definition ------------------------------------------------------------------------

type NestedMap = Map K (Map K Quantity)

-- | The underlying type of the UPLC built-in type @Value@.
data Value
  = Value
      !NestedMap
      {-^ Map from (currency symbol, token name) to quantity.

      Invariants: no empty inner map, and no zero quantity. -}
      !(IntMap Int)
      {-^ Map from size to the number of inner maps that have that size.
      This allows efficient retrieval of the size of the largest inner map,
      which is useful for costing of operations like `lookupCoin`.

      Invariant: all values are positive. -}
      {-# UNPACK #-} !Int
      {-^ Total size, i.e., sum total of inner map sizes. This avoids recomputing
      the total size during the costing of operations like `unionValue`. -}
      {-# UNPACK #-} !Int
      -- ^ The number of negative amounts it contains.
      !(Map K Int)
      {-^ Map from a currency symbol to the number of negative amounts it holds, so that
      `keepPolicies`, `dropPolicies` and `dropPolicy` can update the previous field without
      recounting the amounts of the currencies they remove.

      Invariant: all counts are positive. -}
  deriving stock (Eq, Show, Generic)
  deriving anyclass (NFData)

instance Hashable Value where
  hash = hash . unpack
  {-# INLINE hash #-}
  hashWithSalt salt = hashWithSalt salt . unpack
  {-# INLINE hashWithSalt #-}

instance CBOR.Serialise Value where
  encode (Value v _ _ _ _) = CBOR.encode v
  {-# INLINE encode #-}
  decode = do
    outerLen <- CBOR.decodeMapLen
    outer <- replicateM outerLen $ do
      currency <- CBOR.decode
      innerLen <- CBOR.decodeMapLen
      inner <- replicateM innerLen ((,) <$> CBOR.decode <*> CBOR.decode)
      pure (currency, inner)
    buildValueWith "Value CBOR decoder" pure pure outer
  {-# INLINE decode #-}

instance Flat.Flat Value where
  encode (Value v _ _ _ _) = Flat.encode v
  {-# INLINE encode #-}
  decode = do
    outer <- Flat.decodeListWith $ do
      currency <- Flat.decode
      inner <- Flat.decodeListWith ((,) <$> Flat.decode <*> Flat.decode)
      pure (currency, inner)
    buildValueWith "Value Flat decoder" pure pure outer
  {-# INLINE decode #-}
  size (Value v _ _ _ _) = Flat.size v
  {-# INLINE size #-}

{-| Unpack a `Value` into a map from (currency symbol, token name) to quantity.

The map is guaranteed to not contain empty inner map or zero quantity. -}
unpack :: Value -> NestedMap
unpack (Value v _ _ _ _) = v
{-# INLINE unpack #-}

{-| Pack a map from (currency symbol, token name) to quantity into a `Value`.

The map will be filtered so that it does not contain empty inner map or zero quantity. -}
pack :: NestedMap -> Value
pack = pack' . normalize
{-# INLINE pack #-}

-- | Like `pack` but does not normalize.
pack' :: NestedMap -> Value
pack' v = Value v sizes total neg negs
  where
    Sizes sizes total = sizeCaches v
    negs = Map.mapMaybe nonZeroNegatives v
    !neg = Map.foldl' (+) 0 negs
{-# INLINEABLE pack' #-}

-- | How many inner maps have each size, and the total size, in \(O(m)\).
sizeCaches :: NestedMap -> Sizes
sizeCaches = Map.foldl' alg (Sizes mempty 0)
  where
    alg (Sizes ss t) inner =
      let innerSize = Map.size inner
       in Sizes (IntMap.insertWith (+) innerSize 1 ss) (t + innerSize)
{-# INLINEABLE sizeCaches #-}

{-| The two size caches, as an accumulator for `sizeCaches`.

A tuple with bang patterns does not compile to the same thing. Worker-wrapper does get rid
of the tuple itself, but a bang makes a field strict rather than unpacked, so the `Int` stays
boxed and the fold unwraps and rewraps it on every step. The `UNPACK`ed field here is an
`Int#` the whole way through. -}
data Sizes = Sizes !(IntMap Int) {-# UNPACK #-} !Int

-- | Number of negative quantities in an inner map.
countNegative :: Map K Quantity -> Int
countNegative = Map.foldl' (\ !acc q -> if q < zeroQuantity then acc + 1 else acc) 0
{-# INLINE countNegative #-}

-- | The count, or `Nothing` when it is zero: the per-currency negative counts store no zeros.
nonZero :: Int -> Maybe Int
nonZero n = if n == 0 then Nothing else Just n
{-# INLINE nonZero #-}

-- | The number of negative amounts in an inner map, or `Nothing` when it holds none.
nonZeroNegatives :: Map K Quantity -> Maybe Int
nonZeroNegatives = nonZero . countNegative
{-# INLINE nonZeroNegatives #-}

-- | Record one more negative amount for a currency.
bumpNegative :: K -> Map K Int -> Map K Int
bumpNegative currency = Map.insertWith (+) currency 1
{-# INLINE bumpNegative #-}

-- | Record one fewer negative amount for a currency, dropping the entry at zero.
dropNegative :: K -> Map K Int -> Map K Int
dropNegative = Map.update \n -> if n <= 1 then Nothing else Just (n - 1)
{-# INLINE dropNegative #-}

{-| Total size, i.e., the number of distinct `(currency symbol, token name)` pairs
contained in the `Value`. -}
totalSize :: Value -> Int
totalSize (Value _ _ total _ _) = total
{-# INLINE totalSize #-}

-- | Size of the largest inner map.
maxInnerSize :: Value -> Int
maxInnerSize (Value _ sizes _ _ _) = maybe 0 fst (IntMap.lookupMax sizes)
{-# INLINE maxInnerSize #-}

negativeAmounts :: Value -> Int
negativeAmounts (Value _ _ _ neg _) = neg
{-# INLINE negativeAmounts #-}

{-| Map from a currency symbol to the number of negative amounts it holds; its sum is
`negativeAmounts`. Exposed for the bookkeeping tests. -}
negativesByPolicy :: Value -> Map K Int
negativesByPolicy (Value _ _ _ _ negs) = negs
{-# INLINE negativesByPolicy #-}

empty :: Value
empty = Value mempty mempty 0 0 mempty
{-# INLINE empty #-}

toList :: Value -> [(K, [(K, Quantity)])]
toList = Map.toList . Map.map Map.toList . unpack
{-# INLINEABLE toList #-}

toFlatList :: Value -> [(K, K, Quantity)]
toFlatList (toList -> xs) = [(c, t, a) | (c, ys) <- xs, (t, a) <- ys]
{-# INLINEABLE toFlatList #-}

fromList :: [(K, [(K, Quantity)])] -> BuiltinResult Value
fromList xs = do
  -- Use unchecked addition during construction
  let outerMap =
        Map.fromListWith
          (Map.unionWith unsafeAddQuantity) -- combine inner maps with unchecked addition
          (second (Map.fromListWith unsafeAddQuantity) <$> xs)
  -- Validate all quantities are within bounds
  pack <$> validateQuantities outerMap
{-# INLINEABLE fromList #-}

-- | Unsafe addition of quantities without bounds checking.
unsafeAddQuantity :: Quantity -> Quantity -> Quantity
unsafeAddQuantity (UnsafeQuantity x) (UnsafeQuantity y) = UnsafeQuantity (x + y)
{-# INLINE unsafeAddQuantity #-}

-- | Validate all quantities in a nested map are within bounds.
validateQuantities :: HasCallStack => NestedMap -> BuiltinResult NestedMap
validateQuantities nestedMap =
  case find isOutOfBounds allQuantities of
    Just (UnsafeQuantity i) -> fail $ context <> ": quantity out of bounds: " <> show i
    Nothing -> pure nestedMap
  where
    allQuantities = concatMap Map.elems $ Map.elems nestedMap
    isOutOfBounds (UnsafeQuantity i) =
      i < unQuantity minBound || i > unQuantity maxBound
    context = case getCallStack callStack of
      (fnName, _) : _ -> fnName
      [] -> "<unknown>"
{-# INLINEABLE validateQuantities #-}

normalize :: NestedMap -> NestedMap
normalize = Map.filter (not . Map.null) . Map.map (Map.filter (/= zeroQuantity))
{-# INLINEABLE normalize #-}

instance Pretty Value where
  pretty = pretty . fmap (bimap toText (fmap (first toText))) . toList
    where
      toText = Text.decodeLatin1 . Base64.encode . unK

{-| \(O(\log \max(m, k))\), where \(m\) is the size of the outer map, and \(k\) is
the size of the largest inner map. -}
insertCoin :: ByteString -> ByteString -> Integer -> Value -> BuiltinResult Value
insertCoin unsafeCurrency unsafeToken unsafeAmount v@(Value outer sizes total neg negs)
  | unsafeAmount == 0 = pure $ deleteCoin unsafeCurrency unsafeToken v
  | otherwise = case (k unsafeCurrency, k unsafeToken, quantity unsafeAmount) of
      (Nothing, _, _) -> fail $ "insertCoin: invalid currency: " <> show (B.unpack unsafeCurrency)
      (_, Nothing, _) -> fail $ "insertCoin: invalid token: " <> show (B.unpack unsafeToken)
      (_, _, Nothing) -> fail $ "insertCoin: quantity out of bounds: " <> show unsafeAmount
      (Just currency, Just token, Just qty) ->
        let f
              :: Maybe (Map K Quantity)
              -> ( -- Left (old size of inner map) if the total size grows by 1,
                   -- otherwise, Right (old quantity)
                   Either Int Quantity
                 , Maybe (Map K Quantity)
                 )
            f = \case
              Nothing -> (Left 0, Just (Map.singleton token qty))
              Just inner ->
                let (mOldQuantity, inner') =
                      Map.insertLookupWithKey (\_ _ _ -> qty) token qty inner
                 in (maybe (Left (Map.size inner)) Right mOldQuantity, Just inner')
            (res, outer') = Map.alterF f currency outer
            (sizes', total', neg', negs') = case res of
              Left oldSize
                | qty < zeroQuantity ->
                    ( updateSizes oldSize (oldSize + 1) sizes
                    , total + 1
                    , neg + 1
                    , bumpNegative currency negs
                    )
                | otherwise ->
                    (updateSizes oldSize (oldSize + 1) sizes, total + 1, neg, negs)
              Right oldQuantity
                | oldQuantity < zeroQuantity && qty > zeroQuantity ->
                    (sizes, total, neg - 1, dropNegative currency negs)
                | oldQuantity > zeroQuantity && qty < zeroQuantity ->
                    (sizes, total, neg + 1, bumpNegative currency negs)
                | otherwise -> (sizes, total, neg, negs)
         in pure $ Value outer' sizes' total' neg' negs'
{-# INLINEABLE insertCoin #-}

-- | \(O(\log \max(m, k))\)
deleteCoin :: ByteString -> ByteString -> Value -> Value
deleteCoin (UnsafeK -> currency) (UnsafeK -> token) (Value outer sizes total neg negs) =
  Value outer' sizes' total' neg' negs'
  where
    (mold, outer') = Map.alterF f currency outer
    (sizes', total', neg', negs') = case mold of
      Just (oldSize, oldQuantity)
        | oldQuantity < zeroQuantity ->
            ( updateSizes oldSize (oldSize - 1) sizes
            , total - 1
            , neg - 1
            , dropNegative currency negs
            )
        | otherwise -> (updateSizes oldSize (oldSize - 1) sizes, total - 1, neg, negs)
      Nothing -> (sizes, total, neg, negs)
    f
      :: Maybe (Map K Quantity)
      -> ( -- Just (old size of inner map, old quantity) if the total size shrinks by 1,
           -- otherwise Nothing
           Maybe (Int, Quantity)
         , Maybe (Map K Quantity)
         )
    f = \case
      Nothing -> (Nothing, Nothing)
      Just inner ->
        let (qty, inner') = Map.updateLookupWithKey (\_ _ -> Nothing) token inner
         in ((Map.size inner,) <$> qty, if Map.null inner' then Nothing else Just inner')

-- | \(O(\log \max(m, k))\)
lookupCoin :: ByteString -> ByteString -> Value -> Integer
lookupCoin (UnsafeK -> currency) (UnsafeK -> token) (unpack -> outer) =
  case Map.lookup currency outer of
    Nothing -> 0
    Just inner -> unQuantity $ Map.findWithDefault zeroQuantity token inner

{-| \(O(m)\), where \(m\) is the size of the outer map. The currency symbols in
the `Value`, in ascending order, including the lovelace currency symbol (the
empty bytestring) if present. -}
policies :: Value -> [ByteString]
policies = map unK . Map.keys . unpack
{-# INLINEABLE policies #-}

{-| The most policies `keepPolicies` and `dropPolicies` accept in their `Value`; both fail
on more.  It is the largest outer size of depth 13. -}
policyFilterMaxSize :: Int
policyFilterMaxSize = 8191

-- | The failure both policy filters raise on a `Value` with too many policies.
policyFilterOverflow :: String -> BuiltinResult a
policyFilterOverflow name =
  fail $ name <> ": maximum number of policies (" <> show policyFilterMaxSize <> ") exceeded"
{-# INLINE policyFilterOverflow #-}

{-| The `Value` restricted to the given currency symbols, in \(O(p \log m)\) for a list of
\(p\) ids and an outer map of size \(m\).  Ids the `Value` does not have, including any
longer than `maxKeyLen`, are ignored.  Fails if the `Value` holds more than
`policyFilterMaxSize` policies. -}
keepPolicies :: [ByteString] -> Value -> BuiltinResult Value
keepPolicies ps (Value outer _ _ _ negs)
  | Map.size outer > policyFilterMaxSize = policyFilterOverflow "keepPolicies"
  | otherwise =
      let outer' = List.foldl' keep Map.empty (mapMaybe k ps)
          keep acc currency = case Map.lookup currency outer of
            Nothing -> acc
            Just inner -> Map.insert currency inner acc
          negs' = Map.intersection negs outer'
          !neg = Map.foldl' (+) 0 negs'
          Sizes sizes total = sizeCaches outer'
       in pure $ Value outer' sizes total neg negs'
{-# INLINEABLE keepPolicies #-}

{-| The `Value` with the given currency symbols removed, in \(O(p \log m)\) for a list of
\(p\) ids and an outer map of size \(m\).  Ids the `Value` does not have, including any
longer than `maxKeyLen`, are ignored.  Fails if the `Value` holds more than
`policyFilterMaxSize` policies. -}
dropPolicies :: [ByteString] -> Value -> BuiltinResult Value
dropPolicies ps v@(Value outer _ _ _ _)
  | Map.size outer > policyFilterMaxSize = policyFilterOverflow "dropPolicies"
  | otherwise = pure $ List.foldl' dropPolicy v (mapMaybe k ps)
{-# INLINEABLE dropPolicies #-}

{-| Remove one currency and subtract its contribution from the cached fields.

A currency the `Value` does not have is a no-op. That is also why a repeated id in
`dropPolicies` does no harm: the first occurrence removes it, and later ones find nothing. -}
dropPolicy :: Value -> K -> Value
dropPolicy v@(Value outer sizes total neg negs) currency =
  case Map.updateLookupWithKey (\_ _ -> Nothing) currency outer of
    (Nothing, _) -> v
    (Just inner, outer') ->
      let innerSize = Map.size inner
          (mInnerNeg, negs') = Map.updateLookupWithKey (\_ _ -> Nothing) currency negs
       in Value
            outer'
            (updateSizes innerSize 0 sizes)
            (total - innerSize)
            (neg - fromMaybe 0 mInnerNeg)
            negs'
{-# INLINE dropPolicy #-}

{-| \(O(n_{2}\log \max(m_{1}, k_{1}))\), where \(n_{2}\) is the total size of the second
`Value`, \(m_{1}\) is the size of the outer map in the first `Value` and \(k_{1}\) is
the size of the largest inner map in the first `Value`.

@a@ contains @b@ if for each @(currency, token, quantity)@ in @b@,
@lookup currency token a >= quantity@.

Both values must not contain negative amounts. -}
valueContains :: Value -> Value -> BuiltinResult Bool
valueContains v1 v2
  | negativeAmounts v1 > 0 = fail "valueContains: first value contains negative amounts"
  | negativeAmounts v2 > 0 = fail "valueContains: second value contains negative amounts"
  | totalSize v1 < totalSize v2 = BuiltinSuccess False
  -- \^ v2 is too big to be contained in v1: `isSubmapOfBy` has a similar check,
  -- but that only applies to the top-level structure of the map, so v1 can
  -- have a larger outer map than v2 but a smaller number of total entries, and
  -- without this check the outer call of `isSubmapOfBy` would carry on and
  -- compare the inner maps even though v2 can't fit inside v1.
  | otherwise = BuiltinSuccess $ Map.isSubmapOfBy (Map.isSubmapOfBy (<=)) (unpack v2) (unpack v1)
{-# INLINEABLE valueContains #-}

{-| \(O(n_{1}) + O(n_{2})\), where \(n_{1}\) and \(n_{2}\) are the total sizes
(i.e., sum of inner map sizes) of the two maps.

Shortcircuits if either value is empty.

Since 'unionValue' is commutative, we switch the arguments whenever the second
value is larger in total size than the first one. We have found through experimentation
that this results in better performance in practice. -}
unionValue :: Value -> Value -> BuiltinResult Value
unionValue vA vB
  | totalSize vA == 0 = BuiltinSuccess vB
  | totalSize vB == 0 = BuiltinSuccess vA
  | otherwise =
      pack'
        <$> M.mergeA
          M.preserveMissing
          M.preserveMissing
          ( M.zipWithMaybeAMatched \_ innerA innerB ->
              fmap (\inner -> if Map.null inner then Nothing else Just inner) $
                M.mergeA
                  M.preserveMissing
                  M.preserveMissing
                  ( M.zipWithMaybeAMatched \_ x y ->
                      case addQuantity x y of
                        Just z -> pure if z == zeroQuantity then Nothing else Just z
                        Nothing ->
                          fail "unionValue: quantity is out of the signed 128-bit integer bounds"
                  )
                  innerA
                  innerB
          )
          v1
          v2
  where
    (v1, v2) =
      if totalSize vB > totalSize vA
        then (unpack vB, unpack vA)
        else (unpack vA, unpack vB)
{-# INLINEABLE unionValue #-}

valueDataMaxSize :: Int
valueDataMaxSize = 40_000

{-| \(O(n)\). Encodes `Value` as `Data`, in the same way as non-builtin @Value@.
This is the denotation of @ValueData@ in Plutus V1, V2 and V3. -}
valueData :: Value -> BuiltinResult Data
valueData v =
  if totalSize v <= valueDataMaxSize
    then pure $ Map . fmap (bimap (B . unK) tokensData) . Map.toList . unpack $ v
    else fail $ "valueData: maximum input size (" ++ show valueDataMaxSize ++ ") exceeded"
  where
    tokensData :: Map K Quantity -> Data
    tokensData = Map . fmap (bimap (B . unK) (I . unQuantity)) . Map.toList
{-# INLINEABLE valueData #-}

{-| \(O(n)\). Decodes `Data` into `Value`.
This is the denotation of @UnValueData@ in Plutus V1, V2 and V3. -}
unValueData :: Data -> BuiltinResult Value
unValueData =
  unMap
    >=> buildValueWith
      "unValueData"
      ( \(cData, tsData) ->
          (,)
            <$> unB cData
            <*> unMap tsData
      )
      (\(tData, qData) -> (,) <$> unB tData <*> unQ qData)
  where
    unB :: Data -> BuiltinResult K
    unB = \case
      B b -> maybe (fail $ "unValueData: invalid key: " <> show (B.unpack b)) pure (k b)
      _ -> fail "unValueData: non-B constructor"
    {-# INLINEABLE unB #-}

    unQ :: Data -> BuiltinResult Quantity
    unQ = \case
      I i
        | Just q <- quantity i -> pure q
        | otherwise -> fail "unValueData: invalid quantity"
      _ -> fail "unValueData: non-I constructor"
    {-# INLINEABLE unQ #-}

    unMap :: Data -> BuiltinResult [(Data, Data)]
    unMap = \case
      Map xs -> pure xs
      _ -> fail "unValueData: non-Map constructor"
{-# INLINEABLE unValueData #-}

-- | Decrement bucket @old@, and increment bucket @new@.
updateSizes :: Int -> Int -> IntMap Int -> IntMap Int
updateSizes old new = dec . inc
  where
    inc =
      if new == 0
        then id
        else IntMap.alter (maybe (Just 1) (Just . (+ 1))) new
    dec =
      if old == 0
        then id
        else IntMap.update (\n -> if n <= 1 then Nothing else Just (n - 1)) old
{-# INLINEABLE updateSizes #-}

-- | \(O(n)\). Scale each token by the given constant factor.
scaleValue :: Integer -> Value -> BuiltinResult Value
scaleValue c (Value outer sizes size neg negs)
  -- When scaling by positive factor, no need to change sizes and number of negative amounts.
  | c > 0 = do
      outer' <- go outer
      BuiltinSuccess $ Value outer' sizes size neg negs
  -- When scaling by negative factor, only need to "flip" negative amounts.
  | c < 0 = do
      outer' <- go outer
      BuiltinSuccess $ Value outer' sizes size (size - neg) (flipNegatives outer negs)
  -- Scaling by 0 is always empty value
  | otherwise = BuiltinSuccess empty
  where
    go :: NestedMap -> BuiltinResult NestedMap
    go = traverse (traverse goScale)
    goScale :: Quantity -> BuiltinResult Quantity
    goScale x =
      case scaleQuantity c x of
        Nothing ->
          fail $
            "scaleValue: quantity out of bounds: "
              <> show c
              <> " * "
              <> show (unQuantity x)
        Just q -> pure q

{-| The per-currency negative counts after every amount in the `Value` has flipped sign: a
currency's new count is its size minus its old count. -}
flipNegatives :: NestedMap -> Map K Int -> Map K Int
flipNegatives =
  M.merge
    (M.mapMaybeMissing \_ inner -> nonZero (Map.size inner))
    M.dropMissing
    (M.zipWithMaybeMatched \_ inner old -> nonZero (Map.size inner - old))
{-# INLINEABLE flipNegatives #-}

{-| Build a `Value` from a list of entries. It fails unless the following
conditions are met:

  * currency symbols are strictly ascending
  * token names are strictly ascending
  * every quantity is within bounds
  * no zero quantity -}
buildValueWith
  :: forall m a b
   . MonadFail m
  => String
  -> (a -> m (K, [b]))
  -- ^ Convert an outer entry into (currency, inner entries)
  -> (b -> m (K, Quantity))
  -- ^ Convert an inner entry into (token, quantity)
  -> [a]
  -> m Value
buildValueWith ctx fouter finner cs = do
  (outerDescList, sizes, total, neg, negsDescList) <- goOuter Nothing mempty mempty 0 0 [] cs
  pure $
    Value
      (Map.fromDistinctDescList outerDescList)
      sizes
      total
      neg
      (Map.fromDistinctDescList negsDescList)
  where
    goOuter
      :: Maybe K
      -> [(K, Map K Quantity)]
      -> IntMap Int
      -> Int
      -> Int
      -> [(K, Int)]
      -> [a]
      -> m ([(K, Map K Quantity)], IntMap Int, Int, Int, [(K, Int)])
    goOuter !prev !acc !sizes !total !neg !negs = \case
      [] -> pure (acc, sizes, total, neg, negs)
      x : xs -> do
        (!c, !innerEntries) <- fouter x
        whenJust
          prev
          ( \p ->
              unless
                (p < c)
                (fail $ ctx <> ": currency symbols not strictly ascending")
          )
        (innerDescList, innerNeg) <- goInner Nothing mempty 0 innerEntries
        when (null innerDescList) . fail $ ctx <> ": empty inner map"
        let !inner = Map.fromDistinctDescList innerDescList
            !innerSize = Map.size inner
            !sizes' = IntMap.alter (maybe (Just 1) (Just . (+ 1))) innerSize sizes
            !negs' = if innerNeg == 0 then negs else (c, innerNeg) : negs
        goOuter (Just c) ((c, inner) : acc) sizes' (total + innerSize) (neg + innerNeg) negs' xs

    goInner :: Maybe K -> [(K, Quantity)] -> Int -> [b] -> m ([(K, Quantity)], Int)
    goInner !prev !acc !neg = \case
      [] -> pure (acc, neg)
      x : xs -> do
        (!t, !q) <- finner x
        whenJust
          prev
          ( \p ->
              unless
                (p < t)
                (fail $ ctx <> ": token names not strictly ascending")
          )
        -- minBound and maxBound are checked in `quantity`. We just need to
        -- guard against zero here.
        when (q == zeroQuantity) . fail $ ctx <> ": zero quantity"
        let neg' = if q < zeroQuantity then neg + 1 else neg
        goInner (Just t) ((t, q) : acc) neg' xs
{-# INLINEABLE buildValueWith #-}
