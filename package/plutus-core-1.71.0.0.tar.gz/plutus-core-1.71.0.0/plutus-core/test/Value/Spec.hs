{-# LANGUAGE OverloadedStrings #-}
{-# LANGUAGE TypeApplications #-}
{-# LANGUAGE ViewPatterns #-}
{-# OPTIONS_GHC -Wno-incomplete-uni-patterns #-}
{-# OPTIONS_GHC -Wno-orphans #-}

module Value.Spec (tests) where

import Codec.Serialise qualified as CBOR
import Data.ByteString (ByteString)
import Data.ByteString qualified as B
import Data.Either
import Data.Foldable qualified as F
import Data.List.Extra (nubOrdOn, sortOn)
import Data.Map.Strict qualified as Map
import Data.Maybe
import Data.SatInt (fromSatInt)
import Safe.Foldable (maximumMay)
import Test.QuickCheck
import Test.Tasty
import Test.Tasty.HUnit
import Test.Tasty.QuickCheck

import PlutusCore.Builtin (BuiltinResult (..))
import PlutusCore.Data (Data (..))
import PlutusCore.Evaluation.Machine.CostStream (sumCostStream)
import PlutusCore.Evaluation.Machine.ExMemoryUsage
  ( ExMemoryUsage (..)
  , ValueOuterDepth (..)
  , flattenCostRose
  )
import PlutusCore.Flat qualified as Flat
import PlutusCore.Generators.QuickCheck.Builtin (arbitraryBuiltin, genShortHex)
import PlutusCore.Value (Value)
import PlutusCore.Value qualified as V

prop_packUnpackRoundtrip :: Value -> Property
prop_packUnpackRoundtrip v = v === V.pack (V.unpack v)

-- | Verifies that @pack@ correctly updates the sizes
prop_packBookkeeping :: V.NestedMap -> Property
prop_packBookkeeping = checkBookkeeping . V.pack

{-| Verifies that @pack@ preserves @Value@ invariants, i.e.,
no empty inner map or zero amount. -}
prop_packPreservesInvariants :: V.NestedMap -> Property
prop_packPreservesInvariants = checkInvariants . V.pack

-- | Verifies that @insertCoin@ correctly updates the sizes
prop_insertCoinBookkeeping :: Value -> V.Quantity -> Property
prop_insertCoinBookkeeping v quantity =
  forAll (genShortHex (V.totalSize v)) $ \currency ->
    forAll (genShortHex (V.totalSize v)) $ \token ->
      let BuiltinSuccess v' =
            V.insertCoin (V.unK currency) (V.unK token) (V.unQuantity quantity) v
       in checkBookkeeping v'

-- | Verifies that @insertCoin@ preserves @Value@ invariants
prop_insertCoinPreservesInvariants :: Value -> V.Quantity -> Property
prop_insertCoinPreservesInvariants v quantity =
  forAll (genShortHex (V.totalSize v)) $ \currency ->
    forAll (genShortHex (V.totalSize v)) $ \token ->
      let BuiltinSuccess v' =
            V.insertCoin (V.unK currency) (V.unK token) (V.unQuantity quantity) v
       in checkInvariants v'

prop_unionCommutative :: Value -> Value -> Property
prop_unionCommutative v v' =
  case (V.unionValue v v', V.unionValue v' v) of
    (BuiltinSuccess r1, BuiltinSuccess r2) -> r1 === r2
    (BuiltinFailure {}, BuiltinFailure {}) -> property True
    _ -> property False

-- | Verifies that @unionValue@ correctly updates the caches
prop_unionBookkeeping :: Value -> Value -> Property
prop_unionBookkeeping v v' =
  case V.unionValue v v' of
    BuiltinSuccess r -> checkBookkeeping r
    _ -> property True

prop_unionAssociative :: Value -> Value -> Value -> Property
prop_unionAssociative v1 v2 v3 =
  let succeeded = not . null
      extractValue = foldr const (error "extractValue called on BuiltinFailure")

      r23 = V.unionValue v2 v3
      r12 = V.unionValue v1 v2
   in if succeeded r23 && succeeded r12
        then do
          let r1 = V.unionValue v1 (extractValue r23)
              r2 = V.unionValue (extractValue r12) v3
          if succeeded r1 && succeeded r2
            then extractValue r1 === extractValue r2
            else discard
        else discard

prop_insertCoinIdempotent :: Value -> Property
prop_insertCoinIdempotent v =
  v
    === F.foldl'
      ( \acc (c, t, q) ->
          let BuiltinSuccess v' = V.insertCoin (V.unK c) (V.unK t) (V.unQuantity q) acc
           in v'
      )
      v
      (V.toFlatList v)

prop_insertCoinValidatesCurrency :: Value -> Property
prop_insertCoinValidatesCurrency v =
  forAll gen33Bytes $ \c ->
    forAll gen32BytesOrFewer $ \t ->
      forAll (arbitraryBuiltin `suchThat` (/= 0)) $ \quantity ->
        case V.insertCoin c t quantity v of
          BuiltinFailure {} -> property True
          _ -> property False

prop_insertCoinValidatesToken :: Value -> Property
prop_insertCoinValidatesToken v =
  forAll gen32BytesOrFewer $ \c ->
    forAll gen33Bytes $ \t ->
      forAll (arbitraryBuiltin `suchThat` (/= 0)) $ \quantity ->
        case V.insertCoin c t quantity v of
          BuiltinFailure {} -> property True
          _ -> property False

prop_insertCoinValidatesQuantityMin :: Value -> Property
prop_insertCoinValidatesQuantityMin v =
  forAll gen32BytesOrFewer $ \c ->
    forAll gen32BytesOrFewer $ \t ->
      forAll genBelowMinQuantity $ \quantity ->
        case V.insertCoin c t quantity v of
          BuiltinFailure {} -> property True
          _ -> property False

prop_insertCoinValidatesQuantityMax :: Value -> Property
prop_insertCoinValidatesQuantityMax v =
  forAll gen32BytesOrFewer $ \c ->
    forAll gen32BytesOrFewer $ \t ->
      forAll genAboveMaxQuantity $ \quantity ->
        case V.insertCoin c t quantity v of
          BuiltinFailure {} -> property True
          _ -> property False

prop_lookupAfterInsertion :: Value -> V.Quantity -> Property
prop_lookupAfterInsertion v quantity =
  forAll (genShortHex (V.totalSize v)) $ \currency ->
    forAll (genShortHex (V.totalSize v)) $ \token ->
      let BuiltinSuccess v' =
            V.insertCoin (V.unK currency) (V.unK token) (V.unQuantity quantity) v
       in V.lookupCoin (V.unK currency) (V.unK token) v' === V.unQuantity quantity

prop_lookupAfterDeletion :: Value -> Property
prop_lookupAfterDeletion v =
  forAll (genShortHex (V.totalSize v)) $ \currency ->
    forAll (genShortHex (V.totalSize v)) $ \token ->
      let v' = V.deleteCoin (V.unK currency) (V.unK token) v
       in V.lookupCoin (V.unK currency) (V.unK token) v' === 0

prop_deleteCoinIdempotent :: Value -> Property
prop_deleteCoinIdempotent v0 =
  forAll (elements fl) $ \(V.unK -> c, V.unK -> t, _) ->
    let v' = V.deleteCoin c t v
     in v' === V.deleteCoin c t v'
  where
    BuiltinSuccess v = if V.totalSize v0 > 0 then pure v0 else V.insertCoin "c" "t" 1 v0
    fl = V.toFlatList v

prop_deleteCoinBookkeeping :: Value -> Property
prop_deleteCoinBookkeeping v =
  conjoin [property (checkBookkeeping v') | v' <- vs]
  where
    fl = V.toFlatList v
    vs = scanr (\(c, t, _) -> V.deleteCoin (V.unK c) (V.unK t)) v fl

prop_deleteCoinPreservesInvariants :: Value -> Property
prop_deleteCoinPreservesInvariants v =
  conjoin [property (checkInvariants v') | v' <- vs]
  where
    fl = V.toFlatList v
    vs = scanr (\(c, t, _) -> V.deleteCoin (V.unK c) (V.unK t)) v fl

prop_policiesStrictlyAscending :: Value -> Property
prop_policiesStrictlyAscending v =
  let ps = V.policies v
   in property $ and (zipWith (<) ps (drop 1 ps))

prop_policiesAfterInsertion :: Value -> V.Quantity -> Property
prop_policiesAfterInsertion v quantity =
  quantity /= V.zeroQuantity ==> forAll genCurrencyToken $ \(currency, token) ->
    let BuiltinSuccess v' = V.insertCoin currency token (V.unQuantity quantity) v
     in property $ currency `elem` V.policies v'
  where
    genCurrencyToken = do
      let hex = V.unK <$> genShortHex (V.totalSize v)
      (,) <$> hex <*> hex

-- | Deleting every token of a policy removes it from @policies@.
prop_policiesAfterDeletion :: Value -> Property
prop_policiesAfterDeletion v0 =
  forAll (elements (Map.toList (V.unpack v))) $ \(currency, inner) ->
    let v' = F.foldl' (\acc t -> V.deleteCoin (V.unK currency) (V.unK t) acc) v (Map.keys inner)
     in property $ V.unK currency `notElem` V.policies v'
  where
    BuiltinSuccess v = if V.totalSize v0 > 0 then pure v0 else V.insertCoin "c" "t" 1 v0

{-| Policy ids for the @keepPolicies@/@dropPolicies@ properties.

Some are drawn from the `Value` itself, so that the properties test a filter that actually
keeps or removes something. The rest are generated and almost never match, which is what
exercises the absent-id path. Some are then repeated, because a repeated id finds what an earlier
occurrence already recorded and neither builtin may count it twice. -}
genPolicyIds :: Value -> Gen [ByteString]
genPolicyIds v = do
  present <- sublistOf (V.policies v)
  absent <- listOf (V.unK <$> genShortHex (V.totalSize v))
  let ids = present <> absent
  repeats <- sublistOf ids
  shuffle (ids <> repeats)

{-| Run a policy filter on a `Value` the generators keep far below `policyFilterMaxSize`,
so that a failure here is a bug and not the bound. -}
filtered :: BuiltinResult Value -> (Value -> Property) -> Property
filtered r prop = case r of
  BuiltinSuccess v -> prop v
  BuiltinSuccessWithLogs _ v -> prop v
  BuiltinFailure {} -> counterexample "policy filter failed below policyFilterMaxSize" False

prop_keepPoliciesBookkeeping :: Value -> Property
prop_keepPoliciesBookkeeping v =
  forAll (genPolicyIds v) $ \ps -> filtered (V.keepPolicies ps v) checkBookkeeping

prop_keepPoliciesPreservesInvariants :: Value -> Property
prop_keepPoliciesPreservesInvariants v =
  forAll (genPolicyIds v) $ \ps -> filtered (V.keepPolicies ps v) checkInvariants

-- | @keepPolicies@ retains exactly those requested policies the `Value` has.
prop_keepPoliciesSelects :: Value -> Property
prop_keepPoliciesSelects v =
  forAll (genPolicyIds v) $ \ps ->
    filtered (V.keepPolicies ps v) $ \kept ->
      V.policies kept === filter (`elem` ps) (V.policies v)

prop_dropPoliciesBookkeeping :: Value -> Property
prop_dropPoliciesBookkeeping v =
  forAll (genPolicyIds v) $ \ps -> filtered (V.dropPolicies ps v) checkBookkeeping

prop_dropPoliciesPreservesInvariants :: Value -> Property
prop_dropPoliciesPreservesInvariants v =
  forAll (genPolicyIds v) $ \ps -> filtered (V.dropPolicies ps v) checkInvariants

-- | @dropPolicies@ removes exactly those requested policies the `Value` has.
prop_dropPoliciesSelects :: Value -> Property
prop_dropPoliciesSelects v =
  forAll (genPolicyIds v) $ \ps ->
    filtered (V.dropPolicies ps v) $ \rest ->
      V.policies rest === filter (`notElem` ps) (V.policies v)

{-| `dropPolicies` maintains the caches by subtraction instead of recomputing them, so it
has to agree field for field with a `Value` repacked from the retained map.

`checkBookkeeping` only looks at the largest entry of the size histogram, so a wrong count in
any other entry would pass it. Comparing whole `Value`s through the derived `Eq` checks every
entry. -}
prop_dropPoliciesAgreesWithRepack :: Value -> Property
prop_dropPoliciesAgreesWithRepack v =
  forAll (genPolicyIds v) $ \ps ->
    let ks = mapMaybe V.k ps
     in filtered (V.dropPolicies ps v) $
          (=== V.pack (Map.filterWithKey (\c _ -> c `notElem` ks) (V.unpack v)))

{-| `keepPolicies` builds the caches from the currencies it keeps rather than recomputing
them over the map it returns, so it has to agree field for field with a `Value` repacked
from that map, for the same reason `dropPolicies` does. -}
prop_keepPoliciesAgreesWithRepack :: Value -> Property
prop_keepPoliciesAgreesWithRepack v =
  forAll (genPolicyIds v) $ \ps ->
    let ks = mapMaybe V.k ps
     in filtered (V.keepPolicies ps v) $
          (=== V.pack (Map.filterWithKey (\c _ -> c `elem` ks) (V.unpack v)))

{-| @keepPolicies@ and @dropPolicies@ partition a `Value`: reuniting the two halves
recovers the original, caches included. -}
prop_keepDropPartition :: Value -> Property
prop_keepDropPartition v =
  forAll (genPolicyIds v) $ \ps ->
    filtered (V.keepPolicies ps v) $ \kept ->
      filtered (V.dropPolicies ps v) $ \dropped ->
        case V.unionValue kept dropped of
          BuiltinSuccess u -> u === v
          _ -> property False

toPositiveValue :: Value -> Value
toPositiveValue =
  V.pack . fmap (Map.map (fromMaybe maxBound . V.quantity . abs . V.unQuantity)) . V.unpack

prop_containsReflexive :: Value -> Property
prop_containsReflexive (toPositiveValue -> v) =
  property $ case V.valueContains v v of
    BuiltinSuccess r -> r
    _ -> False

prop_containsAfterDeletion :: Value -> Property
prop_containsAfterDeletion (toPositiveValue -> v) =
  conjoin [property (case V.valueContains v v' of BuiltinSuccess r -> r; _ -> False) | v' <- vs]
  where
    fl = V.toFlatList v
    vs = scanr (\(c, t, _) -> V.deleteCoin (V.unK c) (V.unK t)) v fl

prop_containsEnforcesPositivity :: Value -> Property
prop_containsEnforcesPositivity v
  | V.negativeAmounts v == 0 = case (V.valueContains v V.empty, V.valueContains V.empty v) of
      (BuiltinSuccess {}, BuiltinSuccess {}) -> property True
      _ -> property False
  | otherwise = case (V.valueContains v V.empty, V.valueContains V.empty v) of
      (BuiltinFailure {}, BuiltinFailure {}) -> property True
      _ -> property False

scaleIncorrectlyBound :: Integer -> Value -> Bool
scaleIncorrectlyBound factor val =
  any
    (\(_, _, V.unQuantity -> q) -> isNothing $ V.quantity $ q * factor)
    $ V.toFlatList val

prop_scaleBookKeeping :: Integer -> Value -> Property
prop_scaleBookKeeping factor v =
  case V.scaleValue factor v of
    BuiltinSuccess r -> checkBookkeeping r
    _ -> property $ scaleIncorrectlyBound factor v

prop_scaleByOneIsId :: Value -> Property
prop_scaleByOneIsId v =
  property $ case V.scaleValue 1 v of
    BuiltinSuccess r -> r == v
    _ -> scaleIncorrectlyBound 1 v

prop_negateInvolutive :: Value -> Property
prop_negateInvolutive v =
  property $ case V.scaleValue (-1) v >>= V.scaleValue (-1) of
    BuiltinSuccess r -> r == v
    _ -> scaleIncorrectlyBound (-1) v

prop_scaleZeroIsZero :: Value -> Property
prop_scaleZeroIsZero v =
  property $ case V.scaleValue 0 v of
    BuiltinSuccess r -> r == V.empty
    _ -> scaleIncorrectlyBound 0 v

prop_negateIsInverse :: Value -> Property
prop_negateIsInverse v =
  let
    inverseUnion = do
      vInv <- V.scaleValue (-1) v
      V.unionValue v vInv
   in
    property $ case inverseUnion of
      BuiltinSuccess r -> r == V.empty
      _ -> scaleIncorrectlyBound (-1) v

prop_oppositeScaleIsInverse :: Integer -> Value -> Property
prop_oppositeScaleIsInverse c v =
  let
    scaledValue = do
      vInv <- V.scaleValue (negate c) v
      v' <- V.scaleValue c v
      V.unionValue v' vInv
   in
    property $ case scaledValue of
      BuiltinSuccess r -> r == V.empty
      _ -> scaleIncorrectlyBound c v

prop_dataRoundtrip :: Value -> Property
prop_dataRoundtrip v =
  case V.valueData v of
    BuiltinSuccess d ->
      case V.unValueData d of
        BuiltinSuccess v' ->
          case V.valueData v' of
            BuiltinSuccess d' -> (v === v') .&&. (d' === d)
            _ -> property False
        _ -> property False
    _ -> property False

prop_flatRoundtrip :: Value -> Property
prop_flatRoundtrip v = Flat.unflat (Flat.flat v) === Right v

prop_cborRoundtrip :: Value -> Property
prop_cborRoundtrip v = CBOR.deserialiseOrFail (CBOR.serialise v) === Right v

gen32BytesOrFewer :: Gen ByteString
gen32BytesOrFewer = do
  len <- chooseInt (0, 32)
  B.pack <$> vectorOf len arbitrary

gen33Bytes :: Gen ByteString
gen33Bytes = B.pack <$> vectorOf 33 arbitrary

genBelowMinQuantity :: Gen Integer
genBelowMinQuantity = do
  Positive offset <- arbitrary
  pure (V.unQuantity minBound - offset)

genAboveMaxQuantity :: Gen Integer
genAboveMaxQuantity = do
  Positive offset <- arbitrary
  pure (V.unQuantity maxBound + offset)

prop_flatDecodeSuccess :: Property
prop_flatDecodeSuccess = forAll (arbitraryBuiltin `suchThat` (/= 0)) $ \quantity ->
  forAll gen32BytesOrFewer $ \c ->
    forAll gen32BytesOrFewer $ \t ->
      let flat = Flat.flat $ Map.singleton c (Map.singleton t quantity)
          BuiltinSuccess v = V.insertCoin c t quantity V.empty
       in Flat.unflat flat === Right v

prop_flatDecodeInvalidCurrency :: Property
prop_flatDecodeInvalidCurrency =
  forAll gen33Bytes $ \c ->
    forAll gen32BytesOrFewer $ \t ->
      let flat = Flat.flat $ Map.singleton c (Map.singleton t (100 :: Integer))
       in property . isLeft $ Flat.unflat @Value flat

prop_flatDecodeInvalidToken :: Property
prop_flatDecodeInvalidToken =
  forAll gen32BytesOrFewer $ \c ->
    forAll gen33Bytes $ \t ->
      let flat = Flat.flat $ Map.singleton c (Map.singleton t (100 :: Integer))
       in property . isLeft $ Flat.unflat @Value flat

{-| The size `keepPolicies` and `dropPolicies` are charged on: the depth of the outer map,
floored at 1. -}
valueOuterDepth :: Value -> Integer
valueOuterDepth = fromSatInt . sumCostStream . flattenCostRose . memoryUsage . ValueOuterDepth

{-| The measure is the bit length of the outer map size, computed here by doubling rather
than by the logarithm the measure itself uses. -}
prop_valueOuterDepthIsBitLength :: Value -> Property
prop_valueOuterDepthIsBitLength v =
  valueOuterDepth v === max 1 (bitLength (Map.size (V.unpack v)))
  where
    bitLength n = toInteger . length $ takeWhile (<= n) (iterate (* 2) 1)

-- | A `Value` holding one policy, whose inner map has @n@ tokens.
oneWideValue :: Int -> Value
oneWideValue n = V.pack (Map.singleton currency inner)
  where
    currency = fromJust (V.k "aaa")
    inner = Map.fromList [(token i, one) | i <- [1 .. n]]
    token i = fromJust . V.k . B.pack $ [fromIntegral (i `div` 256), fromIntegral (i `mod` 256)]
    one = fromJust (V.quantity 1)

-- | A `Value` holding @m@ policies of one token each.
manyPoliciesValue :: Int -> Value
manyPoliciesValue m = V.pack (Map.fromList [(policyId i, Map.singleton token one) | i <- [1 .. m]])
  where
    policyId i = fromJust . V.k . B.pack $ [fromIntegral (i `div` 256), fromIntegral (i `mod` 256)]
    token = fromJust (V.k "t")
    one = fromJust (V.quantity 1)

-- | Whether a policy filter refused its `Value`.
refused :: BuiltinResult Value -> Bool
refused r = case r of
  BuiltinFailure {} -> True
  _ -> False

checkBookkeeping :: Value -> Property
checkBookkeeping v =
  (expectedMaxInnerSize === actualMaxInnerSize)
    .&&. (expectedSize === actualSize)
    .&&. (expectedNeg === actualNeg)
    .&&. (expectedNegsByPolicy === actualNegsByPolicy)
    .&&. counterexample
      "negativesByPolicy stores a zero"
      (notElem 0 (Map.elems actualNegsByPolicy))
  where
    expectedMaxInnerSize = fromMaybe 0 . maximumMay $ Map.map Map.size (V.unpack v)
    actualMaxInnerSize = V.maxInnerSize v
    expectedSize = sum $ Map.map Map.size (V.unpack v)
    actualSize = V.totalSize v
    expectedNeg =
      length [q | inner <- Map.elems (V.unpack v), q <- Map.elems inner, V.unQuantity q < 0]
    actualNeg = V.negativeAmounts v
    -- An entry that reaches zero has to be gone, not stored.
    expectedNegsByPolicy =
      Map.filter (/= 0) $
        Map.map (length . filter ((< 0) . V.unQuantity) . Map.elems) (V.unpack v)
    actualNegsByPolicy = V.negativesByPolicy v

checkInvariants :: Value -> Property
checkInvariants (V.unpack -> v) =
  property ((not . any Map.null) v)
    .&&. property ((not . any (elem V.zeroQuantity)) v)

prop_unValueDataValidatesCurrency :: V.Quantity -> Property
prop_unValueDataValidatesCurrency quantity =
  forAll gen33Bytes $ \c ->
    forAll gen32BytesOrFewer $ \t ->
      let d = Map [(B c, Map [(B t, I (V.unQuantity quantity))])]
       in case V.unValueData d of
            BuiltinFailure {} -> property True
            _ -> property False

prop_unValueDataValidatesToken :: V.Quantity -> Property
prop_unValueDataValidatesToken quantity =
  forAll gen32BytesOrFewer $ \c ->
    forAll gen33Bytes $ \t ->
      let d = Map [(B c, Map [(B t, I (V.unQuantity quantity))])]
       in case V.unValueData d of
            BuiltinFailure {} -> property True
            _ -> property False

prop_unValueDataValidatesQuantityMin :: Property
prop_unValueDataValidatesQuantityMin =
  forAll gen32BytesOrFewer $ \c ->
    forAll gen32BytesOrFewer $ \t ->
      forAll genBelowMinQuantity $ \quantity ->
        let d = Map [(B c, Map [(B t, I quantity)])]
         in case V.unValueData d of
              BuiltinFailure {} -> property True
              _ -> property False

prop_unValueDataValidatesQuantityMax :: Property
prop_unValueDataValidatesQuantityMax =
  forAll gen32BytesOrFewer $ \c ->
    forAll gen32BytesOrFewer $ \t ->
      forAll genAboveMaxQuantity $ \quantity ->
        let d = Map [(B c, Map [(B t, I quantity)])]
         in case V.unValueData d of
              BuiltinFailure {} -> property True
              _ -> property False

prop_unValueDataValidatesMixedQuantities :: Property
prop_unValueDataValidatesMixedQuantities =
  forAll genValueDataWithMixedQuantities $ \(dataVal, hasInvalid) ->
    case V.unValueData dataVal of
      BuiltinSuccess {} -> not hasInvalid
      BuiltinSuccessWithLogs {} -> not hasInvalid
      BuiltinFailure {} -> hasInvalid
  where
    -- Generate Value Data with mixed valid/invalid quantities (90% valid, 10% invalid)
    genValueDataWithMixedQuantities :: Gen (Data, Bool)
    genValueDataWithMixedQuantities = do
      numEntries <- chooseInt (1, 10)
      entries <- fmap (nubOrdOn fst . sortOn fst) . vectorOf numEntries $ do
        c <- gen32BytesOrFewer
        t <- gen32BytesOrFewer
        -- 90% valid, 10% invalid
        quantity <-
          frequency
            [ (9, arbitraryBuiltin :: Gen Integer) -- valid range
            , (1, oneof [genBelowMinQuantity, genAboveMaxQuantity]) -- invalid
            ]
        pure (B c, Map [(B t, I quantity)])
      let hasInvalid = any (\(_, Map inner) -> any isInvalidQuantity inner) entries
          isInvalidQuantity (_, I q) =
            q < V.unQuantity minBound
              || q > V.unQuantity maxBound
              || q == 0
          isInvalidQuantity _ = False
      pure (Map entries, hasInvalid)

prop_unionValueDetectsOverflow :: Property
prop_unionValueDetectsOverflow =
  forAll gen32BytesOrFewer $ \c ->
    forAll gen32BytesOrFewer $ \t ->
      let BuiltinSuccess v1 = V.insertCoin c t (V.unQuantity maxBound) V.empty
          BuiltinSuccess v2 = V.insertCoin c t 1 V.empty
       in case V.unionValue v1 v2 of
            BuiltinFailure {} -> property True
            _ -> property False

prop_flatDecodeInvalidQuantityMin :: Property
prop_flatDecodeInvalidQuantityMin =
  forAll gen32BytesOrFewer $ \c ->
    forAll gen32BytesOrFewer $ \t ->
      forAll genBelowMinQuantity $ \quantity ->
        let flat = Flat.flat $ Map.singleton c (Map.singleton t quantity)
         in property . isLeft $ Flat.unflat @Value flat

prop_flatDecodeInvalidQuantityMax :: Property
prop_flatDecodeInvalidQuantityMax =
  forAll gen32BytesOrFewer $ \c ->
    forAll gen32BytesOrFewer $ \t ->
      forAll genAboveMaxQuantity $ \quantity ->
        let flat = Flat.flat $ Map.singleton c (Map.singleton t quantity)
         in property . isLeft $ Flat.unflat @Value flat

prop_flatDecodeZeroQuantity :: Property
prop_flatDecodeZeroQuantity =
  forAll gen32BytesOrFewer $ \c ->
    forAll gen32BytesOrFewer $ \t ->
      let flat = Flat.flat $ Map.singleton c (Map.singleton t (0 :: Integer))
       in property . isLeft $ Flat.unflat @Value flat

prop_cborDecodeZeroQuantity :: Property
prop_cborDecodeZeroQuantity =
  forAll gen32BytesOrFewer $ \c ->
    forAll gen32BytesOrFewer $ \t ->
      let bs = CBOR.serialise $ Map.singleton c (Map.singleton t (0 :: Integer))
       in property . isLeft $ CBOR.deserialiseOrFail @Value bs

tests :: TestTree
tests =
  testGroup
    "Value"
    [ testProperty
        "packUnpackRoundtrip"
        prop_packUnpackRoundtrip
    , testProperty
        "valueOuterDepthIsBitLength"
        prop_valueOuterDepthIsBitLength
    , -- The floor at 1 is what stops a product-shaped cost model from charging nothing
      -- but its intercept for a policy list applied to an empty `Value`.
      testCase "valueOuterDepthOfEmptyIsOne" $
        valueOuterDepth V.empty @?= 1
    , -- The measure never descends an inner map, which is why the policy filters use it
      -- rather than `ValueMaxDepth`.
      testCase "valueOuterDepthIgnoresTokenCount" $
        valueOuterDepth (oneWideValue 1000) @?= valueOuterDepth (oneWideValue 1)
    , testProperty
        "packBookkeeping"
        prop_packBookkeeping
    , testProperty
        "packPreservesInvariants"
        prop_packPreservesInvariants
    , testProperty
        "insertCoinBookkeeping"
        prop_insertCoinBookkeeping
    , testProperty
        "insertCoinPreservesInvariants"
        prop_insertCoinPreservesInvariants
    , testProperty
        "unionCommutative"
        prop_unionCommutative
    , testProperty
        "unionBookkeeping"
        prop_unionBookkeeping
    , testProperty
        "unionAssociative"
        prop_unionAssociative
    , testProperty
        "insertCoinIdempotent"
        prop_insertCoinIdempotent
    , testProperty
        "insertCoinValidatesCurrency"
        prop_insertCoinValidatesCurrency
    , testProperty
        "insertCoinValidatesToken"
        prop_insertCoinValidatesToken
    , testProperty
        "insertCoinValidatesQuantityMin"
        prop_insertCoinValidatesQuantityMin
    , testProperty
        "insertCoinValidatesQuantityMax"
        prop_insertCoinValidatesQuantityMax
    , testProperty
        "lookupAfterInsertion"
        prop_lookupAfterInsertion
    , testProperty
        "lookupAfterDeletion"
        prop_lookupAfterDeletion
    , testProperty
        "deleteCoinIdempotent"
        prop_deleteCoinIdempotent
    , testProperty
        "deleteCoinBookkeeping"
        prop_deleteCoinBookkeeping
    , testProperty
        "deleteCoinPreservesInvariants"
        prop_deleteCoinPreservesInvariants
    , testCase "policiesEmpty" $
        V.policies V.empty @?= []
    , testProperty
        "policiesStrictlyAscending"
        (withNumTests 20 prop_policiesStrictlyAscending)
    , testProperty
        "policiesAfterInsertion"
        (withNumTests 20 prop_policiesAfterInsertion)
    , testProperty
        "policiesAfterDeletion"
        (withNumTests 20 prop_policiesAfterDeletion)
    , testProperty
        "keepPoliciesBookkeeping"
        (withNumTests 20 prop_keepPoliciesBookkeeping)
    , testProperty
        "keepPoliciesPreservesInvariants"
        (withNumTests 20 prop_keepPoliciesPreservesInvariants)
    , testProperty
        "keepPoliciesSelects"
        (withNumTests 20 prop_keepPoliciesSelects)
    , testProperty
        "keepPoliciesAgreesWithRepack"
        (withNumTests 20 prop_keepPoliciesAgreesWithRepack)
    , testProperty
        "dropPoliciesBookkeeping"
        (withNumTests 20 prop_dropPoliciesBookkeeping)
    , testProperty
        "dropPoliciesPreservesInvariants"
        (withNumTests 20 prop_dropPoliciesPreservesInvariants)
    , testProperty
        "dropPoliciesSelects"
        (withNumTests 20 prop_dropPoliciesSelects)
    , testProperty
        "dropPoliciesAgreesWithRepack"
        (withNumTests 20 prop_dropPoliciesAgreesWithRepack)
    , testProperty
        "keepDropPartition"
        (withNumTests 20 prop_keepDropPartition)
    , testCase "policyFiltersAcceptTheSizeBound" $ do
        let v = manyPoliciesValue V.policyFilterMaxSize
        refused (V.keepPolicies [] v) @?= False
        refused (V.dropPolicies [] v) @?= False
    , testCase "policyFiltersRefuseAboveTheSizeBound" $ do
        let v = manyPoliciesValue (V.policyFilterMaxSize + 1)
        refused (V.keepPolicies [] v) @?= True
        refused (V.dropPolicies [] v) @?= True
    , testProperty
        "containsReflexive"
        prop_containsReflexive
    , testProperty
        "containsAfterDeletion"
        prop_containsAfterDeletion
    , testProperty
        "containsEnforcesPositivity"
        prop_containsEnforcesPositivity
    , testProperty
        "unValueDataValidatesCurrency"
        prop_unValueDataValidatesCurrency
    , testProperty
        "unValueDataValidatesToken"
        prop_unValueDataValidatesToken
    , testProperty
        "unValueDataValidatesQuantityMin"
        prop_unValueDataValidatesQuantityMin
    , testProperty
        "unValueDataValidatesQuantityMax"
        prop_unValueDataValidatesQuantityMax
    , testProperty
        "unValueDataValidatesMixedQuantities"
        prop_unValueDataValidatesMixedQuantities
    , testProperty
        "unionValueDetectsOverflow"
        prop_unionValueDetectsOverflow
    , testProperty
        "scaleBookKeeping"
        prop_scaleBookKeeping
    , testProperty
        "scaleByOneIsId"
        prop_scaleByOneIsId
    , testProperty
        "scaleZeroIsZero"
        prop_scaleZeroIsZero
    , testProperty
        "negateInvolutive"
        prop_negateInvolutive
    , testProperty
        "negateIsInverse"
        prop_negateIsInverse
    , testProperty
        "oppositeScaleIsInverse"
        prop_oppositeScaleIsInverse
    , testProperty
        "dataRoundtrip"
        prop_dataRoundtrip
    , testProperty
        "flatRoundtrip"
        prop_flatRoundtrip
    , testProperty
        "cborRoundtrip"
        prop_cborRoundtrip
    , testProperty
        "flatDecodeSuccess"
        prop_flatDecodeSuccess
    , testProperty
        "flatDecodeInvalidCurrency"
        prop_flatDecodeInvalidCurrency
    , testProperty
        "flatDecodeInvalidToken"
        prop_flatDecodeInvalidToken
    , testProperty
        "flatDecodeInvalidQuantityMin"
        prop_flatDecodeInvalidQuantityMin
    , testProperty
        "flatDecodeInvalidQuantityMax"
        prop_flatDecodeInvalidQuantityMax
    , testProperty
        "flatDecodeZeroQuantity"
        prop_flatDecodeZeroQuantity
    , testProperty
        "cborDecodeZeroQuantity"
        prop_cborDecodeZeroQuantity
    , testCase "K encodes as ByteString" $
        let Just myK = V.k "abc"
         in Flat.flat myK @?= Flat.flat ("abc" :: ByteString)
    , testCase "Quantity encodes as Integer" $
        let Just myQ = V.quantity 42
         in Flat.flat myQ @?= Flat.flat (42 :: Integer)
    ]
