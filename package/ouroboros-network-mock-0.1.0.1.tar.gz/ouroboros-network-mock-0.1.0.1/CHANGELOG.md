# Revision history for ouroboros-network-mock

## 0.1.0.1 -- 2023-04-28

###  Non-breaking changes

* `ghc-9.4` and `ghc-9.6` compatibility.

## 0.1.0.0 -- 2022-11-17

* Initial release
