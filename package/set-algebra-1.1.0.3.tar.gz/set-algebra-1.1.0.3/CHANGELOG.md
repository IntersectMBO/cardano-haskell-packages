# Version history for `set-algebra`

## 1.1.0.3

*

## 1.1.0.2

*

## 1.1.0.1

- Set upper bound ansi-wl-pprint < 1.0

## 1.1.0.0

- Remove unused instances for `Data.UMap` #3371

## 1.0.0.0

* First properly versioned release.
