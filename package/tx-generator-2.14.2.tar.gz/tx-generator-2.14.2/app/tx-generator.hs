import Cardano.Benchmarking.Command (runCommand)

main :: IO ()
main = runCommand
