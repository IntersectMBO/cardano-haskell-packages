module Ouroboros.Consensus.Storage.LedgerDB.InMemory {-# DEPRECATED "Use Ouroboros.Consensus.Storage.LedgerDB instead" #-}
  ( module Ouroboros.Consensus.Storage.LedgerDB
  ) where

import Ouroboros.Consensus.Storage.LedgerDB
