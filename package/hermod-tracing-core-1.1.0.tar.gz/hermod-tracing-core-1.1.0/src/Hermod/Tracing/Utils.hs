{-# LANGUAGE NumericUnderscores #-}

module Hermod.Tracing.Utils
       ( module Hermod.Tracing.Utils
       -- * Re-exported from hermod-tracing-api
       , showT
       , showTHex
       , showTReal
       )
       where

import           Hermod.Tracing.Types.ShowT (showT, showTHex, showTReal)


import           Control.Concurrent (threadDelay)
import           Control.Concurrent.Async (concurrently_)
import           Control.DeepSeq (NFData, force)
import           Control.Exception (SomeAsyncException (..), SomeException, evaluate, fromException,
                   tryJust)
import           Data.IORef
import           Data.Word (Word64)
import           GHC.Conc (labelThread, myThreadId)


-- | Run an IO action which may throw an exception in a loop.
--   On exception, the action will be re-run after a pause (the delay parameters represent seconds).
--   That pause doubles which each exception, but is reset when the action runs long enough.
runInLoop :: IO () -> (SomeException -> IO ()) -> Word64 -> Word64 -> IO ()
runInLoop action handleInterruption initialDelay maxDelay
  | initialDelay == 0         = runInLoop action handleInterruption 1 maxDelay
  | maxDelay < initialDelay   = runInLoop action handleInterruption initialDelay initialDelay
  | otherwise                 = newIORef (fromIntegral initialDelay) >>= go
  where
    go :: IORef Int -> IO ()
    go currentDelay =
      tryJust excludeAsyncExceptions (actionResettingDelay currentDelay) >>= \case
        Left e -> do
          handleInterruption e
          waitForSecs <- atomicModifyIORef' currentDelay bumpDelay
          threadDelay $ 1_000_000 * waitForSecs
          go currentDelay
        Right _ -> return ()

    -- if the action runs at least maxDelay seconds, the pause is reset
    actionResettingDelay currentDelay = concurrently_ action $ do
      threadDelay $ fromIntegral $ 1_000_000 * maxDelay
      atomicWriteIORef currentDelay $ fromIntegral initialDelay

    bumpDelay current =
      ( min (current * 2) (fromIntegral maxDelay)
      , current
      )

-- | Helper functions to force trace + metric values in a controlled section of code
{-# INLINE excludeAsyncExceptions #-}
excludeAsyncExceptions :: SomeException -> Maybe SomeException
excludeAsyncExceptions e =
  case fromException e of
    Just SomeAsyncException{} -> Nothing
    _ -> Just e

{-# INLINE tryEvalNF #-}
tryEvalNF :: NFData a => a -> IO (Either SomeException a)
tryEvalNF = tryJust excludeAsyncExceptions . evaluate . force

threadLabelMe :: String -> IO ()
threadLabelMe label = myThreadId >>= flip labelThread label
