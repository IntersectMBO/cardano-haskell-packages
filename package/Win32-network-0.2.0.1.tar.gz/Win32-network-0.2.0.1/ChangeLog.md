# Revision history for Win32-named-pipes

## 0.2.0.1

* Add labels to wrapper threads.

## 0.2.0.0

* Removed `System.Win32.NamedPipes` since it got merged on `Win32` repo at
version 2.14

## 0.1.1.1

* Relaxed bounds of bytestring package.

## 0.1.1.0

* Support `ghc-9.2` and `ghc-9.4`.

## 0.1.0.0  -- YYYY-mm-dd

* First version. Released on an unsuspecting world.
