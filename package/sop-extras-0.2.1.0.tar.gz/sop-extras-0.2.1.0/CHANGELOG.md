# sop-extras Changelog

# Changelog entries

<a id='changelog-0.2.1.0'></a>
## 0.2.0.0 — 2024-08-26

### Non-Breaking

- Bump to `nothunks` 0.2

<a id='changelog-0.2.0.0'></a>
## 0.2.0.0 — 2024-05-13

### Non-Breaking

- Added `K1` and `Flip` basic functors (poly-kinded).
- Provide `hczipWith` for `InPairs`.
- Added `HTrans` instances to `OptNP`, `Match`, `Telescope`.

### Breaking

- `Index` became poly-kinded.

<a id='changelog-0.1.0.0'></a>
## 0.1.0.0 — 2023-08-25

* First version. Released on an unsuspecting world.
