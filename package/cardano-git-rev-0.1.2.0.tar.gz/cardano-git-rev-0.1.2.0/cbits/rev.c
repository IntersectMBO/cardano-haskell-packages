// <magic: fe> <marker: gitrev> <size: padded to 20 bytes> <space for gitrev (40 char)>
char _cardano_git_rev[68]
  = "fe"
    "gitrev"
    "0000000000"
    "0000000040"
    "0000000000"
    "0000000000"
    "0000000000"
    "0000000000"
    ;