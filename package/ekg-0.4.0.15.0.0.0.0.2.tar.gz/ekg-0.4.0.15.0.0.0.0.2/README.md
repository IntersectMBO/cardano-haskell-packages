# EKG

This library lets you remotely monitor a running process over HTTP. It provides
a simple way to integrate a monitoring server into any application.
