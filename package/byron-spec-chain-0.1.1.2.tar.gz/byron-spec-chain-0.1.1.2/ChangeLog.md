# Revision history for byron-spec-chain

## 0.1.0.0 -- 2018-11-06

* First version. Released on an unsuspecting world.
