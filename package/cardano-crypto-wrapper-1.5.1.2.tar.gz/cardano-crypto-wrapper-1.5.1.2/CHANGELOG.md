# Revision history for `cardano-crypto-wrapper`

## 1.5.1.2

*

## 1.5.1.1

*

## 1.5.1.0

* Bring back `toCBORXPrv` and `fromCBORXPrv`

## 1.5.0.0

* First official release.
