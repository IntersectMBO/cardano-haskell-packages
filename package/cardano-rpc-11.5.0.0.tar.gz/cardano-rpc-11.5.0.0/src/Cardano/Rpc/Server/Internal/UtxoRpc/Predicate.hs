{-# LANGUAGE FlexibleContexts #-}
{-# LANGUAGE GADTs #-}
{-# LANGUAGE ScopedTypeVariables #-}

module Cardano.Rpc.Server.Internal.UtxoRpc.Predicate
  ( -- * UTxO predicates
    matchesUtxoPredicate
  , matchesAnyUtxoPattern
  , matchesTxOutputPattern
  , matchesAddressPattern
  , matchesAssetPattern
  , exactAddressPredicate
  , extractAddressesFromPredicate
  , predicateLeaves
  , CompiledUtxoPredicate
  , compileUtxoPredicate
  , compiledPredicateAddresses
  , matchesCompiledPredicate

    -- * Transaction predicates
  , matchesTxPredicate
  , matchesAnyChainTxPattern
  , matchesTxPattern
  , matchesAddressPatternBytes
  , matchesAssetPatternProto

    -- * Certificate matching
  , matchesCertificatePattern
  , CertificateCredentials (..)
  , certificateCredentials
  , certificateStakeCredentials
  , certificatePoolKeyHashes
  , certificateDRepBytes

    -- * Credential serialisation
  , credentialBytes
  , serialisePaymentCredential
  , serialiseStakeCredential
  )
where

import Cardano.Api.Address
import Cardano.Api.Era
import Cardano.Api.Serialise.Raw
import Cardano.Api.Tx
import Cardano.Api.Value
import Cardano.Rpc.Proto.Api.UtxoRpc.Query qualified as UtxoRpc
import Cardano.Rpc.Proto.Api.UtxoRpc.Submit qualified as Submit
import Cardano.Rpc.Server.Internal.UtxoRpc.Type.BigInt (utxoRpcBigIntToInteger)

import RIO hiding (toList)

import Data.ByteString qualified as BS
import Data.Map.Strict qualified as Map
import Data.ProtoLens (defMessage)
import GHC.IsList
import Network.GRPC.Spec (Proto (..))

-- | Check if a UTxO entry matches a 'UtxoPredicate'.
-- All present fields are combined with AND logic.
matchesUtxoPredicate
  :: IsCardanoEra era
  => Proto UtxoRpc.UtxoPredicate
  -> TxOut CtxUTxO era
  -> Bool
matchesUtxoPredicate p txOut =
  all (`matchesAnyUtxoPattern` txOut) (p ^. UtxoRpc.maybe'match)
    && not (any (`matchesUtxoPredicate` txOut) (p ^. UtxoRpc.not))
    && all (`matchesUtxoPredicate` txOut) (p ^. UtxoRpc.allOf)
    && (null (p ^. UtxoRpc.anyOf) || any (`matchesUtxoPredicate` txOut) (p ^. UtxoRpc.anyOf))

-- | Check if a UTxO entry matches an 'AnyUtxoPattern'.
-- Delegates to the Cardano-specific 'TxOutputPattern' if present.
matchesAnyUtxoPattern
  :: IsCardanoEra era
  => Proto UtxoRpc.AnyUtxoPattern
  -> TxOut CtxUTxO era
  -> Bool
matchesAnyUtxoPattern pat txOut =
  all (`matchesTxOutputPattern` txOut) (pat ^. UtxoRpc.maybe'cardano)

-- | Check if a tx output matches a 'TxOutputPattern'.
-- Address and asset filters are combined with AND; absent fields are vacuously true.
matchesTxOutputPattern
  :: IsCardanoEra era
  => Proto UtxoRpc.TxOutputPattern
  -> TxOut CtxUTxO era
  -> Bool
matchesTxOutputPattern pat (TxOut addrInEra txOutValue _datum _script) =
  all (`matchesAddressPattern` addrInEra) (pat ^. UtxoRpc.maybe'address)
    && all (`matchesAssetPattern` txOutValueToValue txOutValue) (pat ^. UtxoRpc.maybe'asset)

-- | proto3 optional bytes default to empty when absent; treat that as "don't care".
matchesRawField :: ByteString -> ByteString -> Bool
matchesRawField field actual = BS.null field || field == actual

-- | proto3 optional bytes default to empty when absent: an absent filter
-- accepts anything, a set filter needs the component present and equal.
matchesFilter :: ByteString -> Maybe ByteString -> Bool
matchesFilter field mComponent =
  maybe True (\wanted -> mComponent == Just wanted) (nonEmptyField field)

-- | 'Nothing' for a proto3 optional bytes field left unset, which decodes as empty bytes.
nonEmptyField :: ByteString -> Maybe ByteString
nonEmptyField field = if BS.null field then Nothing else Just field

-- | Check if an address matches an 'AddressPattern'.
-- All present fields (exact, payment, delegation) must match (AND logic).
-- Byron addresses only support exact matching; payment\/delegation filters reject them.
matchesAddressPattern
  :: IsCardanoEra era
  => Proto UtxoRpc.AddressPattern
  -> AddressInEra era
  -> Bool
matchesAddressPattern pat address =
  matchesFilter (pat ^. UtxoRpc.exactAddress) (Just $ serialiseToRawBytes address)
    && matchesFilter (pat ^. UtxoRpc.paymentPart) mPaymentCredentialBytes
    && matchesFilter (pat ^. UtxoRpc.delegationPart) mStakeCredentialBytes
 where
  mShelleyAddress :: Maybe (Address ShelleyAddr)
  mShelleyAddress = case address of
    AddressInEra ShelleyAddressInEra{} shelleyAddress -> Just shelleyAddress
    AddressInEra ByronAddressInAnyEra _ -> Nothing
  mPaymentCredentialBytes =
    mShelleyAddress <&> \(ShelleyAddress _ paymentCredential _) ->
      serialisePaymentCredential $ fromShelleyPaymentCredential paymentCredential
  mStakeCredentialBytes = do
    ShelleyAddress _ _ stakeReference <- mShelleyAddress
    StakeAddressByValue credential <- pure $ fromShelleyStakeReference stakeReference
    pure $ serialiseStakeCredential credential

-- | A 'UtxoPredicate' matching UTxOs at the exact address.
exactAddressPredicate
  :: IsCardanoEra era
  => AddressInEra era
  -> Proto UtxoRpc.UtxoPredicate
exactAddressPredicate address =
  defMessage
    & UtxoRpc.match
      .~ ( defMessage
             & UtxoRpc.cardano
               .~ (defMessage & UtxoRpc.address .~ (defMessage & UtxoRpc.exactAddress .~ serialiseToRawBytes address))
         )

-- | Serialise a 'PaymentCredential' to raw bytes (the key or script hash).
serialisePaymentCredential :: PaymentCredential -> ByteString
serialisePaymentCredential (PaymentCredentialByKey h) = serialiseToRawBytes h
serialisePaymentCredential (PaymentCredentialByScript h) = serialiseToRawBytes h

-- | Serialise a 'StakeCredential' to raw bytes (the key or script hash).
serialiseStakeCredential :: StakeCredential -> ByteString
serialiseStakeCredential (StakeCredentialByKey h) = serialiseToRawBytes h
serialiseStakeCredential (StakeCredentialByScript h) = serialiseToRawBytes h

-- | Check if a 'Value' contains a native asset matching an 'AssetPattern'.
-- Ada entries are always skipped; zero-quantity entries do not match.
matchesAssetPattern
  :: Proto UtxoRpc.AssetPattern
  -> Value
  -> Bool
matchesAssetPattern pat value =
  any matchesEntry (toList value)
 where
  patternPolicy = pat ^. UtxoRpc.policyId
  patternTokenName = pat ^. UtxoRpc.assetName
  matchesEntry (AssetId policy tokenName, Quantity qty) =
    (BS.null patternPolicy || serialiseToRawBytes policy == patternPolicy)
      && (BS.null patternTokenName || serialiseToRawBytes tokenName == patternTokenName)
      && qty > 0
  matchesEntry (AdaAssetId, _) = False

-- | Compile a predicate once into a per-address lookup table: matching a UTxO
-- then costs one map lookup, not a walk over every address term. Same acceptance rule as 'extractAddressesFromPredicate'.
compileUtxoPredicate :: Proto UtxoRpc.UtxoPredicate -> Maybe CompiledUtxoPredicate
compileUtxoPredicate p =
  case (p ^. UtxoRpc.maybe'match, p ^. UtxoRpc.not, p ^. UtxoRpc.allOf, p ^. UtxoRpc.anyOf) of
    (Just pat, [], [], []) ->
      CompiledUtxoPredicate . uncurry Map.singleton <$> compileLeaf pat
    (Nothing, [], [], anyPreds@(_ : _)) ->
      CompiledUtxoPredicate . Map.unionsWith (<>) . map unCompiled
        <$> traverse compileUtxoPredicate anyPreds
    _ -> Nothing
 where
  unCompiled (CompiledUtxoPredicate matchersByAddress) = matchersByAddress

-- | The exact addresses a compiled predicate names, for 'QueryUTxOByAddress'.
compiledPredicateAddresses :: CompiledUtxoPredicate -> Set AddressAny
compiledPredicateAddresses (CompiledUtxoPredicate matchersByAddress) = Map.keysSet matchersByAddress

-- | Match a UTxO entry against a predicate already compiled by 'compileUtxoPredicate'.
matchesCompiledPredicate
  :: IsCardanoEra era
  => CompiledUtxoPredicate
  -> TxOut CtxUTxO era
  -> Bool
matchesCompiledPredicate (CompiledUtxoPredicate matchersByAddress) txOut@(TxOut (AddressInEra _ address) _ _ _) =
  maybe False matchesAddressMatcher $ Map.lookup (toAddressAny address) matchersByAddress
 where
  matchesAddressMatcher AcceptAll = True
  matchesAddressMatcher (AnyOfPatterns patterns) = any (`matchesAnyUtxoPattern` txOut) patterns

-- | Try to extract a set of exact addresses from the predicate for use with 'QueryUTxOByAddress'.
-- Returns 'Just' if the optimization is applicable, 'Nothing' otherwise.
extractAddressesFromPredicate :: Proto UtxoRpc.UtxoPredicate -> Maybe (Set AddressAny)
extractAddressesFromPredicate = fmap compiledPredicateAddresses . compileUtxoPredicate

-- | How a compiled predicate finishes matching a UTxO once its address is
-- found: unconditionally, or via the leaves that also carry a payment\/delegation\/asset filter.
data AddressMatcher
  = AcceptAll
  | AnyOfPatterns [Proto UtxoRpc.AnyUtxoPattern]

instance Semigroup AddressMatcher where
  AcceptAll <> _ = AcceptAll
  _ <> AcceptAll = AcceptAll
  AnyOfPatterns patterns1 <> AnyOfPatterns patterns2 = AnyOfPatterns (patterns1 <> patterns2)

-- | A 'UtxoPredicate' compiled into a per-address lookup table; see 'compileUtxoPredicate'.
newtype CompiledUtxoPredicate = CompiledUtxoPredicate (Map AddressAny AddressMatcher)

-- | Compile one leaf: same acceptance rule as the old per-leaf extraction
-- (non-empty, deserialisable exact address). A leaf with no other filter set becomes 'AcceptAll'.
compileLeaf :: Proto UtxoRpc.AnyUtxoPattern -> Maybe (AddressAny, AddressMatcher)
compileLeaf leaf = do
  txoPat <- leaf ^. UtxoRpc.maybe'cardano
  addrPat <- txoPat ^. UtxoRpc.maybe'address
  let exact = addrPat ^. UtxoRpc.exactAddress
  guard $ not (BS.null exact)
  addrAny <- either (const Nothing) Just $ deserialiseFromRawBytes AsAddressAny exact
  let isPureExact =
        BS.null (addrPat ^. UtxoRpc.paymentPart)
          && BS.null (addrPat ^. UtxoRpc.delegationPart)
          && isNothing (txoPat ^. UtxoRpc.maybe'asset)
  pure (addrAny, if isPureExact then AcceptAll else AnyOfPatterns [leaf])

-- | Every 'match' leaf in the predicate tree, duplicates included, descending
-- through 'not', 'allOf' and 'anyOf'. Lazy, so a caller can stop after N leaves.
predicateLeaves :: Proto UtxoRpc.UtxoPredicate -> [Proto UtxoRpc.AnyUtxoPattern]
predicateLeaves p =
  maybeToList (p ^. UtxoRpc.maybe'match)
    <> concatMap predicateLeaves (p ^. UtxoRpc.not <> p ^. UtxoRpc.allOf <> p ^. UtxoRpc.anyOf)

-- ---------------------------------------------------------------------------
-- TxPredicate: matching a mempool\/submitted tx (proto-native, no ledger types)
-- ---------------------------------------------------------------------------

-- | Check if a tx matches a 'TxPredicate'.
-- All present fields are combined with AND logic.
matchesTxPredicate
  :: Proto Submit.TxPredicate
  -> Proto UtxoRpc.Tx
  -> Bool
matchesTxPredicate p tx =
  all (`matchesAnyChainTxPattern` tx) (p ^. Submit.maybe'match)
    && not (any (`matchesTxPredicate` tx) (p ^. Submit.not))
    && all (`matchesTxPredicate` tx) (p ^. Submit.allOf)
    && (null (p ^. Submit.anyOf) || any (`matchesTxPredicate` tx) (p ^. Submit.anyOf))

-- | Check if a tx matches an 'AnyChainTxPattern'.
-- Delegates to the Cardano-specific 'TxPattern' if present.
matchesAnyChainTxPattern
  :: Proto Submit.AnyChainTxPattern
  -> Proto UtxoRpc.Tx
  -> Bool
matchesAnyChainTxPattern pat tx =
  all (`matchesTxPattern` tx) (pat ^. Submit.maybe'cardano)

-- | Check if a tx matches a 'TxPattern'. All present fields are combined with
-- AND logic; absent fields are vacuously true.
--
-- 'consumes' and the input side of 'has_address'\/'moves_asset' rely on
-- 'TxInput.as_output', which the mempool tx conversion never populates
-- (resolving it needs a UTxO lookup outside the pure conversion) - these
-- fields never fire on real mempool traffic today, only in tests that build
-- fixtures with 'as_output' set.
matchesTxPattern
  :: Proto UtxoRpc.TxPattern
  -> Proto UtxoRpc.Tx
  -> Bool
matchesTxPattern pat tx =
  all (matchesConsumesPattern tx) (pat ^. UtxoRpc.maybe'consumes)
    && all (matchesProducesPattern tx) (pat ^. UtxoRpc.maybe'produces)
    && all (matchesHasAddressPattern tx) (pat ^. UtxoRpc.maybe'hasAddress)
    && all (matchesMovesAssetPattern tx) (pat ^. UtxoRpc.maybe'movesAsset)
    && all (matchesMintsAssetPattern tx) (pat ^. UtxoRpc.maybe'mintsAsset)
    && all (matchesHasCertificatePattern tx) (pat ^. UtxoRpc.maybe'hasCertificate)

-- | Resolved outputs of the tx's inputs (see the 'as_output' caveat on 'matchesTxPattern').
resolvedInputOutputs :: Proto UtxoRpc.Tx -> [Proto UtxoRpc.TxOutput]
resolvedInputOutputs tx = mapMaybe (^. UtxoRpc.maybe'asOutput) (tx ^. UtxoRpc.inputs)

-- | 'consumes': match any input (by its resolved output) that exhibits the pattern.
matchesConsumesPattern :: Proto UtxoRpc.Tx -> Proto UtxoRpc.TxOutputPattern -> Bool
matchesConsumesPattern tx pat = any (matchesTxOutputPatternProto pat) (resolvedInputOutputs tx)

-- | 'produces': match any output that exhibits the pattern.
matchesProducesPattern :: Proto UtxoRpc.Tx -> Proto UtxoRpc.TxOutputPattern -> Bool
matchesProducesPattern tx pat = any (matchesTxOutputPatternProto pat) (tx ^. UtxoRpc.outputs)

-- | Check if a tx output (an input's resolved output, or an output proper) matches a 'TxOutputPattern'.
matchesTxOutputPatternProto :: Proto UtxoRpc.TxOutputPattern -> Proto UtxoRpc.TxOutput -> Bool
matchesTxOutputPatternProto pat output =
  all
    (\addressPat -> matchesAddressPatternBytes addressPat (output ^. UtxoRpc.address))
    (pat ^. UtxoRpc.maybe'address)
    && all
      (\assetPat -> matchesAssetPatternProto (> 0) assetPat (output ^. UtxoRpc.assets))
      (pat ^. UtxoRpc.maybe'asset)

-- | 'has_address': match any address appearing in the tx's outputs, resolved
-- inputs, resolved collateral inputs or collateral return.
matchesHasAddressPattern :: Proto UtxoRpc.Tx -> Proto UtxoRpc.AddressPattern -> Bool
matchesHasAddressPattern tx pat = any (matchesAddressPatternBytes pat) (txAddresses tx)

-- | Every address appearing anywhere in the tx; see 'matchesHasAddressPattern'.
txAddresses :: Proto UtxoRpc.Tx -> [ByteString]
txAddresses tx =
  map (^. UtxoRpc.address) $
    resolvedInputOutputs tx
      <> tx ^. UtxoRpc.outputs
      <> mapMaybe (^. UtxoRpc.maybe'asOutput) (tx ^. UtxoRpc.collateral . UtxoRpc.collateral)
      <> maybeToList (tx ^. UtxoRpc.collateral . UtxoRpc.maybe'collateralReturn)

-- | Check if raw address bytes match an 'AddressPattern'.
-- Mirrors 'matchesAddressPattern', but for proto-native tx data where addresses
-- are opaque bytes rather than parsed 'AddressInEra' values: the bytes are
-- parsed via 'deserialiseFromRawBytes' first. Unparseable bytes and Byron
-- addresses only support exact matching, same as 'matchesAddressPattern'.
matchesAddressPatternBytes :: Proto UtxoRpc.AddressPattern -> ByteString -> Bool
matchesAddressPatternBytes pat addressBytes =
  matchesFilter (pat ^. UtxoRpc.exactAddress) (Just addressBytes)
    && matchesFilter (pat ^. UtxoRpc.paymentPart) mPaymentCredentialBytes
    && matchesFilter (pat ^. UtxoRpc.delegationPart) mStakeCredentialBytes
 where
  mShelleyAddress = do
    AddressShelley shelley <-
      either (const Nothing) Just $ deserialiseFromRawBytes AsAddressAny addressBytes
    pure shelley
  mPaymentCredentialBytes =
    mShelleyAddress <&> \(ShelleyAddress _ paymentCredential _) ->
      serialisePaymentCredential $ fromShelleyPaymentCredential paymentCredential
  mStakeCredentialBytes = do
    ShelleyAddress _ _ stakeReference <- mShelleyAddress
    StakeAddressByValue credential <- pure $ fromShelleyStakeReference stakeReference
    pure $ serialiseStakeCredential credential

-- | 'moves_asset': match any asset moved by the tx, i.e. present (with a
-- positive quantity) in a resolved input or an output.
matchesMovesAssetPattern :: Proto UtxoRpc.Tx -> Proto UtxoRpc.AssetPattern -> Bool
matchesMovesAssetPattern tx = do
  let movedAssets = concatMap (^. UtxoRpc.assets) (resolvedInputOutputs tx <> tx ^. UtxoRpc.outputs)
  \pat -> matchesAssetPatternProto (> 0) pat movedAssets

-- | 'mints_asset': match any asset minted or burned by the tx. Burns carry a
-- negative quantity, so (unlike 'moves_asset') zero is the only excluded value.
matchesMintsAssetPattern :: Proto UtxoRpc.Tx -> Proto UtxoRpc.AssetPattern -> Bool
matchesMintsAssetPattern tx pat = matchesAssetPatternProto (/= 0) pat (tx ^. UtxoRpc.mint)

-- | Check if a policy\/asset-name pattern matches any asset entry across a
-- list of 'Multiasset' bundles. @quantityMatches@ selects which quantities
-- count, since 'moves_asset' and 'mints_asset' apply different sign checks.
-- A 'BigInt' that fails to decode is treated as no match.
matchesAssetPatternProto
  :: (Integer -> Bool)
  -> Proto UtxoRpc.AssetPattern
  -> [Proto UtxoRpc.Multiasset]
  -> Bool
matchesAssetPatternProto quantityMatches pat multiassets =
  any
    matchesEntry
    [ (multiasset ^. UtxoRpc.policyId, asset)
    | multiasset <- multiassets
    , asset <- multiasset ^. UtxoRpc.assets
    ]
 where
  patternPolicy = pat ^. UtxoRpc.policyId
  patternTokenName = pat ^. UtxoRpc.assetName
  matchesEntry (policy, asset) =
    matchesRawField patternPolicy policy
      && matchesRawField patternTokenName (asset ^. UtxoRpc.name)
      && maybe False quantityMatches (utxoRpcBigIntToInteger (asset ^. UtxoRpc.quantity))

-- | 'has_certificate': match any certificate in the tx that exhibits the pattern.
matchesHasCertificatePattern :: Proto UtxoRpc.Tx -> Proto UtxoRpc.CertificatePattern -> Bool
matchesHasCertificatePattern tx pat = any (matchesCertificatePattern pat) (tx ^. UtxoRpc.certificates)

-- | Check if a certificate matches a 'CertificatePattern'.
-- The five discriminated branches (stake registration\/deregistration\/delegation,
-- pool registration\/retirement) only match the identically-shaped certificate -
-- the newer Conway certificate families (reg\/unreg\/vote-deleg, DRep, committee)
-- are only reachable through the three "any_*" wildcards below, which scan
-- every certificate variant that carries the relevant credential.
matchesCertificatePattern
  :: Proto UtxoRpc.CertificatePattern
  -> Proto UtxoRpc.Certificate
  -> Bool
matchesCertificatePattern pat cert =
  all (`matchesExactCredential` mStakeRegistration) (pat ^. UtxoRpc.maybe'stakeRegistration)
    && all (`matchesExactCredential` mStakeDeregistration) (pat ^. UtxoRpc.maybe'stakeDeregistration)
    && all matchesStakeDelegationPattern (pat ^. UtxoRpc.maybe'stakeDelegation)
    && all matchesPoolRegistrationPattern (pat ^. UtxoRpc.maybe'poolRegistration)
    && all matchesPoolRetirementPattern (pat ^. UtxoRpc.maybe'poolRetirement)
    -- these three fields are oneof branches: empty means "this branch isn't set"
    && all
      (matchesAnyStakeCredential (certStakeCredentials credentials))
      (nonEmptyField $ pat ^. UtxoRpc.anyStakeCredential)
    && all
      (matchesAnyPoolKeyHash (certPoolKeyHashes credentials))
      (nonEmptyField $ pat ^. UtxoRpc.anyPoolKeyhash)
    && all (matchesAnyDRep (certDRepBytes credentials)) (nonEmptyField $ pat ^. UtxoRpc.anyDrep)
 where
  -- classified once, then read for all three any_* checks below
  credentials = certificateCredentials cert

  mStakeRegistration = cert ^. UtxoRpc.maybe'stakeRegistration
  mStakeDeregistration = cert ^. UtxoRpc.maybe'stakeDeregistration
  mStakeDelegation = cert ^. UtxoRpc.maybe'stakeDelegation
  mPoolRegistration = cert ^. UtxoRpc.maybe'poolRegistration
  mPoolRetirement = cert ^. UtxoRpc.maybe'poolRetirement

  mDelegationStakeCredential = mStakeDelegation <&> (^. UtxoRpc.stakeCredential)
  mDelegationPoolKeyHash = mStakeDelegation <&> (^. UtxoRpc.poolKeyhash)
  mOperatorKeyHash = mPoolRegistration <&> (^. UtxoRpc.operator)
  mRetirementPoolKeyHash = mPoolRetirement <&> (^. UtxoRpc.poolKeyhash)
  mRetirementEpoch = mPoolRetirement <&> (^. UtxoRpc.epoch)

  matchesExactCredential expected mActual =
    (credentialBytes <$> mActual) == Just (credentialBytes expected)

  -- a set pattern branch also requires the certificate to be that variant, so
  -- the presence checks below still reject when every pattern field is empty
  matchesStakeDelegationPattern delegPat =
    isJust mStakeDelegation
      && all
        (`matchesExactCredential` mDelegationStakeCredential)
        (delegPat ^. UtxoRpc.maybe'stakeCredential)
      && matchesFilter (delegPat ^. UtxoRpc.poolKeyhash) mDelegationPoolKeyHash

  -- a 'PoolRegistrationCert' only carries one key hash ('operator'); the
  -- pattern's 'pool_keyhash' field is documented as derived from it
  matchesPoolRegistrationPattern regPat =
    isJust mPoolRegistration
      && matchesFilter (regPat ^. UtxoRpc.operator) mOperatorKeyHash
      && matchesFilter (regPat ^. UtxoRpc.poolKeyhash) mOperatorKeyHash

  matchesPoolRetirementPattern retirePat =
    isJust mPoolRetirement
      && matchesFilter (retirePat ^. UtxoRpc.poolKeyhash) mRetirementPoolKeyHash
      && (retirePat ^. UtxoRpc.epoch == 0 || mRetirementEpoch == Just (retirePat ^. UtxoRpc.epoch))

-- | The bare key\/script hash bytes of a credential, regardless of which it is.
credentialBytes :: Proto UtxoRpc.StakeCredential -> ByteString
credentialBytes credential =
  fromMaybe (credential ^. UtxoRpc.scriptHash) (credential ^. UtxoRpc.maybe'addrKeyHash)

-- | The addr-key\/script hash bytes of a 'DRep' vote target, or 'Nothing' for
-- an abstain\/no-confidence vote (which carries no hash).
voteDrepBytes :: Proto UtxoRpc.DRep -> Maybe ByteString
voteDrepBytes drep = drep ^. UtxoRpc.maybe'addrKeyHash <|> drep ^. UtxoRpc.maybe'scriptHash

-- | Credentials a certificate is about, classified once per oneof variant.
-- Exhaustive match, no wildcard: a new certificate variant in the proto is a
-- compile error here, not a silently unmatched cert.
data CertificateCredentials = CertificateCredentials
  { certStakeCredentials :: [Proto UtxoRpc.StakeCredential]
  , certPoolKeyHashes :: [ByteString]
  , certDRepBytes :: [ByteString]
  }

certificateCredentials :: Proto UtxoRpc.Certificate -> CertificateCredentials
certificateCredentials cert =
  case cert ^. UtxoRpc.maybe'certificate of
    Nothing -> CertificateCredentials [] [] []
    Just (Proto variant) -> case variant of
      UtxoRpc.Certificate'StakeRegistration cred ->
        CertificateCredentials [Proto cred] [] []
      UtxoRpc.Certificate'StakeDeregistration cred ->
        CertificateCredentials [Proto cred] [] []
      UtxoRpc.Certificate'StakeDelegation delegCert ->
        CertificateCredentials
          [Proto delegCert ^. UtxoRpc.stakeCredential]
          [Proto delegCert ^. UtxoRpc.poolKeyhash]
          []
      -- a 'PoolRegistrationCert' only carries one key hash ('operator'); the
      -- owners are deliberately excluded, matching 'matchesPoolRegistrationPattern'
      UtxoRpc.Certificate'PoolRegistration regCert ->
        CertificateCredentials [] [Proto regCert ^. UtxoRpc.operator] []
      UtxoRpc.Certificate'PoolRetirement retireCert ->
        CertificateCredentials [] [Proto retireCert ^. UtxoRpc.poolKeyhash] []
      -- delegates genesis keys; carries no stake\/pool\/drep credential
      UtxoRpc.Certificate'GenesisKeyDelegation _ ->
        CertificateCredentials [] [] []
      -- the targets are the reward recipients; 'any_stake_credential' must reach them
      UtxoRpc.Certificate'MirCert mirCert ->
        CertificateCredentials
          ((^. UtxoRpc.stakeCredential) <$> Proto mirCert ^. UtxoRpc.to)
          []
          []
      UtxoRpc.Certificate'RegCert regCert ->
        CertificateCredentials [Proto regCert ^. UtxoRpc.stakeCredential] [] []
      UtxoRpc.Certificate'UnregCert unregCert ->
        CertificateCredentials [Proto unregCert ^. UtxoRpc.stakeCredential] [] []
      UtxoRpc.Certificate'VoteDelegCert voteDelegCert ->
        CertificateCredentials
          [Proto voteDelegCert ^. UtxoRpc.stakeCredential]
          []
          (maybeToList . voteDrepBytes $ Proto voteDelegCert ^. UtxoRpc.drep)
      UtxoRpc.Certificate'StakeVoteDelegCert stakeVoteDelegCert ->
        CertificateCredentials
          [Proto stakeVoteDelegCert ^. UtxoRpc.stakeCredential]
          [Proto stakeVoteDelegCert ^. UtxoRpc.poolKeyhash]
          (maybeToList . voteDrepBytes $ Proto stakeVoteDelegCert ^. UtxoRpc.drep)
      UtxoRpc.Certificate'StakeRegDelegCert stakeRegDelegCert ->
        CertificateCredentials
          [Proto stakeRegDelegCert ^. UtxoRpc.stakeCredential]
          [Proto stakeRegDelegCert ^. UtxoRpc.poolKeyhash]
          []
      UtxoRpc.Certificate'VoteRegDelegCert voteRegDelegCert ->
        CertificateCredentials
          [Proto voteRegDelegCert ^. UtxoRpc.stakeCredential]
          []
          (maybeToList . voteDrepBytes $ Proto voteRegDelegCert ^. UtxoRpc.drep)
      UtxoRpc.Certificate'StakeVoteRegDelegCert stakeVoteRegDelegCert ->
        CertificateCredentials
          [Proto stakeVoteRegDelegCert ^. UtxoRpc.stakeCredential]
          [Proto stakeVoteRegDelegCert ^. UtxoRpc.poolKeyhash]
          (maybeToList . voteDrepBytes $ Proto stakeVoteRegDelegCert ^. UtxoRpc.drep)
      UtxoRpc.Certificate'AuthCommitteeHotCert authCert ->
        CertificateCredentials
          [ Proto authCert ^. UtxoRpc.committeeColdCredential
          , Proto authCert ^. UtxoRpc.committeeHotCredential
          ]
          []
          []
      UtxoRpc.Certificate'ResignCommitteeColdCert resignCert ->
        CertificateCredentials [Proto resignCert ^. UtxoRpc.committeeColdCredential] [] []
      UtxoRpc.Certificate'RegDrepCert regDrepCert -> do
        let drepCredential = Proto regDrepCert ^. UtxoRpc.drepCredential
        CertificateCredentials [drepCredential] [] [credentialBytes drepCredential]
      UtxoRpc.Certificate'UnregDrepCert unregDrepCert -> do
        let drepCredential = Proto unregDrepCert ^. UtxoRpc.drepCredential
        CertificateCredentials [drepCredential] [] [credentialBytes drepCredential]
      UtxoRpc.Certificate'UpdateDrepCert updateDrepCert -> do
        let drepCredential = Proto updateDrepCert ^. UtxoRpc.drepCredential
        CertificateCredentials [drepCredential] [] [credentialBytes drepCredential]

-- | Every stake-shaped credential embedded in a certificate; see 'certificateCredentials'.
certificateStakeCredentials :: Proto UtxoRpc.Certificate -> [Proto UtxoRpc.StakeCredential]
certificateStakeCredentials = certStakeCredentials . certificateCredentials

matchesAnyStakeCredential :: [Proto UtxoRpc.StakeCredential] -> ByteString -> Bool
matchesAnyStakeCredential stakeCredentials bytes = any ((== bytes) . credentialBytes) stakeCredentials

-- | Every pool key hash embedded in a certificate; see 'certificateCredentials'.
certificatePoolKeyHashes :: Proto UtxoRpc.Certificate -> [ByteString]
certificatePoolKeyHashes = certPoolKeyHashes . certificateCredentials

matchesAnyPoolKeyHash :: [ByteString] -> ByteString -> Bool
matchesAnyPoolKeyHash poolKeyHashes bytes = bytes `elem` poolKeyHashes

-- | Every DRep, identified by key\/script hash, embedded in a certificate; see 'certificateCredentials'.
certificateDRepBytes :: Proto UtxoRpc.Certificate -> [ByteString]
certificateDRepBytes = certDRepBytes . certificateCredentials

matchesAnyDRep :: [ByteString] -> ByteString -> Bool
matchesAnyDRep drepHashes bytes = bytes `elem` drepHashes
