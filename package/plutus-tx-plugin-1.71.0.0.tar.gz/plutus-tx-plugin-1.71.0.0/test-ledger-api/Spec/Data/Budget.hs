{-# LANGUAGE BangPatterns #-}
{-# LANGUAGE DataKinds #-}
{-# LANGUAGE LambdaCase #-}
{-# LANGUAGE MultiParamTypeClasses #-}
{-# LANGUAGE NegativeLiterals #-}
{-# LANGUAGE OverloadedStrings #-}
{-# LANGUAGE PatternSynonyms #-}
{-# LANGUAGE TemplateHaskell #-}
{-# LANGUAGE ViewPatterns #-}
{-# OPTIONS_GHC -fplugin-opt Plinth.Plugin:context-level=0 #-}
{-# OPTIONS_GHC -fplugin-opt Plinth.Plugin:defer-errors #-}

module Spec.Data.Budget where

import Test.Tasty (TestTree)
import Test.Tasty.Extras

import Data.Bifunctor
import Data.String
import PlutusLedgerApi.V1.Data.Value
import PlutusLedgerApi.V3.Data.MintValue qualified as MintValue
import PlutusTx.Code
import PlutusTx.Data.AssocMap as Map
import PlutusTx.Lift (liftCodeDef)
import PlutusTx.TH (compile)
import PlutusTx.Test

tests :: TestTree
tests =
  runTestNested ["test-ledger-api", "Spec", "Data", "Budget"] . pure . testNestedGhc $
    [ goldenPirReadable "gt" compiledGt
    , goldenPirReadable "currencySymbolValueOf" compiledCurrencySymbolValueOf
    , goldenPirReadable "valueOf" compiledValueOf
    , goldenPirReadable "lovelaceValueOf" compiledLovelaceValueOf
    , goldenPirReadable "unsafeLovelaceValueOf" compiledUnsafeLovelaceValueOf
    ]
      ++ testCases

compiledGt :: CompiledCode (Value -> Value -> Bool)
compiledGt = $$(compile [||gt||])

compiledGeq :: CompiledCode (Value -> Value -> Bool)
compiledGeq = $$(compile [||geq||])

compiledMintValueMinted :: CompiledCode (MintValue.MintValue -> Value)
compiledMintValueMinted = $$(compile [||MintValue.mintValueMinted||])

compiledMintValueBurned :: CompiledCode (MintValue.MintValue -> Value)
compiledMintValueBurned = $$(compile [||MintValue.mintValueBurned||])

compiledCurrencySymbolValueOf :: CompiledCode (Value -> CurrencySymbol -> Integer)
compiledCurrencySymbolValueOf = $$(compile [||currencySymbolValueOf||])

compiledValueOf :: CompiledCode (Value -> CurrencySymbol -> TokenName -> Integer)
compiledValueOf = $$(compile [||valueOf||])

compiledLovelaceValueOf :: CompiledCode (Value -> Lovelace)
compiledLovelaceValueOf = $$(compile [||lovelaceValueOf||])

compiledUnsafeLovelaceValueOf :: CompiledCode (Value -> Lovelace)
compiledUnsafeLovelaceValueOf = $$(compile [||unsafeLovelaceValueOf||])

mkValue :: [(Integer, [(Integer, Integer)])] -> Value
mkValue = Value . mkCurrencyMap

mkMintValue :: [(Integer, [(Integer, Integer)])] -> MintValue.MintValue
mkMintValue = MintValue.UnsafeMintValue . mkCurrencyMap

mkCurrencyMap :: [(Integer, [(Integer, Integer)])] -> Map CurrencySymbol (Map TokenName Integer)
mkCurrencyMap =
  Map.unsafeFromSOPList
    . fmap (bimap toSymbol (Map.unsafeFromSOPList . fmap (first toToken)))

toSymbol :: Integer -> CurrencySymbol
toSymbol = currencySymbol . fromString . show

toToken :: Integer -> TokenName
toToken = fromString . show

value1 :: Value
value1 =
  mkValue
    [ (1, [(100, 101)])
    , (2, [(200, 201), (202, 203)])
    , (3, [(300, 301), (302, 303), (304, 305)])
    , (4, [(400, 401), (402, 403), (404, 405), (406, 407)])
    , (5, [(500, 501), (502, 503), (504, 505), (506, 507), (508, 509)])
    ]

-- | One more CurrencySymbol than `value1`.
value2 :: Value
value2 =
  mkValue
    [ (1, [(100, 101)])
    , (2, [(200, 201), (202, 203)])
    , (3, [(300, 301), (302, 303), (304, 305)])
    , (4, [(400, 401), (402, 403), (404, 405), (406, 407)])
    , (5, [(500, 501), (502, 503), (504, 505), (506, 507), (508, 509)])
    , (6, [(600, 601), (602, 603), (604, 605), (606, 607), (608, 609), (610, 611)])
    ]

-- | One more TokenName than `value1`.
value3 :: Value
value3 =
  mkValue
    [ (1, [(100, 101)])
    , (2, [(200, 201), (202, 203)])
    , (3, [(300, 301), (302, 303), (304, 305), (306, 307)])
    , (4, [(400, 401), (402, 403), (404, 405), (406, 407)])
    , (5, [(500, 501), (502, 503), (504, 505), (506, 507), (508, 509)])
    ]

value4 :: MintValue.MintValue
value4 =
  mkMintValue
    [ (1, [(100, -101)])
    , (2, [(200, -201), (202, 203)])
    , (3, [(300, -301), (302, -303), (304, -305), (306, -307)])
    , (4, [(400, -401), (402, 403), (404, 405), (406, 407)])
    , (5, [(500, -501), (502, 503), (504, 505), (506, 507), (508, -509)])
    ]

{-| A ledger-shaped @TxOut@ value: ada (the empty 'CurrencySymbol' and
'TokenName') sorts first, followed by native assets, exactly as the ledger
presents it to a validator. This is the canonical shape that
'unsafeLovelaceValueOf' assumes. -}
txOutValue :: Value
txOutValue =
  Value . Map.unsafeFromSOPList $
    (adaSymbol, Map.unsafeFromSOPList [(adaToken, 2000000)])
      : fmap
        (bimap toSymbol (Map.unsafeFromSOPList . fmap (first toToken)))
        [ (1, [(100, 101)])
        , (2, [(200, 201), (202, 203)])
        , (3, [(300, 301), (302, 303), (304, 305)])
        ]

testCases :: [TestNested]
testCases =
  [ goldenEvalCekCatchBudget
      "gt1"
      ( compiledGt
          `unsafeApplyCode` liftCodeDef value1
          `unsafeApplyCode` liftCodeDef value1
      )
  , goldenEvalCekCatchBudget
      "gt2"
      ( compiledGt
          `unsafeApplyCode` liftCodeDef value1
          `unsafeApplyCode` liftCodeDef value2
      )
  , goldenEvalCekCatchBudget
      "gt3"
      ( compiledGt
          `unsafeApplyCode` liftCodeDef value2
          `unsafeApplyCode` liftCodeDef value1
      )
  , goldenEvalCekCatchBudget
      "gt4"
      ( compiledGt
          `unsafeApplyCode` liftCodeDef value1
          `unsafeApplyCode` liftCodeDef value3
      )
  , goldenEvalCekCatchBudget
      "gt5"
      ( compiledGt
          `unsafeApplyCode` liftCodeDef value3
          `unsafeApplyCode` liftCodeDef value1
      )
  , goldenEvalCekCatchBudget
      "geq1"
      ( compiledGeq
          `unsafeApplyCode` liftCodeDef value1
          `unsafeApplyCode` liftCodeDef value1
      )
  , goldenEvalCekCatchBudget
      "geq2"
      ( compiledGeq
          `unsafeApplyCode` liftCodeDef value1
          `unsafeApplyCode` liftCodeDef value2
      )
  , goldenEvalCekCatchBudget
      "geq3"
      ( compiledGeq
          `unsafeApplyCode` liftCodeDef value2
          `unsafeApplyCode` liftCodeDef value1
      )
  , goldenEvalCekCatchBudget
      "geq4"
      ( compiledGeq
          `unsafeApplyCode` liftCodeDef value1
          `unsafeApplyCode` liftCodeDef value3
      )
  , goldenEvalCekCatchBudget
      "geq5"
      ( compiledGeq
          `unsafeApplyCode` liftCodeDef value3
          `unsafeApplyCode` liftCodeDef value1
      )
  , goldenEvalCekCatchBudget
      "currencySymbolValueOf"
      ( compiledCurrencySymbolValueOf
          `unsafeApplyCode` liftCodeDef value2
          `unsafeApplyCode` liftCodeDef (toSymbol 6)
      )
  , goldenEvalCekCatchBudget
      "valueOf_hit_first"
      ( compiledValueOf
          `unsafeApplyCode` liftCodeDef value1
          `unsafeApplyCode` liftCodeDef (toSymbol 1)
          `unsafeApplyCode` liftCodeDef (toToken 100)
      )
  , goldenEvalCekCatchBudget
      "valueOf_hit_middle"
      ( compiledValueOf
          `unsafeApplyCode` liftCodeDef value1
          `unsafeApplyCode` liftCodeDef (toSymbol 3)
          `unsafeApplyCode` liftCodeDef (toToken 302)
      )
  , goldenEvalCekCatchBudget
      "valueOf_hit_last"
      ( compiledValueOf
          `unsafeApplyCode` liftCodeDef value1
          `unsafeApplyCode` liftCodeDef (toSymbol 5)
          `unsafeApplyCode` liftCodeDef (toToken 508)
      )
  , goldenEvalCekCatchBudget
      "valueOf_miss"
      ( compiledValueOf
          `unsafeApplyCode` liftCodeDef value1
          `unsafeApplyCode` liftCodeDef (toSymbol 99)
          `unsafeApplyCode` liftCodeDef (toToken 999)
      )
  , goldenEvalCekCatchBudget
      "mintValueMinted"
      ( compiledMintValueMinted
          `unsafeApplyCode` liftCodeDef value4
      )
  , goldenEvalCekCatchBudget
      "mintValueBurned"
      ( compiledMintValueBurned
          `unsafeApplyCode` liftCodeDef value4
      )
  , goldenEvalCekCatchBudget
      "lovelaceValueOf"
      ( compiledLovelaceValueOf
          `unsafeApplyCode` liftCodeDef txOutValue
      )
  , goldenEvalCekCatchBudget
      "unsafeLovelaceValueOf"
      ( compiledUnsafeLovelaceValueOf
          `unsafeApplyCode` liftCodeDef txOutValue
      )
  ]
