trace-dispatcher

We integrated contra-tracer-0.1.0.0 into the source tree, because the
iohk-monitoring framework depends on the non-arrow based contra-tracer framework.
This should become a dependency later.

The documentation can currently be found under: docs/trace-dispatcher.md  

## Developers

Benchmarking team is responsible for this library.
The primary developer is [@JürgenNF](https://github.com/jutaro).
