module Cardano.Ledger.PoolDistr
  {-# DEPRECATED "Use `Cardano.Ledger.State` instead" #-} (
  module Cardano.Ledger.State.PoolDistr,
)
where

import Cardano.Ledger.State.PoolDistr
