# Revision history for typed-protocols-cborg

## 0.1.0.7 -- 2023-10-20

* Improved performance of `prop_codecs_splitsM` and `prop_codecs_compatM`.

## 0.1.0.5 -- 2023-03-08

* Support `ghc-9.6.1`.
* Use `io-classes-1.1.0.0`.


