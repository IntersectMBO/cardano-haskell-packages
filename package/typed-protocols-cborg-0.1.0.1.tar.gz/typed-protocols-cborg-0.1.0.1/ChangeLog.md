# Revision history for typed-protocols-cborg

## 0.1.0.0 -- 2021-07-28

* Initial experiments and prototyping

