{-# LANGUAGE OverloadedStrings #-}

module Test.Golden.Byron.TxBody
  ( golden_byronTxBody
  ) where

import           Hedgehog (Property)

{- HLINT ignore "Use camelCase" -}

golden_byronTxBody :: Property
golden_byronTxBody = error "TODO"
