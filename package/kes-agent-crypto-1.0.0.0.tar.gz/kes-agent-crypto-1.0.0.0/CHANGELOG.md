# Revision history for kes-agent-crypto

## 1.0.0.0 -- 2026-01-09

- First major release. See `kes-agent`'s `CHANGELOG.md` for details.
