# 0.1.2.0

* Added `ToCBOR` and `FromCBOR` instances for `StrictSeq`: [#361](https://github.com/input-output-hk/cardano-base/pull/361)

# 0.1.1.0

* Added instances of `Monoid` and `Semigroup` for `StrictMaybe`: [#314](https://github.com/input-output-hk/cardano-base/pull/314)

# 0.1.0.1

* Intiial release
