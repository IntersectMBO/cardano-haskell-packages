module Cardano.Ledger.ShelleyMA.Timelocks
  {-# DEPRECATED "Use `Cardano.Ledger.Allegra.Scripts` from 'cardano-ledger-allegra' package instead" #-} (
  module Cardano.Ledger.Allegra.Scripts,
)
where

import Cardano.Ledger.Allegra.Scripts
