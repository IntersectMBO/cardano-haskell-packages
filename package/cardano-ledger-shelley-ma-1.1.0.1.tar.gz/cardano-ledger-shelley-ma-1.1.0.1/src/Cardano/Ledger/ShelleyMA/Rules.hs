module Cardano.Ledger.ShelleyMA.Rules
  {-# DEPRECATED "Use `Cardano.Ledger.Allegra.Rules` from 'cardano-ledger-allegra' package instead" #-} (
  module Cardano.Ledger.Allegra.Rules,
)
where

import Cardano.Ledger.Allegra.Rules
