module Cardano.Ledger.ShelleyMA.Tx
  {-# DEPRECATED "Use `Cardano.Ledger.Allegra.Tx` from 'cardano-ledger-allegra' package instead" #-} (
  module Cardano.Ledger.Allegra.Tx,
)
where

import Cardano.Ledger.Allegra.Tx
