module Foundation.Monad.MonadIO
    ( MonadIO(..)
    ) where

import Control.Monad.IO.Class
