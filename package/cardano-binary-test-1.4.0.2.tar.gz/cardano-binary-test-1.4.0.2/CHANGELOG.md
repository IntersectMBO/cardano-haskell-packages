# Changelog for `cardano-binary-test`

## 1.4.0.2

* GHC-9.6 compatibility

## 1.4.0.1

* Remove `development` flag: #372

## 1.4.0.0

* Remove `Test.Cardano.Binary.Drop` module

## 1.3.0.1

* Initial release

