// Place holder for a git revision (40 characters) intended to be replaced in
// the final binary.
//
// NOTE: Keep consistent with what is searched for in 'src/Hydra/Version.hs'
char _hydra_gitrev[40]
  = "0000000001" // 10
    "0000000001" // 20
    "0000000001" // 30
    "0000000001" // 40
    ;
