{-# LANGUAGE BangPatterns        #-}
{-# LANGUAGE DataKinds           #-}
{-# LANGUAGE GADTs               #-}
{-# LANGUAGE LambdaCase          #-}
{-# LANGUAGE NamedFieldPuns      #-}
{-# LANGUAGE OverloadedStrings   #-}
{-# LANGUAGE PackageImports      #-}
{-# LANGUAGE RecordWildCards     #-}
{-# LANGUAGE ScopedTypeVariables #-}

module DMQ.SigSubmissionV2.Outbound
  ( sigSubmissionOutbound
  , TraceSigSubmissionOutbound (..)
  ) where

import Data.Aeson (KeyValue ((.=)), ToJSON (toJSON), Value (String), object)
import Data.Foldable qualified as Foldable
import Data.List.NonEmpty qualified as NonEmpty
import Data.Map.Strict (Map)
import Data.Map.Strict qualified as Map
import Data.Maybe (mapMaybe)
import Data.Sequence.Strict (StrictSeq)
import Data.Sequence.Strict qualified as Seq
import Data.Set (Set)
import Data.Set qualified as Set

import Control.Concurrent.Class.MonadSTM (MonadSTM (..))
import Control.Exception (assert)
import Control.Monad (unless, when)
import Control.Monad.Class.MonadSTM
import Control.Monad.Class.MonadThrow
import Control.Monad.Class.MonadTimer.SI
import "contra-tracer" Control.Tracer (Tracer (..), traceWith)

import Ouroboros.Network.TxSubmission.Mempool.Reader (MempoolSnapshot (..),
           TxSubmissionMempoolReader (..))

import DMQ.Protocol.SigSubmissionV2.Outbound
import DMQ.Protocol.SigSubmissionV2.Type
import DMQ.SigSubmissionV2.Types


data TraceSigSubmissionOutbound sigId sig
  = TraceSigSubmissionOutboundRecvMsgRequestSigs
      [sigId]
      -- ^ The IDs of the signatures requested.
  | TraceSigSubmissionOutboundSendMsgReplySigs
      [sig]
      -- ^ The sigs to be sent in the response.
  deriving Show

instance (ToJSON sigId, ToJSON sig)
      => ToJSON (TraceSigSubmissionOutbound sigId sig) where
  toJSON (TraceSigSubmissionOutboundRecvMsgRequestSigs sigIds) =
    object
      [ "kind"  .= String "SigSubmissionOutboundRecvMsgRequestSigs"
      , "sigIds" .= sigIds
      ]
  toJSON (TraceSigSubmissionOutboundSendMsgReplySigs sigs) =
    object
      [ "kind" .= String "SigSubmissionOutboundSendMsgReplySigs"
      , "sigs"  .= sigs
      ]

data Delivered = Delivered | NotDelivered

sigSubmissionOutbound
  :: forall version sigId sig idx m.
     (Ord sigId, Show sigId, Ord idx, MonadTimer m, MonadThrow m)
  => Tracer m (TraceSigSubmissionOutbound sigId sig)
  -> NumIdsAck  -- ^ Maximum number of unacknowledged sigIds allowed
  -> TxSubmissionMempoolReader sigId sig idx m
  -> version
  -> SigSubmissionOutbound sigId sig m ()
sigSubmissionOutbound tracer maxUnacked TxSubmissionMempoolReader{..} _version =
    SigSubmissionOutbound (pure (server Seq.empty mempoolZeroIdx))
  where
    server :: StrictSeq (sigId, idx, Delivered) -> idx -> OutboundStIdle sigId sig m ()
    server !unackedSeq !lastIdx =
        OutboundStIdle { recvMsgRequestSigIds, recvMsgRequestSigs, recvMsgDone }
      where
        recvMsgDone :: m ()
        recvMsgDone = pure ()

        recvMsgRequestSigIds :: forall blocking.
                               SingBlockingStyle blocking
                            -> NumIdsAck
                            -> NumIdsReq
                            -> m (OutboundStSigIds blocking sigId sig m ())
        recvMsgRequestSigIds blocking ackNo reqNo = do
          when (getNumIdsAck ackNo > fromIntegral (Seq.length unackedSeq)) $
            throwIO ProtocolErrorAckedTooManySigIds

          let unackedNo = Seq.length unackedSeq
          when (  unackedNo
                - fromIntegral (getNumIdsAck ackNo)
                + fromIntegral (getNumIdsReq reqNo)
                > fromIntegral (getNumIdsAck maxUnacked)) $
            throwIO (ProtocolErrorRequestedTooManySigIds reqNo unackedNo maxUnacked)

          -- Update our tracking state to remove the number of sigIds that the
          -- peer has acknowledged.
          let !unackedSeq' = Seq.drop (fromIntegral ackNo) unackedSeq

          -- Update our tracking state with any extra sigs available.
          let update sigs =
                -- These sigs should all be fresh
                assert (all (\(_, idx, _) -> idx > lastIdx) sigs) $
                  let !unackedSeq'' = unackedSeq' <> Seq.fromList
                                        [ (sigId, idx, NotDelivered) | (sigId, idx, _) <- sigs ]
                      !lastIdx'
                        | null sigs = lastIdx
                        | otherwise = idx where (_, idx, _) = last sigs
                      sigs'        :: [(sigId, SizeInBytes)]
                      sigs'         = [ (sigId, size) | (sigId, _, size) <- sigs ]
                      server'       = server unackedSeq'' lastIdx'
                  in  (sigs', server')

          -- Grab info about any new sigs after the last sig idx we've seen,
          -- up to the number that the peer has requested.
          case blocking of
            SingBlocking -> do
              when (reqNo == 0) $
                throwIO ProtocolErrorRequestedNothing
              unless (Seq.null unackedSeq') $
                throwIO ProtocolErrorRequestBlocking

              let
                -- block until timeout expires
                timeoutSTM :: TVar m Bool
                           -> STM m (OutboundStSigIds StBlocking sigId sig m ())
                timeoutSTM timer = do
                  readTVar timer >>= check
                  let !(_, server') = update []
                  pure (SendMsgReplyNoSigIds server')

                -- block until we have any sidids to send back
                sigIdsSTM :: STM m (OutboundStSigIds StBlocking sigId sig m ())
                sigIdsSTM = do
                  MempoolSnapshot{mempoolTxIdsAfter} <- mempoolGetSnapshot
                  let sigs = mempoolTxIdsAfter lastIdx
                  check (not $ null sigs)
                  let !(sigs', server') = update (take (fromIntegral reqNo) sigs)
                      sigs'' = case NonEmpty.nonEmpty sigs' of
                        Just x -> x
                        -- Assert sigs is non-empty: we blocked until sigs was non-null,
                        -- and we know reqNo > 0, hence `take reqNo sigs` is non-null.
                        Nothing -> error "sigSubmissionOutbound: empty signature list"
                  pure (SendMsgReplySigIds (BlockingReply sigs'') server')

              -- Timeout is 2 seconds less than the protocol timeout for blocking
              timerExpired <- registerDelay 17
              atomically $ timeoutSTM timerExpired
                           `orElse`
                           sigIdsSTM

            SingNonBlocking -> do
              when (reqNo == 0 && ackNo == 0) $
                throwIO ProtocolErrorRequestedNothing
              when (Seq.null unackedSeq') $
                throwIO ProtocolErrorRequestNonBlocking

              sigs <- atomically $ do
                MempoolSnapshot{mempoolTxIdsAfter} <- mempoolGetSnapshot
                let sigs = mempoolTxIdsAfter lastIdx
                return (take (fromIntegral reqNo) sigs)

              let !(sigs', server') = update sigs
              pure (SendMsgReplySigIds (NonBlockingReply sigs') server')

        recvMsgRequestSigs :: [sigId]
                           -> m (OutboundStSigs sigId sig m ())
        recvMsgRequestSigs sigIds = do
          -- Trace the IDs of the signatures requested.
          traceWith tracer (TraceSigSubmissionOutboundRecvMsgRequestSigs sigIds)

          MempoolSnapshot{mempoolLookupTx} <- atomically mempoolGetSnapshot

          -- The window size is expected to be small (currently 132, and might
          -- increase in the future); thus using `sets` and `maps` rather than
          -- lists.
          let unackedMap, requestedMap :: Map sigId (idx, Delivered)
              unackedSet, requestedSet :: Set sigId

              unackedMap   = Map.fromList
                           $ map (\(sigId, idx, delivered) -> (sigId, (idx, delivered)))
                           $ Foldable.toList unackedSeq
              unackedSet   = Map.keysSet unackedMap

              requestedSet = Set.fromList sigIds
              requestedMap = unackedMap `Map.restrictKeys` requestedSet

          unless (requestedSet `Set.isSubsetOf` unackedSet) $
            throwIO ProtocolErrorRequestedUnavailableSig

          let deliveredSet, requestedAndDeliveredSet :: Set sigId
              deliveredSet =
                  Map.keysSet
                . Map.filter (\case
                                (_, Delivered) -> True
                                (_, NotDelivered) -> False
                             )
                $ unackedMap
              requestedAndDeliveredSet =
                requestedSet `Set.intersection` deliveredSet

          unless (length requestedSet == length sigIds) $
            throwIO $ ProtocolErrorDuplicateSigIds sigIds

          unless (Set.null $ requestedAndDeliveredSet) $
            throwIO $ ProtocolErrorDuplicateRequest (Set.toList requestedAndDeliveredSet)

          -- The 'mempoolLookupTx' will return nothing if the signature is no
          -- longer in the mempool. This is good. Neither the sending nor
          -- receiving side wants to forward sigs that are no longer of interest.
          let sigs    = mapMaybe (mempoolLookupTx . fst) $ Map.elems requestedMap
              -- flip delivered flags
              unackedSeq' =
                (\case
                  (sigId, idx, NotDelivered)
                    | sigId `Set.member` requestedSet
                    -> (sigId, idx, Delivered)

                  a -> a
                )
                <$>
                unackedSeq
              server' = server unackedSeq' lastIdx

          -- Trace the sigs to be sent in the response.
          traceWith tracer (TraceSigSubmissionOutboundSendMsgReplySigs sigs)

          return $ SendMsgReplySigs sigs server'
