# `cardano-base`

This package contains a collection of Cardano-related utilities.

See the [Haddocks](https://intersectmbo.github.io/cardano-base/cardano-base/).
