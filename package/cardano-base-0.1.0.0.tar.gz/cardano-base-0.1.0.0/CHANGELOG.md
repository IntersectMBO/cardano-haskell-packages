# Changelog for `cardano-base`

## 0.1.0.0

* Added `Cardano.Base.FeatureFlag`.
