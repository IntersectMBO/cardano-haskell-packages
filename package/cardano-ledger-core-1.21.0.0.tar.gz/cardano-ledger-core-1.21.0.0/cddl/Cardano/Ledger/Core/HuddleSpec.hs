{-# LANGUAGE AllowAmbiguousTypes #-}
{-# LANGUAGE BinaryLiterals #-}
{-# LANGUAGE DataKinds #-}
{-# LANGUAGE FlexibleContexts #-}
{-# LANGUAGE FlexibleInstances #-}
{-# LANGUAGE KindSignatures #-}
{-# LANGUAGE LambdaCase #-}
{-# LANGUAGE MonoLocalBinds #-}
{-# LANGUAGE MultiParamTypeClasses #-}
{-# LANGUAGE NumericUnderscores #-}
{-# LANGUAGE OverloadedLists #-}
{-# LANGUAGE OverloadedStrings #-}
{-# LANGUAGE QuasiQuotes #-}
{-# LANGUAGE ScopedTypeVariables #-}
{-# LANGUAGE TypeApplications #-}
{-# LANGUAGE UndecidableInstances #-}
{-# OPTIONS_GHC -Wno-orphans #-}

module Cardano.Ledger.Core.HuddleSpec (
  plutusScriptGen,
) where

import Cardano.Ledger.BaseTypes (getVersion)
import Cardano.Ledger.Core (ByronEra, eraProtVerHigh, eraProtVerLow)
import Cardano.Ledger.Huddle
import Cardano.Ledger.Huddle.Gen (
  MonadGen (choose),
  RuleTerm (..),
  arbitrary,
  genArrayTerm,
  oneof,
  vectorOf,
 )
import Codec.CBOR.Cuddle.Huddle as H
import Codec.CBOR.Term (Term (..))
import Data.Bits (Bits (..))
import Data.ByteString (ByteString)
import qualified Data.ByteString as BS
import Data.MemPack (VarLen (..), packByteString)
import Data.Proxy (Proxy (..))
import Data.Word (Word16, Word32, Word64)
import GHC.TypeLits (KnownSymbol, Symbol)
import Text.Heredoc
import Prelude hiding ((/))

genByteString :: MonadGen m => Int -> m ByteString
genByteString n = BS.pack <$> vectorOf n arbitrary

-- | Generator for plutus scripts that produces random bytestrings.
-- This avoids collisions when scripts appear in sets (tag 258).
plutusScriptGen :: MonadGen m => m RuleTerm
plutusScriptGen = SingleTerm . TBytes <$> (genByteString =<< choose (8, 1024))

instance Era era => HuddleRule "hash28" era where
  huddleRuleNamed pname _ = pname =.= VBytes `H.sized` (28 :: Word64)

instance Era era => HuddleRule "hash32" era where
  huddleRuleNamed pname _ = pname =.= VBytes `H.sized` (32 :: Word64)

instance Era era => HuddleRule "max_word64" era where
  huddleRuleNamed pname _ = pname =.= (18446744073709551615 :: Integer)

instance Era era => HuddleRule "positive_int" era where
  huddleRuleNamed pname p = pname =.= (1 :: Integer) ... huddleRule @"max_word64" p

instance Era era => HuddleRule "max_word32" era where
  huddleRuleNamed pname _ = pname =.= (4294967295 :: Integer)

instance Era era => HuddleRule "positive_word32" era where
  huddleRuleNamed pname p = pname =.= (1 :: Integer) ... huddleRule @"max_word32" p

instance Era era => HuddleRule "unit_interval" era where
  huddleRuleNamed pname _ =
    comment
      [str| A unit interval is a number in the range between 0 and 1, which
          | means there are two extra constraints:
          |   1. numerator <= denominator
          |   2. denominator > 0
          |
          | The relation between numerator and denominator can be
          | expressed in CDDL, but we have a limitation currently
          | (see: https://github.com/input-output-hk/cuddle/issues/30).
          |]
      . withCBORGen generator
      $ pname =.= tag 30 (arr [a VUInt, a VUInt])
    where
      generator = do
        let genUnitInterval64 l u = do
              d <- choose (max 1 l, u)
              n <- choose (l, d)
              pure (n, d)
            max64 = toInteger (maxBound @Word64)
        (n, d) <-
          oneof
            [ genUnitInterval64 0 max64
            , genUnitInterval64 0 1000
            , genUnitInterval64 (max64 - 1000) max64
            ]
        SingleTerm . TTagged 30
          <$> genArrayTerm [TInteger $ toInteger n, TInteger $ toInteger d]

instance Era era => HuddleRule "nonnegative_interval" era where
  huddleRuleNamed pname p =
    pname =.= tag 30 (arr [a VUInt, a (huddleRule @"positive_int" p)])

instance Era era => HuddleRule "nonce" era where
  huddleRuleNamed pname p = pname =.= arr [0] / arr [1, a (huddleRule @"hash32" p)]

instance Era era => HuddleRule "epoch" era where
  huddleRuleNamed pname _ = pname =.= VUInt `H.sized` (8 :: Word64)

instance Era era => HuddleRule "epoch_interval" era where
  huddleRuleNamed pname _ = pname =.= VUInt `H.sized` (4 :: Word64)

instance Era era => HuddleRule "slot" era where
  huddleRuleNamed pname _ = pname =.= VUInt `H.sized` (8 :: Word64)

instance Era era => HuddleRule "block_number" era where
  huddleRuleNamed pname _ = pname =.= VUInt `H.sized` (8 :: Word64)

instance Era era => HuddleRule "addr_keyhash" era where
  huddleRuleNamed pname p = pname =.= huddleRule @"hash28" p

instance Era era => HuddleRule "pool_keyhash" era where
  huddleRuleNamed pname p = pname =.= huddleRule @"hash28" p

instance Era era => HuddleRule "vrf_keyhash" era where
  huddleRuleNamed pname p = pname =.= huddleRule @"hash32" p

instance Era era => HuddleRule "vkey" era where
  huddleRuleNamed pname _ = pname =.= VBytes `H.sized` (32 :: Word64)

instance Era era => HuddleRule "vrf_vkey" era where
  huddleRuleNamed pname _ = pname =.= VBytes `H.sized` (32 :: Word64)

instance Era era => HuddleRule "vrf_cert" era where
  huddleRuleNamed pname _ = pname =.= arr [a VBytes, a (VBytes `H.sized` (80 :: Word64))]

instance Era era => HuddleRule "kes_vkey" era where
  huddleRuleNamed pname _ = pname =.= VBytes `H.sized` (32 :: Word64)

instance Era era => HuddleRule "kes_signature" era where
  huddleRuleNamed pname _ = pname =.= VBytes `H.sized` (448 :: Word64)

instance Era era => HuddleRule "signkey_kes" era where
  huddleRuleNamed pname _ = pname =.= VBytes `H.sized` (64 :: Word64)

instance Era era => HuddleRule "sequence_number" era where
  huddleRuleNamed pname _ = pname =.= VUInt `H.sized` (8 :: Word64)

instance Era era => HuddleRule "kes_period" era where
  huddleRuleNamed pname _ = pname =.= VUInt `H.sized` (8 :: Word64)

instance Era era => HuddleRule "signature" era where
  huddleRuleNamed pname _ = pname =.= VBytes `H.sized` (64 :: Word64)

instance Era era => HuddleRule "coin" era where
  huddleRuleNamed pname _ = pname =.= VUInt

instance Era era => HuddleRule "positive_coin" era where
  huddleRuleNamed pname p = pname =.= (1 :: Integer) ... huddleRule @"max_word64" p

genHash28 :: MonadGen m => m ByteString
genHash28 = genByteString 28

instance Era era => HuddleRule "address" era where
  huddleRuleNamed pname _ =
    comment
      [str| address format:
          |   [ 8 bit header | payload ];
          |
          | shelley payment addresses:
          |      bit 7: 0
          |      bit 6: base/other
          |      bit 5: pointer/enterprise [for base: stake cred is keyhash/scripthash]
          |      bit 4: payment cred is keyhash/scripthash
          |   bits 3-0: network id
          |
          | reward addresses:
          |   bits 7-5: 111
          |      bit 4: credential is keyhash/scripthash
          |   bits 3-0: network id
          |
          | byron addresses:
          |   bits 7-4: 1000
          |
          |      0000: base address: keyhash28,keyhash28
          |      0001: base address: scripthash28,keyhash28
          |      0010: base address: keyhash28,scripthash28
          |      0011: base address: scripthash28,scripthash28
          |      0100: pointer address: keyhash28, 3 variable length uint
          |      0101: pointer address: scripthash28, 3 variable length uint
          |      0110: enterprise address: keyhash28
          |      0111: enterprise address: scripthash28
          |      1000: byron address
          |      1110: account address: keyhash28
          |      1111: account address: scripthash28
          | 1001-1101: future formats
          |]
      . withCBORGen generator
      $ pname =.= VBytes
    where
      generator = do
        stakeRef <- choose (0, 0b11)
        let
          stakeRefMask = stakeRef `shiftL` 5 -- 0b0xx00000
          mkMask mask isMask = if isMask then mask else 0
        isPaymentScriptMask <- mkMask 0b00010000 <$> arbitrary
        isMainnetMask <- mkMask 0b00000001 <$> arbitrary
        let
          header = stakeRefMask .|. isPaymentScriptMask .|. isMainnetMask
          genVar32 = VarLen <$> arbitrary @Word32
          genVar16 = VarLen <$> arbitrary @Word16
        stakeCred <- case stakeRef of
          0b00 -> genHash28 -- staking payment hash
          0b01 -> genHash28 -- staking script hash
          0b10 -> do
            -- Ptr
            slotNo <- genVar32
            txIx <- genVar16
            certIx <- genVar16
            pure $ packByteString slotNo <> packByteString txIx <> packByteString certIx
          _ -> pure mempty
        paymentCred <- genHash28
        -- TODO use genBytesTerm once indefinite bytestring decoding has been fixed
        let bytesTerm = TBytes . BS.cons header $ paymentCred <> stakeCred
        pure $ SingleTerm bytesTerm

instance Era era => HuddleRule "reward_account" era where
  huddleRuleNamed pname _ = withCBORGen generator $ pname =.= VBytes
    where
      generator = do
        isMainnet <- arbitrary
        isScript <- arbitrary
        let
          mainnetMask | isMainnet = 0b00000001 | otherwise = 0x00
          scriptMask | isScript = 0b00010000 | otherwise = 0x00
          header = 0b11100000 .|. mainnetMask .|. scriptMask
        payload <- genHash28
        let term = TBytes $ BS.cons header payload
        pure $ SingleTerm term

instance Era era => HuddleRule "transaction_index" era where
  huddleRuleNamed pname _ = pname =.= VUInt `H.sized` (2 :: Word64)

instance Era era => HuddleRule "metadatum_label" era where
  huddleRuleNamed pname _ = pname =.= VUInt `H.sized` (8 :: Word64)

instance (Era era, HuddleRule "metadatum" era) => HuddleRule "metadata" era where
  huddleRuleNamed pname p =
    pname
      =.= mp
        [ 0
            <+ asKey (huddleRule @"metadatum_label" p)
            ==> huddleRule @"metadatum" p
        ]

instance Era era => HuddleRule "auxiliary_data_hash" era where
  huddleRuleNamed pname p = pname =.= huddleRule @"hash32" p

instance Era era => HuddleRule "script_hash" era where
  huddleRuleNamed pname p =
    comment
      [str| To compute a script hash, note that you must prepend
          | a tag to the bytes of the script before hashing.
          | The tag is determined by the language.
          | The tags are:
          |   "\x00" for multisig/native scripts
          |   "\x01" for Plutus V1 scripts
          |   "\x02" for Plutus V2 scripts
          |   "\x03" for Plutus V3 scripts
          |   "\x04" for Plutus V4 scripts
          |]
      $ pname
        =.= huddleRule @"hash28" p

instance Era era => HuddleRule "credential" era where
  huddleRuleNamed pname p =
    pname
      =.= arr [0, a (huddleRule @"addr_keyhash" p)]
      / arr [1, a (huddleRule @"script_hash" p)]

instance Era era => HuddleRule "stake_credential" era where
  huddleRuleNamed pname p = pname =.= huddleRule @"credential" p

instance Era era => HuddleRule "port" era where
  huddleRuleNamed pname _ = pname =.= VUInt `le` 65535

ipRule ::
  forall era (r :: Symbol).
  KnownSymbol r => Int -> Proxy r -> Proxy era -> Rule
ipRule n pname _ = pname =.= VBytes `H.sized` (fromIntegral n :: Word64)

instance Era era => HuddleRule "ipv4" era where
  huddleRuleNamed = ipRule 4

instance Era era => HuddleRule "ipv6" era where
  huddleRuleNamed = ipRule 16

instance Era era => HuddleRule "major_protocol_version" era where
  huddleRuleNamed pname _ =
    pname
      =.= getVersion @Integer (eraProtVerLow @ByronEra)
      ... succ (getVersion @Integer (eraProtVerHigh @era))

instance Era era => HuddleRule "protocol_version" era where
  huddleRuleNamed pname p =
    pname =.= arr [a $ huddleRule @"major_protocol_version" p, a $ VUInt `sized` (4 :: Word64)]

instance Era era => HuddleGroup "protocol_version" era where
  huddleGroupNamed pname p =
    pname =.~ grp [a $ huddleRule @"major_protocol_version" p, a $ VUInt `sized` (4 :: Word64)]
