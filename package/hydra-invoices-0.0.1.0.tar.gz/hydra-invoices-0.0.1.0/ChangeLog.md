# Changelog for hydra-invoices

## v0.0.1.0

* Initial commit of `hydra-invoices`.
* Add `Invoice` type with parameterisable fields.
* Add `StandardInvoice` type with typical field types for use with `cardano-api`.
* Add `generateStandardInvoice` function.
