{-# LANGUAGE DeriveAnyClass    #-}
{-# LANGUAGE DerivingVia       #-}
{-# LANGUAGE NamedFieldPuns    #-}
{-# LANGUAGE NoImplicitPrelude #-}
{-# LANGUAGE OverloadedStrings #-}
{-# LANGUAGE RecordWildCards   #-}
{-# LANGUAGE TemplateHaskell   #-}
{-# LANGUAGE ViewPatterns      #-}
{-# OPTIONS_GHC -Wno-simplifiable-class-constraints #-}
{-# OPTIONS_GHC -fno-omit-interface-pragmas #-}
{-# OPTIONS_GHC -fno-specialise #-}
{-# OPTIONS_GHC -fno-strictness #-}

module PlutusLedgerApi.V3.Contexts where

import GHC.Generics (Generic)
import Prettyprinter (nest, vsep, (<+>))
import Prettyprinter.Extras

import PlutusLedgerApi.V2 qualified as V2
import PlutusTx qualified
import PlutusTx.AssocMap hiding (filter, mapMaybe)
import PlutusTx.Prelude qualified as PlutusTx

import Prelude qualified as Haskell

newtype ColdCommitteeCredential = ColdCommitteeCredential V2.Credential
  deriving stock (Generic)
  deriving (Pretty) via (PrettyShow ColdCommitteeCredential)
  deriving newtype
    ( Haskell.Eq
    , Haskell.Show
    , PlutusTx.Eq
    , PlutusTx.ToData
    , PlutusTx.FromData
    , PlutusTx.UnsafeFromData
    )

newtype HotCommitteeCredential = HotCommitteeCredential V2.Credential
  deriving stock (Generic)
  deriving (Pretty) via (PrettyShow HotCommitteeCredential)
  deriving newtype
    ( Haskell.Eq
    , Haskell.Show
    , PlutusTx.Eq
    , PlutusTx.ToData
    , PlutusTx.FromData
    , PlutusTx.UnsafeFromData
    )

newtype DRepCredential = DRepCredential V2.Credential
  deriving stock (Generic)
  deriving (Pretty) via (PrettyShow DRepCredential)
  deriving newtype
    ( Haskell.Eq
    , Haskell.Show
    , PlutusTx.Eq
    , PlutusTx.ToData
    , PlutusTx.FromData
    , PlutusTx.UnsafeFromData
    )

data DRep
  = DRep DRepCredential
  | DRepAlwaysAbstain
  | DRepAlwaysNoConfidence
  deriving stock (Generic, Haskell.Show, Haskell.Eq)
  deriving (Pretty) via (PrettyShow DRep)

instance PlutusTx.Eq DRep where
  {-# INLINEABLE (==) #-}
  DRep a == DRep a'                                = a PlutusTx.== a'
  DRepAlwaysAbstain == DRepAlwaysAbstain           = Haskell.True
  DRepAlwaysNoConfidence == DRepAlwaysNoConfidence = Haskell.True
  _ == _                                           = Haskell.False

data Delegatee
  = DelegStake V2.PubKeyHash
  | DelegVote DRep
  | DelegStakeVote V2.PubKeyHash DRep
  deriving stock (Generic, Haskell.Show, Haskell.Eq)
  deriving (Pretty) via (PrettyShow Delegatee)

instance PlutusTx.Eq Delegatee where
  {-# INLINEABLE (==) #-}
  DelegStake a == DelegStake a' = a PlutusTx.== a'
  DelegVote a == DelegVote a' = a PlutusTx.== a'
  DelegStakeVote a b == DelegStakeVote a' b' =
    a PlutusTx.== a' PlutusTx.&& b PlutusTx.== b'
  _ == _ = Haskell.False

data TxCert
  = -- | Register staking credential with an optional deposit amount
    TxCertRegStaking V2.Credential (Haskell.Maybe V2.Value)
  | -- | Un-Register staking credential with an optional refund amount
    TxCertUnRegStaking V2.Credential (Haskell.Maybe V2.Value)
  | -- | Delegate staking credential to a Delegatee
    TxCertDelegStaking V2.Credential Delegatee
  | -- | Register and delegate staking credential to a Delegatee in one certificate. Noter that
    -- deposit is mandatory.
    TxCertRegDeleg V2.Credential Delegatee V2.Value
  | -- | Register a DRep with a deposit value. The optional anchor is omitted.
    TxCertRegDRep DRepCredential V2.Value
  | -- | Update a DRep. The optional anchor is omitted.
    TxCertUpdateDRep DRepCredential
  | -- | UnRegister a DRep with mandatory refund value
    TxCertUnRegDRep DRepCredential V2.Value
  | -- | A digest of the PoolParams
    TxCertPoolRegister
      V2.PubKeyHash
      -- ^ poolId
      V2.PubKeyHash
      -- ^ pool VFR
  | -- | The retirement certificate and the Epoch in which the retirement will take place
    TxCertPoolRetire V2.PubKeyHash Haskell.Integer
  | -- | Authorize a Hot credential for a specific Committee member's cold credential
    TxCertAuthHotCommittee ColdCommitteeCredential HotCommitteeCredential
  | TxCertResignColdCommittee ColdCommitteeCredential
  deriving stock (Generic, Haskell.Show, Haskell.Eq)
  deriving (Pretty) via (PrettyShow TxCert)

instance PlutusTx.Eq TxCert where
  {-# INLINEABLE (==) #-}
  TxCertRegStaking a b == TxCertRegStaking a' b' =
    a PlutusTx.== a' PlutusTx.&& b PlutusTx.== b'
  TxCertUnRegStaking a b == TxCertUnRegStaking a' b' =
    a PlutusTx.== a' PlutusTx.&& b PlutusTx.== b'
  TxCertDelegStaking a b == TxCertDelegStaking a' b' =
    a PlutusTx.== a' PlutusTx.&& b PlutusTx.== b'
  TxCertRegDeleg a b c == TxCertRegDeleg a' b' c' =
    a PlutusTx.== a' PlutusTx.&& b PlutusTx.== b' PlutusTx.&& c PlutusTx.== c'
  TxCertRegDRep a b == TxCertRegDRep a' b' =
    a PlutusTx.== a' PlutusTx.&& b PlutusTx.== b'
  TxCertUpdateDRep a == TxCertUpdateDRep a' =
    a PlutusTx.== a'
  TxCertUnRegDRep a b == TxCertUnRegDRep a' b' =
    a PlutusTx.== a' PlutusTx.&& b PlutusTx.== b'
  TxCertAuthHotCommittee a b == TxCertAuthHotCommittee a' b' =
    a PlutusTx.== a' PlutusTx.&& b PlutusTx.== b'
  TxCertResignColdCommittee a == TxCertResignColdCommittee a' =
    a PlutusTx.== a'
  _ == _ = Haskell.False

data Voter
  = CommitteeVoter HotCommitteeCredential
  | DRepVoter DRepCredential
  | StakePoolVoter V2.PubKeyHash
  deriving stock (Generic, Haskell.Show, Haskell.Eq)
  deriving (Pretty) via (PrettyShow Voter)

instance PlutusTx.Eq Voter where
  {-# INLINEABLE (==) #-}
  CommitteeVoter a == CommitteeVoter a' =
    a PlutusTx.== a'
  DRepVoter a == DRepVoter a' =
    a PlutusTx.== a'
  StakePoolVoter a == StakePoolVoter a' =
    a PlutusTx.== a'
  _ == _ = Haskell.False

-- | A vote. The optional anchor is omitted.
data Vote
  = VoteNo
  | VoteYes
  | Abstain
  deriving stock (Generic, Haskell.Show, Haskell.Eq)
  deriving (Pretty) via (PrettyShow Vote)

instance PlutusTx.Eq Vote where
  {-# INLINEABLE (==) #-}
  VoteNo == VoteNo   = Haskell.True
  VoteYes == VoteYes = Haskell.True
  Abstain == Abstain = Haskell.True
  _ == _             = Haskell.False

-- | Similar to TxOutRef, but for GovActions
data GovernanceActionId = GovernanceActionId
  { gaidTxId        :: V2.TxId
  , gaidGovActionIx :: Haskell.Integer
  }
  deriving stock (Generic, Haskell.Show, Haskell.Eq)

instance Pretty GovernanceActionId where
  pretty GovernanceActionId{..} =
    vsep
      [ "gaidTxId:" <+> pretty gaidTxId
      , "gaidGovActionIx:" <+> pretty gaidGovActionIx
      ]

instance PlutusTx.Eq GovernanceActionId where
  {-# INLINEABLE (==) #-}
  GovernanceActionId a b == GovernanceActionId a' b' =
    a PlutusTx.== a' PlutusTx.&& b PlutusTx.== b'

data Committee = Committee
  { committeeMembers :: Map ColdCommitteeCredential Haskell.Integer
  -- ^ Committee members with epoch number when each of them expires
  , committeeQuorum  :: PlutusTx.Rational
  -- ^ Quorum of the committee that is necessary for a successful vote
  }
  deriving stock (Generic, Haskell.Show, Haskell.Eq)

instance Pretty Committee where
  pretty Committee{..} =
    vsep
      [ "committeeMembers:" <+> pretty committeeMembers
      , "committeeQuorum:" <+> pretty committeeQuorum
      ]

instance PlutusTx.Eq Committee where
  {-# INLINEABLE (==) #-}
  Committee a b == Committee a' b' =
    a PlutusTx.== a' PlutusTx.&& b PlutusTx.== b'

-- | A constitution. The optional anchor is omitted.
newtype Constitution = Constitution
  { constitutionScript :: Haskell.Maybe V2.ScriptHash
  }
  deriving stock (Generic)
  deriving newtype (Haskell.Show, Haskell.Eq)

instance Pretty Constitution where
  pretty (Constitution script) = "constitutionScript:" <+> pretty script

instance PlutusTx.Eq Constitution where
  {-# INLINEABLE (==) #-}
  Constitution a == Constitution a' = a PlutusTx.== a'

data ProtocolVersion = ProtocolVersion
  { pvMajor :: Haskell.Integer
  , pvMinor :: Haskell.Integer
  }
  deriving stock (Generic, Haskell.Show, Haskell.Eq)

instance Pretty ProtocolVersion where
  pretty ProtocolVersion{..} =
    vsep
      [ "pvMajor:" <+> pretty pvMajor
      , "pvMinor:" <+> pretty pvMinor
      ]

instance PlutusTx.Eq ProtocolVersion where
  {-# INLINEABLE (==) #-}
  ProtocolVersion a b == ProtocolVersion a' b' =
    a PlutusTx.== a' PlutusTx.&& b PlutusTx.== b'

{- | A Plutus Data object containing proposed parameter changes. The Data object contains
a @Map@ with one entry per changed parameter, from the parameter name to the new value.
Unchanged parameters are not included.
-}
newtype ChangedParameters = ChangedParameters {getChangedParameters :: PlutusTx.BuiltinData}
  deriving stock (Generic, Haskell.Show)
  deriving newtype
    ( Haskell.Eq
    , Haskell.Ord
    , PlutusTx.Eq
    , PlutusTx.ToData
    , PlutusTx.FromData
    , PlutusTx.UnsafeFromData
    , Pretty
    )

data GovernanceAction
  = ParameterChange
      (Haskell.Maybe GovernanceActionId)
      ChangedParameters
      (Haskell.Maybe V2.ScriptHash) -- ^ Hash of the constitution script
  | -- | proposal to update protocol version
    HardForkInitiation (Haskell.Maybe GovernanceActionId) ProtocolVersion
  | TreasuryWithdrawals
      (Map V2.Credential V2.Value)
      (Haskell.Maybe V2.ScriptHash) -- ^ Hash of the constitution script
  | NoConfidence (Haskell.Maybe GovernanceActionId)
  | NewCommittee
      (Haskell.Maybe GovernanceActionId)
      [ColdCommitteeCredential] -- ^ Old committee
      Committee -- ^ New Committee
  | NewConstitution (Haskell.Maybe GovernanceActionId) Constitution
  | InfoAction
  deriving stock (Generic, Haskell.Show, Haskell.Eq)
  deriving (Pretty) via (PrettyShow GovernanceAction)

instance PlutusTx.Eq GovernanceAction where
  {-# INLINEABLE (==) #-}
  ParameterChange a b c == ParameterChange a' b' c' =
    a PlutusTx.== a' PlutusTx.&& b PlutusTx.== b' PlutusTx.&& c PlutusTx.== c'
  HardForkInitiation a b == HardForkInitiation a' b' =
    a PlutusTx.== a' PlutusTx.&& b PlutusTx.== b'
  TreasuryWithdrawals a b == TreasuryWithdrawals a' b' =
    a PlutusTx.== a' PlutusTx.&& b PlutusTx.== b'
  NoConfidence a == NoConfidence a' = a PlutusTx.== a'
  NewCommittee a b c == NewCommittee a' b' c' =
    a PlutusTx.== a' PlutusTx.&& b PlutusTx.== b' PlutusTx.&& c PlutusTx.== c'
  NewConstitution a b == NewConstitution a' b' =
    a PlutusTx.== a' PlutusTx.&& b PlutusTx.== b'
  InfoAction == InfoAction = Haskell.True
  _ == _ = Haskell.False

-- | A proposal procedure. The optional anchor is omitted.
data ProposalProcedure = ProposalProcedure
  { ppDeposit          :: V2.Value
  , ppReturnAddr       :: V2.Credential
  , ppGovernanceAction :: GovernanceAction
  }
  deriving stock (Generic, Haskell.Show, Haskell.Eq)

instance Pretty ProposalProcedure where
  pretty ProposalProcedure{..} =
    vsep
      [ "ppDeposit:" <+> pretty ppDeposit
      , "ppReturnAddr:" <+> pretty ppReturnAddr
      , "ppGovernanceAction:" <+> pretty ppGovernanceAction
      ]

instance PlutusTx.Eq ProposalProcedure where
  {-# INLINEABLE (==) #-}
  ProposalProcedure a b c == ProposalProcedure a' b' c' =
    a PlutusTx.== a'
      PlutusTx.&& b PlutusTx.== b'
      PlutusTx.&& c PlutusTx.== c'

data ScriptPurpose
  = Minting V2.CurrencySymbol
  | Spending V2.TxOutRef
  | Rewarding V2.Credential
  | Certifying TxCert
  | Voting Voter GovernanceActionId
  | Proposing Haskell.Integer
  deriving stock (Generic, Haskell.Show, Haskell.Eq)
  deriving (Pretty) via (PrettyShow ScriptPurpose)

instance PlutusTx.Eq ScriptPurpose where
  {-# INLINEABLE (==) #-}
  Minting a == Minting a' =
    a PlutusTx.== a'
  Spending a == Spending a' =
    a PlutusTx.== a'
  Rewarding a == Rewarding a' =
    a PlutusTx.== a'
  Certifying a == Certifying a' =
    a PlutusTx.== a'
  Voting a b == Voting a' b' =
    a PlutusTx.== a' PlutusTx.&& b PlutusTx.== b'
  Proposing a == Proposing a' =
    a PlutusTx.== a'
  _ == _ = Haskell.False

-- | TxInfo for PlutusV3
data TxInfo = TxInfo
  { txInfoInputs                :: [V2.TxInInfo]
  , txInfoReferenceInputs       :: [V2.TxInInfo]
  , txInfoOutputs               :: [V2.TxOut]
  , txInfoFee                   :: V2.Lovelace
  , txInfoMint                  :: V2.Value
  , txInfoTxCerts               :: [TxCert]
  , txInfoWdrl                  :: Map V2.Credential V2.Lovelace
  , txInfoValidRange            :: V2.POSIXTimeRange
  , txInfoSignatories           :: [V2.PubKeyHash]
  , txInfoRedeemers             :: Map ScriptPurpose V2.Redeemer
  , txInfoData                  :: Map V2.DatumHash V2.Datum
  , txInfoId                    :: V2.TxId
  , txInfoVotes                 :: Map Voter (Map GovernanceActionId Vote)
  , txInfoProposalProcedures    :: [ProposalProcedure]
  , txInfoCurrentTreasuryAmount :: Haskell.Maybe V2.Lovelace
  , txInfoTreasuryDonation      :: Haskell.Maybe V2.Lovelace
  }
  deriving stock (Generic, Haskell.Show, Haskell.Eq)

instance Pretty TxInfo where
  pretty TxInfo{..} =
    vsep
      [ "TxId:" <+> pretty txInfoId
      , "Inputs:" <+> pretty txInfoInputs
      , "Reference inputs:" <+> pretty txInfoReferenceInputs
      , "Outputs:" <+> pretty txInfoOutputs
      , "Fee:" <+> pretty txInfoFee
      , "Value minted:" <+> pretty txInfoMint
      , "TxCerts:" <+> pretty txInfoTxCerts
      , "Wdrl:" <+> pretty txInfoWdrl
      , "Valid range:" <+> pretty txInfoValidRange
      , "Signatories:" <+> pretty txInfoSignatories
      , "Redeemers:" <+> pretty txInfoRedeemers
      , "Datums:" <+> pretty txInfoData
      , "Votes:" <+> pretty txInfoVotes
      , "Proposal Procedures:" <+> pretty txInfoProposalProcedures
      , "Current Treasury Amount:" <+> pretty txInfoCurrentTreasuryAmount
      , "Treasury Donation:" <+> pretty txInfoTreasuryDonation
      ]

instance PlutusTx.Eq TxInfo where
  {-# INLINEABLE (==) #-}
  TxInfo a b c d e f g h i j k l m n o p
    == TxInfo a' b' c' d' e' f' g' h' i' j' k' l' m' n' o' p' =
      a PlutusTx.== a'
        PlutusTx.&& b PlutusTx.== b'
        PlutusTx.&& c PlutusTx.== c'
        PlutusTx.&& d PlutusTx.== d'
        PlutusTx.&& e PlutusTx.== e'
        PlutusTx.&& f PlutusTx.== f'
        PlutusTx.&& g PlutusTx.== g'
        PlutusTx.&& h PlutusTx.== h'
        PlutusTx.&& i PlutusTx.== i'
        PlutusTx.&& j PlutusTx.== j'
        PlutusTx.&& k PlutusTx.== k'
        PlutusTx.&& l PlutusTx.== l'
        PlutusTx.&& m PlutusTx.== m'
        PlutusTx.&& n PlutusTx.== n'
        PlutusTx.&& o PlutusTx.== o'
        PlutusTx.&& p PlutusTx.== p'

-- | The context that the currently-executing script can access.
data ScriptContext = ScriptContext
  { scriptContextTxInfo  :: TxInfo
  -- ^ information about the transaction the currently-executing script is included in
  , scriptContextPurpose :: ScriptPurpose
  -- ^ the purpose of the currently-executing script
  }
  deriving stock (Generic, Haskell.Eq, Haskell.Show)

instance Pretty ScriptContext where
  pretty ScriptContext{..} =
    vsep
      [ "Purpose:" <+> pretty scriptContextPurpose
      , nest 2 (vsep ["TxInfo:", pretty scriptContextTxInfo])
      ]

instance PlutusTx.Eq ScriptContext where
  {-# INLINEABLE (==) #-}
  ScriptContext a b == ScriptContext a' b' =
    a PlutusTx.== a' PlutusTx.&& b PlutusTx.== b'

{-# INLINEABLE findOwnInput #-}

-- | Find the input currently being validated.
findOwnInput :: ScriptContext -> Haskell.Maybe V2.TxInInfo
findOwnInput
  ScriptContext
    { scriptContextTxInfo = TxInfo{txInfoInputs}
    , scriptContextPurpose = Spending txOutRef
    } =
    PlutusTx.find
      (\V2.TxInInfo{txInInfoOutRef} -> txInInfoOutRef PlutusTx.== txOutRef)
      txInfoInputs
findOwnInput _ = Haskell.Nothing

{-# INLINEABLE findDatum #-}

-- | Find the data corresponding to a data hash, if there is one
findDatum :: V2.DatumHash -> TxInfo -> Haskell.Maybe V2.Datum
findDatum dsh TxInfo{txInfoData} = lookup dsh txInfoData

{-# INLINEABLE findDatumHash #-}

{- | Find the hash of a datum, if it is part of the pending transaction's
hashes
-}
findDatumHash :: V2.Datum -> TxInfo -> Haskell.Maybe V2.DatumHash
findDatumHash ds TxInfo{txInfoData} =
  PlutusTx.fst PlutusTx.<$> PlutusTx.find f (toList txInfoData)
  where
    f (_, ds') = ds' PlutusTx.== ds

{-# INLINEABLE findTxInByTxOutRef #-}

{- | Given a UTXO reference and a transaction (`TxInfo`), resolve it to one of the
transaction's inputs (`TxInInfo`).

Note: this only searches the true transaction inputs and not the referenced transaction inputs.
-}
findTxInByTxOutRef :: V2.TxOutRef -> TxInfo -> Haskell.Maybe V2.TxInInfo
findTxInByTxOutRef outRef TxInfo{txInfoInputs} =
  PlutusTx.find
    (\V2.TxInInfo{txInInfoOutRef} -> txInInfoOutRef PlutusTx.== outRef)
    txInfoInputs

{-# INLINEABLE findContinuingOutputs #-}

{- | Find the indices of all the outputs that pay to the same script address we are
currently spending from, if any.
-}
findContinuingOutputs :: ScriptContext -> [Haskell.Integer]
findContinuingOutputs ctx
  | Haskell.Just V2.TxInInfo{txInInfoResolved = V2.TxOut{txOutAddress}} <-
      findOwnInput ctx =
      PlutusTx.findIndices
        (f txOutAddress)
        (txInfoOutputs (scriptContextTxInfo ctx))
  where
    f addr V2.TxOut{txOutAddress = otherAddress} = addr PlutusTx.== otherAddress
findContinuingOutputs _ = PlutusTx.traceError "Le" -- "Can't find any continuing outputs"

{-# INLINEABLE getContinuingOutputs #-}

{- | Get all the outputs that pay to the same script address we are currently spending
from, if any.
-}
getContinuingOutputs :: ScriptContext -> [V2.TxOut]
getContinuingOutputs ctx
  | Haskell.Just V2.TxInInfo{txInInfoResolved = V2.TxOut{txOutAddress}} <-
      findOwnInput ctx =
      PlutusTx.filter (f txOutAddress) (txInfoOutputs (scriptContextTxInfo ctx))
  where
    f addr V2.TxOut{txOutAddress = otherAddress} = addr PlutusTx.== otherAddress
getContinuingOutputs _ = PlutusTx.traceError "Lf" -- "Can't get any continuing outputs"

{-# INLINEABLE txSignedBy #-}

-- | Check if a transaction was signed by the given public key.
txSignedBy :: TxInfo -> V2.PubKeyHash -> Haskell.Bool
txSignedBy TxInfo{txInfoSignatories} k = case PlutusTx.find ((PlutusTx.==) k) txInfoSignatories of
  Haskell.Just _  -> Haskell.True
  Haskell.Nothing -> Haskell.False

{-# INLINEABLE pubKeyOutputsAt #-}

-- | Get the values paid to a public key address by a pending transaction.
pubKeyOutputsAt :: V2.PubKeyHash -> TxInfo -> [V2.Value]
pubKeyOutputsAt pk p =
  let flt V2.TxOut{txOutAddress = V2.Address (V2.PubKeyCredential pk') _, txOutValue}
        | pk PlutusTx.== pk' = Haskell.Just txOutValue
      flt _ = Haskell.Nothing
   in PlutusTx.mapMaybe flt (txInfoOutputs p)

{-# INLINEABLE valuePaidTo #-}

-- | Get the total value paid to a public key address by a pending transaction.
valuePaidTo :: TxInfo -> V2.PubKeyHash -> V2.Value
valuePaidTo ptx pkh = PlutusTx.mconcat (pubKeyOutputsAt pkh ptx)

{-# INLINEABLE valueSpent #-}

-- | Get the total value of inputs spent by this transaction.
valueSpent :: TxInfo -> V2.Value
valueSpent =
  PlutusTx.foldMap
    (V2.txOutValue PlutusTx.. V2.txInInfoResolved)
    PlutusTx.. txInfoInputs

{-# INLINEABLE valueProduced #-}

-- | Get the total value of outputs produced by this transaction.
valueProduced :: TxInfo -> V2.Value
valueProduced = PlutusTx.foldMap V2.txOutValue PlutusTx.. txInfoOutputs

{-# INLINEABLE ownCurrencySymbol #-}

-- | The 'CurrencySymbol' of the current validator script.
ownCurrencySymbol :: ScriptContext -> V2.CurrencySymbol
ownCurrencySymbol ScriptContext{scriptContextPurpose = Minting cs} = cs
ownCurrencySymbol _ =
  -- "Can't get currency symbol of the current validator script"
  PlutusTx.traceError "Lh"

{-# INLINEABLE spendsOutput #-}

{- | Check if the pending transaction spends a specific transaction output
(identified by the hash of a transaction and an index into that
transactions' outputs)
-}
spendsOutput :: TxInfo -> V2.TxId -> Haskell.Integer -> Haskell.Bool
spendsOutput p h i =
  let spendsOutRef inp =
        let outRef = V2.txInInfoOutRef inp
         in h PlutusTx.== V2.txOutRefId outRef
              PlutusTx.&& i PlutusTx.== V2.txOutRefIdx outRef
   in PlutusTx.any spendsOutRef (txInfoInputs p)

PlutusTx.makeLift ''ColdCommitteeCredential
PlutusTx.makeLift ''HotCommitteeCredential
PlutusTx.makeLift ''DRepCredential

PlutusTx.makeLift ''DRep
PlutusTx.makeIsDataIndexed
  ''DRep
  [ ('DRep, 0)
  , ('DRepAlwaysAbstain, 1)
  , ('DRepAlwaysNoConfidence, 2)
  ]

PlutusTx.makeLift ''Delegatee
PlutusTx.makeIsDataIndexed
  ''Delegatee
  [ ('DelegStake, 0)
  , ('DelegVote, 1)
  , ('DelegStakeVote, 2)
  ]

PlutusTx.makeLift ''TxCert
PlutusTx.makeIsDataIndexed
  ''TxCert
  [ ('TxCertRegStaking, 0)
  , ('TxCertUnRegStaking, 1)
  , ('TxCertDelegStaking, 2)
  , ('TxCertRegDeleg, 3)
  , ('TxCertRegDRep, 4)
  , ('TxCertUpdateDRep, 5)
  , ('TxCertUnRegDRep, 6)
  , ('TxCertPoolRegister, 7)
  , ('TxCertPoolRetire, 8)
  , ('TxCertAuthHotCommittee, 9)
  , ('TxCertResignColdCommittee, 10)
  ]

PlutusTx.makeLift ''Voter
PlutusTx.makeIsDataIndexed
  ''Voter
  [ ('CommitteeVoter, 0)
  , ('DRepVoter, 1)
  , ('StakePoolVoter, 2)
  ]

PlutusTx.makeLift ''Vote
PlutusTx.makeIsDataIndexed
  ''Vote
  [ ('VoteNo, 0)
  , ('VoteYes, 1)
  , ('Abstain, 2)
  ]

PlutusTx.makeLift ''GovernanceActionId
PlutusTx.makeIsDataIndexed ''GovernanceActionId [('GovernanceActionId, 0)]

PlutusTx.makeLift ''Committee
PlutusTx.makeIsDataIndexed ''Committee [('Committee, 0)]

PlutusTx.makeLift ''Constitution
PlutusTx.makeIsDataIndexed ''Constitution [('Constitution, 0)]

PlutusTx.makeLift ''ProtocolVersion
PlutusTx.makeIsDataIndexed ''ProtocolVersion [('ProtocolVersion, 0)]

PlutusTx.makeLift ''ChangedParameters
PlutusTx.makeLift ''GovernanceAction
PlutusTx.makeIsDataIndexed
  ''GovernanceAction
  [ ('ParameterChange, 0)
  , ('HardForkInitiation, 1)
  , ('TreasuryWithdrawals, 2)
  , ('NoConfidence, 3)
  , ('NewCommittee, 4)
  , ('NewConstitution, 5)
  , ('InfoAction, 6)
  ]

PlutusTx.makeLift ''ProposalProcedure
PlutusTx.makeIsDataIndexed ''ProposalProcedure [('ProposalProcedure, 0)]

PlutusTx.makeLift ''ScriptPurpose
PlutusTx.makeIsDataIndexed
  ''ScriptPurpose
  [ ('Minting, 0)
  , ('Spending, 1)
  , ('Rewarding, 2)
  , ('Certifying, 3)
  , ('Voting, 4)
  , ('Proposing, 5)
  ]

PlutusTx.makeLift ''TxInfo
PlutusTx.makeIsDataIndexed ''TxInfo [('TxInfo, 0)]

PlutusTx.makeLift ''ScriptContext
PlutusTx.makeIsDataIndexed ''ScriptContext [('ScriptContext, 0)]
