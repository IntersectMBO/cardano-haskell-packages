# Version history for `vector-map`

## 1.1.0.1

*

## 1.1.0.0

* Moved `ToExpr` instances out of the main library and into the testlib.

## 1.0.1.0

* Add `ToJSON`/`FromJSON` instances for `VMap`

## 1.0.0.0

* First properly versioned release
