{-# LANGUAGE BangPatterns #-}
{-# LANGUAGE CPP #-}
{-# LANGUAGE DataKinds #-}
{-# LANGUAGE DerivingVia #-}
{-# LANGUAGE GADTs #-}
{-# LANGUAGE LambdaCase #-}
{-# LANGUAGE MagicHash #-}
{-# LANGUAGE RankNTypes #-}
{-# LANGUAGE ScopedTypeVariables #-}
{-# LANGUAGE StandaloneDeriving #-}
{-# LANGUAGE TypeApplications #-}
{-# LANGUAGE TypeFamilyDependencies #-}
{-# LANGUAGE UnboxedTuples #-}

{- FOURMOLU_DISABLE -}
module Cardano.Crypto.PackedBytes.Internal
  ( PackedBytes(..)
  , packBytes
  , packBytesMaybe
  , packByteString
  , packShortByteString
  , packShortByteStringWithOffset
  , packPinnedBytes
  , unpackAsByteArray
  , unpackBytes
  , unpackPinnedBytes
  , xorPackedBytes
  ) where

import Codec.CBOR.Decoding as D (decodeBytes)
import Cardano.Base.Bytes (byteArrayToByteString)
import Cardano.Binary (FromCBOR (..), ToCBOR (..), Size)
import Control.DeepSeq (NFData(..))
import Control.Monad (unless, when)
import Control.Monad.Primitive (primitive_)
import Control.Monad.Reader (MonadReader(ask), MonadTrans(lift))
import Control.Monad.State.Strict (MonadState(state))
import Data.Bits
import Data.ByteString as BS
import Data.ByteString.Internal as BS (accursedUnutterablePerformIO, toForeignPtr)
import Data.ByteString.Short.Internal as SBS
import Data.MemPack (guardAdvanceUnpack, st_, MemPack(..), Pack(Pack))
import Data.MemPack.Buffer (Buffer(buffer), byteArrayToShortByteString)
import Data.Primitive.ByteArray
import Data.Primitive.PrimArray (PrimArray(..), imapPrimArray, indexPrimArray)
import Data.Typeable
import Foreign.ForeignPtr
import Foreign.Ptr (castPtr)
import Foreign.Storable (Storable(..))
import GHC.Exts
#if MIN_VERSION_base(4,15,0)
import GHC.ForeignPtr (unsafeWithForeignPtr)
#endif
import GHC.ST
import GHC.TypeLits
import GHC.Word
import NoThunks.Class

#include "MachDeps.h"


data PackedBytes (n :: Nat) where
  PackedBytes8  :: {-# UNPACK #-} !Word64
                -> PackedBytes 8
  PackedBytes28 :: {-# UNPACK #-} !Word64
                -> {-# UNPACK #-} !Word64
                -> {-# UNPACK #-} !Word64
                -> {-# UNPACK #-} !Word32
                -> PackedBytes 28
  PackedBytes32 :: {-# UNPACK #-} !Word64
                -> {-# UNPACK #-} !Word64
                -> {-# UNPACK #-} !Word64
                -> {-# UNPACK #-} !Word64
                -> PackedBytes 32
  PackedBytes# :: ByteArray# -> PackedBytes n

deriving via OnlyCheckWhnfNamed "PackedBytes" (PackedBytes n) instance NoThunks (PackedBytes n)

instance Eq (PackedBytes n) where
  PackedBytes8 x == PackedBytes8 y = x == y
  PackedBytes28 x0 x1 x2 x3 == PackedBytes28 y0 y1 y2 y3 =
    x0 == y0 && x1 == y1 && x2 == y2 && x3 == y3
  PackedBytes32 x0 x1 x2 x3 == PackedBytes32 y0 y1 y2 y3 =
    x0 == y0 && x1 == y1 && x2 == y2 && x3 == y3
  x1 == x2 = unpackBytes x1 == unpackBytes x2
  {-# INLINE (==) #-}

instance Ord (PackedBytes n) where
  compare (PackedBytes8 x) (PackedBytes8 y) = compare x y
  compare (PackedBytes28 x0 x1 x2 x3) (PackedBytes28 y0 y1 y2 y3) =
    compare x0 y0 <> compare x1 y1 <> compare x2 y2 <> compare x3 y3
  compare (PackedBytes32 x0 x1 x2 x3) (PackedBytes32 y0 y1 y2 y3) =
    compare x0 y0 <> compare x1 y1 <> compare x2 y2 <> compare x3 y3
  compare x1 x2 = compare (unpackBytes x1) (unpackBytes x2)
  {-# INLINE compare #-}

instance NFData (PackedBytes n) where
  rnf PackedBytes8  {} = ()
  rnf PackedBytes28 {} = ()
  rnf PackedBytes32 {} = ()
  rnf PackedBytes#  {} = ()

instance KnownNat n => MemPack (PackedBytes n) where
  packedByteCount = fromInteger @Int . natVal
  {-# INLINE packedByteCount #-}
  packM pb = do
    let !len@(I# len#) = packedByteCount pb
    i@(I# i#) <- state $ \i -> (i, i + len)
    mba@(MutableByteArray mba#) <- ask
    Pack $ \_ -> lift $ case pb of
      PackedBytes8 w -> writeWord64BE mba i w
      PackedBytes28 w0 w1 w2 w3 -> do
        writeWord64BE mba i        w0
        writeWord64BE mba (i + 8)  w1
        writeWord64BE mba (i + 16) w2
        writeWord32BE mba (i + 24) w3
      PackedBytes32 w0 w1 w2 w3 -> do
        writeWord64BE mba i        w0
        writeWord64BE mba (i + 8)  w1
        writeWord64BE mba (i + 16) w2
        writeWord64BE mba (i + 24) w3
      PackedBytes# ba# ->
        st_ (copyByteArray# ba# 0# mba# i# len#)
  {-# INLINE packM #-}
  unpackM = do
    let !len = fromInteger @Int $ natVal' (proxy# :: Proxy# n)
    curPos@(I# curPos#) <- guardAdvanceUnpack len
    buf <- ask
    pure $! buffer buf
#if MIN_VERSION_mempack(0,2,0)
      (\ba# off# -> packBytes (SBS.SBS ba#) (curPos + I# off#))
#else
      (\ba# -> packBytes (SBS.SBS ba#) curPos)
#endif
      -- Usage of `accursedUnutterablePerformIO` is safe below because there are no memory
      -- allocations happening that depend on the IO monad that we are excaping here. All
      -- IO actions are morally pure reads using pointers into the immutable
      -- memory. Furthermore, in the place where ByteArray is allocated in
      -- `packPinnedPtrN`, mutation and freezing are encapsulated with `runST` and is not
      -- related to the `IO` we are escaping.
      (\addr# -> accursedUnutterablePerformIO $ packPinnedPtr (Ptr (addr# `plusAddr#` curPos#)))
  {-# INLINE unpackM #-}

instance KnownNat n => ToCBOR (PackedBytes n) where
  toCBOR = toCBOR . unpackBytes
  {-# INLINE toCBOR #-}

  encodedSizeExpr _size proxy =
    encodedSizeExpr (const packedBytesSize) (unpackBytes <$> proxy)
    where
      packedBytesSize :: Size
      packedBytesSize = fromInteger (natVal' (proxy# @n))

instance KnownNat n => FromCBOR (PackedBytes n) where
  fromCBOR = D.decodeBytes >>= packByteString
  {-# INLINE fromCBOR #-}

instance KnownNat n => Storable (PackedBytes n) where
  sizeOf _ = fromInteger @Int (natVal' (proxy# @n))
  alignment a =
    -- First explicit values for specialized cases to make alignment dead obvious
    case sizeOf a of
      8 -> 8
      28 -> 32
      32 -> 32
      n   -- Cache line on modern CPUs is 64 bytes, higher alignment is unnecessary
        | n >= 64 -> 64
          -- Size is already power of two or zero:
        | popCount n <= 1 -> n
          -- Otherwise set the next highest bit, making it the next closest power of two
        | otherwise -> bit (finiteBitSize n - countLeadingZeros n)

  poke pbPtr = \case
    PackedBytes8 w -> poke (castPtr pbPtr) w
    PackedBytes28 w0 w1 w2 w3 ->
      let ptr = castPtr pbPtr
      in poke ptr w0 >>
          pokeElemOff ptr 1 w1 >>
          pokeElemOff ptr 2 w2 >>
          pokeByteOff (castPtr pbPtr) (8 * 3) w3
    PackedBytes32 w0 w1 w2 w3 ->
      let ptr = castPtr pbPtr
      in poke ptr w0 >>
          pokeElemOff ptr 1 w1 >>
          pokeElemOff ptr 2 w2 >>
          pokeElemOff ptr 3 w3
    PackedBytes# ba# -> do
      copyByteArrayToAddr (castPtr pbPtr) (ByteArray ba#) 0 (fromInteger @Int (natVal' (proxy# @n)))
  {-# INLINE poke #-}
  peek pbPtr =
    let px = Proxy :: Proxy n
     in case sameNat px (Proxy :: Proxy 8) of
          Just Refl -> PackedBytes8 <$> peek (castPtr pbPtr)
          Nothing -> case sameNat px (Proxy :: Proxy 28) of
            Just Refl -> peek28 pbPtr
            Nothing -> case sameNat px (Proxy :: Proxy 32) of
              Just Refl -> peek32 pbPtr
              Nothing -> do
                let n = fromInteger @Int (natVal' (proxy# @n))
                mba <- newByteArray n
                copyPtrToMutableByteArray mba 0 (castPtr pbPtr :: Ptr Word8) n
                ByteArray ba# <- unsafeFreezeByteArray mba
                pure $ PackedBytes# ba#
  {-# INLINE[1] peek #-}

peek28 :: Ptr (PackedBytes 28) -> IO (PackedBytes 28)
peek28 pbPtr = do
  let ptr = castPtr pbPtr
  w0 <- peek ptr
  w1 <- peekElemOff ptr 1
  w2 <- peekElemOff ptr 2
  w3 <- peekByteOff (castPtr pbPtr) (8 * 3)
  pure $ PackedBytes28 w0 w1 w2 w3
{-# INLINE peek28 #-}

peek32 :: Ptr (PackedBytes 32) -> IO (PackedBytes 32)
peek32 pbPtr = do
  let ptr = castPtr pbPtr
  w0 <- peek ptr
  w1 <- peekElemOff ptr 1
  w2 <- peekElemOff ptr 2
  w3 <- peekElemOff ptr 3
  pure $ PackedBytes32 w0 w1 w2 w3
{-# INLINE peek32 #-}

{-# RULES
"peek28" peek = peek28
"peek32" peek = peek32
  #-}

xorPackedBytes :: PackedBytes n -> PackedBytes n -> PackedBytes n
xorPackedBytes (PackedBytes8 x) (PackedBytes8 y) = PackedBytes8 (x `xor` y)
xorPackedBytes (PackedBytes28 x0 x1 x2 x3) (PackedBytes28 y0 y1 y2 y3) =
  PackedBytes28 (x0 `xor` y0) (x1 `xor` y1) (x2 `xor` y2) (x3 `xor` y3)
xorPackedBytes (PackedBytes32 x0 x1 x2 x3) (PackedBytes32 y0 y1 y2 y3) =
  PackedBytes32 (x0 `xor` y0) (x1 `xor` y1) (x2 `xor` y2) (x3 `xor` y3)
xorPackedBytes (PackedBytes# ba1#) (PackedBytes# ba2#) =
  let pa1 = PrimArray ba1# :: PrimArray Word8
      pa2 = PrimArray ba2# :: PrimArray Word8
   in case imapPrimArray (xor . indexPrimArray pa1) pa2 of
        PrimArray pa# -> PackedBytes# pa#
xorPackedBytes _ _ =
  error "Impossible case. GHC can't figure out that pattern match is exhaustive."
{-# INLINE xorPackedBytes #-}


withMutableByteArray :: Int -> (forall s . MutableByteArray s -> ST s ()) -> ByteArray
withMutableByteArray n f = do
  runST $ do
    mba <- newByteArray n
    f mba
    unsafeFreezeByteArray mba
{-# INLINE withMutableByteArray #-}

withPinnedMutableByteArray :: Int -> (forall s . MutableByteArray s -> ST s ()) -> ByteArray
withPinnedMutableByteArray n f = do
  runST $ do
    mba <- newPinnedByteArray n
    f mba
    unsafeFreezeByteArray mba
{-# INLINE withPinnedMutableByteArray #-}

unpackAsByteArray :: PackedBytes n -> ByteArray
unpackAsByteArray = unpackBytesWith withMutableByteArray
{-# INLINE unpackAsByteArray #-}

unpackBytes :: PackedBytes n -> ShortByteString
unpackBytes = byteArrayToShortByteString . unpackBytesWith withMutableByteArray
{-# INLINE unpackBytes #-}

unpackPinnedBytes :: PackedBytes n -> ByteString
unpackPinnedBytes = byteArrayToByteString . unpackBytesWith withPinnedMutableByteArray
{-# INLINE unpackPinnedBytes #-}


unpackBytesWith ::
     (Int -> (forall s. MutableByteArray s -> ST s ()) -> ByteArray)
  -> PackedBytes n
  -> ByteArray
unpackBytesWith allocate (PackedBytes8 w) =
  allocate 8  $ \mba -> writeWord64BE mba 0 w
unpackBytesWith allocate (PackedBytes28 w0 w1 w2 w3) =
  allocate 28 $ \mba -> do
    writeWord64BE mba 0  w0
    writeWord64BE mba 8  w1
    writeWord64BE mba 16 w2
    writeWord32BE mba 24 w3
unpackBytesWith allocate (PackedBytes32 w0 w1 w2 w3) =
  allocate 32 $ \mba -> do
    writeWord64BE mba 0  w0
    writeWord64BE mba 8  w1
    writeWord64BE mba 16 w2
    writeWord64BE mba 24 w3
unpackBytesWith _ (PackedBytes# ba#) = ByteArray ba#
{-# INLINE unpackBytesWith #-}


packBytes8 :: ShortByteString -> Int -> PackedBytes 8
packBytes8 (SBS ba#) offset =
  let ba = ByteArray ba#
   in PackedBytes8 (indexWord64BE ba offset)
{-# INLINE packBytes8 #-}

packBytes28 :: ShortByteString -> Int -> PackedBytes 28
packBytes28 (SBS ba#) offset =
  let ba = ByteArray ba#
  in PackedBytes28
       (indexWord64BE ba offset)
       (indexWord64BE ba (offset + 8))
       (indexWord64BE ba (offset + 16))
       (indexWord32BE ba (offset + 24))
{-# INLINE packBytes28 #-}

packBytes32 :: ShortByteString -> Int -> PackedBytes 32
packBytes32 (SBS ba#) offset =
  let ba = ByteArray ba#
  in PackedBytes32
       (indexWord64BE ba offset)
       (indexWord64BE ba (offset + 8))
       (indexWord64BE ba (offset + 16))
       (indexWord64BE ba (offset + 24))
{-# INLINE packBytes32 #-}

packBytes :: forall n . KnownNat n => ShortByteString -> Int -> PackedBytes n
packBytes sbs@(SBS ba#) offset =
  let px = Proxy :: Proxy n
      n = fromInteger (natVal px)
      ba = ByteArray ba#
   in case sameNat px (Proxy :: Proxy 8) of
        Just Refl -> packBytes8 sbs offset
        Nothing -> case sameNat px (Proxy :: Proxy 28) of
          Just Refl -> packBytes28 sbs offset
          Nothing -> case sameNat px (Proxy :: Proxy 32) of
            Just Refl -> packBytes32 sbs offset
            Nothing
              | offset == 0
              , sizeofByteArray ba == n -> PackedBytes# ba#
            Nothing ->
              let !(ByteArray slice#) = cloneByteArray ba offset n
               in PackedBytes# slice#
{-# INLINE[1] packBytes #-}

{-# RULES
"packBytes8"  packBytes = packBytes8
"packBytes28" packBytes = packBytes28
"packBytes32" packBytes = packBytes32
  #-}

-- | Construct `PackedBytes` from a `ShortByteString` and a non-negative offset
-- in number of bytes from the beginning. This function is safe.
packBytesMaybe :: forall n . KnownNat n => ShortByteString -> Int -> Maybe (PackedBytes n)
packBytesMaybe = packShortByteStringWithOffset
{-# INLINE packBytesMaybe #-}
{-# DEPRECATED packBytesMaybe "In favor of `packShortByteStringWithOffset`" #-}

-- | Construct `PackedBytes` from a `ShortByteString`. This function is safe and will fail
--  if the buffer size does not match expected size of packed bytes exactly.
--
-- @since 2.3.0.0
packByteString :: forall n m. (KnownNat n, MonadFail m) => ByteString -> m (PackedBytes n)
packByteString = packedBytesSizeGuard BS.length packPinnedBytes
{-# INLINE packByteString #-}

-- | Construct `PackedBytes` from a `ShortByteString`. This function is safe and will fail
--  if the buffer size does not match expected size of packed bytes exactly.
--
-- @since 2.3.0.0
packShortByteString :: forall n m. (KnownNat n, MonadFail m) => ShortByteString -> m (PackedBytes n)
packShortByteString = packedBytesSizeGuard SBS.length (`packBytes` 0)
{-# INLINE packShortByteString #-}

packedBytesSizeGuard ::
  forall b n m. (KnownNat n, MonadFail m) =>
  -- | Function for getting the size of the source buffer
  (b -> Int) ->
  -- | Function for packing the buffer in full
  (b -> PackedBytes n) ->
  -- | The actual buffer to be packed
  b ->
  m (PackedBytes n)
packedBytesSizeGuard getSizeOfBuffer packBuffer buf = do
  let bufferSize = getSizeOfBuffer buf
      size = fromInteger (natVal' (proxy# @n))
  unless (size == bufferSize) $ do
    fail $ "Number of bytes mismatch. Expected " <> show size <> " number of bytes, but got " <> show bufferSize
  pure $ packBuffer buf
{-# INLINE packedBytesSizeGuard #-}

-- | Construct `PackedBytes` from a `ShortByteString` and a non-negative offset in number of bytes
-- from the beginning. This function is safe, but it only checks whether there are enough
-- bytes. I.e. it doesn't enforce full buffer consumption. If you need to check that
-- buffer has no other data except what is being packed, then use `packShortByteString` instead
--
-- @since 2.2.4.0
packShortByteStringWithOffset ::
  forall n m. (KnownNat n, MonadFail m) =>
  ShortByteString ->
  -- ^ Buffer to read data from
  Int ->
  -- ^ Non-negative offset into the buffer, where packing will start from.
  m (PackedBytes n)
packShortByteStringWithOffset bs offset = do
  let bufferSize = SBS.length bs
      size = fromInteger (natVal' (proxy# @n))
  when (offset < 0) $ do
    fail $ "Expected non-negative offset, but got: " <> show offset
  when (size > bufferSize - offset) $ do
    fail $ mconcat [ "Not enough data. Expected to read "
                   , show size
                   , " number of bytes, but supplied buffer has only "
                   , show bufferSize
                   , ", which is not enough when reading from "
                   , show offset
                   , " offset."
                   ]
  pure $ packBytes bs offset
{-# INLINE packShortByteStringWithOffset #-}


packPinnedPtr8 :: Ptr a -> IO (PackedBytes 8)
packPinnedPtr8 = fmap PackedBytes8 . (`peekWord64BE` 0)
{-# INLINE packPinnedPtr8 #-}

packPinnedPtr28 :: Ptr a -> IO (PackedBytes 28)
packPinnedPtr28 ptr =
  PackedBytes28
    <$> peekWord64BE ptr 0
    <*> peekWord64BE ptr 8
    <*> peekWord64BE ptr 16
    <*> peekWord32BE ptr 24
{-# INLINE packPinnedPtr28 #-}

packPinnedPtr32 :: Ptr a -> IO (PackedBytes 32)
packPinnedPtr32 ptr =
  PackedBytes32 <$> peekWord64BE ptr 0
                <*> peekWord64BE ptr 8
                <*> peekWord64BE ptr 16
                <*> peekWord64BE ptr 24
{-# INLINE packPinnedPtr32 #-}

packPinnedPtrN :: forall n a. KnownNat n => Ptr a -> IO (PackedBytes n)
packPinnedPtrN (Ptr addr#) = pure $! PackedBytes# ba#
  where
    !(ByteArray ba#) = withMutableByteArray len $ \(MutableByteArray mba#) ->
           st_ (copyAddrToByteArray# addr# mba# 0# len#)
    !len@(I# len#) = fromInteger (natVal' (proxy# :: Proxy# n))
{-# INLINE packPinnedPtrN #-}

packPinnedPtr :: forall n a. KnownNat n => Ptr a -> IO (PackedBytes n)
packPinnedPtr bs =
  let px = Proxy :: Proxy n
   in case sameNat px (Proxy :: Proxy 8) of
        Just Refl -> packPinnedPtr8 bs
        Nothing -> case sameNat px (Proxy :: Proxy 28) of
          Just Refl -> packPinnedPtr28 bs
          Nothing -> case sameNat px (Proxy :: Proxy 32) of
            Just Refl -> packPinnedPtr32 bs
            Nothing   -> packPinnedPtrN bs
{-# INLINE[1] packPinnedPtr #-}
{-# RULES
"packPinnedPtr8"  packPinnedPtr = packPinnedPtr8
"packPinnedPtr28" packPinnedPtr = packPinnedPtr28
"packPinnedPtr32" packPinnedPtr = packPinnedPtr32
  #-}

packPinnedBytes :: forall n . KnownNat n => ByteString -> PackedBytes n
packPinnedBytes bs = unsafeWithByteStringPtr bs packPinnedPtr
{-# INLINE packPinnedBytes #-}


--- Primitive architecture agnostic helpers

#if WORD_SIZE_IN_BITS == 64

indexWord64BE :: ByteArray -> Int -> Word64
indexWord64BE (ByteArray ba#) (I# i#) =
#ifdef WORDS_BIGENDIAN
  W64# (indexWord8ArrayAsWord64# ba# i#)
#else
  W64# (byteSwap64# (indexWord8ArrayAsWord64# ba# i#))
#endif
{-# INLINE indexWord64BE #-}

peekWord64BE :: Ptr a -> Int -> IO Word64
peekWord64BE ptr i =
#ifndef WORDS_BIGENDIAN
  byteSwap64 <$>
#endif
  peekByteOff (castPtr ptr) i
{-# INLINE peekWord64BE #-}


writeWord64BE :: MutableByteArray s -> Int -> Word64 -> ST s ()
writeWord64BE (MutableByteArray mba#) (I# i#) (W64# w#) =
  primitive_ (writeWord8ArrayAsWord64# mba# i# wbe#)
  where
#ifdef WORDS_BIGENDIAN
    !wbe# = w#
#else
    !wbe# = byteSwap64# w#
#endif
{-# INLINE writeWord64BE #-}

#elif WORD_SIZE_IN_BITS == 32

indexWord64BE :: ByteArray -> Int -> Word64
indexWord64BE ba i =
  (fromIntegral @Word32 @Word64 (indexWord32BE ba i) `shiftL` 32) .|. fromIntegral @Word32 @Word64 (indexWord32BE ba (i + 4))
{-# INLINE indexWord64BE #-}

peekWord64BE :: Ptr a -> Int -> IO Word64
peekWord64BE ptr i = do
  u <- peekWord32BE ptr i
  l <- peekWord32BE ptr (i + 4)
  pure ((fromIntegral @Word32 @Word64 u `shiftL` 32) .|. fromIntegral @Word32 @Word64 l)
{-# INLINE peekWord64BE #-}

writeWord64BE :: MutableByteArray s -> Int -> Word64 -> ST s ()
writeWord64BE mba i w64 = do
  writeWord32BE mba i (fromIntegral @Word64 @Word32 (w64 `shiftR` 32))
  writeWord32BE mba (i + 4) (fromIntegral @Word64 @Word32 w64)
{-# INLINE writeWord64BE #-}

#else
#error "Unsupported architecture"
#endif


indexWord32BE :: ByteArray -> Int -> Word32
indexWord32BE (ByteArray ba#) (I# i#) =
#ifdef WORDS_BIGENDIAN
  w32
#else
  byteSwap32 w32
#endif
  where
    w32 = W32# (indexWord8ArrayAsWord32# ba# i#)
{-# INLINE indexWord32BE #-}

peekWord32BE :: Ptr a -> Int -> IO Word32
peekWord32BE ptr i =
#ifndef WORDS_BIGENDIAN
  byteSwap32 <$>
#endif
  peekByteOff (castPtr ptr) i
{-# INLINE peekWord32BE #-}


writeWord32BE :: MutableByteArray s -> Int -> Word32 -> ST s ()
writeWord32BE (MutableByteArray mba#) (I# i#) w =
  primitive_ (writeWord8ArrayAsWord32# mba# i# w#)
  where
#ifdef WORDS_BIGENDIAN
    !(W32# w#) = w
#else
    !(W32# w#) = byteSwap32 w
#endif
{-# INLINE writeWord32BE #-}

-- Usage of `accursedUnutterablePerformIO` here is safe because we only use it
-- for indexing into an immutable `ByteString`, which is analogous to
-- `Data.ByteString.index`.  Make sure you know what you are doing before using
-- this function.
unsafeWithByteStringPtr :: ByteString -> (Ptr b -> IO a) -> a
unsafeWithByteStringPtr bs f =
  accursedUnutterablePerformIO $
    case toForeignPtr bs of
      (fp, offset, _) ->
        unsafeWithForeignPtr (plusForeignPtr fp offset) f
{-# INLINE unsafeWithByteStringPtr #-}

#if !MIN_VERSION_base(4,15,0)
-- | A compatibility wrapper for 'GHC.ForeignPtr.unsafeWithForeignPtr' provided
-- by GHC 9.0.1 and later.
unsafeWithForeignPtr :: ForeignPtr a -> (Ptr a -> IO b) -> IO b
unsafeWithForeignPtr = withForeignPtr
{-# INLINE unsafeWithForeignPtr #-}
#endif
