module Ledger.Typed.Scripts.Validators
  {-# DEPRECATED "Use Plutus.Script.Utils.V1.Typed.Scripts.Validators instead" #-} (
  module Plutus.Script.Utils.V1.Typed.Scripts.Validators,
)
where

import Plutus.Script.Utils.V1.Typed.Scripts.Validators
