# Changelog for Cardano-submit-api

## vNext

## 8.0.0 -- May 2023

- [Add tx_submit_fail_count metric](https://github.com/input-output-hk/cardano-node/pull/4566)
- [Configurable metrics port in submit-api](https://github.com/input-output-hk/cardano-node/pull/4281)

## 1.35.3 -- July 2022

None

## 1.35.2 -- July 2022 (not released)

None

## 1.35.1 -- July 2022 (not released)

None

## 1.35.0 -- June 2022
- Babbage transactions for submit-api (#3979)