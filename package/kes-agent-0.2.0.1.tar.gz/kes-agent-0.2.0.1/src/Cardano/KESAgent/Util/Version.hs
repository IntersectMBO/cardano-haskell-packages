{-# LANGUAGE CPP #-}
{-# LANGUAGE TemplateHaskell #-}

module Cardano.KESAgent.Util.Version
where

libraryVersion :: String
libraryVersion = "v0.2.0.1"
