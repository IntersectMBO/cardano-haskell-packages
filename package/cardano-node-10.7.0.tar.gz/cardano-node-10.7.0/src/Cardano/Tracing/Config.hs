{-# LANGUAGE DataKinds #-}
{-# LANGUAGE DeriveGeneric #-}
{-# LANGUAGE KindSignatures #-}
{-# LANGUAGE NamedFieldPuns #-}
{-# LANGUAGE OverloadedStrings #-}
{-# LANGUAGE RecordWildCards #-}
{-# LANGUAGE ScopedTypeVariables #-}
{-# LANGUAGE TypeApplications #-}

{- HLINT ignore "Redundant <$>" -}

module Cardano.Tracing.Config
  ( TraceOptions (..)
  , TraceSelection (..)
  , OnOff (..)
  , PartialTraceOptions (..)
  , PartialTraceSelection (..)
  , partialTraceSelectionToEither
  , defaultPartialTraceConfiguration
  , lastToEither

  -- * Trace symbols
  , TraceAcceptPolicy
  , TraceBlockchainTime
  , TraceBlockFetchClient
  , TraceBlockFetchDecisions
  , TraceBlockFetchProtocol
  , TraceBlockFetchProtocolSerialised
  , TraceBlockFetchServer
  , TraceChainDB
  , TraceChainSyncClient
  , TraceChainSyncBlockServer
  , TraceChainSyncHeaderServer
  , TraceChainSyncProtocol
  , TraceConnectionManager
  , TraceConnectionManagerCounters
  , TraceConnectionManagerTransitions
  , DebugPeerSelectionInitiator
  , DebugPeerSelectionInitiatorResponder
  , TraceDiffusionInitialization
  , TraceDnsResolver
  , TraceDnsSubscription
  , TraceErrorPolicy
  , TraceForge
  , TraceForgeStateInfo
  , TraceHandshake
  , TraceIpSubscription
  , TraceKeepAliveClient
  , TraceLedgerPeers
  , TraceLocalChainSyncProtocol
  , TraceLocalConnectionManager
  , TraceLocalErrorPolicy
  , TraceLocalHandshake
  , TraceLocalInboundGovernor
  , TraceLocalRootPeers
  , TraceLocalServer
  , TraceLocalStateQueryProtocol
  , TraceLocalTxMonitorProtocol
  , TraceLocalTxSubmissionProtocol
  , TraceLocalTxSubmissionServer
  , TraceMempool
  , TraceMux
  , TraceMuxBearer
  , TraceMuxChannel
  , TraceLocalMux
  , TraceLocalMuxBearer
  , TraceLocalMuxChannel
  , TracePeerSelection
  , TracePeerSelectionCounters
  , TracePeerSelectionActions
  , TracePublicRootPeers
  , TraceServer
  , TraceInboundGovernor
  , TraceInboundGovernorCounters
  , TraceInboundGovernorTransitions
  , TraceTxInbound
  , TraceTxOutbound
  , TraceTxSubmissionProtocol
  , TraceTxSubmission2Protocol
  , TraceKeepAliveProtocol
  , TracePeerSharingProtocol
  , proxyName
  ) where

import           Cardano.BM.Tracing (TracingVerbosity (..))
import           Cardano.Node.Orphans ()

import           Control.Monad (MonadPlus (..))
import           Data.Aeson
import qualified Data.Aeson.Key as Aeson
import           Data.Aeson.Types
import           Data.Bifunctor (Bifunctor (..))
import           Data.Monoid (Last (..))
import           Data.Proxy (Proxy (..))
import           Data.Text (Text)
import qualified Data.Text as Text
import           GHC.Generics (Generic)
import           GHC.TypeLits (KnownSymbol, Symbol, symbolVal)

import           Generic.Data (gmappend)

{- HLINT ignore "Functor law" -}

data TraceOptions
  = TracingOff
  | TracingOnLegacy TraceSelection
  | TraceDispatcher TraceSelection
  deriving (Eq, Show)

data PartialTraceOptions
  = PartialTracingOff
  | PartialTracingOnLegacy PartialTraceSelection
  | PartialTraceDispatcher PartialTraceSelection
  deriving (Eq, Show)

instance Monoid PartialTraceOptions where
  mempty = PartialTracingOff

-- Mimics Last's semantics
instance Semigroup PartialTraceOptions where

  tracingA <> tracingB =
    case (tracingA, tracingB) of
      (PartialTracingOnLegacy ptsA, PartialTracingOnLegacy ptsB) ->
        PartialTracingOnLegacy (ptsA <> ptsB)

      (PartialTraceDispatcher ptsA, PartialTraceDispatcher ptsB) ->
        PartialTraceDispatcher (ptsA <> ptsB)

      (_, tracing) -> tracing

type TraceAcceptPolicy = ("TraceAcceptPolicy" :: Symbol)
type TraceBlockchainTime = ("TraceBlockchainTime" :: Symbol)
type TraceBlockFetchClient = ("TraceBlockFetchClient" :: Symbol)
type TraceBlockFetchDecisions = ("TraceBlockFetchDecisions" :: Symbol)
type TraceBlockFetchProtocol = ("TraceBlockFetchProtocol" :: Symbol)
type TraceBlockFetchProtocolSerialised = ("TraceBlockFetchProtocolSerialised" :: Symbol)
type TraceBlockFetchServer = ("TraceBlockFetchServer" :: Symbol)
type TraceChainDB = ("TraceChainDb" :: Symbol)
type TraceChainSyncClient = ("TraceChainSyncClient" :: Symbol)
type TraceChainSyncBlockServer = ("TraceChainSyncBlockServer" :: Symbol)
type TraceChainSyncHeaderServer = ("TraceChainSyncHeaderServer" :: Symbol)
type TraceChainSyncProtocol = ("TraceChainSyncProtocol" :: Symbol)
type TraceConnectionManager = ("TraceConnectionManager" :: Symbol)
type TraceConnectionManagerCounters = ("TraceConnectionManagerCounters" :: Symbol)
type TraceConnectionManagerTransitions = ("TraceConnectionManagerTransitions" :: Symbol)
type DebugPeerSelectionInitiator = ("DebugPeerSelectionInitiator" :: Symbol)
type DebugPeerSelectionInitiatorResponder = ("DebugPeerSelectionInitiatorResponder" :: Symbol)
type TraceDiffusionInitialization = ("TraceDiffusionInitialization" :: Symbol)
type TraceDnsResolver = ("TraceDnsResolver" :: Symbol)
type TraceDnsSubscription = ("TraceDnsSubscription" :: Symbol)
type TraceErrorPolicy = ("TraceErrorPolicy" :: Symbol)
type TraceForge = ("TraceForge" :: Symbol)
type TraceForgeStateInfo = ("TraceForgeStateInfo" :: Symbol)
type TraceGDD = ("TraceGDD" :: Symbol)
type TraceHandshake = ("TraceHandshake" :: Symbol)
type TraceIpSubscription = ("TraceIpSubscription" :: Symbol)
type TraceKeepAliveClient = ("TraceKeepAliveClient" :: Symbol)
type TraceLedgerPeers = ("TraceLedgerPeers" :: Symbol)
type TraceLocalChainSyncProtocol = ("TraceLocalChainSyncProtocol" :: Symbol)
type TraceLocalConnectionManager = ("TraceLocalConnectionManager" :: Symbol)
type TraceLocalErrorPolicy = ("TraceLocalErrorPolicy" :: Symbol)
type TraceLocalHandshake = ("TraceLocalHandshake" :: Symbol)
type TraceLocalInboundGovernor = ("TraceLocalInboundGovernor" :: Symbol)
type TraceLocalRootPeers = ("TraceLocalRootPeers" :: Symbol)
type TraceLocalServer = ("TraceLocalServer" :: Symbol)
type TraceLocalStateQueryProtocol = ("TraceLocalStateQueryProtocol" :: Symbol)
type TraceLocalTxMonitorProtocol = ("TraceLocalTxMonitorProtocol" :: Symbol)
type TraceLocalTxSubmissionProtocol = ("TraceLocalTxSubmissionProtocol" :: Symbol)
type TraceLocalTxSubmissionServer = ("TraceLocalTxSubmissionServer" :: Symbol)
type TraceMempool = ("TraceMempool" :: Symbol)
type TraceBackingStore = ("TraceBackingStore" :: Symbol)
type TraceMux = ("TraceMux" :: Symbol)
type TraceMuxBearer = ("TraceMuxBearer" :: Symbol)
type TraceMuxChannel = ("TraceMuxChannel" :: Symbol)
type TraceLocalMux = ("TraceLocalMux" :: Symbol)
type TraceLocalMuxBearer = ("TraceLocalMuxBearer" :: Symbol)
type TraceLocalMuxChannel = ("TraceLocalMuxChannel" :: Symbol)
type TracePeerSelection = ("TracePeerSelection" :: Symbol)
type TracePeerSelectionCounters = ("TracePeerSelectionCounters" :: Symbol)
type TracePeerSelectionActions = ("TracePeerSelectionActions" :: Symbol)
type TracePublicRootPeers = ("TracePublicRootPeers" :: Symbol)
type TraceSanityCheckIssue = ("TraceSanityCheckIssue" :: Symbol)
type TraceServer = ("TraceServer" :: Symbol)
type TraceInboundGovernor = ("TraceInboundGovernor" :: Symbol)
type TraceInboundGovernorCounters = ("TraceInboundGovernorCounters" :: Symbol)
type TraceInboundGovernorTransitions = ("TraceInboundGovernorTransitions" :: Symbol)
type TraceTxInbound = ("TraceTxInbound" :: Symbol)
type TraceTxOutbound = ("TraceTxOutbound" :: Symbol)
type TraceTxSubmissionProtocol = ("TraceTxSubmissionProtocol" :: Symbol)
type TraceTxSubmission2Protocol = ("TraceTxSubmission2Protocol" :: Symbol)
type TraceKeepAliveProtocol = ("TraceKeepAliveProtocol" :: Symbol)
type TracePeerSharingProtocol = ("TracePeerSharingProtocol" :: Symbol)
type TraceGsm = ("TraceGsm" :: Symbol)
type TraceCsj = ("TraceCsj" :: Symbol)
type TraceKesAgent = ("TraceKesAgent" :: Symbol)
type TraceDevotedBlockFetch = ("TraceDevotedBlockFetch" :: Symbol)
type TraceChurnMode = ("TraceChurnMode" :: Symbol)
type TraceDNS = ("TraceDNS" :: Symbol)
type TraceTxLogic = ("TraceTxLogic" :: Symbol)
type TraceTxCounters = ("TraceTxCounters" :: Symbol)

newtype OnOff (name :: Symbol) = OnOff { isOn :: Bool } deriving (Eq, Show)

instance FromJSON (OnOff a) where
    parseJSON (Data.Aeson.Bool b)= return $ OnOff b
    parseJSON _ = mzero

proxyName :: KnownSymbol name => Proxy name -> Text
proxyName p = Text.pack (symbolVal p)

data TraceSelection
  = TraceSelection
  { traceVerbosity :: !TracingVerbosity

  -- Per-trace toggles, alpha-sorted.
  , traceAcceptPolicy :: OnOff TraceAcceptPolicy
  , traceBlockFetchClient :: OnOff TraceBlockFetchClient
  , traceBlockFetchDecisions :: OnOff TraceBlockFetchDecisions
  , traceBlockFetchProtocol :: OnOff TraceBlockFetchProtocol
  , traceBlockFetchProtocolSerialised :: OnOff TraceBlockFetchProtocolSerialised
  , traceBlockFetchServer :: OnOff TraceBlockFetchServer
  , traceBlockchainTime :: OnOff TraceBlockchainTime
  , traceChainDB :: OnOff TraceChainDB
  , traceChainSyncBlockServer :: OnOff TraceChainSyncBlockServer
  , traceChainSyncClient :: OnOff TraceChainSyncClient
  , traceChainSyncHeaderServer :: OnOff TraceChainSyncHeaderServer
  , traceChainSyncProtocol :: OnOff TraceChainSyncProtocol
  , traceConnectionManager :: OnOff TraceConnectionManager
  , traceConnectionManagerCounters :: OnOff TraceConnectionManagerCounters
  , traceConnectionManagerTransitions :: OnOff TraceConnectionManagerTransitions
  , traceDebugPeerSelectionInitiatorTracer :: OnOff DebugPeerSelectionInitiator
  , traceDebugPeerSelectionInitiatorResponderTracer :: OnOff DebugPeerSelectionInitiatorResponder
  , traceDiffusionInitialization :: OnOff TraceDiffusionInitialization
  , traceDnsResolver :: OnOff TraceDnsResolver
  , traceDnsSubscription :: OnOff TraceDnsSubscription
  , traceErrorPolicy :: OnOff TraceErrorPolicy
  , traceForge :: OnOff TraceForge
  , traceForgeStateInfo :: OnOff TraceForgeStateInfo
  , traceGDD :: OnOff TraceGDD
  , traceHandshake :: OnOff TraceHandshake
  , traceInboundGovernor :: OnOff TraceInboundGovernor
  , traceInboundGovernorCounters :: OnOff TraceInboundGovernorCounters
  , traceInboundGovernorTransitions :: OnOff TraceInboundGovernorTransitions
  , traceIpSubscription :: OnOff TraceIpSubscription
  , traceKeepAliveClient :: OnOff TraceKeepAliveClient
  , traceLedgerPeers :: OnOff TraceLedgerPeers
  , traceLocalChainSyncProtocol :: OnOff TraceLocalChainSyncProtocol
  , traceLocalConnectionManager :: OnOff TraceLocalConnectionManager
  , traceLocalErrorPolicy :: OnOff TraceLocalErrorPolicy
  , traceLocalHandshake :: OnOff TraceLocalHandshake
  , traceLocalInboundGovernor :: OnOff TraceLocalInboundGovernor
  , traceLocalMux :: OnOff TraceLocalMux
  , traceLocalMuxBearer :: OnOff TraceLocalMuxBearer
  , traceLocalMuxChannel :: OnOff TraceLocalMuxChannel
  , traceLocalRootPeers :: OnOff TraceLocalRootPeers
  , traceLocalServer :: OnOff TraceLocalServer
  , traceLocalStateQueryProtocol :: OnOff TraceLocalStateQueryProtocol
  , traceLocalTxMonitorProtocol :: OnOff TraceLocalTxMonitorProtocol
  , traceLocalTxSubmissionProtocol :: OnOff TraceLocalTxSubmissionProtocol
  , traceLocalTxSubmissionServer :: OnOff TraceLocalTxSubmissionServer
  , traceMempool :: OnOff TraceMempool
  , traceBackingStore :: OnOff TraceBackingStore
  , traceMux :: OnOff TraceMux
  , traceMuxBearer :: OnOff TraceMuxBearer
  , traceMuxChannel :: OnOff TraceMuxChannel
  , tracePeerSelection :: OnOff TracePeerSelection
  , tracePeerSelectionCounters :: OnOff TracePeerSelectionCounters
  , tracePeerSelectionActions :: OnOff TracePeerSelectionActions
  , tracePublicRootPeers :: OnOff TracePublicRootPeers
  , traceSanityCheckIssue :: OnOff TraceSanityCheckIssue
  , traceServer :: OnOff TraceServer
  , traceTxInbound :: OnOff TraceTxInbound
  , traceTxOutbound :: OnOff TraceTxOutbound
  , traceTxSubmissionProtocol :: OnOff TraceTxSubmissionProtocol
  , traceTxSubmission2Protocol :: OnOff TraceTxSubmission2Protocol
  , traceKeepAliveProtocol :: OnOff TraceKeepAliveProtocol
  , tracePeerSharingProtocol :: OnOff TracePeerSharingProtocol
  , traceGsm :: OnOff TraceGsm
  , traceCsj :: OnOff TraceCsj
  , traceKesAgent :: OnOff TraceKesAgent
  , traceDevotedBlockFetch :: OnOff TraceDevotedBlockFetch
  , traceChurnMode :: OnOff TraceChurnMode
  , traceDNS :: OnOff TraceDNS
  , traceTxLogic :: OnOff TraceTxLogic
  , traceTxCounters :: OnOff TraceTxCounters
  } deriving (Eq, Show)



data PartialTraceSelection
  = PartialTraceSelection
      { pTraceVerbosity :: !(Last TracingVerbosity)

      -- Per-trace toggles, alpha-sorted.
      , pTraceAcceptPolicy :: Last (OnOff TraceAcceptPolicy)
      , pTraceBlockchainTime :: Last (OnOff TraceBlockchainTime)
      , pTraceBlockFetchClient :: Last (OnOff TraceBlockFetchClient)
      , pTraceBlockFetchDecisions :: Last (OnOff TraceBlockFetchDecisions)
      , pTraceBlockFetchProtocol :: Last (OnOff TraceBlockFetchProtocol)
      , pTraceBlockFetchProtocolSerialised :: Last (OnOff TraceBlockFetchProtocolSerialised)
      , pTraceBlockFetchServer :: Last (OnOff TraceBlockFetchServer)
      , pTraceChainDB :: Last (OnOff TraceChainDB)
      , pTraceChainSyncBlockServer :: Last (OnOff TraceChainSyncBlockServer)
      , pTraceChainSyncClient :: Last (OnOff TraceChainSyncClient)
      , pTraceChainSyncHeaderServer :: Last (OnOff TraceChainSyncHeaderServer)
      , pTraceChainSyncProtocol :: Last (OnOff TraceChainSyncProtocol)
      , pTraceConnectionManager :: Last (OnOff TraceConnectionManager)
      , pTraceConnectionManagerCounters :: Last (OnOff TraceConnectionManagerCounters)
      , pTraceConnectionManagerTransitions :: Last (OnOff TraceConnectionManagerTransitions)
      , pTraceDebugPeerSelectionInitiatorTracer :: Last (OnOff DebugPeerSelectionInitiator)
      , pTraceDiffusionInitialization :: Last (OnOff TraceDiffusionInitialization)
      , pTraceDebugPeerSelectionInitiatorResponderTracer :: Last (OnOff DebugPeerSelectionInitiatorResponder)
      , pTraceDnsResolver :: Last (OnOff TraceDnsResolver)
      , pTraceDnsSubscription :: Last (OnOff TraceDnsSubscription)
      , pTraceErrorPolicy :: Last (OnOff TraceErrorPolicy)
      , pTraceForge :: Last (OnOff TraceForge)
      , pTraceForgeStateInfo :: Last (OnOff TraceForgeStateInfo)
      , pTraceGDD :: Last (OnOff TraceGDD)
      , pTraceHandshake :: Last (OnOff TraceHandshake)
      , pTraceInboundGovernor :: Last (OnOff TraceInboundGovernor)
      , pTraceInboundGovernorCounters :: Last (OnOff TraceInboundGovernorCounters)
      , pTraceInboundGovernorTransitions :: Last (OnOff TraceInboundGovernorTransitions)
      , pTraceIpSubscription :: Last (OnOff TraceIpSubscription)
      , pTraceKeepAliveClient :: Last (OnOff TraceKeepAliveClient)
      , pTraceLedgerPeers :: Last (OnOff TraceLedgerPeers)
      , pTraceLocalChainSyncProtocol :: Last (OnOff TraceLocalChainSyncProtocol)
      , pTraceLocalConnectionManager :: Last (OnOff TraceLocalConnectionManager)
      , pTraceLocalErrorPolicy :: Last (OnOff TraceLocalErrorPolicy)
      , pTraceLocalHandshake :: Last (OnOff TraceLocalHandshake)
      , pTraceLocalInboundGovernor :: Last (OnOff TraceLocalInboundGovernor)
      , pTraceLocalMux :: Last (OnOff TraceLocalMux)
      , pTraceLocalMuxBearer :: Last (OnOff TraceLocalMuxBearer)
      , pTraceLocalMuxChannel :: Last (OnOff TraceLocalMuxChannel)
      , pTraceLocalRootPeers :: Last (OnOff TraceLocalRootPeers)
      , pTraceLocalServer :: Last (OnOff TraceLocalServer)
      , pTraceLocalStateQueryProtocol :: Last (OnOff TraceLocalStateQueryProtocol)
      , pTraceLocalTxMonitorProtocol :: Last (OnOff TraceLocalTxMonitorProtocol)
      , pTraceLocalTxSubmissionProtocol :: Last (OnOff TraceLocalTxSubmissionProtocol)
      , pTraceLocalTxSubmissionServer :: Last (OnOff TraceLocalTxSubmissionServer)
      , pTraceMempool :: Last (OnOff TraceMempool)
      , pTraceBackingStore :: Last (OnOff TraceBackingStore)
      , pTraceMux :: Last (OnOff TraceMux)
      , pTraceMuxBearer :: Last (OnOff TraceMuxBearer)
      , pTraceMuxChannel :: Last (OnOff TraceMuxChannel)
      , pTracePeerSelection :: Last (OnOff TracePeerSelection)
      , pTracePeerSelectionCounters :: Last (OnOff TracePeerSelectionCounters)
      , pTracePeerSelectionActions :: Last (OnOff TracePeerSelectionActions)
      , pTracePublicRootPeers :: Last (OnOff TracePublicRootPeers)
      , pTraceSanityCheckIssue :: Last (OnOff TraceSanityCheckIssue)
      , pTraceServer :: Last (OnOff TraceServer)
      , pTraceTxInbound :: Last (OnOff TraceTxInbound)
      , pTraceTxOutbound :: Last (OnOff TraceTxOutbound)
      , pTraceTxSubmissionProtocol :: Last (OnOff TraceTxSubmissionProtocol)
      , pTraceTxSubmission2Protocol :: Last (OnOff TraceTxSubmission2Protocol)
      , pTraceKeepAliveProtocol :: Last (OnOff TraceKeepAliveProtocol)
      , pTracePeerSharingProtocol :: Last (OnOff TracePeerSharingProtocol)
      , pTraceGsm :: Last (OnOff TraceGsm)
      , pTraceCsj :: Last (OnOff TraceCsj)
      , pTraceDevotedBlockFetch :: Last (OnOff TraceDevotedBlockFetch)
      , pTraceChurnMode :: Last (OnOff TraceChurnMode)
      , pTraceDNS :: Last (OnOff TraceDNS)
      , pTraceKesAgent :: Last (OnOff TraceKesAgent)
      , pTraceTxLogic :: Last (OnOff TraceTxLogic)
      , pTraceTxCounters :: Last (OnOff TraceTxCounters)
      } deriving (Eq, Generic, Show)


instance Semigroup PartialTraceSelection where
  (<>) = gmappend

instance FromJSON PartialTraceSelection where
  parseJSON = withObject "PartialTraceSelection" $ \v -> do
    PartialTraceSelection
      <$> Last <$> v .:? "TracingVerbosity"
      <*> parseTracer (Proxy @TraceAcceptPolicy) v
      <*> parseTracer (Proxy @TraceBlockchainTime) v
      <*> parseTracer (Proxy @TraceBlockFetchClient) v
      <*> parseTracer (Proxy @TraceBlockFetchDecisions) v
      <*> parseTracer (Proxy @TraceBlockFetchProtocol) v
      <*> parseTracer (Proxy @TraceBlockFetchProtocolSerialised) v
      <*> parseTracer (Proxy @TraceBlockFetchServer) v
      <*> parseTracer (Proxy @TraceChainDB) v
      <*> parseTracer (Proxy @TraceChainSyncBlockServer) v
      <*> parseTracer (Proxy @TraceChainSyncClient) v
      <*> parseTracer (Proxy @TraceChainSyncHeaderServer) v
      <*> parseTracer (Proxy @TraceChainSyncProtocol) v
      <*> parseTracer (Proxy @TraceConnectionManager) v
      <*> parseTracer (Proxy @TraceConnectionManagerCounters) v
      <*> parseTracer (Proxy @TraceConnectionManagerTransitions) v
      <*> parseTracer (Proxy @DebugPeerSelectionInitiator) v
      <*> parseTracer (Proxy @TraceDiffusionInitialization) v
      <*> parseTracer (Proxy @DebugPeerSelectionInitiatorResponder) v
      <*> parseTracer (Proxy @TraceDnsResolver) v
      <*> parseTracer (Proxy @TraceDnsSubscription) v
      <*> parseTracer (Proxy @TraceErrorPolicy) v
      <*> parseTracer (Proxy @TraceForge) v
      <*> parseTracer (Proxy @TraceForgeStateInfo) v
      <*> parseTracer (Proxy @TraceGDD) v
      <*> parseTracer (Proxy @TraceHandshake) v
      <*> parseTracer (Proxy @TraceInboundGovernor) v
      <*> parseTracer (Proxy @TraceInboundGovernorCounters) v
      <*> parseTracer (Proxy @TraceInboundGovernorTransitions) v
      <*> parseTracer (Proxy @TraceIpSubscription) v
      <*> parseTracer (Proxy @TraceKeepAliveClient) v
      <*> parseTracer (Proxy @TraceLedgerPeers) v
      <*> parseTracer (Proxy @TraceLocalChainSyncProtocol) v
      <*> parseTracer (Proxy @TraceLocalConnectionManager) v
      <*> parseTracer (Proxy @TraceLocalErrorPolicy) v
      <*> parseTracer (Proxy @TraceLocalHandshake) v
      <*> parseTracer (Proxy @TraceLocalInboundGovernor) v
      <*> parseTracer (Proxy @TraceLocalMux) v
      <*> parseTracer (Proxy @TraceLocalMuxBearer) v
      <*> parseTracer (Proxy @TraceLocalMuxChannel) v
      <*> parseTracer (Proxy @TraceLocalRootPeers) v
      <*> parseTracer (Proxy @TraceLocalServer) v
      <*> parseTracer (Proxy @TraceLocalStateQueryProtocol) v
      <*> parseTracer (Proxy @TraceLocalTxMonitorProtocol) v
      <*> parseTracer (Proxy @TraceLocalTxSubmissionProtocol) v
      <*> parseTracer (Proxy @TraceLocalTxSubmissionServer) v
      <*> parseTracer (Proxy @TraceMempool) v
      <*> parseTracer (Proxy @TraceBackingStore) v
      <*> parseTracer (Proxy @TraceMux) v
      <*> parseTracer (Proxy @TraceMuxBearer) v
      <*> parseTracer (Proxy @TraceMuxChannel) v
      <*> parseTracer (Proxy @TracePeerSelection) v
      <*> parseTracer (Proxy @TracePeerSelectionCounters) v
      <*> parseTracer (Proxy @TracePeerSelectionActions) v
      <*> parseTracer (Proxy @TracePublicRootPeers) v
      <*> parseTracer (Proxy @TraceSanityCheckIssue) v
      <*> parseTracer (Proxy @TraceServer) v
      <*> parseTracer (Proxy @TraceTxInbound) v
      <*> parseTracer (Proxy @TraceTxOutbound) v
      <*> parseTracer (Proxy @TraceTxSubmissionProtocol) v
      <*> parseTracer (Proxy @TraceTxSubmission2Protocol) v
      <*> parseTracer (Proxy @TraceKeepAliveProtocol) v
      <*> parseTracer (Proxy @TracePeerSharingProtocol) v
      <*> parseTracer (Proxy @TraceGsm) v
      <*> parseTracer (Proxy @TraceCsj) v
      <*> parseTracer (Proxy @TraceDevotedBlockFetch) v
      <*> parseTracer (Proxy @TraceChurnMode) v
      <*> parseTracer (Proxy @TraceDNS) v
      <*> parseTracer (Proxy @TraceKesAgent) v
      <*> parseTracer (Proxy @TraceTxLogic) v
      <*> parseTracer (Proxy @TraceTxCounters) v


defaultPartialTraceConfiguration :: PartialTraceSelection
defaultPartialTraceConfiguration =
  PartialTraceSelection
    { pTraceVerbosity = Last $ Just NormalVerbosity
    -- Per-trace toggles, alpha-sorted.
    , pTraceAcceptPolicy = pure $ OnOff False
    , pTraceBlockchainTime = pure $ OnOff False
    , pTraceBlockFetchClient = pure $ OnOff False
    , pTraceBlockFetchDecisions = pure $ OnOff True
    , pTraceBlockFetchProtocol = pure $ OnOff False
    , pTraceBlockFetchProtocolSerialised = pure $ OnOff False
    , pTraceBlockFetchServer = pure $ OnOff False
    , pTraceChainDB = pure $ OnOff True
    , pTraceChainSyncBlockServer = pure $ OnOff False
    , pTraceChainSyncClient = pure $ OnOff True
    , pTraceChainSyncHeaderServer = pure $ OnOff False
    , pTraceChainSyncProtocol = pure $ OnOff False
    , pTraceConnectionManager = pure $ OnOff True
    , pTraceConnectionManagerCounters = pure $ OnOff True
    , pTraceConnectionManagerTransitions = pure $ OnOff False
    , pTraceDebugPeerSelectionInitiatorTracer = pure $ OnOff False
    , pTraceDebugPeerSelectionInitiatorResponderTracer = pure $ OnOff False
    , pTraceDiffusionInitialization = pure $ OnOff False
    , pTraceDnsResolver = pure $ OnOff False
    , pTraceDnsSubscription = pure $ OnOff True
    , pTraceErrorPolicy = pure $ OnOff True
    , pTraceForge = pure $ OnOff True
    , pTraceForgeStateInfo = pure $ OnOff True
    , pTraceGDD = pure $ OnOff False
    , pTraceHandshake = pure $ OnOff False
    , pTraceInboundGovernor = pure $ OnOff True
    , pTraceInboundGovernorCounters = pure $ OnOff True
    , pTraceInboundGovernorTransitions = pure $ OnOff True
    , pTraceIpSubscription = pure $ OnOff True
    , pTraceKeepAliveClient = pure $ OnOff False
    , pTraceLedgerPeers = pure $ OnOff False
    , pTraceLocalChainSyncProtocol = pure $ OnOff False
    , pTraceLocalConnectionManager = pure $ OnOff True
    , pTraceLocalErrorPolicy = pure $ OnOff True
    , pTraceLocalHandshake = pure $ OnOff True
    , pTraceLocalInboundGovernor = pure $ OnOff True
    , pTraceLocalMux = pure $ OnOff False
    , pTraceLocalMuxBearer = pure $ OnOff False
    , pTraceLocalMuxChannel = pure $ OnOff False
    , pTraceLocalTxMonitorProtocol = pure $ OnOff False
    , pTraceLocalRootPeers = pure $ OnOff False
    , pTraceLocalServer = pure $ OnOff True
    , pTraceLocalStateQueryProtocol = pure $ OnOff False
    , pTraceLocalTxSubmissionProtocol = pure $ OnOff False
    , pTraceLocalTxSubmissionServer = pure $ OnOff False
    , pTraceMempool = pure $ OnOff True
    , pTraceBackingStore = pure $ OnOff False
    , pTraceMux = pure $ OnOff False
    , pTraceMuxBearer = pure $ OnOff False
    , pTraceMuxChannel = pure $ OnOff False
    , pTracePeerSelection = pure $ OnOff True
    , pTracePeerSelectionCounters = pure $ OnOff True
    , pTracePeerSelectionActions = pure $ OnOff True
    , pTracePublicRootPeers = pure $ OnOff False
    , pTraceSanityCheckIssue = pure $ OnOff False
    , pTraceServer = pure $ OnOff True
    , pTraceTxInbound = pure $ OnOff False
    , pTraceTxOutbound = pure $ OnOff False
    , pTraceTxSubmissionProtocol = pure $ OnOff False
    , pTraceTxSubmission2Protocol = pure $ OnOff False
    , pTraceKeepAliveProtocol = pure $ OnOff False
    , pTracePeerSharingProtocol = pure $ OnOff False
    , pTraceGsm = pure $ OnOff True
    , pTraceCsj = pure $ OnOff True
    , pTraceDevotedBlockFetch = pure $ OnOff True
    , pTraceChurnMode = pure $ OnOff True
    , pTraceDNS = pure $ OnOff True
    , pTraceKesAgent = pure $ OnOff False
    , pTraceTxLogic = pure $ OnOff False
    , pTraceTxCounters = pure $ OnOff False
    }


partialTraceSelectionToEither :: Last PartialTraceOptions -> Either Text TraceOptions
partialTraceSelectionToEither (Last Nothing) = Right TracingOff
partialTraceSelectionToEither  (Last (Just PartialTracingOff)) = Right TracingOff
partialTraceSelectionToEither (Last (Just (PartialTraceDispatcher pTraceSelection))) = do
   let PartialTraceSelection {..} = defaultPartialTraceConfiguration <> pTraceSelection
   traceVerbosity <- first Text.pack $ lastToEither "Default value not specified for TracingVerbosity" pTraceVerbosity
   traceAcceptPolicy <- proxyLastToEither (Proxy @TraceAcceptPolicy) pTraceAcceptPolicy
   traceBlockchainTime <- proxyLastToEither (Proxy @TraceBlockchainTime) pTraceBlockchainTime
   traceBlockFetchClient <- proxyLastToEither (Proxy @TraceBlockFetchClient) pTraceBlockFetchClient
   traceBlockFetchDecisions <- proxyLastToEither (Proxy @TraceBlockFetchDecisions) pTraceBlockFetchDecisions
   traceBlockFetchProtocol <- proxyLastToEither (Proxy @TraceBlockFetchProtocol) pTraceBlockFetchProtocol
   traceBlockFetchProtocolSerialised <- proxyLastToEither (Proxy @TraceBlockFetchProtocolSerialised) pTraceBlockFetchProtocolSerialised
   traceBlockFetchServer <- proxyLastToEither (Proxy @TraceBlockFetchServer) pTraceBlockFetchServer
   traceChainDB <- proxyLastToEither (Proxy @TraceChainDB) pTraceChainDB
   traceChainSyncClient <- proxyLastToEither (Proxy @TraceChainSyncClient) pTraceChainSyncClient
   traceChainSyncBlockServer <- proxyLastToEither (Proxy @TraceChainSyncBlockServer) pTraceChainSyncBlockServer
   traceChainSyncHeaderServer <- proxyLastToEither (Proxy @TraceChainSyncHeaderServer) pTraceChainSyncHeaderServer
   traceChainSyncProtocol <- proxyLastToEither (Proxy @TraceChainSyncProtocol) pTraceChainSyncProtocol
   traceConnectionManager <- proxyLastToEither (Proxy @TraceConnectionManager) pTraceConnectionManager
   traceConnectionManagerCounters <- proxyLastToEither (Proxy @TraceConnectionManagerCounters) pTraceConnectionManagerCounters
   traceConnectionManagerTransitions <- proxyLastToEither (Proxy @TraceConnectionManagerTransitions) pTraceConnectionManagerTransitions
   traceDebugPeerSelectionInitiatorTracer <- proxyLastToEither (Proxy @DebugPeerSelectionInitiator) pTraceDebugPeerSelectionInitiatorTracer
   traceDebugPeerSelectionInitiatorResponderTracer <- proxyLastToEither (Proxy @DebugPeerSelectionInitiatorResponder) pTraceDebugPeerSelectionInitiatorResponderTracer
   traceDiffusionInitialization <- proxyLastToEither (Proxy @TraceDiffusionInitialization) pTraceDiffusionInitialization
   traceDnsResolver <- proxyLastToEither (Proxy @TraceDnsResolver) pTraceDnsResolver
   traceDnsSubscription <- proxyLastToEither (Proxy @TraceDnsSubscription) pTraceDnsSubscription
   traceErrorPolicy <- proxyLastToEither (Proxy @TraceErrorPolicy) pTraceErrorPolicy
   traceForge <- proxyLastToEither (Proxy @TraceForge) pTraceForge
   traceForgeStateInfo <- proxyLastToEither (Proxy @TraceForgeStateInfo) pTraceForgeStateInfo
   traceGDD <- proxyLastToEither (Proxy @TraceGDD) pTraceGDD
   traceHandshake <- proxyLastToEither (Proxy @TraceHandshake) pTraceHandshake
   traceInboundGovernor <- proxyLastToEither (Proxy @TraceInboundGovernor) pTraceInboundGovernor
   traceInboundGovernorCounters <- proxyLastToEither (Proxy @TraceInboundGovernorCounters) pTraceInboundGovernorCounters
   traceInboundGovernorTransitions <- proxyLastToEither (Proxy @TraceInboundGovernorTransitions) pTraceInboundGovernorTransitions
   traceIpSubscription <- proxyLastToEither (Proxy @TraceIpSubscription) pTraceIpSubscription
   traceKeepAliveClient <- proxyLastToEither (Proxy @TraceKeepAliveClient) pTraceKeepAliveClient
   traceLedgerPeers <- proxyLastToEither (Proxy @TraceLedgerPeers) pTraceLedgerPeers
   traceLocalChainSyncProtocol <- proxyLastToEither (Proxy @TraceLocalChainSyncProtocol) pTraceLocalChainSyncProtocol
   traceLocalConnectionManager <- proxyLastToEither (Proxy @TraceLocalConnectionManager) pTraceLocalConnectionManager
   traceLocalErrorPolicy <- proxyLastToEither (Proxy @TraceLocalErrorPolicy) pTraceLocalErrorPolicy
   traceLocalHandshake <- proxyLastToEither (Proxy @TraceLocalHandshake) pTraceLocalHandshake
   traceLocalInboundGovernor <- proxyLastToEither (Proxy @TraceLocalInboundGovernor) pTraceLocalInboundGovernor
   traceLocalMux <- proxyLastToEither (Proxy @TraceLocalMux) pTraceLocalMux
   traceLocalMuxBearer <- proxyLastToEither (Proxy @TraceLocalMuxBearer) pTraceLocalMuxBearer
   traceLocalMuxChannel <- proxyLastToEither (Proxy @TraceLocalMuxChannel) pTraceLocalMuxChannel
   traceLocalTxMonitorProtocol <- proxyLastToEither (Proxy @TraceLocalTxMonitorProtocol) pTraceLocalTxMonitorProtocol
   traceLocalRootPeers <- proxyLastToEither (Proxy @TraceLocalRootPeers) pTraceLocalRootPeers
   traceLocalServer <- proxyLastToEither (Proxy @TraceLocalServer) pTraceLocalServer
   traceLocalStateQueryProtocol <- proxyLastToEither (Proxy @TraceLocalStateQueryProtocol) pTraceLocalStateQueryProtocol
   traceLocalTxSubmissionProtocol <- proxyLastToEither (Proxy @TraceLocalTxSubmissionProtocol) pTraceLocalTxSubmissionProtocol
   traceLocalTxSubmissionServer <- proxyLastToEither (Proxy @TraceLocalTxSubmissionServer) pTraceLocalTxSubmissionServer
   traceMempool <- proxyLastToEither (Proxy @TraceMempool) pTraceMempool
   traceBackingStore <- proxyLastToEither (Proxy @TraceBackingStore) pTraceBackingStore
   traceMux <- proxyLastToEither (Proxy @TraceMux) pTraceMux
   traceMuxBearer <- proxyLastToEither (Proxy @TraceMuxBearer) pTraceMuxBearer
   traceMuxChannel <- proxyLastToEither (Proxy @TraceMuxChannel) pTraceMuxChannel
   tracePeerSelection <- proxyLastToEither (Proxy @TracePeerSelection) pTracePeerSelection
   tracePeerSelectionCounters <- proxyLastToEither (Proxy @TracePeerSelectionCounters) pTracePeerSelectionCounters
   tracePeerSelectionActions <- proxyLastToEither (Proxy @TracePeerSelectionActions) pTracePeerSelectionActions
   tracePublicRootPeers <- proxyLastToEither (Proxy @TracePublicRootPeers) pTracePublicRootPeers
   traceSanityCheckIssue <- proxyLastToEither (Proxy @TraceSanityCheckIssue) pTraceSanityCheckIssue
   traceServer <- proxyLastToEither (Proxy @TraceServer) pTraceServer
   traceTxInbound <- proxyLastToEither (Proxy @TraceTxInbound) pTraceTxInbound
   traceTxOutbound <- proxyLastToEither (Proxy @TraceTxOutbound) pTraceTxOutbound
   traceTxSubmissionProtocol <- proxyLastToEither (Proxy @TraceTxSubmissionProtocol) pTraceTxSubmissionProtocol
   traceTxSubmission2Protocol <- proxyLastToEither (Proxy @TraceTxSubmission2Protocol) pTraceTxSubmission2Protocol
   traceKeepAliveProtocol <- proxyLastToEither (Proxy @TraceKeepAliveProtocol) pTraceKeepAliveProtocol
   tracePeerSharingProtocol <- proxyLastToEither (Proxy @TracePeerSharingProtocol) pTracePeerSharingProtocol
   traceGsm <- proxyLastToEither (Proxy @TraceGsm) pTraceGsm
   traceCsj <- proxyLastToEither (Proxy @TraceCsj) pTraceCsj
   traceKesAgent <- proxyLastToEither (Proxy @TraceKesAgent) pTraceKesAgent
   traceDevotedBlockFetch <- proxyLastToEither (Proxy @TraceDevotedBlockFetch) pTraceDevotedBlockFetch
   traceChurnMode <- proxyLastToEither (Proxy @TraceChurnMode) pTraceChurnMode
   traceDNS <- proxyLastToEither (Proxy @TraceDNS) pTraceDNS
   traceTxLogic <- proxyLastToEither (Proxy @TraceTxLogic) pTraceTxLogic
   traceTxCounters <- proxyLastToEither (Proxy @TraceTxCounters) pTraceTxCounters
   Right $ TraceDispatcher $ TraceSelection
             { traceVerbosity = traceVerbosity
             , traceAcceptPolicy = traceAcceptPolicy
             , traceBlockFetchClient = traceBlockFetchClient
             , traceBlockFetchDecisions = traceBlockFetchDecisions
             , traceBlockFetchProtocol = traceBlockFetchProtocol
             , traceBlockFetchProtocolSerialised = traceBlockFetchProtocolSerialised
             , traceBlockFetchServer = traceBlockFetchServer
             , traceBlockchainTime = traceBlockchainTime
             , traceChainDB = traceChainDB
             , traceChainSyncBlockServer = traceChainSyncBlockServer
             , traceChainSyncClient = traceChainSyncClient
             , traceChainSyncHeaderServer = traceChainSyncHeaderServer
             , traceChainSyncProtocol = traceChainSyncProtocol
             , traceConnectionManager = traceConnectionManager
             , traceConnectionManagerCounters = traceConnectionManagerCounters
             , traceConnectionManagerTransitions = traceConnectionManagerTransitions
             , traceDebugPeerSelectionInitiatorTracer = traceDebugPeerSelectionInitiatorTracer
             , traceDebugPeerSelectionInitiatorResponderTracer = traceDebugPeerSelectionInitiatorResponderTracer
             , traceDiffusionInitialization = traceDiffusionInitialization
             , traceDnsResolver = traceDnsResolver
             , traceDnsSubscription = traceDnsSubscription
             , traceErrorPolicy = traceErrorPolicy
             , traceForge = traceForge
             , traceForgeStateInfo = traceForgeStateInfo
             , traceGDD = traceGDD
             , traceHandshake = traceHandshake
             , traceInboundGovernor = traceInboundGovernor
             , traceInboundGovernorCounters = traceInboundGovernorCounters
             , traceInboundGovernorTransitions = traceInboundGovernorTransitions
             , traceIpSubscription = traceIpSubscription
             , traceKeepAliveClient = traceKeepAliveClient
             , traceLedgerPeers = traceLedgerPeers
             , traceLocalChainSyncProtocol = traceLocalChainSyncProtocol
             , traceLocalConnectionManager = traceLocalConnectionManager
             , traceLocalErrorPolicy = traceLocalErrorPolicy
             , traceLocalHandshake = traceLocalHandshake
             , traceLocalInboundGovernor = traceLocalInboundGovernor
             , traceLocalMux = traceLocalMux
             , traceLocalMuxBearer = traceLocalMuxBearer
             , traceLocalMuxChannel = traceLocalMuxChannel
             , traceLocalTxMonitorProtocol = traceLocalTxMonitorProtocol
             , traceLocalRootPeers = traceLocalRootPeers
             , traceLocalServer = traceLocalServer
             , traceLocalStateQueryProtocol = traceLocalStateQueryProtocol
             , traceLocalTxSubmissionProtocol = traceLocalTxSubmissionProtocol
             , traceLocalTxSubmissionServer = traceLocalTxSubmissionServer
             , traceMempool = traceMempool
             , traceBackingStore = traceBackingStore
             , traceMux = traceMux
             , traceMuxBearer = traceMuxBearer
             , traceMuxChannel = traceMuxChannel
             , tracePeerSelection = tracePeerSelection
             , tracePeerSelectionCounters = tracePeerSelectionCounters
             , tracePeerSelectionActions = tracePeerSelectionActions
             , tracePublicRootPeers = tracePublicRootPeers
             , traceSanityCheckIssue = traceSanityCheckIssue
             , traceServer = traceServer
             , traceTxInbound = traceTxInbound
             , traceTxOutbound = traceTxOutbound
             , traceTxSubmissionProtocol = traceTxSubmissionProtocol
             , traceTxSubmission2Protocol = traceTxSubmission2Protocol
             , traceKeepAliveProtocol = traceKeepAliveProtocol
             , tracePeerSharingProtocol = tracePeerSharingProtocol
             , traceGsm = traceGsm
             , traceCsj = traceCsj
             , traceDevotedBlockFetch = traceDevotedBlockFetch
             , traceChurnMode
             , traceDNS
             , traceKesAgent = traceKesAgent
             , traceTxLogic
             , traceTxCounters
             }

partialTraceSelectionToEither (Last (Just (PartialTracingOnLegacy pTraceSelection))) = do
  -- This will be removed once the old tracing system is deprecated.
  let PartialTraceSelection {..} = defaultPartialTraceConfiguration <> pTraceSelection
  traceVerbosity <- first Text.pack $ lastToEither "Default value not specified for TracingVerbosity" pTraceVerbosity
  traceAcceptPolicy <- proxyLastToEither (Proxy @TraceAcceptPolicy) pTraceAcceptPolicy
  traceBlockchainTime <- proxyLastToEither (Proxy @TraceBlockchainTime) pTraceBlockchainTime
  traceBlockFetchClient <- proxyLastToEither (Proxy @TraceBlockFetchClient) pTraceBlockFetchClient
  traceBlockFetchDecisions <- proxyLastToEither (Proxy @TraceBlockFetchDecisions) pTraceBlockFetchDecisions
  traceBlockFetchProtocol <- proxyLastToEither (Proxy @TraceBlockFetchProtocol) pTraceBlockFetchProtocol
  traceBlockFetchProtocolSerialised <- proxyLastToEither (Proxy @TraceBlockFetchProtocolSerialised) pTraceBlockFetchProtocolSerialised
  traceBlockFetchServer <- proxyLastToEither (Proxy @TraceBlockFetchServer) pTraceBlockFetchServer
  traceChainDB <- proxyLastToEither (Proxy @TraceChainDB) pTraceChainDB
  traceChainSyncBlockServer <- proxyLastToEither (Proxy @TraceChainSyncBlockServer) pTraceChainSyncBlockServer
  traceChainSyncClient <- proxyLastToEither (Proxy @TraceChainSyncClient) pTraceChainSyncClient
  traceChainSyncHeaderServer <- proxyLastToEither (Proxy @TraceChainSyncHeaderServer) pTraceChainSyncHeaderServer
  traceChainSyncProtocol <- proxyLastToEither (Proxy @TraceChainSyncProtocol) pTraceChainSyncProtocol
  traceConnectionManager <- proxyLastToEither (Proxy @TraceConnectionManager) pTraceConnectionManager
  traceConnectionManagerCounters <- proxyLastToEither (Proxy @TraceConnectionManagerCounters) pTraceConnectionManagerCounters
  traceConnectionManagerTransitions <- proxyLastToEither (Proxy @TraceConnectionManagerTransitions) pTraceConnectionManagerTransitions
  traceDebugPeerSelectionInitiatorTracer <- proxyLastToEither (Proxy @DebugPeerSelectionInitiator) pTraceDebugPeerSelectionInitiatorTracer
  traceDebugPeerSelectionInitiatorResponderTracer <- proxyLastToEither (Proxy @DebugPeerSelectionInitiatorResponder) pTraceDebugPeerSelectionInitiatorResponderTracer
  traceDiffusionInitialization <- proxyLastToEither (Proxy @TraceDiffusionInitialization) pTraceDiffusionInitialization
  traceDnsResolver <- proxyLastToEither (Proxy @TraceDnsResolver) pTraceDnsResolver
  traceDnsSubscription <- proxyLastToEither (Proxy @TraceDnsSubscription) pTraceDnsSubscription
  traceErrorPolicy <- proxyLastToEither (Proxy @TraceErrorPolicy) pTraceErrorPolicy
  traceForge <- proxyLastToEither (Proxy @TraceForge) pTraceForge
  traceForgeStateInfo <- proxyLastToEither (Proxy @TraceForgeStateInfo) pTraceForgeStateInfo
  traceGDD <- proxyLastToEither (Proxy @TraceGDD) pTraceGDD
  traceHandshake <- proxyLastToEither (Proxy @TraceHandshake) pTraceHandshake
  traceInboundGovernor <- proxyLastToEither (Proxy @TraceInboundGovernor) pTraceInboundGovernor
  traceIpSubscription <- proxyLastToEither (Proxy @TraceIpSubscription) pTraceIpSubscription
  traceInboundGovernorCounters <- proxyLastToEither (Proxy @TraceInboundGovernorCounters) pTraceInboundGovernorCounters
  traceInboundGovernorTransitions <- proxyLastToEither (Proxy @TraceInboundGovernorTransitions) pTraceInboundGovernorTransitions
  traceKeepAliveClient <- proxyLastToEither (Proxy @TraceKeepAliveClient) pTraceKeepAliveClient
  traceLedgerPeers <- proxyLastToEither (Proxy @TraceLedgerPeers) pTraceLedgerPeers
  traceLocalChainSyncProtocol <- proxyLastToEither (Proxy @TraceLocalChainSyncProtocol) pTraceLocalChainSyncProtocol
  traceLocalConnectionManager <- proxyLastToEither (Proxy @TraceLocalConnectionManager) pTraceLocalConnectionManager
  traceLocalErrorPolicy <- proxyLastToEither (Proxy @TraceLocalErrorPolicy) pTraceLocalErrorPolicy
  traceLocalHandshake <- proxyLastToEither (Proxy @TraceLocalHandshake) pTraceLocalHandshake
  traceLocalInboundGovernor <- proxyLastToEither (Proxy @TraceLocalInboundGovernor) pTraceLocalInboundGovernor
  traceLocalMux <- proxyLastToEither (Proxy @TraceLocalMux) pTraceLocalMux
  traceLocalMuxBearer <- proxyLastToEither (Proxy @TraceLocalMuxBearer) pTraceLocalMuxBearer
  traceLocalMuxChannel <- proxyLastToEither (Proxy @TraceLocalMuxChannel) pTraceLocalMuxChannel
  traceLocalRootPeers <- proxyLastToEither (Proxy @TraceLocalRootPeers) pTraceLocalRootPeers
  traceLocalServer <- proxyLastToEither (Proxy @TraceLocalServer) pTraceLocalServer
  traceLocalTxMonitorProtocol <- proxyLastToEither (Proxy @TraceLocalTxMonitorProtocol) pTraceLocalTxMonitorProtocol
  traceLocalStateQueryProtocol <- proxyLastToEither (Proxy @TraceLocalStateQueryProtocol) pTraceLocalStateQueryProtocol
  traceLocalTxSubmissionProtocol <- proxyLastToEither (Proxy @TraceLocalTxSubmissionProtocol) pTraceLocalTxSubmissionProtocol
  traceLocalTxSubmissionServer <- proxyLastToEither (Proxy @TraceLocalTxSubmissionServer) pTraceLocalTxSubmissionServer
  traceMempool <- proxyLastToEither (Proxy @TraceMempool) pTraceMempool
  traceBackingStore <- proxyLastToEither (Proxy @TraceBackingStore) pTraceBackingStore
  traceMux <- proxyLastToEither (Proxy @TraceMux) pTraceMux
  traceMuxBearer <- proxyLastToEither (Proxy @TraceMuxBearer) pTraceMuxBearer
  traceMuxChannel <- proxyLastToEither (Proxy @TraceMuxChannel) pTraceMuxChannel
  tracePeerSelection <- proxyLastToEither (Proxy @TracePeerSelection) pTracePeerSelection
  tracePeerSelectionCounters <- proxyLastToEither (Proxy @TracePeerSelectionCounters) pTracePeerSelectionCounters
  tracePeerSelectionActions <- proxyLastToEither (Proxy @TracePeerSelectionActions) pTracePeerSelectionActions
  tracePublicRootPeers <- proxyLastToEither (Proxy @TracePublicRootPeers) pTracePublicRootPeers
  traceSanityCheckIssue <- proxyLastToEither (Proxy @TraceSanityCheckIssue) pTraceSanityCheckIssue
  traceServer <- proxyLastToEither (Proxy @TraceServer) pTraceServer
  traceTxInbound <- proxyLastToEither (Proxy @TraceTxInbound) pTraceTxInbound
  traceTxOutbound <- proxyLastToEither (Proxy @TraceTxOutbound) pTraceTxOutbound
  traceTxSubmissionProtocol <- proxyLastToEither (Proxy @TraceTxSubmissionProtocol) pTraceTxSubmissionProtocol
  traceTxSubmission2Protocol <- proxyLastToEither (Proxy @TraceTxSubmission2Protocol) pTraceTxSubmission2Protocol
  traceKeepAliveProtocol <- proxyLastToEither (Proxy @TraceKeepAliveProtocol) pTraceKeepAliveProtocol
  tracePeerSharingProtocol <- proxyLastToEither (Proxy @TracePeerSharingProtocol) pTracePeerSharingProtocol
  traceGsm <- proxyLastToEither (Proxy @TraceGsm) pTraceGsm
  traceCsj <- proxyLastToEither (Proxy @TraceCsj) pTraceCsj
  traceKesAgent <- proxyLastToEither (Proxy @TraceKesAgent) pTraceKesAgent
  traceDevotedBlockFetch <- proxyLastToEither (Proxy @TraceDevotedBlockFetch) pTraceDevotedBlockFetch
  traceChurnMode <- proxyLastToEither (Proxy @TraceChurnMode) pTraceChurnMode
  traceDNS <- proxyLastToEither (Proxy @TraceDNS) pTraceDNS
  traceTxLogic <- proxyLastToEither (Proxy @TraceTxLogic) pTraceTxLogic
  traceTxCounters <- proxyLastToEither (Proxy @TraceTxCounters) pTraceTxCounters
  Right $ TracingOnLegacy $ TraceSelection
            { traceVerbosity = traceVerbosity
            , traceAcceptPolicy = traceAcceptPolicy
            , traceBlockFetchClient = traceBlockFetchClient
            , traceBlockFetchDecisions = traceBlockFetchDecisions
            , traceBlockFetchProtocol = traceBlockFetchProtocol
            , traceBlockFetchProtocolSerialised = traceBlockFetchProtocolSerialised
            , traceBlockFetchServer = traceBlockFetchServer
            , traceBlockchainTime = traceBlockchainTime
            , traceChainDB = traceChainDB
            , traceChainSyncBlockServer = traceChainSyncBlockServer
            , traceChainSyncClient = traceChainSyncClient
            , traceChainSyncHeaderServer = traceChainSyncHeaderServer
            , traceChainSyncProtocol = traceChainSyncProtocol
            , traceConnectionManager = traceConnectionManager
            , traceConnectionManagerCounters = traceConnectionManagerCounters
            , traceConnectionManagerTransitions = traceConnectionManagerTransitions
            , traceDebugPeerSelectionInitiatorTracer = traceDebugPeerSelectionInitiatorTracer
            , traceDebugPeerSelectionInitiatorResponderTracer = traceDebugPeerSelectionInitiatorResponderTracer
            , traceDiffusionInitialization = traceDiffusionInitialization
            , traceDnsResolver = traceDnsResolver
            , traceDnsSubscription = traceDnsSubscription
            , traceErrorPolicy = traceErrorPolicy
            , traceForge = traceForge
            , traceForgeStateInfo = traceForgeStateInfo
            , traceGDD = traceGDD
            , traceHandshake = traceHandshake
            , traceInboundGovernor = traceInboundGovernor
            , traceInboundGovernorCounters = traceInboundGovernorCounters
            , traceInboundGovernorTransitions = traceInboundGovernorTransitions
            , traceIpSubscription = traceIpSubscription
            , traceKeepAliveClient = traceKeepAliveClient
            , traceLedgerPeers = traceLedgerPeers
            , traceLocalChainSyncProtocol = traceLocalChainSyncProtocol
            , traceLocalConnectionManager = traceLocalConnectionManager
            , traceLocalErrorPolicy = traceLocalErrorPolicy
            , traceLocalHandshake = traceLocalHandshake
            , traceLocalInboundGovernor = traceLocalInboundGovernor
            , traceLocalMux = traceLocalMux
            , traceLocalMuxBearer = traceLocalMuxBearer
            , traceLocalMuxChannel = traceLocalMuxChannel
            , traceLocalRootPeers = traceLocalRootPeers
            , traceLocalServer = traceLocalServer
            , traceLocalStateQueryProtocol = traceLocalStateQueryProtocol
            , traceLocalTxMonitorProtocol = traceLocalTxMonitorProtocol
            , traceLocalTxSubmissionProtocol = traceLocalTxSubmissionProtocol
            , traceLocalTxSubmissionServer = traceLocalTxSubmissionServer
            , traceMempool = traceMempool
            , traceBackingStore = traceBackingStore
            , traceMux = traceMux
            , traceMuxBearer = traceMuxBearer
            , traceMuxChannel = traceMuxChannel
            , tracePeerSelection = tracePeerSelection
            , tracePeerSelectionCounters = tracePeerSelectionCounters
            , tracePeerSelectionActions = tracePeerSelectionActions
            , tracePublicRootPeers = tracePublicRootPeers
            , traceSanityCheckIssue = traceSanityCheckIssue
            , traceServer = traceServer
            , traceTxInbound = traceTxInbound
            , traceTxOutbound = traceTxOutbound
            , traceTxSubmissionProtocol = traceTxSubmissionProtocol
            , traceTxSubmission2Protocol = traceTxSubmission2Protocol
            , traceKeepAliveProtocol = traceKeepAliveProtocol
            , tracePeerSharingProtocol = tracePeerSharingProtocol
            , traceGsm = traceGsm
            , traceCsj = traceCsj
            , traceDevotedBlockFetch = traceDevotedBlockFetch
            , traceChurnMode
            , traceDNS
            , traceKesAgent = traceKesAgent
            , traceTxLogic
            , traceTxCounters
            }

proxyLastToEither :: KnownSymbol name => Proxy name -> Last (OnOff name) -> Either Text (OnOff name)
proxyLastToEither name (Last x) =
  maybe (Left $ "Default value not specified for " <> proxyName name) Right x

parseTracer :: KnownSymbol name => Proxy name -> Object -> Parser (Last (OnOff name))
parseTracer p obj = Last <$> obj .:? Aeson.fromText (proxyName p)

lastToEither :: String -> Last a -> Either String a
lastToEither errMsg (Last x) = maybe (Left errMsg) Right x
