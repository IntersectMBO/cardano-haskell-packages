# Version history for `small-steps`

## 1.0.0.0

* First properly versioned release
