# Version history for `cardano-ledger-babbage`

## 1.0.0.0

* First properly versioned release.
