# Version history for `byron-spec-ledger`

## 1.0.1.0

* Replaced `small-steps-test` dependency with `small-steps:testlib`

## 1.0.0.2

*

## 1.0.0.1

*

## 1.0.0.0

* First properly versioned release.

## 0.1.0.0

* Some really old improperly versioned release
