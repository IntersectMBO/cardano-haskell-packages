# Changelog for cardano-api-gen

## 8.1.0.2

First usable version.
