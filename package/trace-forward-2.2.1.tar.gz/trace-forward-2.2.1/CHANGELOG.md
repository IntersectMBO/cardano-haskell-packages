# ChangeLog

## 2.2.1 - Oct 2023

* Updated to `ouroboros-network-api-0.6` and `ouroboros-network-framework-0.10`

## 2.1.0 - Sep 18 2023

* Updated to `ouroboros-network-api-0.5.1` and `ouroboros-network-framework-0.9.0`.

## 2.0.0 - May 2023

* Undocumented changes

## 1.34.5 - November 2022

* No changes

## 0.1.0 - October 2022

* Initial Release
