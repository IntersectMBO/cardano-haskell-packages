{-# LANGUAGE TypeApplications #-}
{-# OPTIONS_GHC -Wno-orphans #-}

module Main where

import Cardano.Ledger.Block (Block (Block))
import Cardano.Ledger.Coin (Coin (..))
import Cardano.Ledger.Conway (ConwayEra)
import Cardano.Ledger.Conway.Tx (tierRefScriptFee)
import Cardano.Protocol.Crypto (StandardCrypto)
import qualified Cardano.Protocol.Praos.BlockHeader as Praos
import qualified Test.Cardano.Base.QuickCheck as BaseQC
import Test.Cardano.Ledger.Common
import qualified Test.Cardano.Ledger.Conway.Binary.CddlSpec as Cddl
import qualified Test.Cardano.Ledger.Conway.GenesisSpec as Genesis
import qualified Test.Cardano.Ledger.Conway.GoldenSpec as GoldenSpec
import qualified Test.Cardano.Ledger.Conway.GoldenTranslation as GoldenTranslation
import qualified Test.Cardano.Ledger.Conway.GovActionReorderSpec as GovActionReorder
import qualified Test.Cardano.Ledger.Conway.Imp as Imp
import Test.Cardano.Ledger.Conway.Plutus.PlutusSpec as PlutusSpec
import qualified Test.Cardano.Ledger.Conway.Spec as ConwaySpec
import qualified Test.Cardano.Ledger.Conway.TxInfoSpec as TxInfo
import Test.Cardano.Ledger.Core.Binary.RoundTrip (
  roundTripAnnEraExpectation,
  roundTripEraExpectation,
 )
import Test.Cardano.Ledger.Era
import Test.Cardano.Ledger.Shelley.JSON (roundTripJsonShelleyEraSpec)

instance EraSpec ConwayEra where
  eraImpSpec era = do
    Imp.alonzoToConwaySpec era
    Imp.conwayOnlySpec
    Imp.spec era

main :: IO ()
main = ledgerEraTestMain @ConwayEra $ do
  describe "Conway era-generic" $ ConwaySpec.spec @ConwayEra
  describe "Conway era-specific" $ do
    GoldenTranslation.spec
    Genesis.spec
    GovActionReorder.spec
    describe "Plutus" $ do
      PlutusSpec.spec
    Cddl.spec
    GoldenSpec.spec
    TxInfo.spec
    describe "RoundTrip" $
      prop "Block (Praos.Header)" $
        BaseQC.withNumTests 25 $
          forAll (Block <$> arbitrary <*> scale (`div` 2) arbitrary) $ \block ->
            conjoin
              [ roundTripEraExpectation @ConwayEra @(Block (Praos.Header StandardCrypto) ConwayEra) block
              , roundTripAnnEraExpectation @ConwayEra @(Block (Praos.Header StandardCrypto) ConwayEra) block
              ]
  describe "Various tests for functions defined in Conway" $ do
    prop "tierRefScriptFee is a linear function when growth is 1" $ \(Positive sizeIncrement) baseFee (NonNegative size) ->
      tierRefScriptFee 1 sizeIncrement baseFee size
        === Coin (floor (fromIntegral size * baseFee))
    it "tierRefScriptFee" $ do
      let step = 25600
      map (tierRefScriptFee 1.5 step 15) [0, step .. 204800]
        `shouldBe` map Coin [0, 384000, 960000, 1824000, 3120000, 5064000, 7980000, 12354000, 18915000]
  roundTripJsonShelleyEraSpec @ConwayEra
