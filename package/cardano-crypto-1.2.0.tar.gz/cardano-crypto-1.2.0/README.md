The Cardano-crypto Project
==========================

This repository provides cryptographic libraries that are used in the Byron era of the Cardano node (but not Shelley
or more recent eras).  It is a dependency for various repositories that are used to build the node.  It is therefore maintained, 
but is unlikely to be modified.
