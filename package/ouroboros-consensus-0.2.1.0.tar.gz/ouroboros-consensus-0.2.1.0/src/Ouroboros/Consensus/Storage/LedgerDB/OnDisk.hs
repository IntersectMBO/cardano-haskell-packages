module Ouroboros.Consensus.Storage.LedgerDB.OnDisk {-# DEPRECATED "Use Ouroboros.Consensus.Storage.LedgerDB instead" #-}
  ( module Ouroboros.Consensus.Storage.LedgerDB
  ) where

import Ouroboros.Consensus.Storage.LedgerDB
