# acts-generic changelog

<!-- scriv-insert-here -->

<a id='changelog-0.1.0.1'></a>
## 0.1.0.1 -- 2026-01-15

### Non-Breaking

- Update dependencies.
<!-- scriv-end-here -->

## 0.1.0.0 -- YYYY-mm-dd

* First version. Released on an unsuspecting world.
