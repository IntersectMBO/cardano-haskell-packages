# Version history for `cardano-data`

## 1.0.0.0

* First properly versioned released.
