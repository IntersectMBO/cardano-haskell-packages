# cardano-ping

Utility for pinging cardano nodes.
