{-# LANGUAGE DataKinds #-}
{-# LANGUAGE FlexibleContexts #-}
{-# LANGUAGE FlexibleInstances #-}
{-# LANGUAGE GADTs #-}
{-# LANGUAGE OverloadedStrings #-}
{-# LANGUAGE ScopedTypeVariables #-}

module Test.Cardano.Ledger.Conway.Genesis (expectedConwayGenesis) where

import Cardano.Ledger.BaseTypes (EpochInterval (..), textToUrl)
import Cardano.Ledger.Coin (Coin (..), CompactForm (..))
import Cardano.Ledger.Conway
import Cardano.Ledger.Conway.Genesis (ConwayGenesis (..))
import Cardano.Ledger.Conway.Governance (Anchor (..), Committee (..))
import Cardano.Ledger.Conway.PParams
import Cardano.Ledger.Conway.TxCert (Delegatee (..))
import Cardano.Ledger.Core
import Cardano.Ledger.Credential
import Cardano.Ledger.Slot (EpochNo (..))
import Cardano.Ledger.State (DRep (..), DRepState (..))
import Data.Default (Default (def))
import qualified Data.ListMap as ListMap
import Data.Map as Map
import Data.Maybe (fromJust)
import Data.Maybe.Strict (StrictMaybe (..))
import Data.Ratio ((%))
import Test.Cardano.Ledger.Conway.Arbitrary ()
import Test.Cardano.Ledger.Core.Utils (unsafeBoundRational)
import Test.Cardano.Ledger.Plutus (zeroTestingCostModelV3)

credMember :: Credential ColdCommitteeRole
credMember = KeyHashObj (KeyHash "4e88cc2d27c364aaf90648a87dfb95f8ee103ba67fa1f12f5e86c42a")

scriptMember :: Credential ColdCommitteeRole
scriptMember = ScriptHashObj (ScriptHash "4e88cc2d27c364aaf90648a87dfb95f8ee103ba67fa1f12f5e86c42a")

comm :: Committee ConwayEra
comm =
  Committee
    ( Map.fromList
        [
          ( credMember
          , EpochNo 1
          )
        ,
          ( scriptMember
          , EpochNo 2
          )
        ]
    )
    (unsafeBoundRational (1 % 2))

expectedConwayGenesis :: ConwayGenesis
expectedConwayGenesis =
  ConwayGenesis
    { cgCommittee = comm
    , cgInitialDReps =
        ListMap.fromList
          [
            ( KeyHashObj
                (KeyHash "78301005df84ba67fa1f12f95f8ee10335bc5e86c42afbc593ab4cdd")
            , DRepState
                { drepExpiry = EpochNo 1000
                , drepAnchor = SNothing
                , drepDeposit = CompactCoin 5000
                , drepDelegs = mempty
                }
            )
          ,
            ( ScriptHashObj
                (ScriptHash "01305df84b078ac5e86c42afbc593ab4cdd67fa1f12f95f8ee10335b")
            , DRepState
                { drepExpiry = EpochNo 300
                , drepAnchor =
                    SJust $
                      Anchor
                        { anchorUrl = fromJust $ textToUrl 99 "example.com"
                        , anchorDataHash = def
                        }
                , drepDeposit = CompactCoin 6000
                , drepDelegs = mempty
                }
            )
          ]
    , cgDelegs =
        ListMap.fromList
          [
            ( KeyHashObj
                (KeyHash "35bc5e86c42afbc593ab4cdd78301005df84ba67fa1f12f95f8ee103")
            , DelegVote DRepAlwaysNoConfidence
            )
          ,
            ( KeyHashObj
                (KeyHash "4e88cc2d27c364aaf90648a87dfb95f8ee103ba67fa1f12f5e86c42a")
            , DelegVote DRepAlwaysAbstain
            )
          ,
            ( KeyHashObj
                (KeyHash "5df84bcdd7a5f8ee93aafbc500b435bc5e83067fa1f12f9110386c42")
            , DelegStake $ KeyHash "0335bc5e86c42afbc578301005df84ba67fa1f12f95f8ee193ab4cdd"
            )
          ,
            ( KeyHashObj
                (KeyHash "8ee93a5df84bc42cdd7a5fafbc500b435bc5e83067fa1f12f9110386")
            , DelegStakeVote
                (KeyHash "086c42afbc578301005df84ba67fa1f12f95f8ee193ab4cdd335bc5e")
                DRepAlwaysAbstain
            )
          ,
            ( KeyHashObj
                (KeyHash "df93ab435bc5eafbc500583067fa1f12f9110386c42cdd784ba5f8ee")
            , DelegVote $
                DRepCredential
                  (ScriptHashObj (ScriptHash "01305df84b078ac5e86c42afbc593ab4cdd67fa1f12f95f8ee10335b"))
            )
          ,
            ( ScriptHashObj
                (ScriptHash "afbc5005df84ba5f8ee93ab435bc5e83067fa1f12f9c42cdd7110386")
            , DelegVote $
                DRepCredential
                  (KeyHashObj (KeyHash "78301005df84ba67fa1f12f95f8ee10335bc5e86c42afbc593ab4cdd"))
            )
          ]
    , cgConstitution = def
    , cgUpgradePParams =
        UpgradeConwayPParams
          { ucppPoolVotingThresholds = def
          , ucppDRepVotingThresholds = def
          , ucppCommitteeMinSize = 0
          , ucppCommitteeMaxTermLength = EpochInterval 0
          , ucppGovActionLifetime = EpochInterval 0
          , ucppGovActionDeposit = Coin 0
          , ucppDRepDeposit = Coin 0
          , ucppDRepActivity = EpochInterval 0
          , ucppMinFeeRefScriptCostPerByte = minBound
          , ucppPlutusV3CostModel = zeroTestingCostModelV3
          }
    , cgExtraConfig = SNothing
    }
