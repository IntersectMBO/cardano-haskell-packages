{-# LANGUAGE BangPatterns #-}
{-# LANGUAGE DataKinds #-}
{-# LANGUAGE DeriveAnyClass #-}
{-# LANGUAGE DeriveGeneric #-}
{-# LANGUAGE DerivingStrategies #-}
{-# LANGUAGE FlexibleContexts #-}
{-# LANGUAGE FlexibleInstances #-}
{-# LANGUAGE LambdaCase #-}
{-# LANGUAGE MultiParamTypeClasses #-}
{-# LANGUAGE NamedFieldPuns #-}
{-# LANGUAGE OverloadedStrings #-}
{-# LANGUAGE ScopedTypeVariables #-}
{-# LANGUAGE StandaloneDeriving #-}
{-# LANGUAGE TypeApplications #-}
{-# LANGUAGE TypeFamilies #-}
{-# LANGUAGE TypeOperators #-}
{-# LANGUAGE UndecidableInstances #-}
{-# OPTIONS_GHC -Wno-orphans #-}

module Cardano.Ledger.Conway.Rules.Bbody (
  BBODY,
  ConwayBbodyPredFailure (..),
  alonzoToConwayBbodyPredFailure,
  shelleyToConwayBbodyPredFailure,
  totalRefScriptSizeInBlock,
  conwayBbodyTransition,
  validateBodyRefScriptsSizeTooBig,
) where

import qualified Cardano.Ledger.Allegra.Rules as Allegra
import Cardano.Ledger.Alonzo.PParams (AlonzoEraPParams)
import qualified Cardano.Ledger.Alonzo.Rules as Alonzo
import Cardano.Ledger.Alonzo.Scripts (ExUnits (..))
import Cardano.Ledger.Alonzo.Tx (AlonzoEraTx, IsPhase2Valid (..), isPhase2ValidTxL)
import Cardano.Ledger.Alonzo.TxWits (AlonzoEraTxWits (..))
import Cardano.Ledger.Babbage.Collateral (collOuts)
import Cardano.Ledger.Babbage.Core (BabbageEraTxBody)
import qualified Cardano.Ledger.Babbage.Rules as Babbage
import Cardano.Ledger.BaseTypes (
  Mismatch (..),
  Network (..),
  ProtVer (..),
  Relation (..),
  ShelleyBase,
  Version,
  natVersion,
  networkId,
  pvMajor,
  succVersion,
 )
import Cardano.Ledger.Binary (DecCBOR (..), EncCBOR (..))
import Cardano.Ledger.Binary.Coders (Decode (..), Encode (..), decode, encode, (!>), (<!))
import Cardano.Ledger.Block (Block (..), EraBlockHeader (..))
import Cardano.Ledger.Conway.Era (BBODY, ConwayEra)
import Cardano.Ledger.Conway.PParams (ConwayEraPParams (..))
import Cardano.Ledger.Conway.Rules.Cert (ConwayCertPredFailure)
import Cardano.Ledger.Conway.Rules.Certs (ConwayCertsPredFailure)
import Cardano.Ledger.Conway.Rules.Deleg (ConwayDelegPredFailure)
import Cardano.Ledger.Conway.Rules.Gov (ConwayGovPredFailure)
import Cardano.Ledger.Conway.Rules.GovCert (ConwayGovCertPredFailure)
import Cardano.Ledger.Conway.Rules.Ledger (ConwayLedgerPredFailure)
import Cardano.Ledger.Conway.Rules.Ledgers ()
import Cardano.Ledger.Conway.Rules.Utxo (ConwayUtxoPredFailure)
import Cardano.Ledger.Conway.Rules.Utxos (ConwayUtxosPredFailure)
import Cardano.Ledger.Conway.Rules.Utxow (ConwayUtxowPredFailure)
import Cardano.Ledger.Conway.UTxO (txNonDistinctRefScriptsSize)
import Cardano.Ledger.Core
import Cardano.Ledger.Shelley.LedgerState (LedgerState (..), utxoL)
import qualified Cardano.Ledger.Shelley.Rules as Shelley
import Cardano.Ledger.Shelley.UTxO (UTxO (..), txouts, unUTxO)
import Control.DeepSeq (NFData)
import Control.Monad (guard, when)
import Control.Monad.Trans.Reader (asks)
import Control.State.Transition (
  Embed (..),
  Rule,
  RuleType (..),
  STS (..),
  TRC (..),
  TransitionRule,
  failOnJust,
  judgmentContext,
  liftSTS,
  (?!),
 )
import Data.Foldable (Foldable (foldMap'))
import qualified Data.Foldable as F (foldl')
import qualified Data.Map.Strict as Map
import Data.Monoid (Sum (getSum))
import qualified Data.Monoid as Monoid (Sum (..))
import Data.Sequence (Seq)
import Data.Sequence.Strict (StrictSeq)
import Data.Word (Word32)
import GHC.Generics (Generic)
import Lens.Micro

data ConwayBbodyPredFailure era
  = WrongBlockBodySizeBBODY (Mismatch RelEQ Int)
  | InvalidBodyHashBBODY (Mismatch RelEQ (Hash HASH EraIndependentBlockBody))
  | -- | LEDGERS rule subtransition Failures
    LedgersFailure (PredicateFailure (EraRule "LEDGERS" era))
  | TooManyExUnits (Mismatch RelLTEQ ExUnits)
  | BodyRefScriptsSizeTooBig (Mismatch RelLTEQ Int)
  | HeaderProtVerTooHigh (Mismatch RelLTEQ Version)
  deriving (Generic)

deriving instance
  (Era era, Show (PredicateFailure (EraRule "LEDGERS" era))) =>
  Show (ConwayBbodyPredFailure era)

deriving instance
  (Era era, Eq (PredicateFailure (EraRule "LEDGERS" era))) =>
  Eq (ConwayBbodyPredFailure era)

deriving anyclass instance
  (Era era, NFData (PredicateFailure (EraRule "LEDGERS" era))) =>
  NFData (ConwayBbodyPredFailure era)

instance
  ( Era era
  , EncCBOR (PredicateFailure (EraRule "LEDGERS" era))
  ) =>
  EncCBOR (ConwayBbodyPredFailure era)
  where
  encCBOR =
    encode . \case
      WrongBlockBodySizeBBODY mm -> Sum WrongBlockBodySizeBBODY 0 !> ToGroup mm
      InvalidBodyHashBBODY mm -> Sum (InvalidBodyHashBBODY @era) 1 !> ToGroup mm
      LedgersFailure x -> Sum (LedgersFailure @era) 2 !> To x
      TooManyExUnits mm -> Sum TooManyExUnits 3 !> ToGroup mm
      BodyRefScriptsSizeTooBig mm -> Sum BodyRefScriptsSizeTooBig 4 !> ToGroup mm
      HeaderProtVerTooHigh mm -> Sum HeaderProtVerTooHigh 5 !> To mm

instance
  ( Era era
  , DecCBOR (PredicateFailure (EraRule "LEDGERS" era))
  ) =>
  DecCBOR (ConwayBbodyPredFailure era)
  where
  decCBOR = decode . Summands "ConwayBbodyPred" $ \case
    0 -> SumD WrongBlockBodySizeBBODY <! FromGroup
    1 -> SumD InvalidBodyHashBBODY <! FromGroup
    2 -> SumD LedgersFailure <! From
    3 -> SumD TooManyExUnits <! FromGroup
    4 -> SumD BodyRefScriptsSizeTooBig <! FromGroup
    5 -> SumD HeaderProtVerTooHigh <! From
    n -> Invalid n

type instance EraRuleFailure "BBODY" ConwayEra = ConwayBbodyPredFailure ConwayEra

type instance EraRuleEvent "BBODY" ConwayEra = Alonzo.AlonzoBbodyEvent ConwayEra

instance InjectRuleFailure "BBODY" ConwayBbodyPredFailure ConwayEra

instance InjectRuleFailure "BBODY" Alonzo.AlonzoBbodyPredFailure ConwayEra where
  injectFailure = alonzoToConwayBbodyPredFailure

instance InjectRuleFailure "BBODY" Shelley.ShelleyBbodyPredFailure ConwayEra where
  injectFailure = shelleyToConwayBbodyPredFailure

instance InjectRuleFailure "BBODY" Shelley.ShelleyLedgersPredFailure ConwayEra where
  injectFailure = shelleyToConwayBbodyPredFailure . Shelley.LedgersFailure

instance InjectRuleFailure "BBODY" ConwayLedgerPredFailure ConwayEra where
  injectFailure = shelleyToConwayBbodyPredFailure . Shelley.LedgersFailure . injectFailure

instance InjectRuleFailure "BBODY" ConwayUtxowPredFailure ConwayEra where
  injectFailure = shelleyToConwayBbodyPredFailure . Shelley.LedgersFailure . injectFailure

instance InjectRuleFailure "BBODY" Babbage.BabbageUtxowPredFailure ConwayEra where
  injectFailure = shelleyToConwayBbodyPredFailure . Shelley.LedgersFailure . injectFailure

instance InjectRuleFailure "BBODY" Alonzo.AlonzoUtxowPredFailure ConwayEra where
  injectFailure = shelleyToConwayBbodyPredFailure . Shelley.LedgersFailure . injectFailure

instance InjectRuleFailure "BBODY" Shelley.ShelleyUtxowPredFailure ConwayEra where
  injectFailure = shelleyToConwayBbodyPredFailure . Shelley.LedgersFailure . injectFailure

instance InjectRuleFailure "BBODY" ConwayUtxoPredFailure ConwayEra where
  injectFailure = shelleyToConwayBbodyPredFailure . Shelley.LedgersFailure . injectFailure

instance InjectRuleFailure "BBODY" Babbage.BabbageUtxoPredFailure ConwayEra where
  injectFailure = shelleyToConwayBbodyPredFailure . Shelley.LedgersFailure . injectFailure

instance InjectRuleFailure "BBODY" Alonzo.AlonzoUtxoPredFailure ConwayEra where
  injectFailure = shelleyToConwayBbodyPredFailure . Shelley.LedgersFailure . injectFailure

instance InjectRuleFailure "BBODY" Alonzo.AlonzoUtxosPredFailure ConwayEra where
  injectFailure = shelleyToConwayBbodyPredFailure . Shelley.LedgersFailure . injectFailure

instance InjectRuleFailure "BBODY" ConwayUtxosPredFailure ConwayEra where
  injectFailure = shelleyToConwayBbodyPredFailure . Shelley.LedgersFailure . injectFailure

instance InjectRuleFailure "BBODY" Shelley.ShelleyUtxoPredFailure ConwayEra where
  injectFailure = shelleyToConwayBbodyPredFailure . Shelley.LedgersFailure . injectFailure

instance InjectRuleFailure "BBODY" Allegra.AllegraUtxoPredFailure ConwayEra where
  injectFailure = shelleyToConwayBbodyPredFailure . Shelley.LedgersFailure . injectFailure

instance InjectRuleFailure "BBODY" ConwayCertsPredFailure ConwayEra where
  injectFailure = shelleyToConwayBbodyPredFailure . Shelley.LedgersFailure . injectFailure

instance InjectRuleFailure "BBODY" ConwayCertPredFailure ConwayEra where
  injectFailure = shelleyToConwayBbodyPredFailure . Shelley.LedgersFailure . injectFailure

instance InjectRuleFailure "BBODY" ConwayDelegPredFailure ConwayEra where
  injectFailure = shelleyToConwayBbodyPredFailure . Shelley.LedgersFailure . injectFailure

instance InjectRuleFailure "BBODY" Shelley.ShelleyPoolPredFailure ConwayEra where
  injectFailure = shelleyToConwayBbodyPredFailure . Shelley.LedgersFailure . injectFailure

instance InjectRuleFailure "BBODY" ConwayGovCertPredFailure ConwayEra where
  injectFailure = shelleyToConwayBbodyPredFailure . Shelley.LedgersFailure . injectFailure

instance InjectRuleFailure "BBODY" ConwayGovPredFailure ConwayEra where
  injectFailure = shelleyToConwayBbodyPredFailure . Shelley.LedgersFailure . injectFailure

shelleyToConwayBbodyPredFailure ::
  forall era.
  Shelley.ShelleyBbodyPredFailure era ->
  ConwayBbodyPredFailure era
shelleyToConwayBbodyPredFailure
  (Shelley.WrongBlockBodySizeBBODY m) =
    WrongBlockBodySizeBBODY m
shelleyToConwayBbodyPredFailure
  (Shelley.InvalidBodyHashBBODY m) =
    InvalidBodyHashBBODY m
shelleyToConwayBbodyPredFailure (Shelley.LedgersFailure x) = LedgersFailure x

alonzoToConwayBbodyPredFailure ::
  forall era.
  Alonzo.AlonzoBbodyPredFailure era ->
  ConwayBbodyPredFailure era
alonzoToConwayBbodyPredFailure (Alonzo.ShelleyInAlonzoBbodyPredFailure x) = shelleyToConwayBbodyPredFailure x
alonzoToConwayBbodyPredFailure (Alonzo.TooManyExUnits m) = TooManyExUnits m

instance
  ( Embed (EraRule "LEDGERS" era) (EraRule "BBODY" era)
  , Environment (EraRule "LEDGERS" era) ~ Shelley.ShelleyLedgersEnv era
  , State (EraRule "LEDGERS" era) ~ LedgerState era
  , Signal (EraRule "LEDGERS" era) ~ Seq (Tx TopTx era)
  , AlonzoEraTxWits era
  , EraBlockBody era
  , AlonzoEraPParams era
  , InjectRuleFailure "BBODY" Alonzo.AlonzoBbodyPredFailure era
  , InjectRuleFailure "BBODY" ConwayBbodyPredFailure era
  , InjectRuleFailure "BBODY" Shelley.ShelleyBbodyPredFailure era
  , EraRule "BBODY" era ~ BBODY era
  , AlonzoEraTx era
  , BabbageEraTxBody era
  , ConwayEraPParams era
  ) =>
  STS (BBODY era)
  where
  type State (BBODY era) = Shelley.ShelleyBbodyState era

  type Signal (BBODY era) = Shelley.BbodySignal era

  type Environment (BBODY era) = Shelley.BbodyEnv era

  type BaseM (BBODY era) = ShelleyBase

  type PredicateFailure (BBODY era) = ConwayBbodyPredFailure era

  type Event (BBODY era) = Alonzo.AlonzoBbodyEvent era

  initialRules = []
  transitionRules = [conwayBbodyTransition @era >> Alonzo.alonzoBbodyTransition @era]

conwayBbodyTransition ::
  forall era.
  ( Signal (EraRule "BBODY" era) ~ Shelley.BbodySignal era
  , State (EraRule "BBODY" era) ~ Shelley.ShelleyBbodyState era
  , Environment (EraRule "BBODY" era) ~ Shelley.BbodyEnv era
  , State (EraRule "LEDGERS" era) ~ LedgerState era
  , InjectRuleFailure "BBODY" ConwayBbodyPredFailure era
  , BaseM (EraRule "BBODY" era) ~ ShelleyBase
  , STS (EraRule "BBODY" era)
  , AlonzoEraTx era
  , EraBlockBody era
  , BabbageEraTxBody era
  , ConwayEraPParams era
  ) =>
  TransitionRule (EraRule "BBODY" era)
conwayBbodyTransition = do
  TRC
    ( Shelley.BbodyEnv pp _
      , state@(Shelley.BbodyState ls _)
      , Shelley.BbodySignal block@Block {blockBody}
      ) <-
    judgmentContext

  let curProtVerMajor = pvMajor $ pp ^. ppProtocolVersionL
      checkHeaderProtVerTooHigh = do
        let bhProtVerMajor = pvMajor $ block ^. protVerBlockHeaderL

        -- There is always next version higher than the current one used
        nextProtVerMajor <- succVersion curProtVerMajor
        -- If header version is less than or equal to the next version, then we are OK.
        guard (bhProtVerMajor > nextProtVerMajor)
        Just $
          Mismatch
            { mismatchSupplied = bhProtVerMajor
            , mismatchExpected = nextProtVerMajor
            }
  netId <- liftSTS $ asks networkId

  -- Disable protocol version check for testnets until we are in Dijkstra
  -- https://github.com/IntersectMBO/cardano-ledger/issues/5763
  when (netId == Mainnet || curProtVerMajor >= natVersion @12) $
    failOnJust checkHeaderProtVerTooHigh $
      injectFailure . HeaderProtVerTooHigh @era

  validateBodyRefScriptsSizeTooBig @era pp blockBody (ls ^. utxoL)

  pure state

instance
  ( Era era
  , BaseM ledgers ~ ShelleyBase
  , ledgers ~ EraRule "LEDGERS" era
  , STS ledgers
  ) =>
  Embed ledgers (BBODY era)
  where
  wrapFailed = LedgersFailure
  wrapEvent = Alonzo.ShelleyInAlonzoEvent . Shelley.LedgersEvent

-- | Validate that total reference script size does not exceed block limit.
validateBodyRefScriptsSizeTooBig ::
  forall era.
  ( AlonzoEraTx era
  , BabbageEraTxBody era
  , InjectRuleFailure "BBODY" ConwayBbodyPredFailure era
  , EraBlockBody era
  , ConwayEraPParams era
  ) =>
  PParams era ->
  BlockBody era ->
  UTxO era ->
  Rule (EraRule "BBODY" era) 'Transition ()
validateBodyRefScriptsSizeTooBig pp blockBody utxo =
  let protVer = pp ^. ppProtocolVersionL
      txs = blockBody ^. txSeqBlockBodyL
      totalSize = totalRefScriptSizeInBlock protVer txs utxo
      maxSize = fromIntegral @Word32 @Int $ pp ^. ppMaxRefScriptSizePerBlockG
   in totalSize
        <= maxSize
          ?! injectFailure
            ( BodyRefScriptsSizeTooBig $
                Mismatch
                  { mismatchSupplied = totalSize
                  , mismatchExpected = maxSize
                  }
            )

totalRefScriptSizeInBlock ::
  (AlonzoEraTx era, BabbageEraTxBody era) => ProtVer -> StrictSeq (Tx TopTx era) -> UTxO era -> Int
totalRefScriptSizeInBlock protVer txs (UTxO utxo)
  | pvMajor protVer <= natVersion @10 =
      getSum $ foldMap' (Monoid.Sum . txNonDistinctRefScriptsSize (UTxO utxo)) txs
  | otherwise =
      snd $ F.foldl' accum (utxo, 0) txs
  where
    accum (!accUtxo, !accSum) tx =
      let updatedUtxo = accUtxo `Map.union` unUTxO toAdd
          toAdd
            | Phase2Valid <- tx ^. isPhase2ValidTxL = txouts $ tx ^. bodyTxL
            | otherwise = collOuts $ tx ^. bodyTxL
       in (updatedUtxo, accSum + txNonDistinctRefScriptsSize (UTxO accUtxo) tx)
