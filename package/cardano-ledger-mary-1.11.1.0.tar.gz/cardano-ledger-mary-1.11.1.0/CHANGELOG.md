# Version history for `cardano-ledger-mary`

## 1.11.1.0

* Widen `cardano-crypto-class` upper bound to `<2.7`
* Add `FromJSON` instance for `MaryValue`
* Add `FromJSON` and `FromJSONKey` instances for `AssetName` (hex-decoding from `ToJSON` format)
* Add `ToJSON` and `FromJSON` instances for
  - `TxBody TopTx MaryEra`
  - `Tx TopTx MaryEra`
* Add `EncCBOR`, `ToCBOR` for `Block`
* Add `DecCBOR` instances for `Annotator Block`

### `testlib`

* Add `DecCBOR` instance for `Block`

### `cddl`

* Add `HuddleRule "vrf_cert"` instance

## 1.11.0.0

* Add `Ord` instances for `MaryValue`, `CompactForm MaryValue`
* Add `TranslateEra` instance for `SnapShots`
* Add `ApplyTick` instance for `MaryEra`
* Add `EraForecast` and `ShelleyEraForecast` instances for `MaryEra`.

### `cddl`

* Remove re-exported `genByteString`, `distinct`, `genHash28`, `majorProtocolVersionRule`, `ipRule` and `ipValidator`
* Change `ipv4` and `ipv6` to use exact byte sizes (4 and 16 respectively), no longer allowing leftover bytes

### `testlib`

* Make `Test.Cardano.Ledger.Mary.Imp.spec` accept `Proxy era`
* In `Test.Cardano.Ledger.Mary.Examples`:
  - Remove `exampleMaryBasedShelleyTxBody`, `exampleMaryBasedTxBody`
  - Add `exampleMaryBasedTx`, `exampleMaryTx`

## 1.10.0.0

* Add `Generic` instance for `ApplyTxError`
* Add `MaryApplyTxError` constructor for `ApplyTxError era`
* Add `cddl` sub-library, and `generate-cddl` executable.
* Remove deprecated functions `insert`, `lookup`, `prune`
* Remove deprecated type `Mary`
* Add `burnedMultiAssets`
* Add `TxLevel` argument to `Tx` and `TxBody`
* Add `HasEraTxLevel` instances for `Tx` and `TxBody`
* Add `EraTxLevel` instance

### `cddl`

* Move `cddl-files` to `cddl/data`.
* Export `assetNameRule` for reuse.
* Rename 'multiasset' to `maryMultiasset`
* Add full `HuddleSpec`.

### `testlib`

* Remove `huddle-cddl` and the `CDDL` modules.
* Use fixed-sized `uint .size 8` for `slot` in CDDL for transaction validity intervals

## 1.9.0.0

* Hide `Cardano.Ledger.Mary.Translation` module
* Added `COMPLETE` pragma for `TxCert MaryEra`
* Added `COMPLETE` pragma for `NativeScript MaryEra`
* Move to `testlib` the `DecCBOR` instance for `TxBody MaryEra`
* Remove `MaryTxBody`
* Converted `MaryTxBodyRaw` into a type synonym
* Expose constructor `MkMaryTxBody`
* Add default implementation for `mintValueTxBodyF`

### `testlib`

* Added `EraSpecificSpec MaryEra` instance
* Added `Examples` module with: `ledgerExamples`, `exampleMultiAssetValue`
* Added `Arbitrary` instance for `TransitionConfig MaryEra`
* Added `Era` module with `MaryEraTest` class

## 1.8.0.0

* Add `DecCBOR` instance for `MaryTxBody`
* Converted `CertState` to a type family
* Add `MemPack` instance for `CompactValue` and `CompactForm MaryValue`
* Deprecate `Mary` type synonym
* Remove crypto parametrization from `MaryEra`

## 1.7.1.0

### `testlib`

* Add `mkTokenMintingTx`
* Switch to using `ImpSpec` package

## 1.7.0.1

*

## 1.7.0.0

* Change instance of `TranslationContext` to `NoGenesis`

## 1.6.1.0

* Add `AllegraEraScript` and `ShelleyEraScript` instances for `MaryEra`

## 1.6.0.0

* Change how we report tokens burned in `ValueNotConservedUTxO`: #4288
* Add `getProducedMaryValue`, `pruneZeroMultiAsset`, `filterMultiAsset` and `mapMaybeMultiAsset`
* Deprecate `prune`
* Rename `assetName` to `assetNameBytes`

### `testlib`

* Add `MaryEraImp`

## 1.5.1.0

* Add type `EraRuleEvent` instances for the event type of `TICK` and `LEDGER`
* Add instances for `InjectRuleFailure` and switch to using `injectFailure`
* Add implementation for `getMinFeeTxUtxo`

### `testlib`

* Add `RuleListEra` instance for Mary

## 1.5.0.0

* Change return type of `mintedTxBodyF` to `Set PolicyID`
* Stop exporting all of the internal `hkd*` functions and `PParamsHKD` from
  `Cardano.Ledger.Mary.Core`.
* Stop exporting `ValidityInterval` and `StrictMaybe` from `Cardano.Ledger.Mary.TxBody`
* Moved `ToExpr` instances out of the main library and into the testlib.
* Remove deprecated `translateValue` and `translateCompactValue`

## 1.4.0.0

* Switch `MaryValue` field for ADA from `Integer` to `Coin`
* Make sure that `getConsumedMaryValue` can also handle `DRep` deposits. This is safe for
  all pre-Conway eras and useful for Conway onwards eras.

### `testlib`

* Provide CDDL spec files with `readMaryCddlFileNames` and `readMaryCddlFiles` from
  `Test.Cardano.Ledger.Mary.Binary.Cddl`

## 1.3.5.0

* Add `ToExpr` instance for `CompactValue`
* Implement `getScriptsProvided`

### `testlib`

* Add `Test.Cardano.Ledger.Mary.ImpTest`
* Add `EraImpTest` instance for `MaryEra`

## 1.3.4.0

* Add `ToExpr` instance for:
  - `MaryTxBody`
  - `CompactForm (MaryValue)`
  - `CompactValue`
* Add `Generic` instance for `CompactValue`
* Add `EraTransition` instance.

## 1.3.3.0

* Add `EqRaw` instance for `MaryTxBody`

## 1.3.2.0

* Deprecate `translateValue` and `translateCompactValue`

## 1.3.1.0

* Add implementation for `spendableInputsTxBodyL`

## 1.3.0.2

*

## 1.3.0.1

*

## 1.3.0.0

* Introduction of `TxCert` and `EraTxCert`
* Add `EraTxCert` and `ShelleyEraTxCert` instances to `MaryEra`

## 1.2.0.0

* Removed `genMintValues`

## 1.1.1.0

* Add `TranslateEra` instances for:
  - `DState`
  - `PState`
  - `VState`
* Add `EraDCert`, `ShelleyEraDCert` instances to `MaryEra`

## 1.1.0.0

* Addition of `ToJSON` instances for `AssetName`, `PolicyID`, `MultiAsset` and `MaryValue`.
* Add `ToJSONKey`/`FromJSONKey` instances for `PolicyID`

### `testlib`

* Consolidate all `Arbitrary` instances from the test package to under a new `testlib`. #3285

## 1.0.0.0

* First properly versioned release.
