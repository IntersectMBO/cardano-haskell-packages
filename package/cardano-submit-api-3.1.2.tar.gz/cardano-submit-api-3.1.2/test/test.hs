
import           System.IO (IO)

import qualified System.IO as IO

main :: IO ()
main = IO.putStrLn "cardano-tx-submit test"
