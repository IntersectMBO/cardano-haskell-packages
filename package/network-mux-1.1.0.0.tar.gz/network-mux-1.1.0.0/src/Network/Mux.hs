{-# LANGUAGE BangPatterns              #-}
{-# LANGUAGE DataKinds                 #-}
{-# LANGUAGE ExistentialQuantification #-}
{-# LANGUAGE FlexibleContexts          #-}
{-# LANGUAGE GADTSyntax                #-}
{-# LANGUAGE LambdaCase                #-}
{-# LANGUAGE NamedFieldPuns            #-}
{-# LANGUAGE RankNTypes                #-}
{-# LANGUAGE ScopedTypeVariables       #-}
{-# LANGUAGE TypeFamilies              #-}

-- TODO: GHC-8.10 on Windows
{-# OPTIONS_GHC -Wno-name-shadowing #-}
-- | Network multiplexer API.
--
-- The module should be imported qualified.
module Network.Mux
  ( -- * Defining 'Mux' protocol bundles
    new
  , Mux
  , Mode (..)
  , HasInitiator
  , HasResponder
  , MiniProtocolInfo (..)
  , MiniProtocolNum (..)
  , MiniProtocolDirection (..)
  , MiniProtocolLimits (..)
    -- * Running the Mux
  , run
  , stop
    -- ** Run a mini-protocol
  , runMiniProtocol
  , runMiniProtocolSTM
  , StartOnDemandOrEagerly (..)
  , ByteChannel
  , Channel (..)
    -- * Bearer
  , Bearer
  , MakeBearer (..)
  , ReadBuffer
  , MonadReadBuffer (..)
  , SDUSize (..)
    -- * Monitoring
  , miniProtocolStateMap
  , stopped
    -- * Counters
  , Counters
  , withCounters
  , Counts (..)
  , Failures (..)
  , noFailures
  , noCounts
  , ByteCounts
  , CountersTrace (..)
  , countersInterval
    -- * Errors
  , Error (..)
  , RuntimeError (..)
    -- * Tracing
  , Tracers' (..)
  , Tracers
  , nullTracers
  , contramapTracers'
  , Trace (..)
  , BearerTrace (..)
  , ChannelTrace (..)
  , State (..)
  , traceBearerState
  , WithBearer (..)
  , TracersWithBearer
  , tracersWithBearer
  ) where

import Data.ByteString.Builder (lazyByteString, toLazyByteString)
import Data.ByteString.Lazy qualified as BL
import Data.Foldable (traverse_)
import Data.Int (Int64)
import Data.Map (Map)
import Data.Map.Strict qualified as Map
import Data.Maybe (isNothing, listToMaybe)
import Data.Monoid.Synchronisation (FirstToFinish (..))

import Control.Applicative
import Control.Concurrent.Class.MonadSTM.Strict
import Control.Concurrent.JobPool qualified as JobPool
import Control.Exception (SomeAsyncException (..), SomeException (..), assert)
import Control.Monad
import Control.Monad.Class.MonadAsync
import Control.Monad.Class.MonadFork
import Control.Monad.Class.MonadThrow
import Control.Monad.Class.MonadTimer.SI hiding (timeout)
import Control.Tracer

import Network.Mux.Bearer
import Network.Mux.Channel
import Network.Mux.Counters
import Network.Mux.Egress as Egress
import Network.Mux.Ingress as Ingress
import Network.Mux.Timeout
import Network.Mux.Trace
import Network.Mux.Types


-- | Mux handle which allows to control the multiplexer, e.g.
--
-- * `run`: run the multiplexer
-- * `runMiniProtocol`: start a mini-protocol (eagerly or lazily)
-- * `stop`: stop the multiplexer, causing `run` to return.
--
data Mux (mode :: Mode) m =
     Mux {
       muxMiniProtocols   :: !(Map (MiniProtocolNum, MiniProtocolDir)
                                   (MiniProtocolState mode m)),
       muxControlCmdQueue :: !(StrictTQueue m (ControlCmd mode m)),
       muxStatus          :: StrictTVar m Status,
       muxTracers         :: Tracers m,
       muxCounters        :: !(Maybe (Counters m))
       -- ^ Node-wide counters this mux's failures and bytes are counted in,
       -- given to 'new'.
     }


-- | Get information about all statically registered mini-protocols.
--
miniProtocolStateMap :: MonadSTM m
                     => Mux mode m
                     -> Map (MiniProtocolNum, MiniProtocolDir)
                            (STM m MiniProtocolStatus)
miniProtocolStateMap = fmap (readTVar . miniProtocolStatusVar)
                     . muxMiniProtocols

-- | Await until mux stopped.
--
stopped :: MonadSTM m => Mux mode m -> STM m (Maybe SomeException)
stopped Mux { muxStatus } =
    readTVar muxStatus >>= \case
      Ready      -> retry
      Failed err -> return (Just err)
      Stopping   -> retry
      Stopped    -> return Nothing


-- | Create a mux handle in `Mode` and register mini-protocols.
--
new :: forall (mode :: Mode) m.
       MonadLabelledSTM m
    => Tracers m
    -> Maybe (Counters m)
    -- ^ node-wide counters to count the mux's failures and bytes in, shared
    -- with every other mux made with them, or none; a set is only ever read
    -- by the loop 'withCounters' runs for it.
    -> [MiniProtocolInfo mode]
    -- ^ description of protocols run by the mux layer.  Only these protocols
    -- one will be able to execute.
    -> m (Mux mode m)
new muxTracers muxCounters ptcls = do
    traceWith (tracer_ muxTracers) (TraceNewMux ptcls)
    muxMiniProtocols   <- mkMiniProtocolStateMap ptcls
    muxControlCmdQueue <- atomically newTQueue
    muxStatus <- newTVarIO Ready
    return Mux {
      muxMiniProtocols,
      muxControlCmdQueue,
      muxStatus,
      muxTracers,
      muxCounters
    }

mkMiniProtocolStateMap :: MonadSTM m
                       => [MiniProtocolInfo mode]
                       -> m (Map (MiniProtocolNum, MiniProtocolDir)
                                 (MiniProtocolState mode m))
mkMiniProtocolStateMap ptcls =
    Map.fromList <$>
    sequence
      [ do state <- mkMiniProtocolState ptcl
           return ((miniProtocolNum, protocolDirEnum miniProtocolDir), state)
      | ptcl@MiniProtocolInfo {miniProtocolNum, miniProtocolDir} <- ptcls ]

mkMiniProtocolState :: MonadSTM m
                    => MiniProtocolInfo mode
                    -> m (MiniProtocolState mode m)
mkMiniProtocolState miniProtocolInfo = do
    miniProtocolIngressQueue <- newIngressQueue
    miniProtocolStatusVar    <- newTVarIO StatusIdle
    return MiniProtocolState {
       miniProtocolInfo,
       miniProtocolIngressQueue,
       miniProtocolStatusVar
     }

-- | Shut down the mux. This will cause 'run' to return. It does not
-- wait for any protocol threads to finish, so you should do that first if
-- necessary.
--
stop :: MonadSTM m  => Mux mode m -> m ()
stop Mux{muxControlCmdQueue} =
    atomically $ writeTQueue muxControlCmdQueue CmdShutdown


-- | Mux classification of 'Job's
--
data Group = MuxJob
           | MiniProtocolJob
  deriving (Eq, Ord)


-- | run starts a mux bearer for the specified protocols corresponding to
-- one of the provided Versions.
--
-- __Isometric flow control: analysis of head-of-line blocking of the ingress side of the multiplexer__
--
-- For each mini-protocol (enumerated by @ptcl@), mux will create two
-- channels. One for initiator and one for the responder.  Each channel will use
-- a single 'Wanton'.  When it is filled, it is put in a common queue
-- 'tsrQueue'.  This means that the queue is bound by @2 * |ptcl|@.  Every side
-- of a mini-protocol is served by a single 'Wanton': when an application sends
-- data, the channel will try to put it into the 'Wanton' (which might block).
-- 'Wanton's are taken from the 'tsrQueue' queue by one of mux threads.  This
-- eliminates head of line blocking: each mini-protocol thread can block on
-- putting more bytes into its 'Wanton', but it cannot block the other
-- mini-protocols or the thread that is reading the 'tsrQueue' queue.  This is
-- ensured since the 'muxChannel' will put only a non-empty 'Wanton' to the
-- 'tsrQueue' queue, and on such wantons the queue is never blocked.  This means
-- that  the only way the queue can block is when its empty, which means that
-- none of the mini-protocols wanted to send.  The egress part will read
-- a 'Wanton', take a fixed amount of bytes encode them in as an 'MuxSDU'; if
-- there are leftovers it will put them back in the 'Wanton' and place it at the
-- end of the queue (reading and writing to it will happen in a single STM
-- transaction which assures that the order of requests from a mini-protocol is
-- preserved.
--
-- Properties:
--
-- * at any given time the 'tsrQueue' contains at most one
--   'TranslocationServiceRequest' from a given mini-protocol of the given
--   'MiniProtocolDir', thus the queue contains at most @2 * |ptcl|@
--   translocation requests.
-- * at any given time each @TranslocationServiceRequest@ contains a non-empty
-- 'Wanton'
--
-- A mux is run once: nothing returns its status to 'Ready' afterwards, so a
-- second run could start no mini-protocol.
--
run :: forall m (mode :: Mode).
       ( MonadAsync m
       , MonadDelay m
       , MonadEvaluate m
       , MonadFork m
       , MonadLabelledSTM m
       , Alternative (STM m)
       , MonadThrow (STM m)
       , MonadTimer m
       , MonadMask m
       )
    => Mux mode m
    -> Bearer m
    -> m ()
run Mux { muxMiniProtocols,
          muxControlCmdQueue,
          muxStatus,
          muxTracers = tracers@TracersI {
              tracer_,
              bearerTracer_
            },
          muxCounters
        }
    bearer@Bearer{name} = do

    traceWith tracer_ TraceStarting
    egressQueue <- atomically $ newTBQueue 100

    -- label shared variables
    labelTBQueueIO egressQueue (name ++ "-mux-egress")
    labelTVarIO muxStatus (name ++ "-mux-status")
    labelTQueueIO muxControlCmdQueue (name ++ "-mux-ctrl")

    -- The cells outlive the job pool, so every byte the muxer counted is in
    -- them when they are retired; the demuxer counts in the ingress queues.
    withByteCells muxCounters (miniProtocolIngressQueue <$> muxMiniProtocols) $ \sent ->
      JobPool.withJobPool
        (\jobpool -> do
          JobPool.forkJob jobpool (muxerJob egressQueue sent)
          JobPool.forkJob jobpool demuxerJob
          traceWith tracer_ (TraceState Mature)

          -- Wait for someone to shut us down by calling muxStop or an error.
          -- Outstanding jobs are shut down Upon completion of withJobPool.
          withTimeoutSerial $ \timeout ->
            monitor tracers
                    muxCounters
                    (Map.elems muxMiniProtocols)
                    timeout
                    jobpool
                    egressQueue
                    muxControlCmdQueue
                    muxStatus
        )
    -- Only handle async exceptions, 'monitor' sets 'muxStatus' before throwing
    -- an exception.  Setting 'muxStatus' is necessary to resolve a possible
    -- deadlock of mini-protocol completion action.
    `catch` \(SomeAsyncException e) -> do
      atomically $ writeTVar muxStatus (Failed $ toException e)
      traceWith tracer_ $ TraceState Dead
      throwIO e
  where

    muxerJob egressQueue sent =
      JobPool.Job (muxer egressQueue bearerTracer_ sent bearer)
                  (return . MuxerException)
                  MuxJob
                  (name ++ "-muxer")

    demuxerJob =
      JobPool.Job (demuxer (Map.elems muxMiniProtocols) bearerTracer_ bearer)
                  (return . DemuxerException)
                  MuxJob
                  (name ++ "-demuxer")

-- | Mini-protocol thread executed by `JobPool` which executes `protocolAction`.
--
miniProtocolJob
  :: forall mode m.
     ( MonadCatch m
     , MonadEvaluate m
     , MonadSTM m
     , MonadThrow (STM m)
     )
  => Tracers m
  -> StrictTQueue m (ControlCmd mode m)
  -> EgressQueue m
  -> MiniProtocolState mode m
  -> MiniProtocolAction m
  -> JobPool.Job Group m JobResult
miniProtocolJob TracersI {
                  tracer_,
                  channelTracer_
                }
                cmdQueue
                egressQueue
                MiniProtocolState {
                  miniProtocolInfo =
                    MiniProtocolInfo {
                      miniProtocolNum,
                      miniProtocolDir,
                      miniProtocolStartMode
                    },
                  miniProtocolIngressQueue,
                  miniProtocolStatusVar
                }
               MiniProtocolAction {
                 miniProtocolAction,
                 completionVar
               } =
    JobPool.Job jobAction
                jobHandler
                MiniProtocolJob
                ("prtcl-" ++ (case miniProtocolNum of { MiniProtocolNum a -> show a}) ++ "." ++ show miniProtocolDirEnum)
  where
    jobAction = handle handleAsyncException $ do
      w <- newTVarIO BL.empty
      let chan = muxChannel channelTracer_ egressQueue (Wanton w)
                            miniProtocolNum miniProtocolDirEnum
                            miniProtocolIngressQueue
      (result, remainder) <- miniProtocolAction chan
      traceWith tracer_ (TraceTerminating miniProtocolNum miniProtocolDirEnum)
      atomically $ do
        -- A mini-protocol started eagerly cannot receive data while it is
        -- not running (see 'Network.Mux.Ingress.demuxer'), so neither
        -- trailing bytes nor bytes still in its ingress queue are allowed
        -- when it terminates.  The latter could have arrived after the
        -- callback's last read, e.g. while this transaction waits for the
        -- egress to drain.  The queue is checked in the transaction which
        -- marks the mini-protocol idle, so any later data is rejected by the
        -- demuxer.
        case miniProtocolStartMode of
          StartEagerly -> do
            empty <- nullIngressQueue miniProtocolIngressQueue
            -- guard that ingress queue and remainder are empty
            unless (empty && nullRemainder remainder) $
              throwSTM (UnexpectedIngress miniProtocolNum miniProtocolDirEnum)
          _ -> pure ()
        -- The Wanton w is the SDUs that are queued but not yet sent for this job.
        -- Job threads will be prevented from exiting until all their SDUs have been
        -- transmitted unless an exception/error is encountered. In that case all
        -- jobs will be cancelled directly.
        readTVar w >>= check . BL.null
        writeTVar miniProtocolStatusVar StatusIdle
        putTMVar completionVar (Right result)
          `orElse` throwSTM (BlockedOnCompletionVar miniProtocolNum)
        case remainder of
          Just trailing ->
            modifyTVar miniProtocolIngressQueue $ \q ->
              q { iqLength  = BL.length trailing + iqLength q,
                  iqBuilder = lazyByteString trailing <> iqBuilder q }
          Nothing ->
            pure ()

      return (MiniProtocolShutdown miniProtocolNum miniProtocolDirEnum)

    nullRemainder :: Maybe BL.ByteString -> Bool
    nullRemainder Nothing          = True
    nullRemainder (Just remainder) = BL.null remainder

    -- An asynchronous exception, thrown to the mini-protocol thread from
    -- outside the mux (or raised by the RTS), is not reported by the job pool
    -- (see 'jobHandler'), so it is handled here:
    --
    -- * the status goes 'StatusKilled' and the monitor is sent
    --   'CmdMiniProtocolKilled', on which it ends the mux: the remote side of
    --   the mini-protocol is wherever the kill left it, so the connection
    --   cannot be used any more;
    -- * if the kill lands past the job's last transaction, which fills the
    --   completion var as it writes 'StatusIdle', the mini-protocol has
    --   already terminated: its status is left alone (it may already be a
    --   later start's) and the monitor is not told;
    -- * when the mux itself cancels its jobs (on shutdown or failure) the
    --   monitor no longer reads its command queue, so the command is
    --   ignored.
    --
    -- The asynchronous exception may land in the action, in the trace, or
    -- in the wait for the muxer to take the last bytes, which lasts as
    -- long as the muxer's write. The exception is rethrown, so the thread
    -- still dies of it.
    --
    -- A killed mini-protocol is never run again on this mux, so the data in
    -- its ingress queue is dropped; the demuxer discards any data which
    -- arrives later (the remote side might be sending a reply to a request
    -- sent before the kill).
    handleAsyncException :: SomeAsyncException -> m a
    handleAsyncException err = do
      atomically $ do
        done <- not <$> isEmptyTMVar completionVar
        unless done $ do
          writeTVar miniProtocolStatusVar StatusKilled
          modifyTVar miniProtocolIngressQueue $ \q ->
            q { iqLength = 0, iqBuilder = mempty }
          writeTQueue cmdQueue
            (CmdMiniProtocolKilled miniProtocolNum miniProtocolDirEnum err)
      throwIO err

    -- NOTE: `jobHandler` is never executed on asynchronous exceptions (see
    -- `Control.Concurrent.JobPool.forkJob')`.  Asynchronous exceptions are
    -- handled by `handleAsyncException`.
    jobHandler :: SomeException -> m JobResult
    jobHandler (SomeException err) = do
      -- evaluate error to WHNF; Note that this happens in the mini-protocol
      -- handler thread.
      e <- (toException <$> evaluate err) `catch` return
      _ <- atomically $ tryPutTMVar completionVar (Left e)
      return (MiniProtocolException miniProtocolNum miniProtocolDirEnum e)

    miniProtocolDirEnum :: MiniProtocolDir
    miniProtocolDirEnum = protocolDirEnum miniProtocolDir

data ControlCmd mode m =
     CmdStartProtocolThread
       !(MiniProtocolState mode m)
       !(MiniProtocolAction m)
   | CmdShutdown
   | CmdMiniProtocolKilled !MiniProtocolNum !MiniProtocolDir !SomeAsyncException
     -- ^ a mini-protocol thread was killed by an asynchronous exception; sent
     -- by the mini-protocol job itself, see 'miniProtocolJob'.

data MiniProtocolAction m where
    MiniProtocolAction :: forall m a.
      { miniProtocolAction :: ByteChannel m -> m (a, Maybe BL.ByteString),
        -- ^ mini-protocol action
        completionVar      :: StrictTMVar m (Either SomeException a)
        -- ^ Completion var
      }
      -> MiniProtocolAction m

type MiniProtocolKey = (MiniProtocolNum, MiniProtocolDir)

data MonitorCtx m mode = MonitorCtx {
    -- | Mini-Protocols started on demand and waiting to be scheduled.
    --
    mcOnDemandProtocols :: !(Map MiniProtocolKey
                               (MiniProtocolState mode m, MiniProtocolAction m))
    -- | Mini-Protocols started on demand any and waiting to be scheduled.
    -- Disjoint from `mcOnDemandProtocols`.
    --
  , mcOnDemandAnyProtocols :: !(Map MiniProtocolKey
                                  (MiniProtocolState mode m, MiniProtocolAction m))
  }

-- | The monitoring loop does two jobs:
--
--  1. It waits for mini-protocol threads to terminate.
--  2. It starts responder protocol threads on demand when the first
--     incoming message arrives.
--
monitor :: forall mode m.
           ( MonadAsync m
           , MonadEvaluate m
           , MonadMask m
           , Alternative (STM m)
           , MonadThrow (STM m)
           )
        => Tracers m
        -> Maybe (Counters m)
        -> [MiniProtocolState mode m]
        -> TimeoutFn m
        -> JobPool.JobPool JobPool.WithQueue Group m JobResult
        -> EgressQueue m
        -> StrictTQueue m (ControlCmd mode m)
        -> StrictTVar m Status
        -> m ()
monitor tracers@TracersI {
          tracer_       = tracer,
          bearerTracer_ = bearerTracer
        }
        counters ptcls timeout jobpool egressQueue cmdQueue muxStatus =
    go (MonitorCtx Map.empty Map.empty)
  where
    -- Whether a mini-protocol is running, by the status each keeps: running
    -- from its start command, idle from its last transaction, killed from
    -- its thread's death by an asynchronous exception; a close the demuxer
    -- reads is a failure only then. So a protocol the application has
    -- started whose thread is not yet forked counts as running, and the peer
    -- closing then is a failure, as a close an instant later is; and a
    -- protocol past its last transaction whose job has not yet deregistered
    -- does not.
    anyRunning :: STM m Bool
    anyRunning = elem StatusRunning <$> mapM (readTVar . miniProtocolStatusVar) ptcls

    -- A mini-protocol killed whose 'CmdMiniProtocolKilled' the monitor has
    -- not read yet; the command queue is left as it was.
    pendingKill :: STM m (Maybe (MiniProtocolNum, MiniProtocolDir, SomeAsyncException))
    pendingKill = do
      cmds <- flushTQueue cmdQueue
      traverse_ (writeTQueue cmdQueue) cmds
      return $ listToMaybe [ (n, d, err) | CmdMiniProtocolKilled n d err <- cmds ]

    -- A mini-protocol thread was killed from outside the mux: the remote
    -- side of the mini-protocol is in an unknown state, so the mux is
    -- shut down, as on 'CmdShutdown'.  When the mux itself cancels its
    -- jobs, the monitor does not read the command queue any more, so this
    -- command is only handled for a kill from outside.
    --
    -- The asynchronous exception might be a cleanup after another
    -- mini-protocol failed, 'cancelGroup' blocks until all mini-protocol
    -- jobs terminated, so the failure of such a mini-protocol is in the
    -- completion queue by then, and the mux fails with it, as it would if
    -- the monitor had read it first.  This way original failure is
    -- preserved and the layer above mux can decides based on it what to do
    -- with the connection or the process.  Mini-protocols cancelled by
    -- 'cancelGroup' do not report anything (see
    -- 'Control.Concurrent.JobPool.forkJob').
    miniProtocolKilled :: MiniProtocolNum -> MiniProtocolDir -> SomeAsyncException -> m ()
    miniProtocolKilled pnum pdir err = do
      atomically $ writeTVar muxStatus Stopping
      traceWith tracer (TraceMiniProtocolKilled pnum pdir err)
      results <- JobPool.cancelGroup jobpool MiniProtocolJob
      -- wait for 2 seconds before the egress queue is drained
      _ <- timeout 2 $
        atomically $
              tryPeekTBQueue egressQueue
          >>= check . isNothing

      case [ (n, d, e) | MiniProtocolException n d e <- results ] of
        -- preserve the first published synchronous mini-protocol exception
        (n, d, e) : _ -> do
          atomically $ do
            writeTVar muxStatus $ Failed e
            countMiniProtocolFailure counters n d e
          traceWith tracer (TraceExceptionExit n d e)
          traceWith tracer (TraceState Dead)
          traceWith bearerTracer TraceEmitDeltaQ
          throwIO e

        -- none of the mini-protocols terminated with a synchronous
        -- exception
        [] -> do
          let e = MiniProtocolAsyncException pnum pdir err
          atomically $ do
            writeTVar muxStatus (Failed $ toException e)
            countMiniProtocolFailure counters pnum pdir (toException e)
          traceWith tracer (TraceState Dead)
          -- by exiting the 'monitor' loop we let the job pool kill
          -- demuxer and muxer threads
          throwIO e

    go :: MonitorCtx m mode -> m ()
    go monitorCtx@MonitorCtx { mcOnDemandProtocols
                             , mcOnDemandAnyProtocols } = do
      result <- atomically $ runFirstToFinish $
            -- wait for a mini-protocol thread to terminate
           FirstToFinish (EventJobResult <$> JobPool.waitForJob jobpool)

            -- wait for a new control command
        <> FirstToFinish (EventControlCmd <$> readTQueue cmdQueue)

            -- or wait for data to arrive on the channels that do not yet have
            -- responder threads running
        <> foldMap
             (\(ptclState, ptclAction) ->
               FirstToFinish $ do
                 checkNonEmptyQueue (miniProtocolIngressQueue ptclState)
                 return (EventStartOnDemand ptclState ptclAction)
             )
             mcOnDemandProtocols
       <> foldMap
             (\(ptclState, _ptclAction) ->
               FirstToFinish $ do
                 checkNonEmptyQueue (miniProtocolIngressQueue ptclState)
                 return EventStartOnDemandAny
             )
             mcOnDemandAnyProtocols
      case result of
        -- Protocols that runs to completion are not automatically restarted.
        EventJobResult (MiniProtocolShutdown pnum pmode) -> do
          traceWith tracer (TraceCleanExit pnum pmode)
          traceWith bearerTracer TraceEmitDeltaQ
          go monitorCtx

        EventJobResult (MiniProtocolException pnum pmode e) -> do
          atomically $ do
            writeTVar muxStatus $ Failed e
            countMiniProtocolFailure counters pnum pmode e
          traceWith tracer (TraceExceptionExit pnum pmode e)
          traceWith tracer (TraceState Dead)
          traceWith bearerTracer TraceEmitDeltaQ
          throwIO e

        -- These two cover internal and protocol errors.  The muxer exception is
        -- always fatal.  The demuxer exception 'BearerClosed' when all
        -- mini-protocols stopped indicates a normal shutdown and thus it is not
        -- propagated.
        --
        -- TODO: decide if we should have exception wrappers here to identify
        -- the source of the failure, e.g. specific mini-protocol. If we're
        -- propagating exceptions, we don't need to log them.
        EventJobResult (MuxerException e) -> do
          atomically $ do
            writeTVar muxStatus $ Failed e
            countMuxerFailure counters e
          traceWith tracer (TraceState Dead)
          throwIO e
        EventJobResult (DemuxerException e) -> do
          -- A close read after every mini-protocol has finished is a normal
          -- end and counts nothing; one read while a protocol runs, and a
          -- reset at any time, fail the mux and are counted.  A close read
          -- after the last running mini-protocol was killed, before the
          -- monitor read the kill, is handled as the kill, as it would be if
          -- the monitor had read the kill first.
          r <- atomically $ do
            stopped <- case fromException e of
              Just BearerClosed {} -> not <$> anyRunning
              _                    -> return False
            killed <- if stopped then pendingKill else return Nothing
            case killed of
              Just kill -> return (Left kill)
              Nothing   -> do
                if stopped
                   then writeTVar muxStatus Stopped
                   else countDemuxerFailure counters e
                     >> writeTVar muxStatus (Failed e)
                return (Right stopped)
          case r of
            Left (pnum, pdir, err) -> miniProtocolKilled pnum pdir err
            Right stopped -> do
              traceWith tracer (TraceState Dead)
              unless stopped (throwIO e)

        EventControlCmd (CmdStartProtocolThread
                           ptclState@MiniProtocolState {
                             miniProtocolInfo = MiniProtocolInfo {
                               miniProtocolNum,
                               miniProtocolDir,
                               miniProtocolCapability,
                               miniProtocolStartMode = StartEagerly
                             }
                           }
                           ptclAction) -> do
          traceWith tracer (TraceStartEagerly miniProtocolNum
                                              (protocolDirEnum miniProtocolDir))
          case miniProtocolCapability of
            Nothing ->
              JobPool.forkJob jobpool $
                miniProtocolJob
                  tracers
                  cmdQueue
                  egressQueue
                  ptclState
                  ptclAction
            Just cap ->
              JobPool.forkJobOn cap jobpool $
                miniProtocolJob
                  tracers
                  cmdQueue
                  egressQueue
                  ptclState
                  ptclAction
          go monitorCtx

        EventControlCmd (CmdStartProtocolThread
                           ptclState@MiniProtocolState {
                             miniProtocolInfo = MiniProtocolInfo {
                               miniProtocolNum,
                               miniProtocolDir,
                               miniProtocolStartMode = StartOnDemand
                             }
                           }
                           ptclAction) -> do
          let monitorCtx' = monitorCtx { mcOnDemandProtocols =
                                           Map.insert (protocolKey ptclState)
                                                      (ptclState, ptclAction)
                                                      mcOnDemandProtocols
                                       }
          traceWith tracer (TraceStartOnDemand miniProtocolNum
                             (protocolDirEnum miniProtocolDir))
          go monitorCtx'

        EventControlCmd (CmdStartProtocolThread
                           ptclState@MiniProtocolState {
                             miniProtocolInfo = MiniProtocolInfo {
                               miniProtocolNum,
                               miniProtocolDir,
                               miniProtocolStartMode = StartOnDemandAny
                             }
                           }
                           ptclAction) -> do
          let monitorCtx' = monitorCtx { mcOnDemandAnyProtocols =
                                           Map.insert (protocolKey ptclState)
                                                      (ptclState, ptclAction)
                                                      mcOnDemandAnyProtocols
                                       }
          traceWith tracer (TraceStartOnDemandAny miniProtocolNum
                             (protocolDirEnum miniProtocolDir))
          go monitorCtx'

        EventControlCmd CmdShutdown -> do
          traceWith tracer TraceStopping
          atomically $ writeTVar muxStatus Stopping
          _ <- JobPool.cancelGroup jobpool MiniProtocolJob
          -- wait for 2 seconds before the egress queue is drained
          _ <- timeout 2 $
            atomically $
                  tryPeekTBQueue egressQueue
              >>= check . isNothing
          atomically $ writeTVar muxStatus Stopped
          traceWith tracer TraceStopped
          -- by exiting the 'monitor' loop we let the job pool kill demuxer and
          -- muxer threads

        EventControlCmd (CmdMiniProtocolKilled pnum pdir err) ->
          miniProtocolKilled pnum pdir err

        -- Data has arrived on a channel for a mini-protocol for which we have
        -- an on-demand-start protocol thread. So we start it now along with all
        -- StartOnDemandAny protocols.
        EventStartOnDemand ptclState ptclAction ->
          let ptclKey = protocolKey ptclState in
          assert (Map.null (mcOnDemandAnyProtocols `Map.intersection` mcOnDemandProtocols)) $ do
          doStartOnDemand ptclState ptclAction

          -- Also start any StartOnDemandAny protocols
          mapM_ (uncurry doStartOnDemand) mcOnDemandAnyProtocols

          let monitorCtx' = MonitorCtx { mcOnDemandProtocols =
                                           Map.delete ptclKey mcOnDemandProtocols
                                       , mcOnDemandAnyProtocols = Map.empty
                                       }

          go monitorCtx'

        -- Data has arrived on a channel for a mini-protocol for which we have
        -- an on-demand-start-any protocol thread. So we start them all now.
        EventStartOnDemandAny  -> do
          mapM_ (uncurry doStartOnDemand) mcOnDemandAnyProtocols

          go $ monitorCtx { mcOnDemandAnyProtocols = Map.empty }

    doStartOnDemand :: MiniProtocolState mode m
                        -> MiniProtocolAction m
                        -> m ()
    doStartOnDemand ptclState@MiniProtocolState {
                      miniProtocolInfo = MiniProtocolInfo {
                           miniProtocolNum,
                           miniProtocolDir,
                           miniProtocolCapability
                      },
                      miniProtocolStatusVar
                    }
                    ptclAction = do
      traceWith tracer (TraceStartedOnDemand miniProtocolNum
                                             (protocolDirEnum miniProtocolDir))
      atomically $ modifyTVar miniProtocolStatusVar (\a -> assert (a /= StatusRunning) StatusRunning)
      case miniProtocolCapability of
        Nothing ->
          JobPool.forkJob jobpool $
            miniProtocolJob
              tracers
              cmdQueue
              egressQueue
              ptclState
              ptclAction
        Just cap ->
          JobPool.forkJobOn cap jobpool $
            miniProtocolJob
              tracers
              cmdQueue
              egressQueue
              ptclState
              ptclAction

    checkNonEmptyQueue :: IngressQueue m -> STM m ()
    checkNonEmptyQueue q = do
      l <- iqLength <$> readTVar q
      check (l /= 0)

    protocolKey :: MiniProtocolState mode m -> MiniProtocolKey
    protocolKey MiniProtocolState {
                  miniProtocolInfo = MiniProtocolInfo {
                    miniProtocolNum,
                    miniProtocolDir
                  }
                } =
      (miniProtocolNum, protocolDirEnum miniProtocolDir)

data MonitorEvent mode m =
     EventJobResult  JobResult
   | EventControlCmd (ControlCmd mode m)
   | EventStartOnDemand (MiniProtocolState mode m)
                        (MiniProtocolAction m)
   | EventStartOnDemandAny

-- | The mux forks off a number of threads and its main thread waits and
-- monitors them all. This type covers the different thread and their possible
-- termination behaviour.
--
data JobResult =

       -- | A mini-protocol thread terminated with a result.
       --
       MiniProtocolShutdown MiniProtocolNum MiniProtocolDir

       -- | A mini-protocol thread terminated with an exception. We always
       -- respond by terminating the whole mux.
     | MiniProtocolException MiniProtocolNum MiniProtocolDir SomeException

       -- | Exception in the 'mux' thread. Always fatal.
     | MuxerException   SomeException

       -- | Exception in the 'demux' thread. Always fatal.
     | DemuxerException SomeException


-- | muxChannel creates a duplex channel for a specific 'MiniProtocolId' and
-- 'MiniProtocolDir'.
--
muxChannel
    :: forall m.
       ( MonadEvaluate m
       , MonadSTM m
       )
    => Tracer m ChannelTrace
    -> EgressQueue m
    -> Wanton m
    -> MiniProtocolNum
    -> MiniProtocolDir
    -> IngressQueue m
    -> ByteChannel m
muxChannel tracer egressQueue want@(Wanton w) mc md q =
    Channel { send, recv }
  where
    -- The length of a lazy 'BL.ByteString' counted no further than @n@
    -- bytes. It forces the chunks holding them and nothing after, so it is
    -- below @n@ exactly when the string ended within @n@.
    lengthUpTo :: Int64 -> BL.ByteString -> Int64
    lengthUpTo n = BL.length . BL.take n

    send :: BL.ByteString -> m ()
    send encoding = do
        -- We send CBOR encoded messages by encoding them into by ByteString
        -- forwarding them to the 'mux' thread, see 'Desired servicing semantics'.
        traceWith tracer $ TraceChannelSendStart mc

        -- Force the encoding up to the soft limit here, in the mini-protocol's
        -- thread, to a chunk boundary: unforced, a waiting message keeps alive
        -- whatever its encoder refers to. The muxer encodes the rest as it
        -- sends it.
        held <- evaluate (lengthUpTo egressSoftBufferLimit encoding)

        atomically $ do
            buf <- readTVar w
            -- Count no further than the limit, so the check forces nothing
            -- past it; BL.length only stops there with -O, by a rewrite rule.
            if lengthUpTo egressSoftBufferLimit buf < egressSoftBufferLimit
               then do
                   let wasEmpty = BL.null buf
                   writeTVar w (BL.append buf encoding)
                   when wasEmpty $
                     writeTBQueue egressQueue (TLSRDemand mc md want)
               else retry

        -- The length: the count already made for a message that ended within
        -- the limit; for a longer one, counted as the event is rendered.
        let len = if held < egressSoftBufferLimit
                     then fromIntegral held
                     else fromIntegral (BL.length encoding)
        traceWith tracer $ TraceChannelSendEnd mc len

    recv :: m (Maybe BL.ByteString)
    recv = do
        -- We receive CBOR encoded messages as ByteStrings (possibly partial) from the
        -- matching ingress queue. This is the same queue the 'demux' thread writes to.
        traceWith tracer $ TraceChannelRecvStart mc
        blob <- atomically $ do
            queued <- readTVar q
            if iqLength queued == 0
                then retry
                else do
                  -- The bytes read for the protocol stay counted.
                  writeTVar q queued { iqLength = 0, iqBuilder = mempty }
                  return (toLazyByteString (iqBuilder queued))
        traceWith tracer $ TraceChannelRecvEnd mc (fromIntegral $ BL.length blob)
        return $ Just blob

traceBearerState :: Monad m => Tracer m Trace -> State -> m ()
traceBearerState tracer state =
    traceWith tracer (TraceState state)


--
-- Starting mini-protocol threads
--

-- | An underlying STM version of `runMiniProtocol`.
--
runMiniProtocolSTM
  :: forall mode m a.
     ( Alternative (STM m)
     , MonadSTM   m
     , MonadThrow (STM m)
     )
  => Mux mode m
  -> MiniProtocolNum
  -> MiniProtocolDirection mode
  -> (ByteChannel m -> m (a, Maybe BL.ByteString))
  -> STM m (STM m (Either SomeException a))
runMiniProtocolSTM Mux { muxMiniProtocols,
                         muxControlCmdQueue,
                         muxStatus }
                   ptclNum ptclDir
                   protocolAction

    -- Ensure the mini-protocol is known and get the status var
  | Just ptclState@MiniProtocolState{miniProtocolStatusVar,
                                     miniProtocolInfo}
      <- Map.lookup (ptclNum, ptclDir') muxMiniProtocols

  = do
      st <- readTVar muxStatus
      case st of
        Stopping -> throwSTM (Shutdown Nothing st)
        Stopped  -> throwSTM (Shutdown Nothing st)
        Failed e -> throwSTM (Shutdown (Just e) st)
        Ready {} -> return ()

      -- Make sure no thread is currently running, or was killed, and update
      -- the status to indicate a thread is running (or ready to start on
      -- demand)
      status <- readTVar miniProtocolStatusVar
      unless (status == StatusIdle) $
        throwSTM (ProtocolAlreadyRunning ptclNum ptclDir' status)
      let !status' = case miniProtocolStartMode miniProtocolInfo of
                       StartOnDemand    -> StatusStartOnDemand
                       StartOnDemandAny -> StatusStartOnDemandAny
                       StartEagerly     -> StatusRunning
      writeTVar miniProtocolStatusVar status'

      -- Tell the mux control to start the thread
      completionVar <- newEmptyTMVar
      writeTQueue muxControlCmdQueue $
        CmdStartProtocolThread
          ptclState
          (MiniProtocolAction protocolAction completionVar)

      return $ completionAction completionVar

    -- It is a programmer error to get the wrong protocol, but this is also
    -- very easy to avoid.
  | otherwise
  = throwSTM (UnknownProtocolInternalError ptclNum ptclDir')
  where
    ptclDir' = protocolDirEnum ptclDir

    -- Wait for the miniprotocol to complete.
    -- If the mux was stopped through a call to 'stop' (Stopped)
    -- or in case of an error (Failed) we return the result of
    -- the miniprotocol, or a `Error` if it was still running.
    completionAction :: StrictTMVar m (Either SomeException b)
                     -> STM m (Either SomeException b)
    completionAction completionVar = do
      st <- readTVar muxStatus
      case st of
           Ready    -> readTMVar completionVar
           Stopping -> readTMVar completionVar
                   <|> return (Left $ toException (Shutdown Nothing st))
           Stopped  -> readTMVar completionVar
                   <|> return (Left $ toException (Shutdown Nothing st))
           Failed e -> readTMVar completionVar
                   <|> return (Left $ toException (Shutdown (Just e) st))


-- | Arrange to run a protocol thread (for a particular 'MiniProtocolNum' and
-- 'MiniProtocolDirection') to interact on this protocol's 'Channel'.
--
-- The protocol thread is started according to the 'miniProtocolStartMode'
-- of the mini-protocol's 'MiniProtocolInfo', either eagerly or on-demand:
--
-- * With 'StartEagerly', the thread is started promptly. This is appropriate
--   for mini-protocols where the opening message may be sent by this thread.
--
-- * With 'StartOnDemand', the thread is not started until the first data is
--   received for this mini-protocol. This is appropriate for mini-protocols
--   where the opening message is sent by the remote peer.
--
-- Data received for a mini-protocol started eagerly while it is not running
-- is a protocol error ('UnexpectedIngress'): the mux terminates.
--
-- The result is a STM action to block and wait on the protocol completion.
-- It is safe to call this completion action multiple times: it will always
-- return the same result once the protocol thread completes.
-- In case the Mux has stopped, either due to an exception or because of a call
-- to muxStop a `Left Error` will be returned from the STM action.
--
-- It is an error to start a new protocol thread while one is still running,
-- for the same 'MiniProtocolNum' and 'MiniProtocolDirection'. This can easily be
-- avoided by using the STM completion action to wait for the previous one to
-- finish.
--
-- It is safe to ask to start a protocol thread before 'run'. In this case
-- the protocol thread will not actually start until 'run' is called,
-- irrespective of the 'StartOnDemandOrEagerly' value.
--
-- If the protocol thread is killed by an asynchronous exception, the mux
-- fails with 'MiniProtocolAsyncException', unless another mini-protocol
-- failed with a synchronous exception by then: the mux fails with that
-- exception instead.  This covers a mini-protocol which kills a sibling while
-- cleaning up after its own failure, e.g. block-fetch kills chain-sync in
-- @bracketFetchClient@.  Such a mini-protocol must kill the sibling and
-- rethrow its exception without blocking interruptibly in between, e.g. under
-- 'uninterruptibleMask', as @bracketFetchClient@ does; otherwise the mux can
-- cancel it before it rethrows, and fail with 'MiniProtocolAsyncException'
-- for the killed sibling.
--
runMiniProtocol
  :: forall mode m a.
     ( Alternative (STM m)
     , MonadSTM   m
     , MonadThrow (STM m)
     )
  => Mux mode m
  -> MiniProtocolNum
  -> MiniProtocolDirection mode
  -> (ByteChannel m -> m (a, Maybe BL.ByteString))
  -> m (STM m (Either SomeException a))
runMiniProtocol mux ptclNum ptclDir protocolAction =
    atomically $ runMiniProtocolSTM mux ptclNum ptclDir protocolAction
