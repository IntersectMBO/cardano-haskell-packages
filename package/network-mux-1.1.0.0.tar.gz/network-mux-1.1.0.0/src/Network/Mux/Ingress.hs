{-# LANGUAGE BangPatterns          #-}
{-# LANGUAGE FlexibleContexts      #-}
{-# LANGUAGE MultiParamTypeClasses #-}
{-# LANGUAGE MultiWayIf            #-}
{-# LANGUAGE NamedFieldPuns        #-}
{-# LANGUAGE RankNTypes            #-}
{-# LANGUAGE ScopedTypeVariables   #-}
{-# LANGUAGE TypeFamilies          #-}

module Network.Mux.Ingress
  ( -- $ingress
    demuxer
  ) where

import Data.Array
import Data.ByteString.Builder.Internal (lazyByteStringInsert,
           lazyByteStringThreshold)
import Data.ByteString.Lazy qualified as BL
import Data.List (nub)

import Control.Concurrent.Class.MonadSTM.Strict
import Control.Monad
import Control.Monad.Class.MonadAsync
import Control.Monad.Class.MonadThrow
import Control.Monad.Class.MonadTimer.SI hiding (timeout)
import Control.Tracer (Tracer)

import Network.Mux.Timeout
import Network.Mux.Trace
import Network.Mux.Types as Mx


flipMiniProtocolDir :: MiniProtocolDir -> MiniProtocolDir
flipMiniProtocolDir InitiatorDir = ResponderDir
flipMiniProtocolDir ResponderDir = InitiatorDir

-- $ingress
-- = Ingress Path
--
-- >                  ●
-- >                  │
-- >                  │ ByteStrings
-- >                  │
-- >         ░░░░░░░░░▼░░░░░░░░░
-- >         ░┌───────────────┐░
-- >         ░│ Bearer.read() │░ Mux Bearer implementation (Socket, Pipes, etc.)
-- >         ░└───────────────┘░
-- >         ░░░░░░░░░│░░░░░░░░░
-- >                 ░│░         SDUs
-- >         ░░░░░░░░░▼░░░░░░░░░
-- >         ░┌───────────────┐░
-- >         ░│     demux     │░ For a given Mux Bearer there is a single demux
-- >         ░└───────┬───────┘░ thread reading from the underlying bearer.
-- >         ░░░░░░░░░│░░░░░░░░░
-- >                 ░│░
-- >        ░░░░░░░░░░▼░░░░░░░░░░
-- >        ░ ╭────┬────┬─────╮ ░ There is a limited queue (in bytes) for each mode
-- >        ░ │    │    │     │ ░ (responder/initiator) per miniprotocol. Overflowing
-- >        ░ ▼    ▼    ▼     ▼ ░ a queue is a protocol violation and a
-- >        ░│  │ │  │ │  │ │  │░ IngressQueueOverRun exception is thrown
-- >        ░│ci│ │  │ │bi│ │br│░ and the bearer torn down.
-- >        ░│ci│ │cr│ │bi│ │br│░
-- >        ░└──┘ └──┘ └──┘ └──┘░ Every ingress queue has a dedicated thread which will
-- >        ░░│░░░░│░░░░│░░░░│░░░ read application encoded data from its queue. Data
-- >          │    │    │    │    for a mini-protocol started eagerly which is not
-- >          │    │    │    │    running is a protocol violation: an UnexpectedIngress
-- >          │    │    │    │    exception is thrown.
-- >          │    │    │    │
-- >           application data
-- >          │    │    │    │
-- >          ▼    │    │    ▼
-- > ┌───────────┐ │    │  ┌───────────┐
-- > │ muxDuplex │ │    │  │ muxDuplex │
-- > │ Initiator │ │    │  │ Responder │
-- > │ ChainSync │ │    │  │ BlockFetch│
-- > └───────────┘ │    │  └───────────┘
-- >               ▼    ▼
-- >    ┌───────────┐  ┌───────────┐
-- >    │ muxDuplex │  │ muxDuplex │
-- >    │ Responder │  │ Initiator │
-- >    │ ChainSync │  │ BlockFetch│
-- >    └───────────┘  └───────────┘

-- | Each peer's multiplexer has some state that provides both
-- de-multiplexing details (for despatch of incoming messages to mini
-- protocols) and for dispatching incoming SDUs.  This is shared
-- between the muxIngress and the bearerIngress processes.
--
data MiniProtocolDispatch m =
     MiniProtocolDispatch
       !(Array MiniProtocolNum (Maybe MiniProtocolIx))
       !(Array (MiniProtocolIx, MiniProtocolDir)
               (MiniProtocolDispatchInfo m))

data MiniProtocolDispatchInfo m =
     MiniProtocolDispatchInfo
       !(IngressQueue m)
       !Int
       !StartOnDemandOrEagerly
       !(StrictTVar m MiniProtocolStatus)
   | MiniProtocolDirUnused


-- | demux runs as a single separate thread and reads complete 'SDU's from
-- the underlying Bearer and forwards it to the matching ingress queue.
demuxer :: (MonadAsync m, MonadFork m, MonadMask m, MonadThrow (STM m),
            MonadTimer m)
      => [MiniProtocolState mode m]
      -> Tracer m BearerTrace
      -> Bearer m
      -> m void
demuxer ptcls tracer bearer =
  let !dispatchTable = setupDispatchTable ptcls in
  -- The loop runs masked, as the muxer's is, so nothing lands between the
  -- read's return and the queueing that counts the SDU. A cancellation
  -- lands in the read, where the bearer's timeout lands too, or in the
  -- bearer's tail once it has the SDU, which leaves that SDU unqueued and
  -- uncounted on a mux that is ending anyway. The read runs unmasked to
  -- work around an io-sim bug: a timeout under a mask leaks its exception
  -- past its frame when the timed call finishes as the timer fires
  -- (IntersectMBO/io-sim#269), which GHC retracts; once that is fixed the
  -- unmask can go, the read blocking interruptibly under the mask. Masked
  -- once, outside the loop, an SDU pays the one unmask application.
  withTimeoutSerial $ \timeout ->
  mask $ \unmask ->
  forever $ do
    (sdu, _) <- unmask (Mx.read bearer tracer timeout)
    case lookupMiniProtocol dispatchTable (msNum sdu)
                            -- Notice the mode reversal, ResponderDir is
                            -- delivered to InitiatorDir and vice versa:
                            (flipMiniProtocolDir $ msDir sdu) of
      Nothing   -> throwIO (UnknownMiniProtocol (msNum sdu))
      Just MiniProtocolDirUnused ->
                   throwIO (InitiatorOnly (msNum sdu))
      Just (MiniProtocolDispatchInfo q qMax startMode statusVar) ->
        atomically $ do
          status <- readTVar statusVar
          -- A mini-protocol started eagerly is only allowed to receive data
          -- while it is running; a killed one is handled below.
          when (startMode == StartEagerly) $
            case status of
              StatusRunning -> pure ()
              StatusKilled  -> pure ()
              _ -> throwSTM $ UnexpectedIngress (msNum sdu)
                                                (flipMiniProtocolDir $ msDir sdu)
          IngressQueueState len buf received <- readTVar q
          let !blobLen   = BL.length (msBlob sdu)
              !len'      = len + blobLen
              -- The bytes read for the mini-protocol, header included and
              -- the blob as delivered, in the write that queues them.
              !received' = received + fromIntegral msHeaderLength + fromIntegral blobLen
          if | StatusKilled <- status
             -- A mini-protocol killed by an asynchronous exception is never
             -- run again on this mux, but the peer does not know it and might
             -- still send a valid reply.  The data is discarded (but counted),
             -- rather than queued or treated as a protocol violation.
             -> writeTVar q $ IngressQueueState len buf received'
             | len' <= fromIntegral qMax
             -> do
                let !buf' = if len == 0
                               then -- Don't copy the payload if the queue was empty
                                 lazyByteStringInsert $ msBlob sdu
                               else -- Copy payloads smaller than 128 bytes
                                 buf <> lazyByteStringThreshold 128 (msBlob sdu)
                writeTVar q $ IngressQueueState len' buf' received'
             | otherwise
             -> throwSTM $ IngressQueueOverRun (msNum sdu) (msDir sdu)

lookupMiniProtocol :: MiniProtocolDispatch m
                   -> MiniProtocolNum
                   -> MiniProtocolDir
                   -> Maybe (MiniProtocolDispatchInfo m)
lookupMiniProtocol (MiniProtocolDispatch pnumArray ptclArray) pnum pdir
  | inRange (bounds pnumArray) pnum
  , Just mpid <- pnumArray ! pnum = Just (ptclArray ! (mpid, pdir))
  | otherwise                   = Nothing

-- | Construct the table that maps 'MiniProtocolNum' and 'MiniProtocolDir' to
-- 'MiniProtocolDispatchInfo'. Use 'lookupMiniProtocol' to index it.
--
setupDispatchTable :: forall mode m.
                      [MiniProtocolState mode m] -> MiniProtocolDispatch m
setupDispatchTable ptcls =
    MiniProtocolDispatch pnumArray ptclArray
  where
    -- The 'MiniProtocolNum' space is sparse but we don't want a huge single
    -- table if we use large protocol numbers. So we use a two level mapping.
    --
    -- The first array maps 'MiniProtocolNum' to a dense space of intermediate
    -- integer indexes. These indexes are meaningless outside of the context of
    -- this table. Then we use the index and the 'MiniProtocolDir' for the
    -- second table.
    --
    pnumArray :: Array MiniProtocolNum (Maybe MiniProtocolIx)
    pnumArray =
      array (minpnum, maxpnum) $
            -- Fill in Nothing first to cover any unused ones.
            [ (pnum, Nothing)    | pnum <- [minpnum..maxpnum] ]

            -- And override with the ones actually used.
         ++ [ (pnum, Just pix)   | (pnum, pix) <- zip pnums [0..] ]

    ptclArray :: Array (MiniProtocolIx, MiniProtocolDir)
                       (MiniProtocolDispatchInfo m)
    ptclArray =
      array ((minpix, InitiatorDir), (maxpix, ResponderDir)) $
            -- Fill in MiniProtocolDirUnused first to cover any unused ones.
            [ ((pix, dir), MiniProtocolDirUnused)
            | (pix, dir) <- range ((minpix, InitiatorDir),
                                   (maxpix, ResponderDir)) ]

             -- And override with the ones actually used.
         ++ [ ((pix, dir), MiniProtocolDispatchInfo q qMax miniProtocolStartMode
                                                    miniProtocolStatusVar)
            | MiniProtocolState {
                miniProtocolInfo =
                  MiniProtocolInfo {
                    miniProtocolNum,
                    miniProtocolDir,
                    miniProtocolLimits,
                    miniProtocolStartMode
                  },
                miniProtocolIngressQueue = q,
                miniProtocolStatusVar
              } <- ptcls
            , let pix  =
                   case pnumArray ! miniProtocolNum of
                     Just a  -> a
                     -- This error is impossible to trigger - note that
                     -- `pnumArray` is constructed to ensure that every
                     -- `miniProtocolNum` in `ptcls` indexes to a `Just` value.
                     Nothing -> error ("setupDispatchTable: impossible: missing " ++ show miniProtocolNum)
                  dir      = protocolDirEnum miniProtocolDir
                  qMax     = maximumIngressQueue miniProtocolLimits
            ]

    -- The protocol numbers actually used, in the order of the first use within
    -- the 'ptcls' list. The order does not matter provided we do it
    -- consistently between the two arrays.
    pnums   = nub $ map (miniProtocolNum . miniProtocolInfo) ptcls

    -- The dense range of indexes of used protocol numbers.
    minpix, maxpix :: MiniProtocolIx
    minpix  = 0
    maxpix  = fromIntegral (length pnums - 1)

    -- The sparse range of protocol numbers
    minpnum, maxpnum :: MiniProtocolNum
    minpnum = minimum pnums
    maxpnum = maximum pnums
