module Test.Gen.Cardano.Api.Empty where

import Test.Gen.Cardano.Api ()

-- | This module is empty, but it is needed to prevent unused-packages warning
