# servant-server

![servant](https://raw.githubusercontent.com/haskell-servant/servant/master/servant.png)

This library lets you *implement* an HTTP server with handlers for each endpoint of a servant API, handling most of the boilerplate for you.

## Getting started

We've written a [tutorial](http://docs.servant.dev/en/stable/tutorial/index.html) guide that introduces the core types and features of servant. After this article, you should be able to write your first servant webservices, learning the rest from the haddocks' examples.
