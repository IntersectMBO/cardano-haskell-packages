module Servant.Utils.StaticFiles
    {-# DEPRECATED "Use Servant.Server.StaticFiles." #-}
    ( module Servant.Server.StaticFiles )
  where

import           Servant.Server.StaticFiles
