# Version history for `cardano-ledger-shelley-test`

## 1.2.0.5

*

## 1.2.0.4

*

## 1.2.0.3

*

## 1.2.0.2

* GHC-9.6 compatibility

## 1.2.0.1

* Changed bounds on cardano-ledger-shelley-test
