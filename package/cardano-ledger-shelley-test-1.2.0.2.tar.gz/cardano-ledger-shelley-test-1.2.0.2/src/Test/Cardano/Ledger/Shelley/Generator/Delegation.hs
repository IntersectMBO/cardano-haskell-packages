module Test.Cardano.Ledger.Shelley.Generator.Delegation
  {-# DEPRECATED "Use `Test.Cardano.Ledger.Shelley.Generator.TxCert` instead" #-} (
  module Test.Cardano.Ledger.Shelley.Generator.TxCert,
) where

import Test.Cardano.Ledger.Shelley.Generator.TxCert
