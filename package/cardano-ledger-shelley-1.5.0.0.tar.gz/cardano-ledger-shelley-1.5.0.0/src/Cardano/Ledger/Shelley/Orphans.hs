module Cardano.Ledger.Shelley.Orphans
  {-# DEPRECATED "Use 'import Cardano.Ledger.Orphans' instead" #-}
  ()
where

import Cardano.Ledger.Orphans ()
