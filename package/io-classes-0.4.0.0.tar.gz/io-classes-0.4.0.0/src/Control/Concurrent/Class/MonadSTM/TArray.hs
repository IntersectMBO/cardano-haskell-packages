{-# LANGUAGE ExplicitNamespaces #-}

-- | This module corresponds to `Control.Concurrent.STM.TArray` in "stm" package
--
module Control.Concurrent.Class.MonadSTM.TArray (type TArray) where

import           Control.Monad.Class.MonadSTM.Internal
