# Revision history for ouroboros-network

## 0.3.0.1

* Fixed a bug in peer state actions monitoring loop (PR #4357)

## 0.1.0.0 -- 2018-09-20

* Initial experiments and prototyping
