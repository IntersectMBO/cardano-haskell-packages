# Version history for `cardano-ledger-mary`

## 1.0.0.0

* First properly versioned release.
