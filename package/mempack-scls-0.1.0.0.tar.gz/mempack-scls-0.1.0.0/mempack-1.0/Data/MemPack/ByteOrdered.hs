-- | Helpers for dealing with endianness in binary formats.
module Data.MemPack.ByteOrdered (
  BigEndian (..),
  Storable (..),
  packWord16beM,
  packWord32beM,
  packWord64beM,
  unpackBigEndianM,
) where

import Data.MemPack
import Data.MemPack.Buffer (Buffer)
import Data.Word
import Foreign.Ptr (Ptr, castPtr)
import Foreign.Storable (Storable (..))
import System.ByteOrder (Bytes (..), fromBigEndian, toBigEndian)

{- | A wrapper type to indicate that a value is stored in big-endian format.

Intended to be used with 'DerivingVia' to derive instances.

Example:
@
newtype SlotNo = SlotNo { unSlotNo :: Word64 }
  deriving (Eq, Ord, Show, Read)
  deriving (Storable) via (BigEndian Word64)
@
-}
newtype BigEndian a = BigEndian {unBigEndian :: a}
  deriving (Eq, Ord, Show, Read)

instance (Bytes a, Storable a) => Storable (BigEndian a) where
  sizeOf _ = sizeOf (undefined :: a)
  alignment _ = alignment (undefined :: a)
  peek ptr = do
    w <- peek (castPtr ptr :: Ptr a)
    return (BigEndian (fromBigEndian w))
  poke ptr (BigEndian w) = poke (castPtr ptr :: Ptr a) (toBigEndian w)

instance (Bytes a, MemPack a) => MemPack (BigEndian a) where
  typeName = "BigEndian " ++ typeName @a
  packedByteCount (BigEndian a) = packedByteCount a
  packM (BigEndian a) = packM (toBigEndian a)
  unpackM = BigEndian . fromBigEndian <$> unpackM

packBigEndianM :: (Bytes a, MemPack a) => a -> Pack s ()
packBigEndianM = packM . BigEndian

packWord16beM :: Word16 -> Pack s ()
packWord16beM = packBigEndianM

packWord32beM :: Word32 -> Pack s ()
packWord32beM = packBigEndianM

packWord64beM :: Word64 -> Pack s ()
packWord64beM = packBigEndianM

unpackBigEndianM :: (Bytes a, MemPack a, Buffer b) => Unpack b a
unpackBigEndianM =
  unBigEndian <$> unpackM
