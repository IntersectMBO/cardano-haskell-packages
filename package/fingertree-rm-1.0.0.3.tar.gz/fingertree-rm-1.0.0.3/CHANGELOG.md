## 1.0.0.3 — 2024-10-03

### Patch

* Make it build with `ghc-9.10`.

## 1.0.0.2 — 2024-03-22

### Patch

* Make it build with `ghc-9.8`.

## 1.0.0.1 — 2023-07-14

### Patch

* Make buildable with `ghc-9.4` and `ghc-9.6`.

## 1.0.0.0 — 2023-05-09

### Breaking changes

* Require a root measure to be a cancellative monoid instead of a group.

## 0.1.0.0 — 2023-02-16

First release
