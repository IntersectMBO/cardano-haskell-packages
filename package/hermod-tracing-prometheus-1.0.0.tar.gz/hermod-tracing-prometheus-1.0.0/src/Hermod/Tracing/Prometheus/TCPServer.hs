{-# LANGUAGE RecordWildCards #-}

{-# OPTIONS_GHC -Wno-partial-fields #-}

-- | Run a simple Prometheus TCP server, responding *only* to the '/metrics' URL with current Node metrics
module Hermod.Tracing.Prometheus.TCPServer
       ( runPrometheusSimple
       , runPrometheusSimpleSilent
       , runPrometheusSimpleWith
       , TracePrometheusSimple (..)
       ) where

import           Hermod.Tracing.Prometheus.Exposition (renderExpositionFromSample)
import           Hermod.Tracing.Prometheus.NetworkRun
import           Hermod.Tracing.Types
import           Hermod.Tracing.Utils (runInLoop, showT)

import           Control.Concurrent.Async (Async, async)
import qualified Control.Exception as E
import           Control.Monad (join, when)
import           Control.Tracer
import           Data.Aeson.Types as AE (Value (String), (.=))
import           Data.ByteString (ByteString)
import           Data.ByteString.Builder
import qualified Data.ByteString.Char8 as BC
import qualified Data.ByteString.Lazy.Char8 as BCL (length)
import           Data.Int (Int64)
import           Data.List (find, intersperse)
import           Data.Maybe (fromMaybe)
import           Data.Text as TS (pack)
import           Data.Text.Lazy (Text)
import qualified Data.Text.Lazy as TL (length)
import qualified Data.Text.Lazy.Encoding as T (encodeUtf8)
import           Data.Word (Word16)
import           Network.HTTP.Date (epochTimeToHTTPDate, formatHTTPDate)
import           Network.Socket (HostName, PortNumber)
import qualified Network.Socket.ByteString as Strict (recv)
import qualified Network.Socket.ByteString.Lazy as Lazy (sendAll)
import           System.Metrics as EKG (Store, sampleAll)
import           System.Posix.Types (EpochTime)
import           System.PosixCompat.Time (epochTime)


data TracePrometheusSimple =
    TracePrometheusSimpleStart { port :: Word16 }
  | TracePrometheusSimpleStop  { message :: String }
  deriving Show

instance LogFormatting TracePrometheusSimple where
  forMachine _ = \case
    TracePrometheusSimpleStart portNo -> mconcat
      [ "kind"        .= AE.String "PrometheusSimpleStart"
      , "port"        .= portNo
      ]
    TracePrometheusSimpleStop message -> mconcat
      [ "kind"        .= AE.String "TracePrometheusSimpleStop"
      , "message"     .= message
      ]

  forHuman = \case
    TracePrometheusSimpleStart portNo -> "PrometheusSimple backend starting on port " <> showT portNo
    TracePrometheusSimpleStop message -> "PrometheusSimple backend stop: " <> TS.pack message


-- | Run a PrometheusSimple server with default DoS protection, and don't emit any traces.
--   Will retry / restart Prometheus server when an exception occurs, in increasing intervals.
runPrometheusSimpleSilent :: EKG.Store -> (Bool, Maybe HostName, PortNumber) -> IO (Async ())
runPrometheusSimpleSilent = runPrometheusSimple nullTracer

-- | Run a PrometheusSimple server with default DoS protection.
--   Will retry / restart Prometheus server when an exception occurs, in increasing intervals.
runPrometheusSimple :: Tracer IO TracePrometheusSimple -> EKG.Store -> (Bool, Maybe HostName, PortNumber) -> IO (Async ())
runPrometheusSimple = runPrometheusSimpleWith prometheusSimpleNoOverrides

-- | Run a PrometheusSimple server with custom DoS protection parameter overrides.
--   Will retry / restart Prometheus server when an exception occurs, in increasing intervals.
runPrometheusSimpleWith :: PrometheusSimpleRun -> Tracer IO TracePrometheusSimple -> EKG.Store -> (Bool, Maybe HostName, PortNumber) -> IO (Async ())
runPrometheusSimpleWith PrometheusSimpleRun{..} tr ekgStore (noSuffixes, mHost, portNo) =
    async $ runInLoop fromScratchThrowing traceInterruption 1 60
  where
    traceInterruption (E.SomeException e) =
      traceWith tr $ TracePrometheusSimpleStop (E.displayException e)

    fromScratchThrowing  = traceWith tr (TracePrometheusSimpleStart $ fromIntegral portNo) >> join createRunner

    getCurrentExposition = renderExpositionFromSample noSuffixes <$> sampleAll ekgStore
    createRunner         = mkTCPServerRunner dosOverrides mHost portNo (serveAccepted getCurrentExposition)

    dosDefault@NetworkRunParams{..} = defaultRunParams "PrometheusSimple"
    dosOverrides = dosDefault
      { runSocketTimeout    = maybe runSocketTimeout fromIntegral connTimeout
      , runConnLimitGlobal  = maybe runConnLimitGlobal fromIntegral connCountGlobal
      , runConnLimitPerHost = maybe runConnLimitPerHost fromIntegral connCountPerHost
      , runRateLimit        = fromMaybe runRateLimit connPerSecond
      }

-- serves an incoming connection; will release socket upon remote close, inactivity timeout or runRecvMaxSize bytes received
serveAccepted :: IO Text -> TimeoutServer ()
serveAccepted getCurrentExposition NetworkRunParams{runRecvMaxSize} resetTimeout sock = go
  where
    go = do
      msg <- Strict.recv sock runRecvMaxSize
      let len = BC.length msg
      when (0 < len && len < runRecvMaxSize) $ do
        response <- buildResponse getCurrentExposition $ pseudoParse msg
        Lazy.sendAll sock $ toLazyByteString response
        resetTimeout
        go


data Method = GET | HEAD | UNSUPPORTED deriving Eq

data Accept = TextLike | OpenMetrics | All | Unsupported deriving Eq

-- "parses" a buffer read via TCP into a minimal viable HTTP request (TM): route, HTTP verb, Accept: header
pseudoParse :: ByteString -> Maybe (ByteString, Method, Accept)
pseudoParse request =
  case BC.lines request of
    requestLine : headers
      | method : route : _ <- BC.words requestLine
        -> Just (route, readMethod method, readAccept headers)
    _ -> Nothing
  where
    readMethod :: ByteString -> Method
    readMethod "GET"  = GET
    readMethod "HEAD" = HEAD
    readMethod _      = UNSUPPORTED

    readAccept :: [ByteString] -> Accept
    readAccept headers =
      case find (\h -> any (`BC.isPrefixOf` h) caseInsensitive) headers of
        Nothing -> All
        Just accept
          | "application/openmetrics-text" `BC.isInfixOf` accept  -> OpenMetrics
          | "text/" `BC.isInfixOf`                        accept  -> TextLike
          | "*/*" `BC.isInfixOf`                          accept  -> All
          | otherwise                                             -> Unsupported
      where
        caseInsensitive = ["Accept:", "accept:", "ACCEPT:"]

-- builds a minimal complete HTTP response based on route, HTTP verb and requested content type
buildResponse :: IO Text -> Maybe (ByteString, Method, Accept) -> IO Builder
buildResponse getCurrentExposition = \case
  Nothing -> pure $ responseError False errorBadRequest
  Just (route, method, accept)
    | route /= "/metrics"   -> pure $ responseError withBody errorNotFound
    | method == UNSUPPORTED -> pure $ responseError withBody errorBadMethod
    | accept == Unsupported -> pure $ responseError withBody errorBadContent
    | otherwise ->
        let content = if accept == OpenMetrics then hdrContentTypeOpenMetrics else hdrContentTypePrometheus
        in responseMessage withBody content <$> getCurrentExposition <*> epochTime
    where withBody = method == GET

hdrContentTypeText, hdrContentTypePrometheus, hdrContentTypeOpenMetrics :: Builder
hdrContentTypeText        = "Content-Type: text/plain;charset=utf-8"
hdrContentTypePrometheus  = "Content-Type: text/plain;version=0.0.4;charset=utf-8"
hdrContentTypeOpenMetrics = "Content-Type: application/openmetrics-text;version=1.0.0;charset=utf-8"

hdrContentLength :: Int64 -> Builder
hdrContentLength len = "Content-Length: " <> int64Dec len

errorBadRequest, errorNotFound, errorBadMethod, errorBadContent, errorPayloadTooLarge :: (ByteString, ByteString)
errorBadRequest    = ("400", "Bad Request")
errorNotFound      = ("404", "Not Found")
errorBadMethod     = ("405", "Method Not Allowed")
errorBadContent    = ("415", "Unsupported Media Type")
errorPayloadTooLarge = ("503", "Service Unavailable")

-- 8 MB ceiling as a safeguard for response size - this should never fire.
-- Corresponds to roughly 56.000 distinct application metrics: a legitimate exposition should be well under this!
maxResponseChars :: Int64
maxResponseChars = 8 * 1024 * 1024

-- HTTP header line break
nl :: Builder
nl = char8 '\r' <> char8 '\n'

responseError :: Bool -> (ByteString, ByteString) -> Builder
responseError withBody (errCode, errMsg) =
  mconcat $ intersperse nl $
    "HTTP/1.1 " <> byteString errCode :
    if withBody
      then  [ hdrContentLength (fromIntegral $ BC.length msg)
            , hdrContentTypeText
            , ""
            , byteString msg
            ]
      else  [ hdrContentLength 0
            , nl
            ]
  where
    msg = errCode <> " " <> errMsg

responseMessage :: Bool -> Builder -> Text -> EpochTime -> Builder
responseMessage withBody contentType msg now
  | withBody && TL.length msg > maxResponseChars =
      responseError True errorPayloadTooLarge
  | otherwise =
      mconcat $ intersperse nl
        [ "HTTP/1.1 200 OK"
        , hdrContentLength contentLength
        , contentType
        , "Date: " <> byteString httpDate
        , ""
        , if withBody then lazyByteString contentLBS else ""
        ]
  where
    contentLBS    = T.encodeUtf8 msg
    contentLength = if withBody then BCL.length contentLBS else 0
    httpDate      = formatHTTPDate $ epochTimeToHTTPDate now
