# Revision history for quickcheck-monoids

## 0.1.0.2 -- 2025-06-28

* Package is deprecated, use `QuickCheck >= 2.16` which provides `Every` and
  `Some` monoids.

## 0.1.0.1 -- 2024-08-07

* Make it build with ghc-9.10
  * fix base upper bound

## 0.1.0.0 -- 2024-06-07

* First version. Released on an unsuspecting world.
