# quickcheck-monoids

This package provides two monoids `All` and `Any`, similar to the ones
available in the `base` package, but tailred for `QuickCheck`.
