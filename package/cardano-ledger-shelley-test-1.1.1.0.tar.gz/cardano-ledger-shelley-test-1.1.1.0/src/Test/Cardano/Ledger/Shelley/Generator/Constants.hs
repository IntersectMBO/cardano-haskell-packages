module Test.Cardano.Ledger.Shelley.Generator.Constants (
  Constants (..),
  defaultConstants,
) where

import Test.Cardano.Ledger.Shelley.Constants (Constants (..), defaultConstants)
