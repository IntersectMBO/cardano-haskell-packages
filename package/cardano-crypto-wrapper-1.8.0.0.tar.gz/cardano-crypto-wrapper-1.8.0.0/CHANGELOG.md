# Revision history for `cardano-crypto-wrapper`

## 1.8.0.0

* Depend on `crypton ^>=1.1` and use the `ram` package instead of `memory`

## 1.7.0.0

* Remove deprecated function `hash`

## 1.6.1.0

### `testlib`

* Added `testlib` sublibrary as replacement of `cardano-crypto-test` package

## 1.6.0.0

* Switch from cryptonite library (deprecated) to crypton (a drop in replacement)

## 1.5.1.4

*

## 1.5.1.3

*

## 1.5.1.2

*

## 1.5.1.1

*

## 1.5.1.0

* Bring back `toCBORXPrv` and `fromCBORXPrv`

## 1.5.0.0

* First official release.
