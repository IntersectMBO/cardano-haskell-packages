# Revision history for ntp-client

## 0.0.1.1 -- 2023-04-28

### Non-breaking changes

* `ghc-9.4` and `ghc-9.6` compatiblity.

## 0.0.1.0 -- 2022-12-13

* Initial release
