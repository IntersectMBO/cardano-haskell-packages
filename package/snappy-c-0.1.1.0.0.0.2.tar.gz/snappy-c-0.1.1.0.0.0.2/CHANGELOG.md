# Revision history for snappy-c

## 0.1.0 -- 2024-02-09

* First version. Released on an unsuspecting world.
