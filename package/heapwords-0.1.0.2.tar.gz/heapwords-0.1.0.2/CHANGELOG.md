## 0.1.0.2

* Remove `development` flag: #372

## 0.1.0.1

* Initial release

