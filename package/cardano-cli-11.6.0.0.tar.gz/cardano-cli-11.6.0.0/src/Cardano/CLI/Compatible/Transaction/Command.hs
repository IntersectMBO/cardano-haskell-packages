{-# LANGUAGE DataKinds #-}
{-# LANGUAGE ExistentialQuantification #-}
{-# LANGUAGE GADTs #-}
{-# LANGUAGE LambdaCase #-}
{-# LANGUAGE RankNTypes #-}
{-# LANGUAGE ScopedTypeVariables #-}

module Cardano.CLI.Compatible.Transaction.Command
  ( CompatibleTransactionCmds (..)
  , renderCompatibleTransactionCmd
  )
where

import Cardano.Api

import Cardano.CLI.EraBased.Script.Type
import Cardano.CLI.Type.Common
import Cardano.CLI.Type.Governance

-- TODO: After QA confirmms that the new compatibility commands meet their needs
-- we can remove all remaining legacy commands. We can also remove/move the exising
-- byron era commands under the new compatiblilty commands.
data CompatibleTransactionCmds era
  = CreateCompatibleSignedTransaction
      (ShelleyBasedEra era)
      [TxIn]
      [TxIn]
      -- ^ Collateral inputs
      [TxOutAnyEra]
      !(Maybe UpdateProposalFile)
      ![(ProposalFile In, Maybe AnyNonAssetScript)]
      ![(VoteFile In, Maybe AnyNonAssetScript)]
      [WitnessSigningData]
      -- ^ Signing keys
      (Maybe NetworkId)
      !Coin
      -- ^ Tx fee
      ![(CertificateFile, Maybe AnyNonAssetScript)]
      -- ^ stake registering certs
      !(Maybe ProtocolParamsFile)
      !(File () Out)

renderCompatibleTransactionCmd :: CompatibleTransactionCmds era -> Text
renderCompatibleTransactionCmd = \case
  CreateCompatibleSignedTransaction{} -> "compatible transaction signed-transaction"
