{-# LANGUAGE DataKinds #-}
{-# LANGUAGE FlexibleContexts #-}
{-# LANGUAGE GADTs #-}
{-# LANGUAGE LambdaCase #-}
{-# LANGUAGE OverloadedStrings #-}
{-# LANGUAGE RankNTypes #-}
{-# LANGUAGE ScopedTypeVariables #-}
{-# LANGUAGE TypeApplications #-}
{-# LANGUAGE TypeFamilies #-}

module Cardano.CLI.Read
  ( -- * Metadata
    readFileTxMetadata
  , readTxMetadata

    -- * Script
  , ScriptDecodeError (..)
  , readAnyScript
  , readAnyScriptHash
  , deserialiseScriptInAnyLang
  , readFileScriptInAnyLang
  , PlutusScriptDecodeError (..)

    -- * Script data (datums and redeemers)
  , ScriptDataError (..)
  , renderScriptDataError

    -- * Tx
  , IncompleteTxBody (..)
  , readFileTx
  , readFileTxBody
  , readTx -- For testing purposes

    -- * Sub-transactions
  , readFileUnsignedSubTx
  , readFileSignedSubTx

    -- * Tx witnesses
  , ReadWitnessSigningDataError (..)
  , renderReadWitnessSigningDataError
  , SomeSigningWitness (..)
  , ByronOrShelleyWitness (..)
  , mkShelleyBootstrapWitness
  , ShelleyBootstrapWitnessSigningKeyData (..)
  , readFileTxKeyWitness
  , readWitnessSigningData
  , txWitnessTextEnvelopeTypes -- For testing purposes

    -- * Required signer
  , RequiredSignerError (..)
  , categoriseSomeSigningWitness
  , readRequiredSigner

    -- * Governance related
  , ConstitutionError (..)
  , VoteError (..)
  , CostModelsError (..)
  , readCostModels

    -- * FileOrPipe
  , FileOrPipe
  , fileOrPipe
  , fileOrPipePath
  , fileOrPipeCache
  , readFileOrPipe
  , readFileOrPipeTextEnvelopeAnyOf

    -- * Stake credentials
  , getStakeCredentialFromVerifier
  , getStakeCredentialFromIdentifier
  , getStakeAddressFromVerifier

    -- * Stake pool credentials
  , getHashFromStakePoolKeyHashSource
  , getVerificationKeyFromStakePoolVerificationKeySource

    -- * DRep credentials
  , ReadSafeHashError (..)
  , readHexAsSafeHash
  , readSafeHash
  , scriptHashReader

    -- * Vote related
  , readVoteDelegationTarget
  , readVerificationKeySource

    -- * Genesis hashes
  , readShelleyOnwardsGenesisAndHash
  , readFileCli

    -- * Plutus
  , readFilePlutusScript

    -- * utilities
  , readerFromParsecParser
  , liftError
  , toEither
  )
where

import Cardano.Api as Api
import Cardano.Api.Byron (ByronKey)
import Cardano.Api.Byron qualified as Byron
import Cardano.Api.Experimental (obtainCommonConstraints)
import Cardano.Api.Experimental qualified as Exp
import Cardano.Api.Experimental.Plutus qualified as Exp.Plutus
import Cardano.Api.Ledger qualified as L
import Cardano.Api.Parser.Text qualified as P

import Cardano.Binary qualified as CBOR
import Cardano.CLI.Compatible.Exception
import Cardano.CLI.EraBased.Script.Type
import Cardano.CLI.Type.Common
import Cardano.CLI.Type.Error.BootstrapWitnessError
import Cardano.CLI.Type.Error.PlutusScriptDecodeError
import Cardano.CLI.Type.Error.ScriptDataError
import Cardano.CLI.Type.Error.ScriptDecodeError
import Cardano.CLI.Type.Governance
import Cardano.CLI.Type.Key
import Cardano.Crypto.Hash qualified as Crypto
import Cardano.Ledger.Api qualified as L

import RIO (readFileBinary)
import Prelude

import Control.Exception (bracket)
import Control.Monad (unless, when)
import Data.Aeson qualified as Aeson
import Data.Bifunctor
import Data.ByteString (ByteString)
import Data.ByteString qualified as BS
import Data.ByteString.Base16 qualified as Base16
import Data.ByteString.Builder qualified as Builder
import Data.ByteString.Lazy.Char8 qualified as LBS
import Data.Function ((&))
import Data.IORef (IORef, newIORef, readIORef, writeIORef)
import Data.Text qualified as T
import Data.Text qualified as Text
import Data.Text.Encoding qualified as Text
import Data.Text.Encoding.Error qualified as Text
import Data.Validation (Validation (Failure, Success))
import GHC.IO.Handle (hClose, hIsSeekable)
import GHC.IO.Handle.FD (openFileBlocking)
import GHC.Stack
import Options.Applicative qualified as Opt
import System.IO (IOMode (ReadMode))

-- Metadata

readTxMetadata
  :: Exp.Era era
  -> TxMetadataJsonSchema
  -> [MetadataFile]
  -> CIO e (TxMetadataInEra era)
readTxMetadata _ _ [] = return TxMetadataNone
readTxMetadata era schema files = do
  metadata <- mapM (readFileTxMetadata schema) files
  pure $ TxMetadataInEra (convert era) $ mconcat metadata

readFileTxMetadata
  :: TxMetadataJsonSchema
  -> MetadataFile
  -> CIO e TxMetadata
readFileTxMetadata mapping (MetadataFileJSON fp) = do
  bs <- readFileCli (unFile fp)
  v <-
    fromEitherCli $
      Aeson.eitherDecode' $
        LBS.fromStrict bs
  txMetadata' <-
    fromEitherCli $
      metadataFromJson mapping v

  fromEitherCli $ validateTxMetadata txMetadata'

  return txMetadata'
readFileTxMetadata _ (MetadataFileCBOR fp) = do
  bs <- readFileCli (unFile fp)
  txMetadata' <-
    fromEitherCli $
      deserialiseFromCBOR AsTxMetadata bs
  fromEitherCli $
    do
      validateTxMetadata txMetadata'
      return txMetadata'

-- Script witnesses/ Scripts

readVerificationKeySource
  :: Key keyrole
  => (Hash keyrole -> L.KeyHash kr)
  -> VerificationKeySource keyrole
  -> CIO e (L.Credential kr)
readVerificationKeySource extractHash = \case
  VksScriptHash (ScriptHash scriptHash) ->
    pure $ L.ScriptHashObj scriptHash
  VksScript (File fp) -> do
    ScriptInAnyLang _lang script <-
      readFileScriptInAnyLang fp
    pure . L.ScriptHashObj . toShelleyScriptHash $ hashScript script
  VksKeyHashFile vKeyOrHashOrFile ->
    L.KeyHashObj . extractHash <$> readVerificationKeyOrHashOrTextEnvFile vKeyOrHashOrFile

-- | Reads the script in cardano-api's newest era, so every script language decodes.
-- Returns only the era-independent script hash.
readAnyScriptHash :: MonadIO m => ScriptFile -> m ScriptHash
readAnyScriptHash scriptFile =
  case maxBound of
    Exp.Some (era :: Exp.Era era) ->
      Exp.obtainCommonConstraints era $
        fromShelleyScriptHash . Exp.hashAnyScript <$> readAnyScript @_ @era (unFile scriptFile)

readAnyScript
  :: forall m era
   . (MonadIO m, Exp.IsEra era)
  => FilePath -> m (Exp.AnyScript (Exp.LedgerEra era))
readAnyScript anyScriptFp = do
  bs <-
    readFileCli anyScriptFp

  case deserialiseFromJSON bs of
    Left _ -> do
      -- In addition to the TextEnvelope format, we also try to
      -- deserialize the JSON representation of SimpleScripts..
      case Aeson.eitherDecodeStrict' bs :: Either String SimpleScript of
        Left err -> throwCliError err
        Right script ->
          case Exp.useEra @era of
            Exp.DijkstraEra ->
              pure . Exp.AnySimpleScript . Exp.SimpleScript $ toDijkstraNativeScript script
            era@Exp.ConwayEra -> Exp.obtainConwayConstraints era $ do
              let s :: L.NativeScript (Exp.LedgerEra era) = toAllegraTimelock script
              return . Exp.AnySimpleScript $ Exp.SimpleScript s
    Right te -> do
      let scriptBs = teRawCBOR te
          TextEnvelopeType anyScriptType = teType te
      case Exp.Plutus.textToPlutusLanguage $ Text.pack anyScriptType of
        Just anyPlutusScriptLang -> do
          case Exp.obtainCommonConstraints (Exp.useEra @era) $
                 Exp.Plutus.decodeAnyPlutusScript @(Exp.LedgerEra era) scriptBs anyPlutusScriptLang
                 :: Either CBOR.DecoderError (Exp.Plutus.AnyPlutusScript (Exp.LedgerEra era)) of
            Right (Exp.Plutus.AnyPlutusScript plutusScript) -> return $ Exp.AnyPlutusScript plutusScript
            Left e ->
              throwCliError $ "Failed to decode Plutus script: " <> show e
        -- Simple script text envelope format
        Nothing ->
          case Exp.obtainCommonConstraints (Exp.useEra @era) (Exp.deserialiseSimpleScript scriptBs) of
            Right ss -> return $ Exp.AnySimpleScript ss
            Left e ->
              throwCliError $ "Failed to decode Simple script: " <> show (e :: CBOR.DecoderError)

-- | Read a script file. The file can either be in the text envelope format
-- wrapping the binary representation of any of the supported script languages,
-- or alternatively it can be a JSON format file for one of the simple script
-- language versions.
readFileScriptInAnyLang
  :: MonadIO m
  => FilePath
  -> m ScriptInAnyLang
readFileScriptInAnyLang file = do
  scriptBytes <-
    readFileCli
      file
  fromEitherCli $ deserialiseScriptInAnyLang scriptBytes

deserialiseScriptInAnyLang
  :: BS.ByteString
  -> Either ScriptDecodeError ScriptInAnyLang
deserialiseScriptInAnyLang bs =
  -- Accept either the text envelope format wrapping the binary serialisation,
  -- or accept the simple script language in its JSON format.
  --
  case deserialiseFromJSON bs of
    Left _ ->
      -- In addition to the TextEnvelope format, we also try to
      -- deserialize the JSON representation of SimpleScripts.
      case Aeson.eitherDecodeStrict' bs of
        Left err -> Left (ScriptDecodeSimpleScriptError $ JsonDecodeError err)
        Right script -> Right $ ScriptInAnyLang SimpleScriptLanguage $ SimpleScript script
    Right te ->
      case deserialiseFromTextEnvelopeAnyOf textEnvTypes te of
        Left err -> Left (ScriptDecodeTextEnvelopeError err)
        Right script -> Right script
 where
  -- TODO: Think of a way to get type checker to warn when there is a missing
  -- script version.
  textEnvTypes :: [FromSomeType HasTextEnvelope ScriptInAnyLang]
  textEnvTypes = fromSomeTypeSimpleScript : fromSomeTypePlutusScripts

fromSomeTypeSimpleScript :: FromSomeType HasTextEnvelope ScriptInAnyLang
fromSomeTypeSimpleScript =
  FromSomeType
    (AsScript AsSimpleScript)
    (ScriptInAnyLang SimpleScriptLanguage)

fromSomeTypePlutusScripts :: [FromSomeType HasTextEnvelope ScriptInAnyLang]
fromSomeTypePlutusScripts =
  let allPlutusVersions :: [AnyPlutusScriptVersion] = [minBound .. maxBound]
   in [plutusScriptVersionFromSomeType v | AnyPlutusScriptVersion v <- allPlutusVersions]
 where
  plutusScriptVersionFromSomeType
    :: IsPlutusScriptLanguage lang
    => PlutusScriptVersion lang -> FromSomeType HasTextEnvelope ScriptInAnyLang
  plutusScriptVersionFromSomeType v =
    FromSomeType
      (AsScript $ proxyToAsType (Proxy :: Proxy lang))
      (ScriptInAnyLang $ PlutusScriptLanguage v)

-- Tx & TxBody

readFileTx :: FileOrPipe -> IO (Either (FileError TextEnvelopeError) (InAnyShelleyBasedEra Tx))
readFileTx file = do
  cddlTxOrErr <- readTx file
  case cddlTxOrErr of
    Left e -> return $ Left e
    Right cddlTx -> do
      InAnyShelleyBasedEra sbe tx <- pure cddlTx
      return $ Right $ inAnyShelleyBasedEra sbe tx

data IncompleteTxBody where
  IncompleteTxBody
    :: IsShelleyBasedEra era
    => ShelleyBasedEra era
    -> Exp.UnsignedTx (ShelleyLedgerEra era)
    -> IncompleteTxBody

readFileTxBody :: FileOrPipe -> IO (Either (FileError TextEnvelopeError) IncompleteTxBody)
readFileTxBody file = do
  cddlTxOrErr <- readTx file
  case cddlTxOrErr of
    Left e -> return $ Left e
    Right cddlTx -> do
      InAnyShelleyBasedEra sbe (ShelleyTx _ ledgerTx) <- pure cddlTx
      return $ Right $ shelleyBasedEraConstraints sbe $ IncompleteTxBody sbe (Exp.UnsignedTx ledgerTx)

readTx :: FileOrPipe -> IO (Either (FileError TextEnvelopeError) (InAnyShelleyBasedEra Tx))
readTx =
  readFileOrPipeTextEnvelopeAnyOf fromSomeShelleyTx

fromSomeShelleyTx :: [FromSomeType HasTextEnvelope (InAnyShelleyBasedEra Tx)]
fromSomeShelleyTx =
  [ shelleyBasedEraConstraints sbe $ FromSomeType (makeTxProxy sbe) (InAnyShelleyBasedEra sbe)
  | AnyShelleyBasedEra sbe <- [minBound .. maxBound]
  ]
 where
  makeTxProxy :: HasTypeProxy era => ShelleyBasedEra era -> AsType (Tx era)
  makeTxProxy _ = AsTx (proxyToAsType (Proxy :: Proxy era))

-- Sub-transactions

-- Sub-transactions only exist in Dijkstra, so the envelope type fixes the era.

readFileUnsignedSubTx :: FileOrPipe -> IO (Either (FileError TextEnvelopeError) Exp.UnsignedSubTx)
readFileUnsignedSubTx =
  readFileOrPipeTextEnvelopeAnyOf [FromSomeType Exp.AsUnsignedSubTx id]

readFileSignedSubTx :: FileOrPipe -> IO (Either (FileError TextEnvelopeError) Exp.SignedSubTx)
readFileSignedSubTx =
  readFileOrPipeTextEnvelopeAnyOf [FromSomeType Exp.AsSignedSubTx id]

-- Tx witnesses

readFileTxKeyWitness
  :: FilePath
  -> IO (Either (FileError TextEnvelopeError) (InAnyShelleyBasedEra KeyWitness))
readFileTxKeyWitness fp = do
  file <- fileOrPipe fp
  readFileOrPipeTextEnvelopeAnyOf fromSomeShelleyTxWitness file

fromSomeShelleyTxWitness :: [FromSomeType HasTextEnvelope (InAnyShelleyBasedEra KeyWitness)]
fromSomeShelleyTxWitness =
  [ shelleyBasedEraConstraints sbe $ FromSomeType (makeWitnessProxy sbe) (InAnyShelleyBasedEra sbe)
  | AnyShelleyBasedEra sbe <- [minBound .. maxBound]
  ]
 where
  makeWitnessProxy :: HasTypeProxy era => ShelleyBasedEra era -> AsType (KeyWitness era)
  makeWitnessProxy _ = AsKeyWitness (proxyToAsType (Proxy :: Proxy era))

txWitnessTextEnvelopeTypes :: [Text]
txWitnessTextEnvelopeTypes =
  [ let TextEnvelopeType d = shelleyBasedEraConstraints sbe $ textEnvelopeType (proxyToAsType (makeWitnessProxy sbe))
     in T.pack d
  | AnyShelleyBasedEra sbe <- [minBound .. maxBound]
  ]
 where
  makeWitnessProxy :: ShelleyBasedEra era -> Proxy (KeyWitness era)
  makeWitnessProxy _ = Proxy

-- Witness handling

data SomeSigningWitness
  = AByronSigningWitness (SigningKey ByronKey) (Maybe (Address ByronAddr))
  | APaymentSigningWitness (SigningKey PaymentKey)
  | APaymentExtendedSigningWitness (SigningKey PaymentExtendedKey)
  | AStakeSigningWitness (SigningKey StakeKey)
  | AStakeExtendedSigningWitness (SigningKey StakeExtendedKey)
  | AStakePoolSigningWitness (SigningKey StakePoolKey)
  | AStakePoolExtendedSigningWitness (SigningKey StakePoolExtendedKey)
  | AGenesisSigningWitness (SigningKey GenesisKey)
  | AGenesisExtendedSigningWitness (SigningKey GenesisExtendedKey)
  | AGenesisDelegateSigningWitness (SigningKey GenesisDelegateKey)
  | AGenesisDelegateExtendedSigningWitness (SigningKey GenesisDelegateExtendedKey)
  | AGenesisUTxOSigningWitness (SigningKey GenesisUTxOKey)
  | ADRepSigningWitness (SigningKey DRepKey)
  | ADRepExtendedSigningWitness (SigningKey DRepExtendedKey)
  | ACommitteeColdSigningWitness (SigningKey CommitteeColdKey)
  | ACommitteeColdExtendedSigningWitness (SigningKey CommitteeColdExtendedKey)
  | ACommitteeHotSigningWitness (SigningKey CommitteeHotKey)
  | ACommitteeHotExtendedSigningWitness (SigningKey CommitteeHotExtendedKey)
  deriving Show

-- | Data required for constructing a Shelley bootstrap witness.
data ShelleyBootstrapWitnessSigningKeyData
  = ShelleyBootstrapWitnessSigningKeyData
      !(SigningKey ByronKey)
      -- ^ Byron signing key.
      !(Maybe (Address ByronAddr))
      -- ^ An optionally specified Byron address.
      --
      -- If specified, both the network ID and derivation path are extracted
      -- from the address and used in the construction of the Byron witness.

-- | Construct a Shelley bootstrap witness (i.e. a Byron key witness in the
-- Shelley era).
mkShelleyBootstrapWitness
  :: ()
  => ShelleyBasedEra era
  -> Maybe NetworkId
  -> L.TxBody L.TopTx (ShelleyLedgerEra era)
  -> ShelleyBootstrapWitnessSigningKeyData
  -> Either BootstrapWitnessError (KeyWitness era)
mkShelleyBootstrapWitness _ Nothing _ (ShelleyBootstrapWitnessSigningKeyData _ Nothing) =
  Left MissingNetworkIdOrByronAddressError
mkShelleyBootstrapWitness sbe (Just nw) txBody (ShelleyBootstrapWitnessSigningKeyData skey Nothing) =
  Right $ makeShelleyBasedBootstrapWitness sbe (Byron.WitnessNetworkId nw) txBody skey
mkShelleyBootstrapWitness sbe _ txBody (ShelleyBootstrapWitnessSigningKeyData skey (Just addr)) =
  Right $ makeShelleyBasedBootstrapWitness sbe (Byron.WitnessByronAddress addr) txBody skey

-- | Some kind of Byron or Shelley witness.
data ByronOrShelleyWitness
  = AByronWitness !ShelleyBootstrapWitnessSigningKeyData
  | AShelleyKeyWitness !ShelleyWitnessSigningKey

categoriseSomeSigningWitness :: SomeSigningWitness -> ByronOrShelleyWitness
categoriseSomeSigningWitness swsk =
  case swsk of
    AByronSigningWitness sk addr -> AByronWitness (ShelleyBootstrapWitnessSigningKeyData sk addr)
    APaymentSigningWitness sk -> AShelleyKeyWitness (WitnessPaymentKey sk)
    APaymentExtendedSigningWitness sk -> AShelleyKeyWitness (WitnessPaymentExtendedKey sk)
    AStakeSigningWitness sk -> AShelleyKeyWitness (WitnessStakeKey sk)
    AStakeExtendedSigningWitness sk -> AShelleyKeyWitness (WitnessStakeExtendedKey sk)
    AStakePoolSigningWitness sk -> AShelleyKeyWitness (WitnessStakePoolKey sk)
    AStakePoolExtendedSigningWitness sk -> AShelleyKeyWitness (WitnessStakePoolExtendedKey sk)
    AGenesisSigningWitness sk -> AShelleyKeyWitness (WitnessGenesisKey sk)
    AGenesisExtendedSigningWitness sk -> AShelleyKeyWitness (WitnessGenesisExtendedKey sk)
    AGenesisDelegateSigningWitness sk -> AShelleyKeyWitness (WitnessGenesisDelegateKey sk)
    AGenesisDelegateExtendedSigningWitness sk -> AShelleyKeyWitness (WitnessGenesisDelegateExtendedKey sk)
    AGenesisUTxOSigningWitness sk -> AShelleyKeyWitness (WitnessGenesisUTxOKey sk)
    ADRepSigningWitness sk -> AShelleyKeyWitness (WitnessDRepKey sk)
    ADRepExtendedSigningWitness sk -> AShelleyKeyWitness (WitnessDRepExtendedKey sk)
    ACommitteeColdSigningWitness sk -> AShelleyKeyWitness (WitnessCommitteeColdKey sk)
    ACommitteeColdExtendedSigningWitness sk -> AShelleyKeyWitness (WitnessCommitteeColdExtendedKey sk)
    ACommitteeHotSigningWitness sk -> AShelleyKeyWitness (WitnessCommitteeHotKey sk)
    ACommitteeHotExtendedSigningWitness sk -> AShelleyKeyWitness (WitnessCommitteeHotExtendedKey sk)

data ReadWitnessSigningDataError
  = ReadWitnessSigningDataSigningKeyDecodeError !(FileError InputDecodeError)
  | ReadWitnessSigningDataScriptError !(FileError JsonDecodeError)
  | -- | A Byron address was specified alongside a non-Byron signing key.
    ReadWitnessSigningDataSigningKeyAndAddressMismatch
  deriving Show

instance Error ReadWitnessSigningDataError where
  prettyError = \case
    ReadWitnessSigningDataSigningKeyDecodeError fileErr ->
      prettyError fileErr
    ReadWitnessSigningDataScriptError fileErr ->
      prettyError fileErr
    ReadWitnessSigningDataSigningKeyAndAddressMismatch ->
      "Only a Byron signing key may be accompanied by a Byron address."

-- | Render an error message for a 'ReadWitnessSigningDataError'.
renderReadWitnessSigningDataError :: ReadWitnessSigningDataError -> Doc ann
renderReadWitnessSigningDataError = \case
  ReadWitnessSigningDataSigningKeyDecodeError fileErr ->
    "Error reading signing key: " <> prettyError fileErr
  ReadWitnessSigningDataScriptError fileErr ->
    "Error reading script: " <> prettyError fileErr
  ReadWitnessSigningDataSigningKeyAndAddressMismatch ->
    "Only a Byron signing key may be accompanied by a Byron address."

readWitnessSigningData
  :: WitnessSigningData
  -> IO (Either ReadWitnessSigningDataError SomeSigningWitness)
readWitnessSigningData (KeyWitnessSigningData skFile mbByronAddr) = do
  eRes <-
    first ReadWitnessSigningDataSigningKeyDecodeError
      <$> readFormattedFileAnyOf bech32FileTypes textEnvFileTypes skFile
  return $ do
    res <- eRes
    case (res, mbByronAddr) of
      (AByronSigningWitness _ _, Just _) -> pure res
      (AByronSigningWitness _ _, Nothing) -> pure res
      (_, Nothing) -> pure res
      (_, Just _) ->
        -- A Byron address should only be specified along with a Byron signing key.
        Left ReadWitnessSigningDataSigningKeyAndAddressMismatch
 where
  -- If you update these variables, consider updating the ones with the same
  -- names in Cardano.CLI.Type.Key
  textEnvFileTypes =
    [ FromSomeType (AsSigningKey AsByronKey) (`AByronSigningWitness` mbByronAddr)
    , FromSomeType (AsSigningKey AsPaymentKey) APaymentSigningWitness
    , FromSomeType (AsSigningKey AsPaymentExtendedKey) APaymentExtendedSigningWitness
    , FromSomeType (AsSigningKey AsStakeKey) AStakeSigningWitness
    , FromSomeType (AsSigningKey AsStakeExtendedKey) AStakeExtendedSigningWitness
    , FromSomeType (AsSigningKey AsStakePoolKey) AStakePoolSigningWitness
    , FromSomeType (AsSigningKey AsStakePoolExtendedKey) AStakePoolExtendedSigningWitness
    , FromSomeType (AsSigningKey AsGenesisKey) AGenesisSigningWitness
    , FromSomeType (AsSigningKey AsGenesisExtendedKey) AGenesisExtendedSigningWitness
    , FromSomeType (AsSigningKey AsGenesisDelegateKey) AGenesisDelegateSigningWitness
    , FromSomeType (AsSigningKey AsGenesisDelegateExtendedKey) AGenesisDelegateExtendedSigningWitness
    , FromSomeType (AsSigningKey AsGenesisUTxOKey) AGenesisUTxOSigningWitness
    , FromSomeType (AsSigningKey AsDRepKey) ADRepSigningWitness
    , FromSomeType (AsSigningKey AsDRepExtendedKey) ADRepExtendedSigningWitness
    , FromSomeType (AsSigningKey AsCommitteeColdKey) ACommitteeColdSigningWitness
    , FromSomeType (AsSigningKey AsCommitteeColdExtendedKey) ACommitteeColdExtendedSigningWitness
    , FromSomeType (AsSigningKey AsCommitteeHotKey) ACommitteeHotSigningWitness
    , FromSomeType (AsSigningKey AsCommitteeHotExtendedKey) ACommitteeHotExtendedSigningWitness
    ]

  bech32FileTypes =
    [ FromSomeType (AsSigningKey AsPaymentKey) APaymentSigningWitness
    , FromSomeType (AsSigningKey AsPaymentExtendedKey) APaymentExtendedSigningWitness
    , FromSomeType (AsSigningKey AsStakeKey) AStakeSigningWitness
    , FromSomeType (AsSigningKey AsStakeExtendedKey) AStakeExtendedSigningWitness
    , FromSomeType (AsSigningKey AsStakePoolKey) AStakePoolSigningWitness
    , FromSomeType (AsSigningKey AsStakePoolExtendedKey) AStakePoolExtendedSigningWitness
    ]

-- Required signers

data RequiredSignerError
  = RequiredSignerErrorFile (FileError InputDecodeError)
  | RequiredSignerErrorByronKey (SigningKeyFile In)
  deriving Show

instance Error RequiredSignerError where
  prettyError = \case
    RequiredSignerErrorFile e ->
      prettyError e
    RequiredSignerErrorByronKey (File byronSkeyfile) ->
      "Byron witnesses cannot be used for required signers: " <> pretty byronSkeyfile

readRequiredSigner :: RequiredSigner -> IO (Either RequiredSignerError (Hash PaymentKey))
readRequiredSigner (RequiredSignerHash h) = return $ Right h
readRequiredSigner (RequiredSignerSkeyFile skFile) = do
  eKeyWit <-
    first RequiredSignerErrorFile <$> readFormattedFileAnyOf bech32FileTypes textEnvFileTypes skFile
  return $ do
    keyWit <- eKeyWit
    case categoriseSomeSigningWitness keyWit of
      AByronWitness _ ->
        Left $ RequiredSignerErrorByronKey skFile
      AShelleyKeyWitness skey ->
        return . getHash $ toShelleySigningKey skey
 where
  textEnvFileTypes =
    [ FromSomeType (AsSigningKey AsPaymentKey) APaymentSigningWitness
    , FromSomeType (AsSigningKey AsPaymentExtendedKey) APaymentExtendedSigningWitness
    , FromSomeType (AsSigningKey AsStakePoolKey) AStakePoolSigningWitness
    , FromSomeType (AsSigningKey AsStakePoolExtendedKey) AStakePoolExtendedSigningWitness
    , FromSomeType (AsSigningKey AsGenesisDelegateKey) AGenesisDelegateSigningWitness
    ]
  bech32FileTypes = []

  getHash :: ShelleySigningKey -> Hash PaymentKey
  getHash (ShelleyExtendedSigningKey sk) =
    let extSKey = PaymentExtendedSigningKey sk
        payVKey = castVerificationKey $ getVerificationKey extSKey
     in verificationKeyHash payVKey
  getHash (ShelleyNormalSigningKey sk) =
    verificationKeyHash . getVerificationKey $ PaymentSigningKey sk

newtype VoteError
  = VoteErrorFile (FileError CliScriptWitnessError)

instance Show VoteError where
  show = show . prettyError

instance Error VoteError where
  prettyError = \case
    VoteErrorFile e ->
      prettyError e

newtype ConstitutionError
  = ConstitutionNotUnicodeError Text.UnicodeException
  deriving Show

data CostModelsError
  = CostModelsErrorReadFile (FileError ())
  | CostModelsErrorJSONDecode FilePath String
  | CostModelsErrorEmpty FilePath
  deriving Show

instance Error CostModelsError where
  prettyError = \case
    CostModelsErrorReadFile e ->
      "Cannot read cost model: " <> prettyError e
    CostModelsErrorJSONDecode fp err ->
      "Error decoding JSON cost model at " <> pshow fp <> ": " <> pretty err <> formatExplanation
    CostModelsErrorEmpty fp ->
      "The decoded cost model was empty at: " <> pshow fp <> formatExplanation
   where
    formatExplanation =
      vsep
        [ ""
        , "The expected format of the cost models file is "
        , "{"
        , "  \"PlutusV1\" : <costModel>,"
        , "  \"PlutusV2\" : <costModel>,"
        , "  \"PlutusV3\" : <costModel>,"
        , "}"
        , "where each of the three entries may be ommited, and a <cost model> is either an ordered list of parameter values like"
        , "[205665, 812, 1, ...]"
        , "or a map like"
        , "{ \"addInteger-cpu-arguments-intercept\": 205665, \"addInteger-cpu-arguments-slope\": 812, \"addInteger-memory-arguments-intercept\": 1, ... }"
        , "In both cases, the cost model must be complete, i.e. it must specify all parameters that are needed for the specific Plutus version."
        , "It's not specified what will happen if you provide more parameters than necessary."
        ]

readCostModels
  :: File L.CostModels In
  -> ExceptT CostModelsError IO L.CostModels
readCostModels (File fp) = do
  bytes <- handleIOExceptT (CostModelsErrorReadFile . FileIOError fp) $ LBS.readFile fp
  costModels <- firstExceptT (CostModelsErrorJSONDecode fp) . except $ Aeson.eitherDecode bytes
  when (null $ fromAlonzoCostModels costModels) $ throwE $ CostModelsErrorEmpty fp
  return costModels

-- | We need a type for handling files that may be actually be things like
-- pipes. Currently the CLI makes no guarantee that a "file" will only
-- be read once. This is a problem for a user who who expects to be able to pass
-- a pipe. To handle this, we have a type for representing either files or pipes
-- where the contents will be saved in memory if what we're reading is a pipe (so
-- it can be re-read later). Unfortunately this means we can't easily stream data
-- from pipes, but at present that's not an issue.
data FileOrPipe = FileOrPipe FilePath (IORef (Maybe LBS.ByteString))

instance Show FileOrPipe where
  show (FileOrPipe fp _) = show fp

fileOrPipe :: FilePath -> IO FileOrPipe
fileOrPipe fp = FileOrPipe fp <$> newIORef Nothing

-- | Get the path backing a FileOrPipe. This should primarily be used when
-- generating error messages for a user. A user should not call directly
-- call a function like readFile on the result of this function
fileOrPipePath :: FileOrPipe -> FilePath
fileOrPipePath (FileOrPipe fp _) = fp

fileOrPipeCache :: FileOrPipe -> IO (Maybe LBS.ByteString)
fileOrPipeCache (FileOrPipe _ c) = readIORef c

-- | Get the contents of a file or pipe. This function reads the entire
-- contents of the file or pipe, and is blocking.
readFileOrPipe :: FileOrPipe -> IO LBS.ByteString
readFileOrPipe (FileOrPipe fp cacheRef) = do
  cached <- readIORef cacheRef
  case cached of
    Just dat -> pure dat
    Nothing ->
      bracket
        (openFileBlocking fp ReadMode)
        hClose
        ( \handle -> do
            -- An arbitrary block size.
            let blockSize = 4096
            let go acc = do
                  next <- BS.hGet handle blockSize
                  if BS.null next
                    then pure acc
                    else go (acc <> Builder.byteString next)
            contents <- go mempty
            let dat = Builder.toLazyByteString contents
            -- If our file is not seekable, it's likely a pipe, so we need to
            -- save the result for subsequent calls
            seekable <- hIsSeekable handle
            unless seekable (writeIORef cacheRef (Just dat))
            pure dat
        )

readFileOrPipeTextEnvelopeAnyOf
  :: [FromSomeType HasTextEnvelope b]
  -> FileOrPipe
  -> IO (Either (FileError TextEnvelopeError) b)
readFileOrPipeTextEnvelopeAnyOf types file = do
  let path = fileOrPipePath file
  runExceptT $ do
    content <- handleIOExceptT (FileIOError path) $ readFileOrPipe file
    firstExceptT (FileError path) $ hoistEither $ do
      te <- first TextEnvelopeAesonDecodeError $ Aeson.eitherDecode' content
      deserialiseFromTextEnvelopeAnyOf types te

----------------------------------------------------------------------------------------------------

getStakeCredentialFromVerifier
  :: ()
  => StakeVerifier
  -> CIO e StakeCredential
getStakeCredentialFromVerifier = \case
  StakeVerifierScriptFile (File sFile) -> do
    ScriptInAnyLang _ script <-
      readFileScriptInAnyLang sFile
    pure $ StakeCredentialByScript $ hashScript script
  StakeVerifierKey stakeVerKeyOrFile -> do
    stakeVerKeyHash <-
      readVerificationKeyOrHashOrFile stakeVerKeyOrFile
    pure $ StakeCredentialByKey stakeVerKeyHash

getStakeCredentialFromIdentifier
  :: ()
  => StakeIdentifier
  -> CIO e StakeCredential
getStakeCredentialFromIdentifier = \case
  StakeIdentifierAddress stakeAddr -> pure $ stakeAddressCredential stakeAddr
  StakeIdentifierVerifier stakeVerifier -> getStakeCredentialFromVerifier stakeVerifier

getStakeAddressFromVerifier
  :: ()
  => NetworkId
  -> StakeVerifier
  -> CIO e StakeAddress
getStakeAddressFromVerifier networkId stakeVerifier =
  makeStakeAddress networkId <$> getStakeCredentialFromVerifier stakeVerifier

data ReadSafeHashError
  = ReadSafeHashErrorNotHex ByteString String
  | ReadSafeHashErrorInvalidHash Text

renderReadSafeHashError :: ReadSafeHashError -> Text
renderReadSafeHashError = \case
  ReadSafeHashErrorNotHex bs err ->
    "Error reading anchor data hash: Invalid hex: " <> Text.decodeUtf8 bs <> "\n" <> Text.pack err
  ReadSafeHashErrorInvalidHash err ->
    "Error reading anchor data hash: " <> err

readHexAsSafeHash
  :: ()
  => Text
  -> Either ReadSafeHashError (L.SafeHash L.AnchorData)
readHexAsSafeHash hex = do
  let bs = Text.encodeUtf8 hex

  raw <- Base16.decode bs & first (ReadSafeHashErrorNotHex bs)

  case Crypto.hashFromBytes raw of
    Just a -> Right (L.unsafeMakeSafeHash a)
    Nothing -> Left $ ReadSafeHashErrorInvalidHash "Unable to read hash"

readSafeHash :: Opt.ReadM (L.SafeHash L.AnchorData)
readSafeHash =
  Opt.eitherReader $ \s ->
    readHexAsSafeHash (Text.pack s)
      & first (Text.unpack . renderReadSafeHashError)

scriptHashReader :: Opt.ReadM ScriptHash
scriptHashReader = readerFromParsecParser parseScriptHash

readVoteDelegationTarget
  :: ()
  => VoteDelegationTarget
  -> CIO e L.DRep
readVoteDelegationTarget voteDelegationTarget =
  case voteDelegationTarget of
    VoteDelegationTargetOfDRep drepHashSource ->
      L.DRepCredential <$> readDRepCredential drepHashSource
    VoteDelegationTargetOfAbstain ->
      pure L.DRepAlwaysAbstain
    VoteDelegationTargetOfNoConfidence ->
      pure L.DRepAlwaysNoConfidence

--- | Read the given file and hashes its content using 'Blake2b_256'
readShelleyOnwardsGenesisAndHash
  :: MonadIO m
  => FilePath
  -- ^ The file to read
  -> m (Crypto.Hash Crypto.Blake2b_256 BS.ByteString)
readShelleyOnwardsGenesisAndHash path = do
  content <- liftIO $ BS.readFile path
  return $ Crypto.hashWith id content

-- | Get the hash from a stake pool key hash source
getHashFromStakePoolKeyHashSource
  :: MonadIO m => StakePoolKeyHashSource -> m (Hash StakePoolKey)
getHashFromStakePoolKeyHashSource hashSource =
  case hashSource of
    StakePoolKeyHashSource vkeySource ->
      anyStakePoolVerificationKeyHash <$> getVerificationKeyFromStakePoolVerificationKeySource vkeySource
    StakePoolKeyHashLiteral hash -> pure hash

-- | Get the verification key from a stake pool verification key source
getVerificationKeyFromStakePoolVerificationKeySource
  :: MonadIO m => StakePoolVerificationKeySource -> m AnyStakePoolVerificationKey
getVerificationKeyFromStakePoolVerificationKeySource = \case
  StakePoolVerificationKeyFromFile (File file) -> do
    f <- liftIO $ fileOrPipe file
    fromEitherIOCli $ readStakePoolVerificationKeyFile f
  StakePoolVerificationKeyFromLiteral keyLiteral -> pure keyLiteral
 where
  readStakePoolVerificationKeyFile
    :: FileOrPipe -> IO (Either (FileError TextEnvelopeError) AnyStakePoolVerificationKey)
  readStakePoolVerificationKeyFile = readFileOrPipeTextEnvelopeAnyOf types
   where
    types =
      [ FromSomeType (AsVerificationKey AsStakePoolKey) AnyStakePoolNormalVerificationKey
      , FromSomeType (AsVerificationKey AsStakePoolExtendedKey) AnyStakePoolExtendedVerificationKey
      ]

readFileCli :: (HasCallStack, MonadIO m) => FilePath -> m ByteString
readFileCli = withFrozenCallStack . readFileBinary

readerFromParsecParser :: P.Parser a -> Opt.ReadM a
readerFromParsecParser p = Opt.eitherReader (P.runParser p . T.pack)

liftError :: (e -> e') -> Either e a -> Validation e' a
liftError f = \case
  Left e -> Failure (f e)
  Right a -> Success a

toEither :: Validation e a -> Either e a
toEither = \case
  Failure e -> Left e
  Success a -> Right a

-- TODO: Update to handle hex script bytes directly as well!
readFilePlutusScript
  :: forall e era
   . Exp.IsEra era
  => FilePath
  -> CIO e (Exp.Plutus.AnyPlutusScript (Exp.LedgerEra era))
readFilePlutusScript plutusScriptFp = do
  bs <-
    readFileCli plutusScriptFp
  te <- fromEitherCli $ deserialiseFromJSON bs
  let scriptBs = teRawCBOR te
      TextEnvelopeType anyScriptType = teType te
  case Exp.Plutus.textToPlutusLanguage (Text.pack anyScriptType) of
    Just lang -> do
      let s :: Either CBOR.DecoderError (Exp.Plutus.AnyPlutusScript (Exp.LedgerEra era)) = obtainCommonConstraints (Exp.useEra @era) $ Exp.Plutus.decodeAnyPlutusScript scriptBs lang
      fromEitherCli s
    Nothing ->
      throwCliError $ "Unsupported script language: " <> anyScriptType
