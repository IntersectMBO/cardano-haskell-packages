# Revision history for cardano-ping

## 0.2.0.0 -- 2023-05-08

* Support for `NodeToNodeV_12` and `NodeToClientV_16`, e.g. support for
  querying `NodeToNodeVersionData` / `NodeToClientVersionData`.
* Support `NodeToNodeV_11` and `NodeToClientV_15` (peer sharing).

## 0.1.0.0 -- 2022-12-14

* This code was originally from the cardano-ping executable component of the `network-mux` package.
