# 0.1.1.0

* Added instances of `Monoid` and `Semigroup` for `StrictMaybe`: [#314](https://github.com/input-output-hk/cardano-base/pull/314)

# 0.1.0.1

* Intiial release
