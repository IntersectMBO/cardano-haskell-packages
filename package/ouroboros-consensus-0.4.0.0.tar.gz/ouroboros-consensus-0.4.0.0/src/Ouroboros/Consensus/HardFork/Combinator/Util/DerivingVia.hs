module Ouroboros.Consensus.HardFork.Combinator.Util.DerivingVia {-# DEPRECATED "Use Ouroboros.Consensus.HardFork.Combinator.Lifting" #-} (module Ouroboros.Consensus.HardFork.Combinator.Lifting) where

import Ouroboros.Consensus.HardFork.Combinator.Lifting
