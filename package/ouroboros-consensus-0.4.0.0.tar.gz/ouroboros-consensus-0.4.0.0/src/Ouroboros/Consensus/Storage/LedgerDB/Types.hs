module Ouroboros.Consensus.Storage.LedgerDB.Types {-# DEPRECATED "Use Ouroboros.Consensus.Storage.LedgerDB instead" #-} (
    LDB.PushGoal (..)
  , LDB.PushStart (..)
  , LDB.Pushing (..)
  , LDB.UpdateLedgerDbTraceEvent (..)
  ) where

import qualified Ouroboros.Consensus.Storage.LedgerDB as LDB
