module Ouroboros.Consensus.Storage.FS.IO {-# DEPRECATED "Use System.FS.IO from fs-api" #-} (
    -- * IO implementation & monad
    HandleIO
  , ioHasFS
  ) where

import           System.FS.IO
