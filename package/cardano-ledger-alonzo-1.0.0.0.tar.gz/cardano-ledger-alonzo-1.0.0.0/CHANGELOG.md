# Version history for `cardano-ledger-alonzo`

## 1.0.0.0

* First properly versioned release.
