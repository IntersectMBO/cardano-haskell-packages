module Ouroboros.Consensus.HardFork.Combinator.Util.Telescope {-# DEPRECATED "Use Data.SOP.Telescope" #-} (module Data.SOP.Telescope) where

import Data.SOP.Telescope
