module Ouroboros.Consensus.HardFork.Combinator.Util.Tails {-# DEPRECATED "Use Data.SOP.Tails" #-} (module Data.SOP.Tails) where

import Data.SOP.Tails
