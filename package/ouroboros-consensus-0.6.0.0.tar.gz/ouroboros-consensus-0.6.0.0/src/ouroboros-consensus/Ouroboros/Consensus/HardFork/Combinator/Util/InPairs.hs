module Ouroboros.Consensus.HardFork.Combinator.Util.InPairs {-# DEPRECATED "Use Data.SOP.InPairs" #-} (module Data.SOP.InPairs) where

import Data.SOP.InPairs
