module Ouroboros.Consensus.Util.Counting {-# DEPRECATED "Use Data.SOP.Counting "#-} (module Data.SOP.Counting) where

import Data.SOP.Counting
