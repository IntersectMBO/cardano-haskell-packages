module Test.Util.FS.Sim.STM {-# DEPRECATED "Use System.FS.Sim.STM from fs-sim" #-} (
    runSimFS
  , simHasFS
  ) where

import           System.FS.Sim.STM
