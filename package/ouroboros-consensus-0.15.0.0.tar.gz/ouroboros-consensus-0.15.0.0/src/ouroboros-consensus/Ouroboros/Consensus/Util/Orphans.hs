{-# LANGUAGE DataKinds                  #-}
{-# LANGUAGE DerivingVia                #-}
{-# LANGUAGE FlexibleContexts           #-}
{-# LANGUAGE FlexibleInstances          #-}
{-# LANGUAGE GeneralizedNewtypeDeriving #-}
{-# LANGUAGE ScopedTypeVariables        #-}
{-# LANGUAGE StandaloneDeriving         #-}
{-# LANGUAGE TypeApplications           #-}
{-# LANGUAGE UndecidableInstances       #-}

{-# OPTIONS_GHC -Wno-orphans #-}

module Ouroboros.Consensus.Util.Orphans () where

import           Cardano.Crypto.DSIGN.Class
import           Cardano.Crypto.DSIGN.Mock (MockDSIGN)
import           Cardano.Crypto.Hash (Hash)
import           Codec.CBOR.Decoding (Decoder)
import           Codec.Serialise (Serialise (..))
import           Control.Tracer (Tracer)
import           Data.Bimap (Bimap)
import qualified Data.Bimap as Bimap
import           Data.IntPSQ (IntPSQ)
import qualified Data.IntPSQ as PSQ
import           Data.SOP.BasicFunctors
import           NoThunks.Class (InspectHeap (..), InspectHeapNamed (..),
                     NoThunks (..), OnlyCheckWhnfNamed (..), allNoThunks,
                     noThunksInKeysAndValues)
import           Ouroboros.Consensus.Block.Abstract
import           Ouroboros.Consensus.Util.Condense
import           Ouroboros.Network.AnchoredFragment (AnchoredFragment)
import qualified Ouroboros.Network.AnchoredFragment as AF
import           Ouroboros.Network.Mock.Chain (Chain (..))
import           Ouroboros.Network.Util.ShowProxy
import           System.FS.API (SomeHasFS)
import           System.FS.API.Types (FsPath, Handle)
import           System.FS.CRC (CRC (CRC))

{-------------------------------------------------------------------------------
  Condense
-------------------------------------------------------------------------------}

instance Condense (HeaderHash block) => Condense (Point block) where
    condense GenesisPoint     = "Origin"
    condense (BlockPoint s h) = "(Point " <> condense s <> ", " <> condense h <> ")"

instance Condense block => Condense (Chain block) where
    condense Genesis   = "Genesis"
    condense (cs :> b) = condense cs <> " :> " <> condense b

instance (Condense block, HasHeader block, Condense (HeaderHash block))
    => Condense (AnchoredFragment block) where
    condense (AF.Empty pt) = "EmptyAnchor " <> condense (AF.anchorToPoint pt)
    condense (cs AF.:> b)  = condense cs <> " :> " <> condense b

{-------------------------------------------------------------------------------
  Serialise
-------------------------------------------------------------------------------}

instance Serialise (Hash h a) where

instance Serialise (VerKeyDSIGN MockDSIGN) where
  encode = encodeVerKeyDSIGN
  decode = decodeVerKeyDSIGN

{-------------------------------------------------------------------------------
  ShowProxy
-------------------------------------------------------------------------------}

instance ShowProxy SlotNo where

{-------------------------------------------------------------------------------
  NoThunks
-------------------------------------------------------------------------------}

instance (NoThunks k, NoThunks v)
      => NoThunks (Bimap k v) where
  wNoThunks ctxt = noThunksInKeysAndValues ctxt . Bimap.toList

instance ( NoThunks p
         , NoThunks v
         , Ord p
         ) => NoThunks (IntPSQ p v) where
  showTypeOf _ = "IntPSQ"
  wNoThunks ctxt =
        allNoThunks
      . concatMap (\(k, p, v) ->
        [ noThunks ctxt k
        , noThunks ctxt p
        , noThunks ctxt v])
      . PSQ.toList

deriving via OnlyCheckWhnfNamed "Decoder" (Decoder s a) instance NoThunks (Decoder s a)

deriving via OnlyCheckWhnfNamed "Tracer" (Tracer m ev) instance NoThunks (Tracer m ev)

instance NoThunks a => NoThunks (K a b) where
  showTypeOf _ = showTypeOf (Proxy @a)
  wNoThunks ctxt (K a) = wNoThunks ("K":ctxt) a

{-------------------------------------------------------------------------------
  fs-api
-------------------------------------------------------------------------------}

deriving via InspectHeapNamed "Handle" (Handle h)
    instance NoThunks (Handle h)
deriving via InspectHeap FsPath instance NoThunks FsPath
deriving via OnlyCheckWhnfNamed "SomeHasFS" (SomeHasFS m)
    instance NoThunks (SomeHasFS m)
deriving newtype instance NoThunks CRC
