module Test.Cardano.Ledger.Shelley.Generator.Constants
  {-# DEPRECATED "Use `Test.Cardano.Ledger.Shelley.Constants` instead" #-} (
  Constants (..),
  defaultConstants,
) where

import Test.Cardano.Ledger.Shelley.Constants (Constants (..), defaultConstants)
