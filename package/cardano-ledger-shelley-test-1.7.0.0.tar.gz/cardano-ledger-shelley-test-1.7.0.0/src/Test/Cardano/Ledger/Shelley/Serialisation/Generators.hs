module Test.Cardano.Ledger.Shelley.Serialisation.Generators () where

import Test.Cardano.Ledger.Shelley.Arbitrary ()
