{-# LANGUAGE BlockArguments      #-}
{-# LANGUAGE CPP                 #-}
{-# LANGUAGE FlexibleContexts    #-}
{-# LANGUAGE LambdaCase          #-}
{-# LANGUAGE NamedFieldPuns      #-}
{-# LANGUAGE NumericUnderscores  #-}
{-# LANGUAGE OverloadedStrings   #-}
{-# LANGUAGE RankNTypes          #-}
{-# LANGUAGE ScopedTypeVariables #-}
{-# LANGUAGE TupleSections       #-}
{-# LANGUAGE TypeApplications    #-}

{-# OPTIONS_GHC -Wno-unused-top-binds #-}
#if __GLASGOW_HASKELL__ >= 908
{-# OPTIONS_GHC -Wno-x-partial #-}
#endif

module Test.Ouroboros.Network.PeerSelection.RootPeersDNS
  ( tests
  , mockDNSActions
  , genGroupSrvs
  , genDomainName
  , DomainAccessPoint (..)
  , MockRoots (..)
  , MockDNSMap
  , MockDNSLookupResult
  , DNSTimeout (..)
  , DNSLookupDelay (..)
  , DelayAndTimeoutScripts (..)
  ) where

import Control.Applicative (Alternative)
import Control.Monad (foldM, forever, replicateM_, when)
import Data.Bifunctor (bimap)
import Data.ByteString.Char8 (pack)
import Data.ByteString.Char8 qualified as BSC
import Data.Dynamic (Typeable, fromDynamic)
import Data.Either (fromLeft, rights)
import Data.Foldable as Foldable (foldl')
import Data.Function (fix)
import Data.Functor (void)
import Data.IP (fromHostAddress, toSockAddr)
import Data.List (find, intercalate)
import Data.List.NonEmpty (NonEmpty (..))
import Data.List.NonEmpty qualified as NonEmpty
import Data.Map.Strict (Map)
import Data.Map.Strict qualified as Map
import Data.Maybe (isJust, listToMaybe, mapMaybe)
import Data.Set (Set)
import Data.Set qualified as Set
import Data.Time.Clock (diffTimeToPicoseconds, picosecondsToDiffTime)
import Data.Void (Void)
import Data.Word (Word16)
import Network.DNS (DNSError (NameError), DNSMessage, ResourceRecord (..),
           answer, defaultResponse)
import Network.DNS qualified as DNS
import Network.DNS.Resolver qualified as DNSResolver
import Network.Socket (SockAddr (..))
import System.Random

import Control.Concurrent.Class.MonadSTM qualified as LazySTM
import Control.Concurrent.Class.MonadSTM.Strict
import Control.Exception (IOException, throw)
import Control.Monad.Class.MonadAsync
import Control.Monad.Class.MonadSay (MonadSay (..))
import Control.Monad.Class.MonadThrow
import Control.Monad.Class.MonadTime.SI
import Control.Monad.Class.MonadTimer.SI
import Control.Monad.Class.MonadTimer.SI qualified as MonadTimer
import Control.Monad.IOSim
import Control.Tracer (Tracer, contramap, mkTracer, nullTracer, traceWith)

import Ouroboros.Network.ConnectionManager.Types (Provenance (Outbound))
import Ouroboros.Network.DiffusionMode
import Ouroboros.Network.PeerSelection
import Test.Ouroboros.Network.Data.Script (Script (Script), initScript',
           scriptHead, singletonScript, stepScript')
import Test.Ouroboros.Network.OrphanInstances (genIPv4)
import Test.Ouroboros.Network.PeerSelection.Instances
import Test.QuickCheck
import Test.Tasty (TestTree, testGroup)
import Test.Tasty.QuickCheck (testProperty)

tests :: TestTree
tests =
  testGroup "Ouroboros.Network.PeerSelection"
  [ testGroup "RootPeersDNS"
    [ testGroup "localRootPeersProvider"
       [ testProperty "preserve IPs"
                      prop_local_preservesIPs
       , testProperty "preserves groups and targets"
                      prop_local_preservesGroupNumberAndTargets
       , testProperty "resolves domains correctly"
                      prop_local_resolvesDomainsCorrectly
       , testProperty "updates domains correctly"
                      prop_local_updatesDomainsCorrectly
       , testProperty "reconfigures IP addresses"
                      prop_local_reconfiguresIPs
       , testProperty "publishes IP addresses before setting up a resolver"
                      prop_local_publishesBeforeResolver
       ]
    , testGroup "publicRootPeersProvider"
       [ testProperty "resolves domains correctly"
                      prop_public_resolvesDomainsCorrectly
       ]
    , testGroup "delayedResource"
       [
       ]
    ]
  ]

--
-- Mock Environment and Utils
--

data DomainAccessPoint = DomainAccessPoint !DNS.Domain PortNumber
                       | DomainSRVAccessPoint !DNS.Domain
  deriving (Eq, Show, Ord)

instance Arbitrary DomainAccessPoint where
  arbitrary = oneof [plain, srv]
    where
      plain = DomainAccessPoint
                <$> genDomainName
                <*> arbitrary
      srv = DomainSRVAccessPoint <$> genDomainName

genDomainName :: Gen BSC.ByteString
genDomainName = elements $ (\i -> "test" <> (BSC.pack . show $ i)) <$> [1..6 :: Int]

-- TODO: this type alias should be turned into a newtype with a `Show` instance
-- which displays `IP` as a string literal.
type MockDNSLookupResult = Either [(IP, DNS.TTL)]
                                  [( DNS.Domain
                                   , Word16 -- ^ priority
                                   , Word16 -- ^ weight
                                   , PortNumber)]
type MockDNSMap = (Map (DNS.Domain, DNS.TYPE) MockDNSLookupResult)

data MockRoots = MockRoots {
    mockLocalRootPeers        :: [( HotValency
                                  , WarmValency
                                  , Map RelayAccessPoint (LocalRootConfig ()))
                                  -- ^ extraFlags isn't used here since it is
                                  -- not required for testing.
                                 ]
  , mockLocalRootPeersDNSMap  :: Script MockDNSMap
  , mockPublicRootPeers       :: Map RelayAccessPoint PeerAdvertise
  , mockPublicRootPeersDNSMap :: Script MockDNSMap
  }
  deriving Show

-- | Generates MockRoots environments
--
genMockRoots :: Gen MockRoots
genMockRoots = sized $ \relaysNumber -> do
    -- Generate LocalRootPeers
    --
    relaysPerGroup <- chooseEnum (1, max 1 (relaysNumber `div` 3))

    -- concat unique identifier to DNS domains to simplify tests
    taggedLocalRelays <- tagRelays <$> vectorOf relaysNumber arbitrary
    targets <- vectorOf relaysNumber genTargets
    peerAdvertise <- blocks relaysPerGroup
                      <$> vectorOf relaysNumber arbitrary

    let localRelaysBlocks = blocks relaysPerGroup taggedLocalRelays
        localRelaysMap    = map Map.fromList $ zipWith zip localRelaysBlocks
                                                           peerAdvertise
        localRootPeers    = zipWith (\(h, w) g -> (h, w, g)) targets localRelaysMap

    lrpDNSMap <- Script . NonEmpty.fromList
              <$> listOf1 (genDNSLookupMap taggedLocalRelays)

    -- Generate PublicRootPeers
    --
    publicRootRelays <- tagRelays <$> vectorOf relaysNumber arbitrary
    let publicRootAdvertise = vectorOf relaysNumber arbitrary

    publicRootPeers <- Map.fromList . zip publicRootRelays <$> publicRootAdvertise
    publicRootPeersDNSMap <- Script . NonEmpty.fromList <$> listOf1 (genDNSLookupMap publicRootRelays)

    return (MockRoots {
      mockLocalRootPeers        = localRootPeers,
      mockLocalRootPeersDNSMap  = lrpDNSMap,
      mockPublicRootPeers       = publicRootPeers,
      mockPublicRootPeersDNSMap = publicRootPeersDNSMap
    })
  where
    tagRelays =
      zipWith
        (\tag rel
          -> case rel of
               RelayAccessDomain domain port ->
                 RelayAccessDomain (domain <> (pack . show) tag) port
               RelayAccessSRVDomain domain ->
                 RelayAccessSRVDomain (domain <> (pack . show) tag)
               x -> x
        )
        [(0 :: Int), 1 .. ]

blocks :: Int -> [a] -> [[a]]
blocks _ [] = []
blocks s l  = take s l : blocks s (drop s l)

-- | DNS answers for the domains among the relays: two addresses for each
-- plain domain, and for each SRV domain some of the plain ones.
genDNSLookupMap :: [RelayAccessPoint] -> Gen MockDNSMap
genDNSLookupMap relays = do
    let (_relayAddress, relayDomains, relaySRVs) =
          foldl' threeWay ([], [], []) relays
    lookupIP <- genDomainIPLookupTable 2 (dapDomain <$> relayDomains)
    srvs <- dealDomains relayDomains relaySRVs
    let srvs' = bimap dapDomain (map dapDomain) <$> srvs
    lookupSRV <- Map.fromList . map (bimap (,DNS.SRV) Right)
                 <$> genGroupSrvs srvs'
    return $ Map.union lookupIP lookupSRV
  where
    dapDomain (DomainAccessPoint d _p) = d
    dapDomain (DomainSRVAccessPoint d) = d

    -- assigns some domains to srv records
    dealDomains :: [DomainAccessPoint]
                -> [DomainAccessPoint]
                -> Gen [(DomainAccessPoint, [DomainAccessPoint])]
    dealDomains = dealDomains' []

    -- kickstart the dealing
    dealDomains' [] (domain : domains) (srv : srvs') =
      dealDomains' [(srv, [domain])] domains srvs'

    -- when no more plain domains are available, return empty lookup
    -- which should trace as an error, but a lookup attempt is registered
    dealDomains' acc [] (srv : srvs') =
      dealDomains' ((srv, []):acc) [] srvs'

    -- toss a coin, if True pop a `DomainPlain` and assign it to
    -- the top srv record. Otherwise, pop the next srv record, and
    -- associate the plain domain with that one.
    dealDomains' as'@((s, ds):as) (domain : domains) srvs@(srv : srvs') = do
      toss <- arbitrary
      if toss
        then dealDomains' ((s, domain : ds):as) domains srvs
        else dealDomains' ((srv, [domain]):as') domains srvs'

    dealDomains' as _ds _srvs = return as

    threeWay :: ([RelayAccessPoint], [DomainAccessPoint], [DomainAccessPoint])
             -> RelayAccessPoint
             -> ([RelayAccessPoint], [DomainAccessPoint], [DomainAccessPoint])
    threeWay (rAddressAcc, rDomainAcc, rSRVAcc) = \case
      a@RelayAccessAddress {} -> (a : rAddressAcc, rDomainAcc, rSRVAcc)
      RelayAccessDomain d p  -> (rAddressAcc, DomainAccessPoint d p : rDomainAcc, rSRVAcc)
      RelayAccessSRVDomain d -> (rAddressAcc, rDomainAcc, DomainSRVAccessPoint d : rSRVAcc)

    genDomainIPLookupTable :: Int -> [DNS.Domain] -> Gen (Map (DNS.Domain, DNS.TYPE)
                                                              MockDNSLookupResult)
    genDomainIPLookupTable ipsPerDomain localRootDomains = do
      localRootDomainIPs <- blocks ipsPerDomain
              -- Modules under test do not differ by IP version so we only
              -- generate IPv4 addresses.
              <$> vectorOf (ipsPerDomain * length localRootDomains)
                           genIPv4
      localRootDomainTTLs <- blocks ipsPerDomain
              <$> vectorOf (ipsPerDomain * length localRootDomains)
                           (arbitrary :: Gen DNS.TTL)

      let localRootDomainsIP_TTls = zipWith zip localRootDomainIPs localRootDomainTTLs
          rootDomainKeys = (, DNS.A) <$> localRootDomains
          lrpDNSMap = Map.fromList $ zip rootDomainKeys (Left <$> localRootDomainsIP_TTls)

      return lrpDNSMap

-- assigns weights and priorities to SRV record's subordinate domains
-- such that several subdomains may have the same priority level and port
-- number, and each one will have a random weight, and result is shuffled
--
genGroupSrvs :: (Arbitrary prio, Arbitrary wt)
             => [(srv, [subordinate])]
             -> Gen [(srv, [(subordinate, prio, wt, PortNumber)])]
genGroupSrvs = go []
 where
  go acc [] = return acc
  go acc ((srv, subordinates):srvs) = do
    let worker grouped 0 _ = shuffle grouped
        worker grouped count domains' = do
          howMany <- chooseInt (1, count)
          port <- arbitrary
          prio <- arbitrary
          wts <- vectorOf howMany arbitrary
          let group = take howMany domains'
              smash dom wt = (dom, prio, wt, port)
              grouped' = zipWith smash group wts
                         <> grouped
          worker grouped' (count - howMany) (drop howMany domains')
    organized <- worker [] (length subordinates) subordinates
    go ((srv, organized) : acc) srvs

genTargets :: Gen (HotValency, WarmValency)
genTargets = do
  warmValency <- WarmValency <$> chooseEnum (1, 5)
  hotValency <- HotValency <$> chooseEnum (1, getWarmValency warmValency)
  return (hotValency, warmValency)

type LocalRootsConfig = [( HotValency
                         , WarmValency
                         , Map RelayAccessPoint (LocalRootConfig ()))]

-- | The local root groups the provider publishes.
type LocalRootGroups = [( HotValency
                        , WarmValency
                        , Map SockAddr (LocalRootConfig ()))]

data Edit = EditFlags | EditTargets | Remove | Add
  deriving (Bounded, Enum)

-- | A new local roots configuration for a reload of the given one: a
-- configuration of its own at an independent size, none at all, the same
-- one, or an edit of it which changes flags or targets, removes entries or
-- groups, or adds entries, IP addresses and domains of its own.
genReconfiguration :: LocalRootsConfig -> Gen LocalRootsConfig
genReconfiguration old =
    frequency [ (2, sized $ \n -> do
                      n' <- choose (0, n)
                      mockLocalRootPeers <$> resize n' genMockRoots)
              , (1, pure [])
              , (1, pure old)
              , (8, do edits <- frequency
                                  [ (3, (: []) <$> elements [minBound .. maxBound])
                                  , (1, sublistOf [minBound .. maxBound]) ]
                       foldM edit old edits)
              ]
  where
    edit :: LocalRootsConfig -> Edit -> Gen LocalRootsConfig
    edit conf EditFlags =
      traverse (\(h, w, m) -> (h, w,) <$> traverse (\c -> oneof [pure c, arbitrary]) m) conf
    edit conf EditTargets =
      traverse (\g@(_, _, m) -> oneof [pure g, (\(h, w) -> (h, w, m)) <$> genTargets]) conf
    edit conf Remove =
      sublistOf conf
      >>= traverse (\(h, w, m) -> (h, w,) . Map.fromList <$> sublistOf (Map.toList m))
    edit conf Add = do
      new <- fmap Map.fromList . listOf1 $ (,) <$> genEntry <*> arbitrary
      i <- chooseInt (0, length conf)
      if i == length conf
        then (\(h, w) -> conf ++ [(h, w, new)]) <$> genTargets
        else pure [ if j == i then (h, w, m <> new) else g
                  | (j, g@(h, w, m)) <- zip [0 ..] conf ]

    -- an entry of the new configuration's own: a domain is named apart from
    -- those of 'genMockRoots'
    genEntry :: Gen RelayAccessPoint
    genEntry = frequency [ (2, RelayAccessAddress <$> genIPv4 <*> genPort)
                         , (1, RelayAccessDomain <$> genNewDomain <*> genPort)
                         , (1, RelayAccessSRVDomain <$> genNewDomain) ]
    genPort = fromIntegral <$> chooseInt (1, 65535)
    genNewDomain = (<> "new") <$> genDomainName

-- | Shrinks groups away, entries out of groups, targets towards one, and
-- entries towards a plain configuration.
shrinkLocalRootsConfig :: LocalRootsConfig -> [LocalRootsConfig]
shrinkLocalRootsConfig = shrinkList group
  where
    group (h, w, m) =
         [ (h', w', m) | (h', w') <- targets (h, w) ]
      ++ [ (h, w, Map.fromList m') | m' <- shrinkList entry (Map.toList m) ]
    targets (h, w) =
      [ (1, 1) | (h, w) /= (1, 1) ]
      ++ [ (1, w) | h /= 1, w /= 1 ]
      ++ [ (h, WarmValency (getHotValency h)) | getHotValency h < getWarmValency w, h /= 1 ]
    entry (rap, c) = [ (rap, plain) | c /= plain ]
    plain = LocalRootConfig DoNotAdvertisePeer InitiatorAndResponderDiffusionMode Outbound ()

instance Arbitrary MockRoots where
    arbitrary = genMockRoots
    shrink roots@MockRoots
      { mockLocalRootPeers
      , mockLocalRootPeersDNSMap
      , mockPublicRootPeers
      , mockPublicRootPeersDNSMap
      } =
      [ roots { mockLocalRootPeers        = lrp
              , mockLocalRootPeersDNSMap  = lrpDNSMap
              }
      | lrp <- shrinkList (const []) mockLocalRootPeers,
        let lrpDomains =
              Set.fromList $
                concatMap
                  (mapMaybe
                    (\case
                        RelayAccessDomain d _p -> Just (d, DNS.A)
                        RelayAccessSRVDomain d -> Just (d, DNS.SRV)
                        _otherwise -> Nothing)
                    . Map.keys . thrd)
                  lrp
            lrpDNSMap  = (`Map.restrictKeys` lrpDomains)
                       <$> mockLocalRootPeersDNSMap
      ] ++
      [ roots { mockPublicRootPeers       = prp
              , mockPublicRootPeersDNSMap = prpDNSMap
              }
      | prp <- shrink mockPublicRootPeers,
        let prpDomains = Set.fromList $
              mapMaybe
                ((\case
                    RelayAccessDomain d _p -> Just (d, DNS.A)
                    RelayAccessSRVDomain d -> Just (d, DNS.SRV)
                    _otherwise -> Nothing) . fst)
               (Map.assocs prp)
            prpDNSMap  = (`Map.restrictKeys` prpDomains)
                       <$> mockPublicRootPeersDNSMap
      ]
        where
          thrd (_, _, c) = c

-- | Used for debugging in GHCI
--
simpleMockRoots :: MockRoots
simpleMockRoots = MockRoots localRootPeers dnsMap Map.empty (singletonScript Map.empty)
  where
    localRootPeers =
      [ ( 2, 2
        , Map.fromList
          [ ( RelayAccessAddress (read "192.0.2.1") (read "3333")
            , LocalRootConfig DoAdvertisePeer InitiatorAndResponderDiffusionMode Outbound ()
            )
          , ( RelayAccessDomain  "test.domain"      (read "4444")
            , LocalRootConfig DoNotAdvertisePeer InitiatorAndResponderDiffusionMode Outbound ()
            )
          ]
        )
      ]
    dnsMap = singletonScript $ Map.fromList
              [ (("test.domain", DNS.A), Left [read "192.1.1.1", read "192.2.2.2"])
              ]


genDiffTime :: Integer
            -> Integer
            -> Gen DiffTime
genDiffTime lo hi =
      picosecondsToDiffTime
    . (lo * 1_000_000_000 +)
    . (1_000_000_000 *)
    . getNonNegative
  <$> resize (fromIntegral hi) arbitrary

-- | Whether the timeouts and delays are whole milliseconds, as 'genDiffTime'
-- draws them and their shrinkers keep them; the reload instant of
-- 'reloadDelay' relies on it.
wholeMilliseconds :: Script DNSTimeout -> Script DNSLookupDelay -> Bool
wholeMilliseconds (Script timeouts) (Script delays) =
     all (wholeMillisecond . getDNSTimeout) timeouts
  && all (wholeMillisecond . getDNSLookupDelay) delays
  where
    wholeMillisecond t = diffTimeToPicoseconds t `mod` 1_000_000_000 == 0


newtype DNSTimeout = DNSTimeout { getDNSTimeout :: DiffTime }
  deriving Show

instance Arbitrary DNSTimeout where
    arbitrary = DNSTimeout <$> genDiffTime 110 300
    -- in whole milliseconds, as drawn
    shrink (DNSTimeout delta) =
      [ DNSTimeout (fromIntegral ms / 1000)
      | ms <- shrink (round (delta * 1000) :: Integer)
      , ms >= 110
      ]


newtype DNSLookupDelay = DNSLookupDelay { getDNSLookupDelay :: DiffTime }
  deriving Show

instance Arbitrary DNSLookupDelay where
    arbitrary = DNSLookupDelay <$> genDiffTime 20 120
    -- in whole milliseconds, as drawn
    shrink (DNSLookupDelay delta) =
      [ DNSLookupDelay (fromIntegral ms / 1000)
      | ms <- shrink (round (delta * 1000) :: Integer)
      , ms >= 20
      ]

-- | Mock DNSActions data structure for testing purposes.
-- Adds DNS Lookup function for IOSim with different timeout and lookup
-- delays for every attempt.
mockDNSActions :: forall peerAddr m.
                  ( MonadDelay m
                  , MonadTimer m
                  , MonadAsync m
                  )
               => Tracer m DNSTrace
               -> DNSLookupType
               -> (IP -> PortNumber -> peerAddr)
               -> StrictTVar m MockDNSMap
               -> StrictTVar m (Script DNSTimeout)
               -> StrictTVar m (Script DNSLookupDelay)
               -> DNSActions peerAddr () m
mockDNSActions tracer ofType0 toPeerAddr dnsMapVar dnsTimeoutScript dnsLookupDelayScript =
    DNSActions {
      dnsResolverResource,
      dnsAsyncResolverResource,
      dnsLookupWithTTL = dispatchLookupWithTTL ofType0 mockLookup tracer toPeerAddr
    }
 where
   dnsResolverResource      _ = return (Right <$> constantResource ())
   dnsAsyncResolverResource _ = return (Right <$> constantResource ())

   mockLookup :: resolver
              -> resolvConf
              -> DNS.Domain
              -> DNS.TYPE
              -> m (Maybe (Either DNSError DNSMessage))
   mockLookup _ _ domain ofType = do
     dnsMap <- readTVarIO dnsMapVar
     DNSTimeout dnsTimeout <- stepScript' dnsTimeoutScript
     DNSLookupDelay dnsLookupDelay <- stepScript' dnsLookupDelayScript

     MonadTimer.timeout dnsTimeout do
       MonadTimer.threadDelay dnsLookupDelay
       case Map.lookup (domain, ofType) dnsMap of
         Nothing -> return (Left NameError)
         Just x  -> return (Right $ toDNSMessage x)

     where
       toDNSMessage = \case
         Left ipsttls ->
           defaultResponse {
             answer = [ResourceRecord domain DNS.NULL 0 ttl rdata
                      | (ip, ttl) <- ipsttls
                      , let rdata = case ip of
                              IPv4 ip' -> DNS.RD_A ip'
                              IPv6 ip' -> DNS.RD_AAAA ip']}
         Right ds ->
           defaultResponse {
             answer = [ResourceRecord domain DNS.NULL 0 0 rdata
                      | (domain', prio, weight, port) <- ds
                      , let rdata = DNS.RD_SRV prio weight (fromIntegral port) domain']}

-- | When 'mockLocalRootPeersProvider' applies its reconfiguration: half a
-- millisecond past the second, when no lookup completes, as the delays and
-- timeouts are whole milliseconds and the TTL waits whole seconds. An answer
-- committed in the instant of the reload could have its thread stopped before
-- it is traced.
reloadDelay :: DiffTime
reloadDelay = 100.0005

-- | 'localRootPeersProvider' running with a given MockRoots env
--
mockLocalRootPeersProvider :: forall m.
                              ( Alternative (STM m)
                              , MonadAsync    m
                              , MonadDelay    m
                              , MonadThrow    m
                              , MonadTimer    m
                              , MonadTraceSTM m
                              , MonadLabelledSTM m
                              )
                           => Tracer m (TestTraceEvent (TraceLocalRootPeers () SockAddr))
                           -> MockRoots
                           -> Maybe [( HotValency
                                     , WarmValency
                                     , Map RelayAccessPoint (LocalRootConfig ()))]
                           -- ^ a reconfiguration, applied after 'reloadDelay'
                           -> Script DNSTimeout
                           -> Script DNSLookupDelay
                           -> TestSeed
                           -> m ()
mockLocalRootPeersProvider tracer (MockRoots localRootPeers dnsMapScript _ _) reconfiguration
                           dnsTimeoutScript dnsLookupDelayScript dnsSeed = do
      dnsMapScriptVar <- initScript' dnsMapScript
      dnsMap <- stepScript' dnsMapScriptVar
      dnsMapVar <- newTVarIO dnsMap

      dnsTimeoutScriptVar <- initScript' dnsTimeoutScript
      dnsLookupDelayScriptVar <- initScript' dnsLookupDelayScript
      localRootPeersVar <- newTVarIO localRootPeers
      resultVar <- newTVarIO mempty
      traceTVarIO resultVar (\_ groups -> pure (TraceDynamic (Published groups)))
      withAsync (updateDNSMap dnsMapScriptVar dnsMapVar) $ \_ ->
        withAsync (reconfigure localRootPeersVar) $ \_ -> do
        void $ MonadTimer.timeout 3600 $
          localRootPeersProvider (contramap Left tracer)
                                 PeerActionsDNS {
                                   paToPeerAddr = curry toSockAddr,
                                   paDnsActions =
                                     mockDNSActions
                                       (contramap Right tracer)
                                       LookupReqAOnly
                                       (curry toSockAddr)
                                       dnsMapVar
                                       dnsTimeoutScriptVar
                                       dnsLookupDelayScriptVar
                                 }
                                 DNSResolver.defaultResolvConf
                                 (mkStdGen $ unTestSeed dnsSeed)
                                 (readTVar localRootPeersVar)
                                 resultVar
        -- if the groups never differ from the empty ones `resultVar` starts
        -- with, `localRootPeersProvider` never writes to it, and the
        -- `traceTVarIO` callback never executes. By reading & writing to the
        -- `TVar` we are forcing it to run at least once.
        atomically $ readTVar resultVar >>= writeTVar resultVar
  where
    reconfigure :: StrictTVar m [( HotValency
                                 , WarmValency
                                 , Map RelayAccessPoint (LocalRootConfig ()))]
                -> m ()
    reconfigure localRootPeersVar = do
      threadDelay reloadDelay
      case reconfiguration of
           Just localRootPeers' -> atomically (writeTVar localRootPeersVar localRootPeers')
           Nothing              -> return ()

    updateDNSMap :: StrictTVar m (Script MockDNSMap)
                 -> StrictTVar m MockDNSMap
                 -> m Void
    updateDNSMap dnsMapScriptVar dnsMapVar =
      forever $ do
        threadDelay 10
        dnsMap <- stepScript' dnsMapScriptVar
        atomically (writeTVar dnsMapVar dnsMap)


-- | 'publicRootPeersProvider' running with a given MockRoots env.
--
-- NOTE: This function is used in 'prop_public_resolvesDomainsCorrectly'. Due to
-- API limitations it is needed to run 'publicRootPeersProvider' multiple times,
-- in order to run only 1 simulation which resolves untill we get the expected
-- result, instead of a recursive loop which at each step runs IOSim.
--
mockPublicRootPeersProvider :: forall m a.
                               ( MonadAsync m
                               , MonadDelay m
                               , MonadThrow m
                               , MonadTimer m
                               )
                            => Tracer m (TestTraceEvent TracePublicRootPeers)
                            -> MockRoots
                            -> Script DNSTimeout
                            -> Script DNSLookupDelay
                            -> TestSeed
                            -> ((Int -> m (Map SockAddr PeerAdvertise, TTL)) -> m a)
                            -> m ()
mockPublicRootPeersProvider tracer (MockRoots _ _ publicRootPeers dnsMapScript)
                            dnsTimeoutScript dnsLookupDelayScript dnsSeed action = do
      dnsMapScriptVar <- initScript' dnsMapScript
      dnsMap <- stepScript' dnsMapScriptVar
      dnsMapVar <- newTVarIO dnsMap
      dnsSemaphore <- newLedgerAndPublicRootDNSSemaphore

      dnsTimeoutScriptVar <- initScript' dnsTimeoutScript
      dnsLookupDelayScriptVar <- initScript' dnsLookupDelayScript
      publicRootPeersVar <- newTVarIO publicRootPeers
      replicateM_ 5 $ do
        dnsMap' <- stepScript' dnsMapScriptVar
        atomically (writeTVar dnsMapVar dnsMap')

        publicRootPeersProvider (contramap Left tracer)
                                (curry toSockAddr)
                                dnsSemaphore
                                DNSResolver.defaultResolvConf
                                (readTVar publicRootPeersVar)
                                (mockDNSActions
                                  (contramap Right tracer)
                                  LookupReqAOnly
                                  (curry toSockAddr)
                                  dnsMapVar
                                  dnsTimeoutScriptVar
                                  dnsLookupDelayScriptVar)
                                (mkStdGen $ unTestSeed dnsSeed)
                                action

-- | 'resolveDomainAddresses' running with a given MockRoots env
--
mockResolveLedgerPeers :: ( MonadAsync m
                          , MonadDelay m
                          , MonadThrow m
                          , MonadTimer m
                          )
                       => Tracer m (TestTraceEvent TraceLedgerPeers)
                       -> MockRoots
                       -> Script DNSTimeout
                       -> Script DNSLookupDelay
                       -> TestSeed
                       -> m (Map DNS.Domain (Set SockAddr))
mockResolveLedgerPeers tracer (MockRoots _ _ publicRootPeers dnsMapScript)
                       dnsTimeoutScript dnsLookupDelayScript (TestSeed dnsSeed) = do
      dnsMapScriptVar <- initScript' dnsMapScript
      dnsMap <- stepScript' dnsMapScriptVar
      dnsMapVar <- newTVarIO dnsMap
      dnsSemaphore <- newLedgerAndPublicRootDNSSemaphore

      dnsTimeoutScriptVar <- initScript' dnsTimeoutScript
      dnsLookupDelayScriptVar <- initScript' dnsLookupDelayScript
      let relays = [ dap
                   | (relay, _) <- Map.assocs publicRootPeers
                   , dap <- case relay of
                              RelayAccessAddress {} -> []
                              x                     -> [x]]
      traceWith tracer . Left $ TraceLedgerPeersDomains relays
      resolveLedgerPeers dnsSemaphore
                         DNSResolver.defaultResolvConf
                         (mockDNSActions
                           (contramap Right tracer)
                           LookupReqAOnly
                           (curry toSockAddr)
                           dnsMapVar
                           dnsTimeoutScriptVar
                           dnsLookupDelayScriptVar)
                         SingAllLedgerPeers
                         relays
                         (mkStdGen dnsSeed)

--
-- Utils for properties
--

type TestTraceEvent a = Either a DNSTrace

tracerTraceLocalRoots :: Tracer (IOSim s) (TestTraceEvent (TraceLocalRootPeers () SockAddr))
tracerTraceLocalRoots = mkTracer traceM

tracerTracePublicRoots :: Tracer (IOSim s) (TestTraceEvent TracePublicRootPeers)
tracerTracePublicRoots = mkTracer traceM

selectTestTraceEvents :: (Typeable b) => SimTrace a
                      -> [(Time, TestTraceEvent b)]
selectTestTraceEvents = go
  where
    go (SimTrace t _ _ (EventLog e) trace)
     | Just x <- fromDynamic e = (t, x) : go trace
    go (SimPORTrace t _ _ _ (EventLog e) trace)
     | Just x <- fromDynamic e       = (t,x) : go trace
    go (SimTrace _ _ _ _ trace)      =         go trace
    go (SimPORTrace _ _ _ _ _ trace) =         go trace
    go (TraceMainException _ _ e _)  = throw e
    go (TraceDeadlock      _   _)    = [] -- expected result in many cases
    go  TraceMainReturn {}           = []
    go (TraceInternalError e)        = error ("IOSim: " ++ e)
    go TraceLoop                     = error "IOSimPOR step time limit exceeded"

selectLocalRootPeersWithDNSEvents :: SimTrace a
                                  -> [(Time, TestTraceEvent (TraceLocalRootPeers () SockAddr))]
selectLocalRootPeersWithDNSEvents = filter them . selectTestTraceEvents
  where
    them (_t, Right dns) =
      case dns of
        (DNSLookupResult DNSLocalPeer _ _ _) -> True
        (DNSLookupError DNSLocalPeer _ _ _)  -> True
        (SRVLookupResult DNSLocalPeer _ _)   -> True
        (SRVLookupError DNSLocalPeer _)      -> True
        _otherwise                           -> False
    them _ = True

selectLocalRootGroupsEvents :: [(Time, TestTraceEvent (TraceLocalRootPeers () SockAddr))]
                            -> [(Time, [(HotValency, WarmValency, Map SockAddr (LocalRootConfig ()))])]
selectLocalRootGroupsEvents trace = [ (t, r)
                                    | (t, Left (TraceLocalRootGroups r)) <- trace ]

selectPublicRootPeersWithDNSEvents :: SimTrace a
                                   -> [(Time, TestTraceEvent TracePublicRootPeers)]
selectPublicRootPeersWithDNSEvents = filter them . selectTestTraceEvents
  where
    them (_t, Right dns) =
      case dns of
        (DNSLookupResult DNSPublicPeer _ _ _) -> True
        (DNSLookupError DNSPublicPeer _ _ _)  -> True
        (SRVLookupResult DNSPublicPeer _ _)   -> True
        (SRVLookupError DNSPublicPeer _)      -> True
        _otherwise                            -> False
    them _ = True

selectDnsResultEvents :: [(Time, TestTraceEvent a)]
                      -> [(Time, DNSTrace)]
selectDnsResultEvents trace = [(t, r)
                              | (t, Right r@(DNSLookupResult {})) <- trace]

--
-- Local Root Peers Provider Tests
--

-- | The 'localRootPeersProvider' should use the IP addresses. This property
-- tests whether local root peer groups contain the IP addresses provided.
--
prop_local_preservesIPs :: MockRoots
                        -> Script DNSTimeout
                        -> Script DNSLookupDelay
                        -> TestSeed
                        -> Property
prop_local_preservesIPs mockRoots@(MockRoots localRoots _ _ _)
                        dnsTimeoutScript
                        dnsLookupDelayScript
                        dnsSeed =
    let tr = selectLocalRootGroupsEvents
           $ selectLocalRootPeersWithDNSEvents
           $ runSimTrace
           $ mockLocalRootPeersProvider tracerTraceLocalRoots
                                        mockRoots
                                        Nothing
                                        dnsTimeoutScript
                                        dnsLookupDelayScript
                                        dnsSeed

     in counterexample (intercalate "\n" $ map show tr)
      $ classify (length tr > 0) "Actually testing something"
      $ checkAll tr
  where
    checkAll :: [(Time, [( HotValency
                         , WarmValency
                         , Map SockAddr (LocalRootConfig ()))])]
             -> Property
    checkAll [] = property True
    checkAll (x:t) =
      let thrd (_, _, c) = c
          -- get local root ip addresses
          localRootAddresses :: [(a, b, Map RelayAccessPoint (LocalRootConfig ()))]
                             -> Set SockAddr
          localRootAddresses lrp =
            Set.fromList
            [ toSockAddr (ip, port)
            | (_, _, m) <- lrp
            , RelayAccessAddress ip port <- Map.keys m
            ]

          -- get ip addresses out of LocalRootGroup trace events
          localGroupEventsAddresses :: (a, [( HotValency
                                            , WarmValency
                                            , Map SockAddr (LocalRootConfig ()))])
                                    -> Set SockAddr
          localGroupEventsAddresses (_, s) =
              Set.fromList
            $ concatMap (Map.keys . thrd)
            $ s

          localRootAddressesSet = localRootAddresses localRoots
          localGroupEventsAddressesSet = localGroupEventsAddresses x
       in counterexample (show localRootAddressesSet ++ " is not subset of "
                         ++ show localGroupEventsAddressesSet)
        $ localRootAddressesSet `Set.isSubsetOf` localGroupEventsAddressesSet
        .&&. checkAll t

-- | The configuration without its domain names.
ipEntriesOnly :: [(HotValency, WarmValency, Map RelayAccessPoint (LocalRootConfig ()))]
              -> [(HotValency, WarmValency, Map RelayAccessPoint (LocalRootConfig ()))]
ipEntriesOnly = map (\(h, w, m) -> (h, w, Map.filterWithKey (\rap _ -> isRelayAccessAddress rap) m))

-- | The IP entries of a group, as the provider publishes them.
ipAddressesOf :: Map RelayAccessPoint (LocalRootConfig ()) -> Map SockAddr (LocalRootConfig ())
ipAddressesOf m =
  Map.fromList [ (toSockAddr (ip, port), c) | (RelayAccessAddress ip port, c) <- Map.toList m ]

-- | After a reconfiguration the provider applies the new local root groups at
-- once, IP addresses included, even when the new configuration has no domain
-- name to resolve.
--
-- The provider sees the change at the reload, after 'reloadDelay', and from
-- then on every value it publishes has the groups and targets of the new
-- configuration, every IP address of a group with its own configuration, and
-- nothing else but addresses of the group's domains, each with that domain's
-- configuration.
--
-- At the reload a kept domain contributes the addresses it had, which must be
-- there, and no other domain contributes: a new one is not resolved yet. Every
-- kept domain is then looked up again. For a configuration without domain
-- names this is equality with the configured groups.
--
prop_local_reconfiguresIPs :: Script DNSTimeout
                           -> Script DNSLookupDelay
                           -> TestSeed
                           -> Property
prop_local_reconfiguresIPs dnsTimeoutScript dnsLookupDelayScript dnsSeed =
    checkCoverage $
    forAllShrink genRoots shrinkRoots $
    \(mockRoots@(MockRoots localRoots (Script dnsMaps) _ _), newRoots, ipOnly) ->
    let newRoots' :: LocalRootsConfig
        newRoots'
          | ipOnly    = ipEntriesOnly newRoots
          | otherwise = newRoots
        simTrace :: SimTrace ()
        simTrace = runSimTrace
                 $ mockLocalRootPeersProvider tracerTraceLocalRoots
                                              mockRoots
                                              (Just newRoots')
                                              dnsTimeoutScript
                                              dnsLookupDelayScript
                                              dnsSeed
        tr :: [(Time, TestTraceEvent (TraceLocalRootPeers () SockAddr))]
        tr = selectLocalRootPeersWithDNSEvents simTrace
        published :: [(Time, LocalRootGroups)]
        published = [ (t, groups)
                    | (t, Published groups) <- selectTraceEventsDynamicWithTime simTrace
                    ]
        reload :: Time
        reload = Time reloadDelay
        changed :: Bool
        changed = newRoots' /= localRoots
        -- the groups published at the reload: the last by then, as no answer
        -- of the old lookup threads is published in the instant of the reload
        atReload :: LocalRootGroups
        atReload = last ([] : [ groups | (t, groups) <- published, t <= reload ])
        -- the groups the provider wrote in that instant, if any, which it
        -- traces right after the domains, and only then
        writtenAtReload, tracedAtReload :: [LocalRootGroups]
        writtenAtReload = [ groups | (t, groups) <- published, t == reload ]
        tracedAtReload  = case [ ev | (_, Left ev) <- after ] of
                            _ : TraceLocalRootDomains _ : TraceLocalRootGroups g : _ -> [g]
                            _ -> []
        oldDomains :: Set RelayAccessPoint
        oldDomains = Set.fromList [ rap
                                  | (_, _, m) <- localRoots
                                  , rap <- Map.keys m
                                  , not (isRelayAccessAddress rap)
                                  ]
        -- the trace up to the provider seeing the change, and from then on
        before, after :: [(Time, TestTraceEvent (TraceLocalRootPeers () SockAddr))]
        (before, after) = break isReconfigured tr
        isReconfigured :: (Time, TestTraceEvent (TraceLocalRootPeers () SockAddr)) -> Bool
        isReconfigured (_, Left TraceLocalRootReconfigured {}) = True
        isReconfigured _                                       = False
        reconfigured :: Bool
        reconfigured = case after of
                         (t, _) : _ -> t >= reload
                         []         -> False
        -- the addresses the provider had resolved when it saw the change, and
        -- the ones it started the new configuration from: those of each kept
        -- domain, none for the others. The last traced map is the last
        -- committed one, as IOSim resumes threads in the order they committed
        resolvedBefore :: Map RelayAccessPoint [SockAddr]
        resolvedBefore = last (Map.empty : [ m | (_, Left (TraceLocalRootDNSMap m)) <- before ])
        startedFrom :: Maybe (Map RelayAccessPoint [SockAddr])
        startedFrom = listToMaybe [ m | (_, Left (TraceLocalRootDNSMap m)) <- after ]
        expectedStart :: Map RelayAccessPoint [SockAddr]
        expectedStart = Map.fromList [ (rap, Map.findWithDefault [] rap resolvedBefore)
                                     | (_, _, m) <- newRoots'
                                     , rap <- Map.keys m
                                     , not (isRelayAccessAddress rap)
                                     ]
        -- the addresses of the IP entries and the kept domains at the reload,
        -- each with the configuration of its IP entry, if any, else of the
        -- first domain of its group that holds it, as the provider gives an
        -- address held by several entries
        requiredAtReload :: [Map SockAddr (LocalRootConfig ())]
        requiredAtReload =
          [ ipAddressesOf m
            `Map.union`
            Map.fromListWith (\_ first -> first)
              [ (a, c)
              | (rap, c) <- Map.toList m
              , not (isRelayAccessAddress rap)
              , a <- Map.findWithDefault [] rap expectedStart
              ]
          | (_, _, m) <- newRoots'
          ]
        missingAtReload :: [String]
        missingAtReload
          | changed   = [ show (a, c) ++ " missing at the reload in " ++ show pm
                        | (required, (_, _, pm)) <- zip requiredAtReload atReload
                        , (a, c) <- Map.toList required
                        , Map.lookup a pm /= Just c
                        ]
          | otherwise = []
        -- the kept domains are looked up again
        lookedUp :: Set DNS.Domain
        lookedUp = Set.fromList [ d
                                | (_, Right ev) <- after
                                , Just d <- [lookedUpDomain ev]
                                ]
        notLookedUp :: [RelayAccessPoint]
        notLookedUp
          | changed   = [ rap
                        | (_, _, m) <- newRoots'
                        , rap <- Map.keys m
                        , rap `Set.member` oldDomains
                        , Just d <- [relayAccessPointDomain rap]
                        , d `Set.notMember` lookedUp
                        ]
          | otherwise = []
        sameShape :: (   (HotValency, WarmValency, Map RelayAccessPoint (LocalRootConfig ()))
                      -> (HotValency, WarmValency, Map RelayAccessPoint (LocalRootConfig ()))
                      -> Bool)
                  -> Bool
        sameShape f = changed
                   && length newRoots' == length localRoots
                   && and (zipWith f newRoots' localRoots)
        allowedOld, allowedLater :: [Map SockAddr [LocalRootConfig ()]]
        allowedOld   = map (allowedBy dnsMaps (`Set.member` oldDomains)) newRoots'
        allowedLater = map (allowedBy dnsMaps (const True)) newRoots'
        -- once the groups match the new configuration, an address beyond
        -- those of its IP entries and old domains is a new domain's
        newDomainContributes :: Bool
        newDomainContributes =
          any (\(t, groups) -> t > reload && isJust (discrepancy newRoots' allowedOld groups))
              published
    in counterexample (intercalate "\n" $ map show tr)
     $ cover 30 (all (all isRelayAccessAddress . Map.keys . entriesOf) newRoots')
                "new configuration has no domain names"
     $ cover 1 (null [ ()
                     | (_, _, m) <- newRoots'
                     , rap <- Map.keys m
                     , isRelayAccessAddress rap
                     ])
                "new configuration has no IP addresses"
     $ cover 1 (newRoots' == localRoots) "unchanged configuration"
     $ cover 1 (null localRoots && not (null newRoots')) "from no groups"
     $ cover 1 (not (null localRoots) && null newRoots') "to no groups"
     $ cover 1 (sameShape (\g g' -> targetsOf g == targetsOf g'
                                  && Map.keys (entriesOf g) == Map.keys (entriesOf g')))
               "only flags change"
     $ cover 1 (sameShape (\g g' -> entriesOf g == entriesOf g')) "only targets change"
     $ cover 1 (newRoots' /= localRoots && removalOf newRoots' localRoots) "only removals"
     $ cover 5 (any (\rap -> not (isRelayAccessAddress rap) && rap `Set.member` oldDomains)
                    (concatMap (Map.keys . entriesOf) newRoots'))
               "a domain is kept"
     $ cover 5 newDomainContributes "a new domain contributes"
     $ (case traceResult False simTrace of
          Left e  -> counterexample ("the simulation failed: " ++ show e) False
          Right _ -> property True)
       .&&. counterexample "the configuration change was not seen at the reload"
              (not changed || reconfigured)
       .&&. counterexample ("the reload instant relies on whole-millisecond "
                            ++ "timeouts and delays")
              (wholeMilliseconds dnsTimeoutScript dnsLookupDelayScript)
       .&&. counterexample ("the provider started from " ++ show startedFrom
                            ++ " rather than " ++ show expectedStart)
              (not changed || startedFrom == Just expectedStart)
       .&&. (case missingAtReload of
               []    -> property True
               e : _ -> counterexample e False)
       .&&. counterexample ("the groups written at the reload " ++ show writtenAtReload
                            ++ " are traced as " ++ show tracedAtReload)
              (not changed || writtenAtReload == tracedAtReload)
       .&&. counterexample ("kept domains not looked up again: " ++ show notLookedUp)
              (null notLookedUp)
       .&&. (case discrepancy newRoots' allowedOld atReload of
               Nothing -> property True
               Just e  -> counterexample ("at the reload: " ++ e) False)
       .&&. (case [ "at " ++ show t ++ ": " ++ e
                  | (t, groups) <- published
                  , t > reload
                  , Just e <- [discrepancy newRoots' allowedLater groups]
                  ] of
               []    -> property True
               e : _ -> counterexample e False)
  where
    -- the domain a lookup trace is of; the subordinate of an SRV domain is
    -- traced with it
    lookedUpDomain :: DNSTrace -> Maybe DNS.Domain
    lookedUpDomain = \case
      DNSLookupResult _ d Nothing _  -> Just d
      DNSLookupResult _ _ (Just d) _ -> Just d
      DNSLookupError _ _ d _         -> Just d
      SRVLookupResult _ d _          -> Just d
      SRVLookupError _ d             -> Just d

    genRoots :: Gen (MockRoots, LocalRootsConfig, Bool)
    genRoots = do
      roots <- arbitrary
      noGroups <- frequency [(1, pure True), (5, pure False)]
      let roots' | noGroups  = roots { mockLocalRootPeers = [] }
                 | otherwise = roots
      newRoots <- genReconfiguration (mockLocalRootPeers roots')
      -- the domains the new configuration adds get answers too; for the
      -- old ones the script's own entries take precedence
      newDNSMap <- genDNSLookupMap (concatMap (Map.keys . entriesOf) newRoots)
      let roots'' = roots' { mockLocalRootPeersDNSMap =
                               (`Map.union` newDNSMap) <$> mockLocalRootPeersDNSMap roots' }
      ipOnly <- frequency [(1, pure True), (2, pure False)]
      return (roots'', newRoots, ipOnly)

    -- the old configuration only loses entries, and the new one loses them
    -- too, so a kept domain stays kept and a new one new; an unchanged
    -- configuration stays unchanged
    shrinkRoots :: (MockRoots, LocalRootsConfig, Bool) -> [(MockRoots, LocalRootsConfig, Bool)]
    shrinkRoots (roots@MockRoots { mockLocalRootPeers = old }, newRoots, ipOnly) =
         [ (roots { mockLocalRootPeers = old' }, newRoots', ipOnly)
         | old' <- shrinkList (\(h, w, m) -> [ (h, w, Map.fromList m')
                                             | m' <- shrinkList (const []) (Map.toList m)
                                             ])
                              old
         , let removed = keysOf old `Set.difference` keysOf old'
               newRoots' | newRoots == old = old'
                         | otherwise       = without removed newRoots
         ]
      ++ [ (roots, newRoots', ipOnly)
         | newRoots /= old
         , newRoots' <- shrinkLocalRootsConfig newRoots
         ]
      -- the public roots play no part
      ++ [ ( roots { mockPublicRootPeers       = Map.empty
                   , mockPublicRootPeersDNSMap = singletonScript Map.empty }
           , newRoots, ipOnly )
         | not (Map.null (mockPublicRootPeers roots))
         ]
      where
        keysOf :: LocalRootsConfig -> Set RelayAccessPoint
        keysOf conf = Set.fromList (concatMap (Map.keys . entriesOf) conf)

        without :: Set RelayAccessPoint -> LocalRootsConfig -> LocalRootsConfig
        without removed = map (\(h, w, m) -> (h, w, m `Map.withoutKeys` removed))

    -- the new groups are the old ones with groups or entries left out
    removalOf :: LocalRootsConfig -> LocalRootsConfig -> Bool
    removalOf [] _ = True
    removalOf _ [] = False
    removalOf new@((h, w, m) : new') ((h', w', m') : old')
      | h == h', w == w', m `Map.isSubmapOf` m' = removalOf new' old'
      | otherwise                               = removalOf new old'

    -- the addresses a relay access point can stand for, in any step of the
    -- DNS script
    resolvable :: NonEmpty MockDNSMap -> RelayAccessPoint -> Set SockAddr
    resolvable dnsMaps = \case
      RelayAccessAddress ip port -> Set.singleton (toSockAddr (ip, port))
      RelayAccessDomain d port   -> aRecords dnsMaps d port
      RelayAccessSRVDomain d     ->
        Set.unions [ aRecords dnsMaps d' port
                   | dnsMap <- NonEmpty.toList dnsMaps
                   , Just (Right srvs) <- [Map.lookup (d, DNS.SRV) dnsMap]
                   , (d', _, _, port) <- srvs
                   ]

    aRecords :: NonEmpty MockDNSMap -> DNS.Domain -> PortNumber -> Set SockAddr
    aRecords dnsMaps d port =
      Set.fromList [ toSockAddr (ip, port)
                   | dnsMap <- NonEmpty.toList dnsMaps
                   , Just (Left ips) <- [Map.lookup (d, DNS.A) dnsMap]
                   , (ip, _) <- ips
                   ]

    -- the addresses each group may hold, with the configurations each may
    -- have, when only the domains 'resolved' admits have contributed
    allowedBy :: NonEmpty MockDNSMap
              -> (RelayAccessPoint -> Bool)
              -> (HotValency, WarmValency, Map RelayAccessPoint (LocalRootConfig ()))
              -> Map SockAddr [LocalRootConfig ()]
    allowedBy dnsMaps resolved (_, _, m) =
      Map.fromListWith (++) [ (a, [c])
                            | (rap, c) <- Map.toList m
                            , isRelayAccessAddress rap || resolved rap
                            , a <- Set.toList (resolvable dnsMaps rap)
                            ]

    -- the first way the published groups differ from those of the new
    -- configuration, if any
    discrepancy :: LocalRootsConfig
                -> [Map SockAddr [LocalRootConfig ()]]
                -> [(HotValency, WarmValency, Map SockAddr (LocalRootConfig ()))]
                -> Maybe String
    discrepancy conf allowed groups
      | map targetsOf groups /= map targetsOf conf
      = Just ("groups or targets differ: " ++ show groups)
      | otherwise
      = listToMaybe (concat (zipWith3 group conf allowed groups))
      where
        group :: (HotValency, WarmValency, Map RelayAccessPoint (LocalRootConfig ()))
              -> Map SockAddr [LocalRootConfig ()]
              -> (HotValency, WarmValency, Map SockAddr (LocalRootConfig ()))
              -> [String]
        group (_, _, m) ok (_, _, pm) =
             [ show a ++ " missing or misconfigured in " ++ show pm
             | (RelayAccessAddress ip port, c) <- Map.toList m
             , let a = toSockAddr (ip, port)
             , Map.lookup a pm /= Just c
             ]
          ++ [ show (a, c) ++ " is not from the configuration " ++ show m
             | (a, c) <- Map.toList pm
             , c `notElem` Map.findWithDefault [] a ok
             ]

    targetsOf :: (HotValency, WarmValency, entries) -> (HotValency, WarmValency)
    targetsOf (h, w, _) = (h, w)

    entriesOf :: (HotValency, WarmValency, entries) -> entries
    entriesOf (_, _, m) = m

-- | The provider publishes the IP addresses of its configuration before it
-- sets up a DNS resolver, so they are in place even if that fails: at
-- startup, or, when the first set-up succeeds, at a reload to a
-- configuration without domain names after 'reloadDelay'.
prop_local_publishesBeforeResolver :: MockRoots -> MockRoots -> Bool -> Property
prop_local_publishesBeforeResolver (MockRoots localRoots (Script dnsMaps) _ _)
                                   (MockRoots newRoots _ _ _)
                                   atReload =
    classify (atReload && newRoots' /= localRoots) "the set-up fails at a reload" $
    case runSim sim of
      Left failure -> counterexample (show failure) False
      Right groups -> groups === addressesOf (if atReload then newRoots' else localRoots)
  where
    newRoots' :: LocalRootsConfig
    newRoots' = ipEntriesOnly newRoots

    addressesOf :: LocalRootsConfig -> LocalRootGroups
    addressesOf conf = [ (h, w, ipAddressesOf m) | (h, w, m) <- conf ]

    sim :: IOSim s [(HotValency, WarmValency, Map SockAddr (LocalRootConfig ()))]
    sim = do
      dnsMapVar <- newTVarIO (NonEmpty.head dnsMaps)
      timeouts  <- initScript' (singletonScript (DNSTimeout 10))
      delays    <- initScript' (singletonScript (DNSLookupDelay 0))
      confVar   <- newTVarIO localRoots
      resultVar <- newTVarIO []
      let mock = mockDNSActions nullTracer LookupReqAOnly (curry toSockAddr)
                                dnsMapVar timeouts delays
          actions = mock {
            dnsAsyncResolverResource = \conf -> do
              -- the set-up fails at startup, or under the new configuration
              conf' <- readTVarIO confVar
              if not atReload || conf' == newRoots'
                then throwIO (userError "no resolver")
                else dnsAsyncResolverResource mock conf
          }
      withAsync (when atReload $ do
                   threadDelay reloadDelay
                   atomically (writeTVar confVar newRoots')) $ \_ ->
        void $ MonadTimer.timeout (reloadDelay + 100) $
          try @_ @IOException $
            localRootPeersProvider nullTracer
                                   PeerActionsDNS { paToPeerAddr = curry toSockAddr,
                                                    paDnsActions = actions }
                                   DNSResolver.defaultResolvConf
                                   (mkStdGen 0)
                                   (readTVar confVar)
                                   resultVar
      readTVarIO resultVar

-- | The groups the provider published, one write at a time.
newtype Published = Published [(HotValency, WarmValency, Map SockAddr (LocalRootConfig ()))]

-- | The 'localRootPeersProvider' should preserve the local root peers
-- group number and respective targets. This property tests whether local
-- root peer groups update due to DNS resolution results, does not alter
-- the initial groups configuration.
--
prop_local_preservesGroupNumberAndTargets :: MockRoots
                                          -> Script DNSTimeout
                                          -> Script DNSLookupDelay
                                          -> TestSeed
                                          -> Property
prop_local_preservesGroupNumberAndTargets mockRoots@(MockRoots lrp _ _ _)
                                          dnsTimeoutScript
                                          dnsLookupDelayScript
                                          dnsSeed =
    let tr = selectLocalRootGroupsEvents
           $ selectLocalRootPeersWithDNSEvents
           $ runSimTrace
           $ mockLocalRootPeersProvider tracerTraceLocalRoots
                                        mockRoots
                                        Nothing
                                        dnsTimeoutScript
                                        dnsLookupDelayScript
                                        dnsSeed

        -- For all LocalRootGroup results, the number of groups should be
        -- preserved, i.e. no new groups are added nor deleted along the
        -- trace by localRootPeersProvider.
        preservesGroupNumber = all ((== length lrp) . length . snd) tr

        -- For all LocalRootGroup results, the targets for each group
        -- should be preserved, i.e. targets are not modified along the
        -- trace by localRootPeersProvider.
        preservesTargets     = all (all (\((a, b, _), (a', b', _)) -> a == a' && b == b'))
                                   [ zip lrp r | r <- map snd tr ]

     in label (show $ length tr `div` 100 * 100) $
        preservesGroupNumber .&&. preservesTargets

-- | The 'localRootPeersProvider' should be able to resolve DNS domains
-- correctly, assuming the domain maps to any IP address. This property
-- tests whether 'localRootPeersProvider' is capable of eventually resolving
-- domain addresses even after having failed to do so in the first attempt.
--
prop_local_resolvesDomainsCorrectly :: MockRoots
                                    -> Script DNSTimeout
                                    -> Script DNSLookupDelay
                                    -> TestSeed
                                    -> Property
prop_local_resolvesDomainsCorrectly mockRoots@(MockRoots localRoots lDNSMap _ _)
                                    dnsTimeoutScript
                                    dnsLookupDelayScript
                                    dnsSeed =
    let mockRoots' =
          mockRoots { mockLocalRootPeersDNSMap =
                        singletonScript (scriptHead lDNSMap)
                    }
        tr = selectLocalRootPeersWithDNSEvents
           $ runSimTrace
           $ mockLocalRootPeersProvider tracerTraceLocalRoots
                                        mockRoots'
                                        Nothing
                                        dnsTimeoutScript
                                        dnsLookupDelayScript
                                        dnsSeed

        -- local root domains
        localRootDomains :: Set (DNS.Domain, DNS.TYPE)
        localRootDomains =
          Set.fromList
          [ item
          | (_, _, m) <- localRoots
          , item <- flip mapMaybe (Map.keys m) \case
              RelayAccessDomain d _p -> Just (d, DNS.A)
              RelayAccessSRVDomain d -> Just (d, DNS.SRV)
              _otherwise -> Nothing
          ]

        -- domains that were resolved during simulation
        resultMap :: Set (DNS.Domain, DNS.TYPE)
        resultMap = Set.fromList
                  . mapMaybe (filtering . snd)
                  . selectDnsResultEvents
                  $ tr
          where
            filtering = \case
              DNSLookupResult _ domain Nothing _ -> Just (domain, DNS.A)
              DNSLookupResult _ _ (Just domain) _ -> Just (domain, DNS.SRV)
              _otherwise -> Nothing

        -- all domains that could have been resolved in each script
        maxResultMap :: Script (Set (DNS.Domain, DNS.TYPE))
        maxResultMap = Map.keysSet
                       . (`Map.restrictKeys` localRootDomains)
                       <$> lDNSMap

        -- all domains that were tried to resolve during the simulation
        allTriedDomains :: Set (DNS.Domain, DNS.TYPE)
        allTriedDomains = Set.fromList
                        . map filtering
                        . mapMaybe (selectDnsTraces . snd)
                        $ tr
          where
            filtering = \case
              DNSLookupResult _ domain Nothing _ -> (domain, DNS.A)
              DNSLookupResult _ _ (Just domain) _ -> (domain, DNS.SRV)
              DNSLookupError _ Nothing srvDomain _ -> (srvDomain, DNS.SRV)
              DNSLookupError _ (Just _) domain _ -> (domain, DNS.A)
              SRVLookupResult _ domain _ -> (domain, DNS.A)
              SRVLookupError _ domain -> (domain, DNS.SRV)
            selectDnsTraces = \case
              Right trace -> Just trace
              Left  _ -> Nothing
    in
      -- we verify that we tried to resolve all local root domains, and that the
      -- resolved ones are a subset of `maxResultMap`
           counterexample ("violation: localRootDomains isSubsetOf allTriedDomains\nlocalRootDomains: "
                           <> show localRootDomains
                           <> "\nallTriedDomains: " <> show allTriedDomains) $
           localRootDomains `Set.isSubsetOf` allTriedDomains
      .&&. foldr (\rm r -> counterexample (show resultMap ++ " is subset of "
                                     ++ show rm)
                          (resultMap `Set.isSubsetOf` rm)
                        .&&. r
                 )
                 (property True)
                 maxResultMap


-- | The 'localRootPeersProvider' after resolving a DNS domain address
-- should update the local result group list correctly, i.e. add the
-- resolved ip addresses to the correct group where the domain address was
-- (in the initial configuration specification). This property tests whether
-- after a successful DNS lookup the result list is updated correctly.
--
-- Correctly means: Updates in the right place and does not overwrite the
-- previous state.
--
prop_local_updatesDomainsCorrectly :: MockRoots
                                   -> Script DNSTimeout
                                   -> Script DNSLookupDelay
                                   -> TestSeed
                                   -> Property
prop_local_updatesDomainsCorrectly mockRoots@(MockRoots lrp _ _ _)
                                   dnsTimeoutScript
                                   dnsLookupDelayScript
                                   dnsSeed =
    let tr = selectLocalRootPeersWithDNSEvents
           $ runSimTrace
           $ mockLocalRootPeersProvider tracerTraceLocalRoots
                                        mockRoots
                                        Nothing
                                        dnsTimeoutScript
                                        dnsLookupDelayScript
                                        dnsSeed

        r = Foldable.foldl' (\(b, (t, x)) (t', y) ->
                    case (x, y) of
                      -- Last result groups value, Current result groups value
                      (Left (TraceLocalRootGroups lrpg), Left (TraceLocalRootGroups lrpg')) ->
                        let -- Get all IPs present in last group at position
                            -- 'index'
                            ipsAtIndex = Map.keys
                                       $ foldMap thrd lrpg

                            -- Get all IPs present in current group at position
                            -- 'index'
                            ipsAtIndex' = Map.keys
                                        $ foldMap thrd lrpg'

                            arePreserved = all (`elem` ipsAtIndex') ipsAtIndex

                         in (arePreserved && b, (t', y))
                      -- Last DNS lookup result   , Current result groups value
                      (Right (DNSLookupResult _ dFollow dSRV ipsttls@(ipttl : _)), Left (TraceLocalRootGroups lrpg)) ->
                        -- create and index db for each group
                        let rap =
                              case dSRV of
                                Just dSRV' -> RelayAccessSRVDomain dSRV'
                                Nothing    -> RelayAccessDomain dFollow (port ipttl)

                            db = zip [0,1..] lrp
                            -- since our MockRoots generator generates
                            -- unique domain addresses we can look for
                            -- which group index does a particular domain
                            -- address belongs
                            index = foldr (\(i, (_, _, m)) prev ->
                                            case Map.lookup rap m of
                                              Nothing -> prev
                                              Just _  -> i
                                          ) (-1) db
                            -- Get all IPs present in group at position
                            -- 'index'
                            ipsAtIndex = map (\sockAddr ->
                                             case sockAddr of
                                               SockAddrInet _ hostAddr
                                                 -> IPv4 $ fromHostAddress hostAddr
                                               _ -> error $ show sockAddr --error "Impossible happened!"

                                         ) $ Map.keys
                                           $ thrd
                                           $ lrpg !! index :: [IP]
                            -- Check if all ips from the previous DNS
                            -- lookup result are present in the current
                            -- result group at the correct index
                            arePresent = all ((`elem` ipsAtIndex) . ip) ipsttls
                         in (arePresent && b, (t', y))
                      -- the empty DNS result trivially passes
                      (Right (DNSLookupResult _ _ _ []), Left (TraceLocalRootGroups {})) ->
                        (b, (t', y))
                      (Right {}, _) -> (b, (t, x))
                      (_, _)        -> (b, (t', y))
                   )
              (True, head tr)
              (tail tr)
     in property (fst r)
  where
    thrd (_, _, c) = c
    port (_, it, _) = it
    ip   (it, _, _) = it

--
-- Public Root Peers Provider Tests
--

-- | Delay and timeout script which make sure that eventually the dns lookup
-- will not timeout.
--
data DelayAndTimeoutScripts = DelayAndTimeoutScripts
       (Script DNSLookupDelay)
       (Script DNSTimeout)
    deriving Show

fixupDelayAndTimeoutScripts :: DelayAndTimeoutScripts
                            -> DelayAndTimeoutScripts
fixupDelayAndTimeoutScripts (DelayAndTimeoutScripts lookupScript@(Script delays)
                                                    timeoutScript@(Script timeouts)) =
      let lastTimeout :: DiffTime
          lastTimeout = getDNSTimeout $ NonEmpty.last timeouts

          lookupScript' =
            if getDNSLookupDelay (NonEmpty.last delays) >= lastTimeout
              then Script (delays <> (DNSLookupDelay (lastTimeout / 2) :| []))
              else lookupScript

      in DelayAndTimeoutScripts lookupScript' timeoutScript

instance Arbitrary DelayAndTimeoutScripts where
    arbitrary = fmap fixupDelayAndTimeoutScripts
              $ DelayAndTimeoutScripts
                  <$> arbitrary
                  <*> arbitrary

    shrink (DelayAndTimeoutScripts lookupScript timeoutScript) =
      [ fixupDelayAndTimeoutScripts
          (DelayAndTimeoutScripts lookupScript timeoutScript')
      | timeoutScript' <- shrink timeoutScript
      ]
      ++
      [ fixupDelayAndTimeoutScripts
          (DelayAndTimeoutScripts lookupScript' timeoutScript)
      | lookupScript' <- shrink lookupScript
      ]



-- | The 'publicRootPeersProvider' should be able to resolve DNS domains
-- correctly, assuming the domain maps to any IP address. This property
-- tests whether 'publicRootPeersProvider' is capable of eventually resolving domain
-- addresses even after having failed to do so in the first attempt, in
-- a bounded amount of time.
--
prop_public_resolvesDomainsCorrectly :: MockRoots
                                     -> DelayAndTimeoutScripts
                                     -> Int
                                     -> TestSeed
                                     -> Property
prop_public_resolvesDomainsCorrectly
    mockRoots@(MockRoots _ _ _ pDNSMap)
    (DelayAndTimeoutScripts dnsLookupDelayScript dnsTimeoutScript)
    n
    dnsSeed
  =
    let pDNSMap' = scriptHead pDNSMap
        mockPublicRootPeersDNSMap = singletonScript pDNSMap'
        mockRoots' =
          mockRoots { mockPublicRootPeersDNSMap }
        tr = runSimTrace
           $ mockPublicRootPeersProvider tracerTracePublicRoots
                                         mockRoots'
                                         dnsTimeoutScript
                                         dnsLookupDelayScript
                                         dnsSeed
                                         ($ n)

        successes = selectDnsResultEvents @TracePublicRootPeers
                  . selectTestTraceEvents
                  $ tr

        successes' = map snd successes

        step :: DNSTrace -> Property -> Property
        step (DNSLookupResult _ "" (Just srvDomain) []) r =
          counterexample "SRV record not found in mock lookup map" $
            Map.member (srvDomain, DNS.SRV) pDNSMap' .&&. r
        step (DNSLookupResult _ domain srvDomain ipsttls) r =
          case srvDomain of
            Nothing ->
               counterexample "DNS.A IP mismatch error" $
                 (fromLookup === fromTrace) .&&. r
               where
                 fromLookup =
                  fst <$> fromLeft (error e) (pDNSMap' Map.! (domain, DNS.A))
                 e = "Domain " <> show domain <> " not found in lookup map"
                 fromTrace = ip <$> ipsttls
            Just srvDomain' ->
              counterexample "SRV lookup error" $
                case Map.lookup (srvDomain', DNS.SRV) pDNSMap' of
                  Nothing -> property False
                  Just (Left {}) -> property False
                  Just (Right ds) ->
                    case find ((domain ==) . dFollow) ds of
                      Nothing -> property False
                      Just (d, _, _, _) ->
                        counterexample "IP mismatch" $
                          fromLookup === fromTrace .&&. r
                        where
                          fromLookup =
                            fst <$> fromLeft (error err) (pDNSMap' Map.! (d, DNS.A))
                          err = "Domain " <> show d <> " from SRV lookup of " <> show srvDomain'
                                <> " not found."
                          fromTrace = ip <$> ipsttls

        step (SRVLookupResult _ domain _) r =
          Map.member (domain, DNS.SRV) pDNSMap' .&&. r
        step _ _ = error "impossible!"
     in
       foldr step (property True) successes'
  where
    ip (it, _, _) = it
    dFollow (it, _, _, _) = it



-- | Create a resource from a list.
--
-- Invariant: the resource fails if it is run more than the number of items.
--
listResource :: forall e m a. Monad m
             => Tracer m a
             -> [Either e a] -> Resource m (Either e a)
listResource tracer = fix go
  where
    go :: ([Either e a] -> Resource m (Either e a))
       -> ([Either e a] -> Resource m (Either e a))
    go _this [] = error "listResource: invariant vaiolation"
    go this (a@(Right x) : as) = Resource $ do
      traceWith tracer x
      pure (a, this as)
    go this (a@Left {}: as) = Resource $
      pure (a, this as)


-- | Verify retryResource
--
prop_retryResource :: NonEmptyList DNSTimeout -> [Either Int Int] -> Property
prop_retryResource (NonEmpty delays0) as =
    counterexample (ppTrace trace) $
    selectTraceEventsDynamic trace /= model delays as
  where
    delays :: NonEmpty DiffTime
    delays = getDNSTimeout <$> NonEmpty.fromList delays0

    tracer :: Tracer (IOSim s) Int
    tracer = mkTracer (\a -> getMonotonicTime >>= \t -> traceM (t, a))
          <> mkTracer (\a -> getMonotonicTime >>= \t -> say (show (t, a)))

    resource :: Resource (IOSim s) Int
    resource = retryResource nullTracer delays
             $ listResource tracer as

    sim :: IOSim s [Int]
    sim = run (length (rights as)) resource
      where
        run :: Int -> Resource (IOSim s) Int -> IOSim s [Int]
        run = go []
          where
            go xs n _ | n <= 0 = return (reverse xs)
            go xs n r = do
              (x, r') <- withResource r
              go (x : xs) (pred n) r'


    trace = runSimTrace sim

    -- pure model of `retryResource`
    model :: NonEmpty DiffTime -> [Either Int Int] -> [(Time, Int)]
    model ds0 = go (Time 0) [] ds0
      where
        dropHead :: forall x. NonEmpty x -> NonEmpty x
        dropHead xs@(_ :| [])  = xs
        dropHead (_ :| x : xs) = x :| xs

        go :: Time
           -- ^ current time
           -> [(Time, Int)]
           -- ^ results
           -> NonEmpty DiffTime
           -- ^ delays stack
           -> [Either Int Int]
           -> [(Time, Int)]
        go _t r _ds [] = reverse r
        go t r ds (Left _ : xs) =
          -- lefts cause delay
          go (NonEmpty.head ds `addTime` t)
             r
             (dropHead ds)
             xs
        go t r _ds (Right x : xs) =
          -- rights do not take time
          go t ((t, x) : r) ds0 xs

ex :: (MonadLabelledSTM m, MonadTimer m, MonadTraceSTM m, MonadSay m) => m ()
ex = do
    d <- registerDelay 1
    LazySTM.labelTVarIO d "delayVar"
    LazySTM.traceTVarIO d (\_ a -> pure (TraceString (show a)))
    atomically (LazySTM.readTVar d >>= check)
    say "Sink me!"
