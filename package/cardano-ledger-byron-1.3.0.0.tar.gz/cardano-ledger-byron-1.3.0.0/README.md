# cardano-ledger

This package contains the validation rules for the Cardano Ledger. The rules
define state transition systems that describe how to validate new blocks and
transaction, and how to extend the ledger. They are an implementation of the
formal specification defined in
[`cardano-ledger`](https://github.com/intersectmbo/cardano-ledger).
