# Revision history for cardano-ledger-dijkstra

## 0.1.0.0

* First version. Released on an unsuspecting world.
