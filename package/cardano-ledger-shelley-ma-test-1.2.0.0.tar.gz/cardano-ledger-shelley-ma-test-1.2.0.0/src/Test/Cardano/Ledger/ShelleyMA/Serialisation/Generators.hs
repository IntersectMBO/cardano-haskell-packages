module Test.Cardano.Ledger.ShelleyMA.Serialisation.Generators (
  sizedTimelock,
  maxTimelockDepth,
) where

import Test.Cardano.Ledger.Allegra.Arbitrary (
  maxTimelockDepth,
  sizedTimelock,
 )
