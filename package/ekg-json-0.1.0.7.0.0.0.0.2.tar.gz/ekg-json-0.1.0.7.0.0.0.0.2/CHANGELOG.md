# EKG-json Changelog

# Changelog entries

## 0.1.1.0 (2023-11-13)

 * GHC 9.8 support.

## 0.1.0.6 (2017-07-31)

 * GHC 8.2 support.

## 0.1.0.5 (2017-04-19)

 * Support aeson 1.2.

## 0.1.0.3 (2016-09-14)

 * Support aeson 1.0.

## 0.1.0.2 (2016-05-28)

 * GHC 8.0 support.
