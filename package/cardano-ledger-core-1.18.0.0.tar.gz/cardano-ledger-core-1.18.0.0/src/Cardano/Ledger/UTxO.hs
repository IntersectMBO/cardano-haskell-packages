module Cardano.Ledger.UTxO
  {-# DEPRECATED "Use `Cardano.Ledger.State` instead" #-} (
  module Cardano.Ledger.State.UTxO,
) where

import Cardano.Ledger.State.UTxO
