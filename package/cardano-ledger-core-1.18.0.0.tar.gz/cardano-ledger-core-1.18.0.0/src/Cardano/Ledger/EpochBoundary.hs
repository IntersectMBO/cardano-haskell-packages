module Cardano.Ledger.EpochBoundary
  {-# DEPRECATED "Use `Cardano.Ledger.State` instead" #-} (
  module Cardano.Ledger.State.SnapShots,
) where

import Cardano.Ledger.State.SnapShots
