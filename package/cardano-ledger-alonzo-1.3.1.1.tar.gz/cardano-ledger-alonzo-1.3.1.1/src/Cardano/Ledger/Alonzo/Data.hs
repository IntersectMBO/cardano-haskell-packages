module Cardano.Ledger.Alonzo.Data
  {-# DEPRECATED "This module has been split into two `Cardano.Ledger.Alonzo.TxAuxData` and `Cardano.Ledger.Alonzo.Scripts.Data`" #-} (
  module X,
)
where

import Cardano.Ledger.Alonzo.Scripts.Data as X
import Cardano.Ledger.Alonzo.TxAuxData as X
