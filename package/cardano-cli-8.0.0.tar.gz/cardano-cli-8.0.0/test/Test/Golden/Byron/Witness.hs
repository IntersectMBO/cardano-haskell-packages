{-# LANGUAGE OverloadedStrings #-}

module Test.Golden.Byron.Witness
  ( golden_byronWitness
  ) where

import           Hedgehog (Property)

{- HLINT ignore "Use camelCase" -}

golden_byronWitness :: Property
golden_byronWitness = error "TODO"
