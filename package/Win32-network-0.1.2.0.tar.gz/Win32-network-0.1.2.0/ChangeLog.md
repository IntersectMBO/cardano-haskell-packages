# Revision history for Win32-named-pipes

## 0.1.2.0

* Support GHC-9.{8,10,12}, support `Win32` `>=2.14` and `<2.14`.

## 0.1.1.1

* Relaxed bounds of bytestring package.

## 0.1.1.0

* Support `ghc-9.2` and `ghc-9.4`.

## 0.1.0.0  -- YYYY-mm-dd

* First version. Released on an unsuspecting world.
