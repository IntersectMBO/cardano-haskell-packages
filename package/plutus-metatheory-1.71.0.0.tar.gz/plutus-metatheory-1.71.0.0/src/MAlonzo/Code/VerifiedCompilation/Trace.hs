{-# LANGUAGE BangPatterns #-}
{-# LANGUAGE EmptyCase #-}
{-# LANGUAGE EmptyDataDecls #-}
{-# LANGUAGE ExistentialQuantification #-}
{-# LANGUAGE NoMonomorphismRestriction #-}
{-# LANGUAGE OverloadedStrings #-}
{-# LANGUAGE PatternSynonyms #-}
{-# LANGUAGE RankNTypes #-}
{-# LANGUAGE ScopedTypeVariables #-}

{-# OPTIONS_GHC -Wno-overlapping-patterns #-}

module MAlonzo.Code.VerifiedCompilation.Trace where

import MAlonzo.RTE (coe, erased, AgdaAny, addInt, subInt, mulInt,
                    quotInt, remInt, geqInt, ltInt, eqInt, add64, sub64, mul64, quot64,
                    rem64, lt64, eq64, word64FromNat, word64ToNat)
import qualified MAlonzo.RTE
import qualified Data.Text
import qualified MAlonzo.Code.Agda.Builtin.List
import qualified MAlonzo.Code.Agda.Builtin.String
import qualified MAlonzo.Code.Utils

import UntypedPlutusCore.Transform.Certify.Trace
import qualified UntypedPlutusCore.Transform.Certify.Hints as Hints
import qualified Data.List.NonEmptySep as NES
import FFI.CostInfo
-- VerifiedCompilation.Trace.UncertifiedOptTag
d_UncertifiedOptTag_4 = ()
type T_UncertifiedOptTag_4 = UncertifiedOptStage
pattern C_caseOfCaseT_6 = CaseOfCase
pattern C_constantFoldingT_8 = ConstantFolding
pattern C_polyBuiltinT_10 = PolyBuiltin
check_caseOfCaseT_6 :: T_UncertifiedOptTag_4
check_caseOfCaseT_6 = CaseOfCase
check_constantFoldingT_8 :: T_UncertifiedOptTag_4
check_constantFoldingT_8 = ConstantFolding
check_polyBuiltinT_10 :: T_UncertifiedOptTag_4
check_polyBuiltinT_10 = PolyBuiltin
cover_UncertifiedOptTag_4 :: UncertifiedOptStage -> ()
cover_UncertifiedOptTag_4 x
  = case x of
      CaseOfCase -> ()
      ConstantFolding -> ()
      PolyBuiltin -> ()
-- VerifiedCompilation.Trace.CertifiedOptTag
d_CertifiedOptTag_12 = ()
type T_CertifiedOptTag_12 = CertifiedOptStage
pattern C_floatDelayT_14 = FloatDelay
pattern C_forceDelayT_16 = ForceDelay
pattern C_forceCaseDelayT_18 = ForceCaseDelay
pattern C_inlineT_20 = Inline
pattern C_cseT_22 = CSE
pattern C_applyToCaseT_24 = ApplyToCase
pattern C_caseReduceT_26 = CaseReduce
pattern C_letFloatOutT_28 = LetFloatOut
check_floatDelayT_14 :: T_CertifiedOptTag_12
check_floatDelayT_14 = FloatDelay
check_forceDelayT_16 :: T_CertifiedOptTag_12
check_forceDelayT_16 = ForceDelay
check_forceCaseDelayT_18 :: T_CertifiedOptTag_12
check_forceCaseDelayT_18 = ForceCaseDelay
check_inlineT_20 :: T_CertifiedOptTag_12
check_inlineT_20 = Inline
check_cseT_22 :: T_CertifiedOptTag_12
check_cseT_22 = CSE
check_applyToCaseT_24 :: T_CertifiedOptTag_12
check_applyToCaseT_24 = ApplyToCase
check_caseReduceT_26 :: T_CertifiedOptTag_12
check_caseReduceT_26 = CaseReduce
check_letFloatOutT_28 :: T_CertifiedOptTag_12
check_letFloatOutT_28 = LetFloatOut
cover_CertifiedOptTag_12 :: CertifiedOptStage -> ()
cover_CertifiedOptTag_12 x
  = case x of
      FloatDelay -> ()
      ForceDelay -> ()
      ForceCaseDelay -> ()
      Inline -> ()
      CSE -> ()
      ApplyToCase -> ()
      CaseReduce -> ()
      LetFloatOut -> ()
-- VerifiedCompilation.Trace.OptTag
d_OptTag_30 :: ()
d_OptTag_30 = erased
-- VerifiedCompilation.Trace.FloatDelayT
d_FloatDelayT_32 ::
  MAlonzo.Code.Utils.T_Either_6
    T_UncertifiedOptTag_4 T_CertifiedOptTag_12
d_FloatDelayT_32
  = coe MAlonzo.Code.Utils.C_inj'8322'_14 (coe C_floatDelayT_14)
-- VerifiedCompilation.Trace.ForceDelayT
d_ForceDelayT_34 ::
  MAlonzo.Code.Utils.T_Either_6
    T_UncertifiedOptTag_4 T_CertifiedOptTag_12
d_ForceDelayT_34
  = coe MAlonzo.Code.Utils.C_inj'8322'_14 (coe C_forceDelayT_16)
-- VerifiedCompilation.Trace.ForceCaseDelayT
d_ForceCaseDelayT_36 ::
  MAlonzo.Code.Utils.T_Either_6
    T_UncertifiedOptTag_4 T_CertifiedOptTag_12
d_ForceCaseDelayT_36
  = coe MAlonzo.Code.Utils.C_inj'8322'_14 (coe C_forceCaseDelayT_18)
-- VerifiedCompilation.Trace.InlineT
d_InlineT_38 ::
  MAlonzo.Code.Utils.T_Either_6
    T_UncertifiedOptTag_4 T_CertifiedOptTag_12
d_InlineT_38
  = coe MAlonzo.Code.Utils.C_inj'8322'_14 (coe C_inlineT_20)
-- VerifiedCompilation.Trace.CseT
d_CseT_40 ::
  MAlonzo.Code.Utils.T_Either_6
    T_UncertifiedOptTag_4 T_CertifiedOptTag_12
d_CseT_40 = coe MAlonzo.Code.Utils.C_inj'8322'_14 (coe C_cseT_22)
-- VerifiedCompilation.Trace.ApplyToCaseT
d_ApplyToCaseT_42 ::
  MAlonzo.Code.Utils.T_Either_6
    T_UncertifiedOptTag_4 T_CertifiedOptTag_12
d_ApplyToCaseT_42
  = coe MAlonzo.Code.Utils.C_inj'8322'_14 (coe C_applyToCaseT_24)
-- VerifiedCompilation.Trace.LetFloatOutT
d_LetFloatOutT_44 ::
  MAlonzo.Code.Utils.T_Either_6
    T_UncertifiedOptTag_4 T_CertifiedOptTag_12
d_LetFloatOutT_44
  = coe MAlonzo.Code.Utils.C_inj'8322'_14 (coe C_letFloatOutT_28)
-- VerifiedCompilation.Trace.CaseReduceT
d_CaseReduceT_46 ::
  MAlonzo.Code.Utils.T_Either_6
    T_UncertifiedOptTag_4 T_CertifiedOptTag_12
d_CaseReduceT_46
  = coe MAlonzo.Code.Utils.C_inj'8322'_14 (coe C_caseReduceT_26)
-- VerifiedCompilation.Trace.CaseOfCaseT
d_CaseOfCaseT_48 ::
  MAlonzo.Code.Utils.T_Either_6
    T_UncertifiedOptTag_4 T_CertifiedOptTag_12
d_CaseOfCaseT_48
  = coe MAlonzo.Code.Utils.C_inj'8321'_12 (coe C_caseOfCaseT_6)
-- VerifiedCompilation.Trace.ConstantFoldingT
d_ConstantFoldingT_50 ::
  MAlonzo.Code.Utils.T_Either_6
    T_UncertifiedOptTag_4 T_CertifiedOptTag_12
d_ConstantFoldingT_50
  = coe MAlonzo.Code.Utils.C_inj'8321'_12 (coe C_constantFoldingT_8)
-- VerifiedCompilation.Trace.PolyBuiltinT
d_PolyBuiltinT_52 ::
  MAlonzo.Code.Utils.T_Either_6
    T_UncertifiedOptTag_4 T_CertifiedOptTag_12
d_PolyBuiltinT_52
  = coe MAlonzo.Code.Utils.C_inj'8321'_12 (coe C_polyBuiltinT_10)
-- VerifiedCompilation.Trace.InlineHints
d_InlineHints_54 = ()
type T_InlineHints_54 = Hints.Inline
pattern C_var_56 = Hints.InlVar
pattern C_expand_58 a0 = Hints.InlExpand a0
pattern C_ƛ_60 a0 = Hints.InlLam a0
pattern C__'183'__62 a0 a1 = Hints.InlApply a0 a1
pattern C__'183''8595'_64 a0 = Hints.InlDrop a0
pattern C_force_66 a0 = Hints.InlForce a0
pattern C_delay_68 a0 = Hints.InlDelay a0
pattern C_con_70 = Hints.InlCon
pattern C_builtin_72 = Hints.InlBuiltin
pattern C_error_74 = Hints.InlError
pattern C_constr_76 a0 = Hints.InlConstr a0
pattern C_case_78 a0 a1 = Hints.InlCase a0 a1
check_var_56 :: T_InlineHints_54
check_var_56 = Hints.InlVar
check_expand_58 :: T_InlineHints_54 -> T_InlineHints_54
check_expand_58 = Hints.InlExpand
check_ƛ_60 :: T_InlineHints_54 -> T_InlineHints_54
check_ƛ_60 = Hints.InlLam
check__'183'__62 ::
  T_InlineHints_54 -> T_InlineHints_54 -> T_InlineHints_54
check__'183'__62 = Hints.InlApply
check__'183''8595'_64 :: T_InlineHints_54 -> T_InlineHints_54
check__'183''8595'_64 = Hints.InlDrop
check_force_66 :: T_InlineHints_54 -> T_InlineHints_54
check_force_66 = Hints.InlForce
check_delay_68 :: T_InlineHints_54 -> T_InlineHints_54
check_delay_68 = Hints.InlDelay
check_con_70 :: T_InlineHints_54
check_con_70 = Hints.InlCon
check_builtin_72 :: T_InlineHints_54
check_builtin_72 = Hints.InlBuiltin
check_error_74 :: T_InlineHints_54
check_error_74 = Hints.InlError
check_constr_76 ::
  MAlonzo.Code.Agda.Builtin.List.T_List_10 () T_InlineHints_54 ->
  T_InlineHints_54
check_constr_76 = Hints.InlConstr
check_case_78 ::
  T_InlineHints_54 ->
  MAlonzo.Code.Agda.Builtin.List.T_List_10 () T_InlineHints_54 ->
  T_InlineHints_54
check_case_78 = Hints.InlCase
cover_InlineHints_54 :: Hints.Inline -> ()
cover_InlineHints_54 x
  = case x of
      Hints.InlVar -> ()
      Hints.InlExpand _ -> ()
      Hints.InlLam _ -> ()
      Hints.InlApply _ _ -> ()
      Hints.InlDrop _ -> ()
      Hints.InlForce _ -> ()
      Hints.InlDelay _ -> ()
      Hints.InlCon -> ()
      Hints.InlBuiltin -> ()
      Hints.InlError -> ()
      Hints.InlConstr _ -> ()
      Hints.InlCase _ _ -> ()
-- VerifiedCompilation.Trace.InlineHints⁺
d_InlineHints'8314'_82 a0 = ()
type T_InlineHints'8314'_82 a0 = Hints.InlinePlus a0
pattern C__'8593''7511'_86 a0 = Hints.InlOne a0
pattern C__'10814''91'_'93'__88 a0 a1 a2 = Hints.InlSeq a0 a1 a2
check__'8593''7511'_86 ::
  forall xA. T_InlineHints_54 -> T_InlineHints'8314'_82 xA
check__'8593''7511'_86 = Hints.InlOne
check__'10814''91'_'93'__88 ::
  forall xA.
    T_InlineHints_54 ->
    xA -> T_InlineHints'8314'_82 xA -> T_InlineHints'8314'_82 xA
check__'10814''91'_'93'__88 = Hints.InlSeq
cover_InlineHints'8314'_82 :: Hints.InlinePlus a1 -> ()
cover_InlineHints'8314'_82 x
  = case x of
      Hints.InlOne _ -> ()
      Hints.InlSeq _ _ _ -> ()
-- VerifiedCompilation.Trace.Hints
d_Hints_92 a0 = ()
type T_Hints_92 a0 = Hints.Hints a0
pattern C_inline_96 a0 = Hints.Inline a0
pattern C_none_98 = Hints.NoHints
check_inline_96 ::
  forall xA. T_InlineHints'8314'_82 xA -> T_Hints_92 xA
check_inline_96 = Hints.Inline
check_none_98 :: forall xA. T_Hints_92 xA
check_none_98 = Hints.NoHints
cover_Hints_92 :: Hints.Hints a1 -> ()
cover_Hints_92 x
  = case x of
      Hints.Inline _ -> ()
      Hints.NoHints -> ()
-- VerifiedCompilation.Trace.NonEmptySep
d_NonEmptySep_104 a0 a1 = ()
type T_NonEmptySep_104 a0 a1 = NES.NonEmptySep a0 a1
pattern C_cons_110 a0 a1 a2 = NES.Cons a0 a1 a2
pattern C_singleton_112 a0 = NES.Singleton a0
check_cons_110 ::
  forall xS.
    forall xA.
      xA -> xS -> T_NonEmptySep_104 xS xA -> T_NonEmptySep_104 xS xA
check_cons_110 = NES.Cons
check_singleton_112 ::
  forall xS. forall xA. xA -> T_NonEmptySep_104 xS xA
check_singleton_112 = NES.Singleton
cover_NonEmptySep_104 :: NES.NonEmptySep a1 a2 -> ()
cover_NonEmptySep_104 x
  = case x of
      NES.Cons _ _ _ -> ()
      NES.Singleton _ -> ()
-- VerifiedCompilation.Trace.head
d_head_126 :: T_NonEmptySep_104 AgdaAny AgdaAny -> AgdaAny
d_head_126 v0
  = case coe v0 of
      C_cons_110 v1 v2 v3 -> coe v1
      C_singleton_112 v1 -> coe v1
      _ -> MAlonzo.RTE.mazUnreachableError
-- VerifiedCompilation.Trace.Trace
d_Trace_132 :: () -> ()
d_Trace_132 = erased
-- VerifiedCompilation.Trace.EvalResult
d_EvalResult_136 = ()
type T_EvalResult_136 = EvalResult
pattern C_success_138 a0 a1 = EvalSuccess a0 a1
pattern C_failure_140 a0 a1 a2 = EvalFailure a0 a1 a2
check_success_138 :: Integer -> Integer -> T_EvalResult_136
check_success_138 = EvalSuccess
check_failure_140 ::
  MAlonzo.Code.Agda.Builtin.String.T_String_6 ->
  Integer -> Integer -> T_EvalResult_136
check_failure_140 = EvalFailure
cover_EvalResult_136 :: EvalResult -> ()
cover_EvalResult_136 x
  = case x of
      EvalSuccess _ _ -> ()
      EvalFailure _ _ _ -> ()
