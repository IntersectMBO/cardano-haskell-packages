module Test.Cardano.Ledger.Alonzo.Scripts (
  alwaysSucceeds,
  alwaysFails,
) where

import Test.Cardano.Ledger.Alonzo.Arbitrary (alwaysFails, alwaysSucceeds)
