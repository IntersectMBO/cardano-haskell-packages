{-# LANGUAGE CPP #-}
{-# LANGUAGE DeriveAnyClass #-}
{-# LANGUAGE DeriveGeneric #-}
{-# LANGUAGE DerivingVia #-}
{-# LANGUAGE DisambiguateRecordFields #-}
{-# LANGUAGE FlexibleContexts #-}
{-# LANGUAGE FlexibleInstances #-}
{-# LANGUAGE GeneralizedNewtypeDeriving #-}
{-# LANGUAGE NamedFieldPuns #-}
{-# LANGUAGE Rank2Types #-}
{-# LANGUAGE ScopedTypeVariables #-}
{-# LANGUAGE StandaloneDeriving #-}
{-# LANGUAGE TypeApplications #-}
{-# LANGUAGE TypeFamilies #-}
{-# LANGUAGE UndecidableInstances #-}
{-# OPTIONS_GHC -Wno-orphans -Wno-x-ord-preserving-coercions #-}
#if __GLASGOW_HASKELL__ < 908
{-# OPTIONS_GHC -Wno-unrecognised-warning-flags #-}
#endif

-- | Shelley mempool integration
--
-- TODO nearly all of the logic in this module belongs in cardano-ledger, not
-- ouroboros-consensus; ouroboros-consensus-cardano should just be "glue code".
module Ouroboros.Consensus.Shelley.Ledger.Mempool
  ( GenTx (..)
  , SL.ApplyTxError (..)
  , TxId (..)
  , DijkstraEbMeasure (..)
  , Validated (..)
  , fixedBlockBodyOverhead
  , mkShelleyTx
  , mkShelleyValidatedTx
  , perTxOverhead

    -- * Exported for tests
  , AlonzoMeasure (..)
  , RefScriptSize (..)
  , fromExUnits
  ) where

import qualified Cardano.Crypto.Hash as Hash
import Cardano.Ledger.Allegra (ApplyTxError (AllegraApplyTxError))
import qualified Cardano.Ledger.Allegra.Rules as AllegraEra
import Cardano.Ledger.Alonzo (ApplyTxError (AlonzoApplyTxError))
import Cardano.Ledger.Alonzo.Core
  ( BlockBody
  , TopTx
  , Tx
  , allInputsTxBodyF
  , bodyTxL
  , eraDecoder
  , ppMaxBBSizeL
  , ppMaxBlockExUnitsL
  , sizeTxF
  , txIdTx
  , txSeqBlockBodyL
  , wireSizeTxF
  )
import qualified Cardano.Ledger.Alonzo.Rules as AlonzoEra
import Cardano.Ledger.Alonzo.Scripts
  ( ExUnits
  , ExUnits' (..)
  , pointWiseExUnits
  , unWrapExUnits
  )
import Cardano.Ledger.Alonzo.Tx (AlonzoEraTx (getTotalExUnits))
import qualified Cardano.Ledger.Api as L
import Cardano.Ledger.Babbage (ApplyTxError (BabbageApplyTxError))
import qualified Cardano.Ledger.Babbage.Rules as BabbageEra
import qualified Cardano.Ledger.BaseTypes as L
import Cardano.Ledger.Binary
  ( Annotator (..)
  , DecCBOR (..)
  , EncCBOR (..)
  , FromCBOR (..)
  , FullByteString (..)
  , ToCBOR (..)
  )
import Cardano.Ledger.Conway (ApplyTxError (ConwayApplyTxError))
import qualified Cardano.Ledger.Conway.PParams as SL
import qualified Cardano.Ledger.Conway.Rules as ConwayEra
import qualified Cardano.Ledger.Conway.UTxO as SL
import Cardano.Ledger.Dijkstra (ApplyTxError (DijkstraApplyTxError))
import Cardano.Ledger.Dijkstra.PParams
  ( ppMaxEndorserBlockExUnitsL
  , ppMaxEndorserBlockReferencesSizeL
  , ppMaxEndorserBlockTxsSizeL
  , ppMaxRefScriptSizePerEndorserBlockL
  )
import qualified Cardano.Ledger.Dijkstra.Rules as DijkstraEra
import qualified Cardano.Ledger.Hashes as SL
import Cardano.Ledger.Mary (ApplyTxError (MaryApplyTxError))
import Cardano.Ledger.Plutus.ExUnits (OrdExUnits (..))
import qualified Cardano.Ledger.Shelley.API as SL
import qualified Cardano.Ledger.Shelley.Rules as ShelleyEra
import Cardano.Protocol.Crypto (Crypto)
import Control.Arrow ((+++))
import Control.Monad (guard)
import Control.Monad.Except (Except, liftEither)
import Control.Monad.Identity (Identity (..))
import Data.ByteString.Short (ShortByteString)
import Data.DerivingVia (InstantiatedAt (..))
import Data.Foldable (toList)
import Data.Measure (Measure, zero)
import Data.Typeable (Typeable)
import qualified Data.Validation as V
import Data.Word (Word32)
import GHC.Generics (Generic)
import GHC.Natural (Natural)
import Lens.Micro ((^.))
import Lens.Micro.Extras (view)
import NoThunks.Class (NoThunks (..), allNoThunks)
import Ouroboros.Consensus.Block
import Ouroboros.Consensus.Ledger.Abstract
import Ouroboros.Consensus.Ledger.SupportsMempool
import Ouroboros.Consensus.Ledger.Tables.Utils
import qualified Ouroboros.Consensus.Leios.Types as Leios
import Ouroboros.Consensus.Protocol.Praos (Praos)
import Ouroboros.Consensus.Shelley.Eras
import Ouroboros.Consensus.Shelley.Ledger.Block
import Ouroboros.Consensus.Shelley.Ledger.Ledger
  ( BigEndianTxIn (..)
  , ShelleyLedgerConfig (shelleyLedgerGlobals)
  , Ticked (TickedShelleyLedgerState, tickedShelleyLedgerState)
  , getPParams
  )
import Ouroboros.Consensus.Shelley.Protocol.Abstract (ProtoCrypto)
import Ouroboros.Consensus.Util (ShowProxy (..), coerceMapKeys, coerceSet)
import Ouroboros.Consensus.Util.Condense
import Ouroboros.Network.Block (unwrapCBORinCBOR, wrapCBORinCBOR)
import Ouroboros.Network.SizeInBytes
import Ouroboros.Network.Tx (HasRawTxId (..))

data instance GenTx (ShelleyBlock proto era) = ShelleyTx !SL.TxId !(Tx TopTx era)
  deriving stock Generic

deriving instance ShelleyBasedEra era => NoThunks (GenTx (ShelleyBlock proto era))

deriving instance ShelleyBasedEra era => Eq (GenTx (ShelleyBlock proto era))

instance
  (Typeable era, Typeable proto) =>
  ShowProxy (GenTx (ShelleyBlock proto era))

data instance Validated (GenTx (ShelleyBlock proto era))
  = ShelleyValidatedTx
      !SL.TxId
      !(SL.ValidatedTx era)

-- We cannot use @deriving stock@ or @deriving instance@ for these instances
-- because 'SL.ValidatedTx' wraps 'SL.StAnnTx', a type family whose Dijkstra
-- instance ('DijkstraStAnnTx') contains 'TxInfoResult', which holds function
-- values. Function types admit no 'Show', 'Eq', or 'NoThunks' instances.
-- Instead we write manual instances that either delegate to the underlying
-- transaction (extracted via 'SL.extractValidatedTx') or ignore the
-- validated-tx payload entirely when it is not needed.

instance ShelleyBasedEra era => NoThunks (Validated (GenTx (ShelleyBlock proto era))) where
  showTypeOf _ = "Validated (GenTx (ShelleyBlock proto era))"
  wNoThunks ctxt (ShelleyValidatedTx txid vtx) =
    allNoThunks
      [ wNoThunks ctxt txid
      , wNoThunks ctxt (SL.extractValidatedTx vtx)
      ]

instance ShelleyBasedEra era => Eq (Validated (GenTx (ShelleyBlock proto era))) where
  ShelleyValidatedTx txid1 _ == ShelleyValidatedTx txid2 _ = txid1 == txid2

instance ShelleyBasedEra era => Show (Validated (GenTx (ShelleyBlock proto era))) where
  show (ShelleyValidatedTx txid vtx) =
    "(ShelleyValidatedTx " ++ show txid ++ " " ++ show (SL.extractValidatedTx vtx) ++ ")"

instance
  (Typeable era, Typeable proto) =>
  ShowProxy (Validated (GenTx (ShelleyBlock proto era)))

type instance ApplyTxErr (ShelleyBlock proto era) = SL.ApplyTxError era

-- orphaned instance
instance Typeable era => ShowProxy (SL.ApplyTxError era)

-- | 'txInBlockSize' is used to estimate how many transactions we can grab from
--  the Mempool to put into the block we are going to forge without exceeding
--  the maximum block body size according to the ledger. If we exceed that
--  limit, we will have forged a block that is invalid according to the ledger.
--  We ourselves won't even adopt it, causing us to lose our slot, something we
--  must try to avoid.
--
--  For this reason it is better to overestimate the size of a transaction than
--  to underestimate. The only downside is that we maybe could have put one (or
--  more?) transactions extra in that block.
--
--  As the sum of the serialised transaction sizes is not equal to the size of
--  the serialised block body ('BlockBody') consisting of those transactions
--  (see cardano-node#1545 for an example), we account for some extra overhead
--  per transaction as a safety margin.
--
--  Also see 'perTxOverhead'.
fixedBlockBodyOverhead :: Num a => a
fixedBlockBodyOverhead = 1024

-- | See 'fixedBlockBodyOverhead'.
perTxOverhead :: Num a => a
perTxOverhead = 4

instance
  (ShelleyCompatible proto era, TxLimits (ShelleyBlock proto era)) =>
  LedgerSupportsMempool (ShelleyBlock proto era)
  where
  txInvariant = const True

  applyTx = applyShelleyTx

  reapplyTx = reapplyShelleyTx

  txForgetValidated (ShelleyValidatedTx txid vtx) = ShelleyTx txid (SL.extractValidatedTx vtx)

  getTransactionKeySets (ShelleyTx _ tx) =
    LedgerTables $
      KeysMK $
        coerceSet
          (tx ^. bodyTxL . allInputsTxBodyF)

  mkMempoolApplyTxError _tlst txt =
    ($ txt) <$> mkEraMkMempoolApplyTxError (Proxy @era)

mkShelleyTx ::
  forall era proto. ShelleyBasedEra era => Tx TopTx era -> GenTx (ShelleyBlock proto era)
mkShelleyTx tx = ShelleyTx (txIdTx tx) tx

mkShelleyValidatedTx ::
  forall era proto.
  ShelleyBasedEra era =>
  SL.ValidatedTx era ->
  Validated (GenTx (ShelleyBlock proto era))
mkShelleyValidatedTx vtx = ShelleyValidatedTx txid vtx
 where
  txid = txIdTx (SL.extractValidatedTx vtx)

newtype instance TxId (GenTx (ShelleyBlock proto era)) = ShelleyTxId SL.TxId
  deriving newtype (Eq, Ord, NoThunks)

deriving newtype instance
  Crypto (ProtoCrypto proto) =>
  EncCBOR (TxId (GenTx (ShelleyBlock proto era)))
deriving newtype instance
  (Typeable era, Typeable proto, Crypto (ProtoCrypto proto)) =>
  DecCBOR (TxId (GenTx (ShelleyBlock proto era)))

instance
  (Typeable era, Typeable proto) =>
  ShowProxy (TxId (GenTx (ShelleyBlock proto era)))

instance ShelleyBasedEra era => HasTxId (GenTx (ShelleyBlock proto era)) where
  txId (ShelleyTx i _) = ShelleyTxId i

instance ShelleyBasedEra era => ConvertRawTxId (GenTx (ShelleyBlock proto era)) where
  toRawTxIdHash (ShelleyTxId i) =
    Hash.hashToBytesShort . SL.extractHash . SL.unTxId $ i

instance ShelleyBasedEra era => HasRawTxId (TxId (GenTx (ShelleyBlock proto era))) where
  type RawTxId (TxId (GenTx (ShelleyBlock proto era))) = ShortByteString
  getRawTxId = toRawTxIdHash

instance ShelleyBasedEra era => HasTxs (ShelleyBlock proto era) where
  extractTxs =
    map mkShelleyTx
      . blockBodyToTxList
      . SL.blockBody
      . shelleyBlockRaw
   where
    blockBodyToTxList :: BlockBody era -> [Tx TopTx era]
    blockBodyToTxList blockBody = toList $ blockBody ^. txSeqBlockBodyL

{-------------------------------------------------------------------------------
  Serialisation
-------------------------------------------------------------------------------}

instance ShelleyCompatible proto era => ToCBOR (GenTx (ShelleyBlock proto era)) where
  -- No need to encode the 'TxId', it's just a hash of the 'SL.TxBody' inside
  -- 'SL.Tx', so it can be recomputed.
  toCBOR (ShelleyTx _txid tx) = wrapCBORinCBOR toCBOR tx

instance ShelleyCompatible proto era => FromCBOR (GenTx (ShelleyBlock proto era)) where
  fromCBOR =
    fmap mkShelleyTx $
      unwrapCBORinCBOR $
        eraDecoder @era $
          (. Full) . runAnnotator <$> decCBOR

{-------------------------------------------------------------------------------
  Pretty-printing
-------------------------------------------------------------------------------}

instance ShelleyBasedEra era => Condense (GenTx (ShelleyBlock proto era)) where
  condense (ShelleyTx _ tx) = show tx

instance Condense (GenTxId (ShelleyBlock proto era)) where
  condense (ShelleyTxId i) = "txid: " <> show i

instance ShelleyBasedEra era => Show (GenTx (ShelleyBlock proto era)) where
  show = condense

instance Show (GenTxId (ShelleyBlock proto era)) where
  show = condense

{-------------------------------------------------------------------------------
  Applying transactions
-------------------------------------------------------------------------------}

applyShelleyTx ::
  forall era proto.
  ShelleyBasedEra era =>
  LedgerConfig (ShelleyBlock proto era) ->
  WhetherToIntervene ->
  SlotNo ->
  GenTx (ShelleyBlock proto era) ->
  TickedLedgerState (ShelleyBlock proto era) ValuesMK ->
  Except
    (ApplyTxErr (ShelleyBlock proto era))
    ( TickedLedgerState (ShelleyBlock proto era) DiffMK
    , Validated (GenTx (ShelleyBlock proto era))
    )
applyShelleyTx cfg wti slot (ShelleyTx _ tx) st0 = do
  let st1 :: TickedLedgerState (ShelleyBlock proto era) EmptyMK
      st1 = stowLedgerTables st0

      innerSt :: SL.NewEpochState era
      innerSt = tickedShelleyLedgerState st1

  (mempoolState', vtx) <-
    applyShelleyBasedTx
      (shelleyLedgerGlobals cfg)
      (SL.mkMempoolEnv innerSt slot)
      (SL.mkMempoolState innerSt)
      wti
      tx

  let st' :: TickedLedgerState (ShelleyBlock proto era) DiffMK
      st' =
        trackingToDiffs $
          calculateDifference st0 $
            unstowLedgerTables $
              set theLedgerLens mempoolState' st1

  pure (st', mkShelleyValidatedTx vtx)

reapplyShelleyTx ::
  ShelleyBasedEra era =>
  LedgerConfig (ShelleyBlock proto era) ->
  SlotNo ->
  Validated (GenTx (ShelleyBlock proto era)) ->
  TickedLedgerState (ShelleyBlock proto era) ValuesMK ->
  Except (ApplyTxErr (ShelleyBlock proto era)) (TickedLedgerState (ShelleyBlock proto era) ValuesMK)
reapplyShelleyTx cfg slot vgtx st0 = do
  let st1 = stowLedgerTables st0
      innerSt = tickedShelleyLedgerState st1

  mempoolState' <-
    liftEither $
      SL.reapplyValidatedTx
        (shelleyLedgerGlobals cfg)
        (SL.mkMempoolEnv innerSt slot)
        (SL.mkMempoolState innerSt)
        vtx

  pure $
    unstowLedgerTables $
      set theLedgerLens mempoolState' st1
 where
  ShelleyValidatedTx _txid vtx = vgtx

-- | The lens combinator
set ::
  (forall f. Applicative f => (a -> f b) -> s -> f t) ->
  b ->
  s ->
  t
set lens inner outer =
  runIdentity $ lens (\_ -> Identity inner) outer

theLedgerLens ::
  Functor f =>
  (SL.LedgerState era -> f (SL.LedgerState era)) ->
  TickedLedgerState (ShelleyBlock proto era) mk ->
  f (TickedLedgerState (ShelleyBlock proto era) mk)
theLedgerLens f x =
  (\y -> x{tickedShelleyLedgerState = y})
    <$> SL.overNewEpochState f (tickedShelleyLedgerState x)

{-------------------------------------------------------------------------------
  Tx Limits
-------------------------------------------------------------------------------}

-- | A non-exported newtype wrapper just to give a 'Semigroup' instance
newtype TxErrorSG era = TxErrorSG {unTxErrorSG :: SL.ApplyTxError era}

deriving newtype instance Semigroup (SL.ApplyTxError era) => Semigroup (TxErrorSG era)

validateMaybe ::
  SL.ApplyTxError era ->
  Maybe a ->
  V.Validation (TxErrorSG era) a
validateMaybe err mb = maybe (V.Failure (TxErrorSG err)) V.Success mb

runValidation ::
  V.Validation (TxErrorSG era) a ->
  Except (SL.ApplyTxError era) a
runValidation = liftEither . (unTxErrorSG +++ id) . view V.either

-----

txsMaxBytes ::
  ShelleyCompatible proto era =>
  TickedLedgerState (ShelleyBlock proto era) mk ->
  IgnoringOverflow ByteSize32
txsMaxBytes TickedShelleyLedgerState{tickedShelleyLedgerState} =
  -- `maxBlockBodySize` is expected to be bigger than `fixedBlockBodyOverhead`
  IgnoringOverflow $
    ByteSize32 $
      maxBlockBodySize - fixedBlockBodyOverhead
 where
  maxBlockBodySize = getPParams tickedShelleyLedgerState ^. ppMaxBBSizeL

txInBlockSize ::
  (ShelleyCompatible proto era, MaxTxSizeUTxO era) =>
  TickedLedgerState (ShelleyBlock proto era) mk ->
  GenTx (ShelleyBlock proto era) ->
  V.Validation (TxErrorSG era) (IgnoringOverflow ByteSize32)
txInBlockSize st (ShelleyTx _txid tx') =
  validateMaybe (maxTxSizeUTxO txsz limit) $ do
    guard $ txsz <= limit
    Just $ IgnoringOverflow $ ByteSize32 $ txsz + perTxOverhead
 where
  txsz = tx' ^. sizeTxF

  pparams = getPParams $ tickedShelleyLedgerState st
  limit = pparams ^. L.ppMaxTxSizeL

class MaxTxSizeUTxO era where
  maxTxSizeUTxO ::
    -- | Actual transaction size
    Word32 ->
    -- | Maximum transaction size
    Word32 ->
    SL.ApplyTxError era

instance MaxTxSizeUTxO ShelleyEra where
  maxTxSizeUTxO txSize txSizeLimit =
    SL.ShelleyApplyTxError . pure $
      ShelleyEra.UtxowFailure $
        ShelleyEra.UtxoFailure $
          ShelleyEra.MaxTxSizeUTxO $
            L.Mismatch
              { mismatchSupplied = txSize
              , mismatchExpected = txSizeLimit
              }

instance MaxTxSizeUTxO AllegraEra where
  maxTxSizeUTxO txSize txSizeLimit =
    AllegraApplyTxError . pure $
      ShelleyEra.UtxowFailure $
        ShelleyEra.UtxoFailure $
          AllegraEra.MaxTxSizeUTxO $
            L.Mismatch
              { mismatchSupplied = txSize
              , mismatchExpected = txSizeLimit
              }

instance MaxTxSizeUTxO MaryEra where
  maxTxSizeUTxO txSize txSizeLimit =
    MaryApplyTxError . pure $
      ShelleyEra.UtxowFailure $
        ShelleyEra.UtxoFailure $
          AllegraEra.MaxTxSizeUTxO $
            L.Mismatch
              { mismatchSupplied = txSize
              , mismatchExpected = txSizeLimit
              }

instance MaxTxSizeUTxO AlonzoEra where
  maxTxSizeUTxO txSize txSizeLimit =
    AlonzoApplyTxError . pure $
      ShelleyEra.UtxowFailure $
        AlonzoEra.ShelleyInAlonzoUtxowPredFailure $
          ShelleyEra.UtxoFailure $
            AlonzoEra.MaxTxSizeUTxO $
              L.Mismatch
                { mismatchSupplied = txSize
                , mismatchExpected = txSizeLimit
                }

instance MaxTxSizeUTxO BabbageEra where
  maxTxSizeUTxO txSize txSizeLimit =
    BabbageApplyTxError . pure $
      ShelleyEra.UtxowFailure $
        BabbageEra.UtxoFailure $
          BabbageEra.AlonzoInBabbageUtxoPredFailure $
            AlonzoEra.MaxTxSizeUTxO $
              L.Mismatch
                { mismatchSupplied = txSize
                , mismatchExpected = txSizeLimit
                }

instance MaxTxSizeUTxO ConwayEra where
  maxTxSizeUTxO txSize txSizeLimit =
    ConwayApplyTxError . pure $
      ConwayEra.ConwayUtxowFailure $
        ConwayEra.UtxoFailure $
          ConwayEra.MaxTxSizeUTxO $
            L.Mismatch
              { mismatchSupplied = txSize
              , mismatchExpected = txSizeLimit
              }

instance MaxTxSizeUTxO DijkstraEra where
  maxTxSizeUTxO txSize txSizeLimit =
    DijkstraApplyTxError . pure $
      DijkstraEra.LedgerFailure $
        DijkstraEra.DijkstraUtxowFailure $
          DijkstraEra.UtxoFailure $
            DijkstraEra.MaxTxSizeUTxO $
              L.Mismatch
                { mismatchSupplied = txSize
                , mismatchExpected = txSizeLimit
                }

-----

wrapCBORinCBOROverhead ::
  -- | payload size
  Word32 ->
  SizeInBytes
wrapCBORinCBOROverhead size =
  2 -- wrapCBORinCBOR's encodeTag 24
    + case size of -- upper bound for wrapCBORinCBOR's encodeBytes overhead;
    -- it is bounded by maximum tx size
      _
        | size <= 0x17 -> 1
        | size <= 0xff -> 2
        | size <= 0xffff -> 3
        | otherwise -> 5
    + fromIntegral size

instance ShelleyCompatible p ShelleyEra => TxLimits (ShelleyBlock p ShelleyEra) where
  type TxMeasurePhase1 (ShelleyBlock p ShelleyEra) = IgnoringOverflow ByteSize32
  type TxMeasurePhase2 (ShelleyBlock p ShelleyEra) = TrivialTxMeasurePhase2
  txWireSize (ShelleyTx _ tx) = wrapCBORinCBOROverhead (tx ^. wireSizeTxF)
  txMeasurePhase1 _cfg st tx = runValidation $ txInBlockSize st tx
  txMeasurePhase2 _cfg _st _tx = pure TrivialTxMeasurePhase2
  blockCapacityTxMeasure _cfg = flip TxMeasure TrivialTxMeasurePhase2 . txsMaxBytes

  type TxEbMeasure (ShelleyBlock p ShelleyEra) = TxMeasure (ShelleyBlock p ShelleyEra)

  txEbMeasure _ = id

  ebCapacityTxMeasure _cfg _st = zero
  mempoolEbReservation _ = id

instance ShelleyCompatible p AllegraEra => TxLimits (ShelleyBlock p AllegraEra) where
  type TxMeasurePhase1 (ShelleyBlock p AllegraEra) = IgnoringOverflow ByteSize32
  type TxMeasurePhase2 (ShelleyBlock p AllegraEra) = TrivialTxMeasurePhase2
  txWireSize (ShelleyTx _ tx) = wrapCBORinCBOROverhead (tx ^. wireSizeTxF)
  txMeasurePhase1 _cfg st tx = runValidation $ txInBlockSize st tx
  txMeasurePhase2 _cfg _st _tx = pure TrivialTxMeasurePhase2
  blockCapacityTxMeasure _cfg = flip TxMeasure TrivialTxMeasurePhase2 . txsMaxBytes

  type TxEbMeasure (ShelleyBlock p AllegraEra) = TxMeasure (ShelleyBlock p AllegraEra)

  txEbMeasure _ = id

  ebCapacityTxMeasure _cfg _st = zero
  mempoolEbReservation _ = id

instance ShelleyCompatible p MaryEra => TxLimits (ShelleyBlock p MaryEra) where
  type TxMeasurePhase1 (ShelleyBlock p MaryEra) = IgnoringOverflow ByteSize32
  type TxMeasurePhase2 (ShelleyBlock p MaryEra) = TrivialTxMeasurePhase2
  txWireSize (ShelleyTx _ tx) = wrapCBORinCBOROverhead (tx ^. wireSizeTxF)
  txMeasurePhase1 _cfg st tx = runValidation $ txInBlockSize st tx
  txMeasurePhase2 _cfg _st _tx = pure TrivialTxMeasurePhase2
  blockCapacityTxMeasure _cfg = flip TxMeasure TrivialTxMeasurePhase2 . txsMaxBytes

  type TxEbMeasure (ShelleyBlock p MaryEra) = TxMeasure (ShelleyBlock p MaryEra)

  txEbMeasure _ = id

  ebCapacityTxMeasure _cfg _st = zero
  mempoolEbReservation _ = id

-----

data AlonzoMeasure = AlonzoMeasure
  { byteSize :: !(IgnoringOverflow ByteSize32)
  , exUnits :: !(ExUnits' Natural)
  }
  deriving stock (Eq, Generic, Show)
  deriving anyclass NoThunks
  deriving
    Measure
    via (InstantiatedAt Generic AlonzoMeasure)

instance HasByteSize AlonzoMeasure where
  txMeasureByteSize = unIgnoringOverflow . byteSize

instance Semigroup AlonzoMeasure where
  AlonzoMeasure b1 e1 <> AlonzoMeasure b2 e2 =
    AlonzoMeasure (b1 <> b2) (e1 <> e2)

instance Monoid AlonzoMeasure where
  mappend = (<>)
  mempty = AlonzoMeasure mempty mempty

instance TxMeasurePhase1Metrics AlonzoMeasure where
  txMeasureMetricTxSizeBytes = txMeasureMetricTxSizeBytes . byteSize
  txMeasureMetricExUnitsMemory = exUnitsMem' . exUnits
  txMeasureMetricExUnitsSteps = exUnitsSteps' . exUnits

fromExUnits :: ExUnits -> ExUnits' Natural
fromExUnits = unWrapExUnits

blockCapacityAlonzoMeasure ::
  forall proto era mk.
  (ShelleyCompatible proto era, L.AlonzoEraPParams era) =>
  TickedLedgerState (ShelleyBlock proto era) mk ->
  AlonzoMeasure
blockCapacityAlonzoMeasure ledgerState =
  AlonzoMeasure
    { byteSize = txsMaxBytes ledgerState
    , exUnits = fromExUnits $ pparams ^. ppMaxBlockExUnitsL
    }
 where
  pparams = getPParams $ tickedShelleyLedgerState ledgerState

txMeasureAlonzo ::
  forall proto era.
  ( ShelleyCompatible proto era
  , L.AlonzoEraTx era
  , ExUnitsTooBigUTxO era
  , MaxTxSizeUTxO era
  ) =>
  TickedLedgerState (ShelleyBlock proto era) EmptyMK ->
  GenTx (ShelleyBlock proto era) ->
  V.Validation (TxErrorSG era) AlonzoMeasure
txMeasureAlonzo st tx@(ShelleyTx _txid tx') =
  AlonzoMeasure <$> txInBlockSize st tx <*> exunits
 where
  txsz = getTotalExUnits tx'

  pparams = getPParams $ tickedShelleyLedgerState st
  limit = pparams ^. L.ppMaxTxExUnitsL

  exunits =
    validateMaybe (exUnitsTooBigUTxO txsz limit) $ do
      guard $ pointWiseExUnits (<=) txsz limit
      Just $ fromExUnits txsz

class ExUnitsTooBigUTxO era where
  exUnitsTooBigUTxO :: ExUnits -> ExUnits -> SL.ApplyTxError era

instance ExUnitsTooBigUTxO AlonzoEra where
  exUnitsTooBigUTxO txsz limit =
    AlonzoApplyTxError . pure $
      ShelleyEra.UtxowFailure $
        AlonzoEra.ShelleyInAlonzoUtxowPredFailure $
          ShelleyEra.UtxoFailure $
            AlonzoEra.ExUnitsTooBigUTxO $
              L.Mismatch
                { mismatchSupplied = OrdExUnits txsz
                , mismatchExpected = OrdExUnits limit
                }

instance ExUnitsTooBigUTxO BabbageEra where
  exUnitsTooBigUTxO txsz limit =
    BabbageApplyTxError . pure $
      ShelleyEra.UtxowFailure $
        BabbageEra.AlonzoInBabbageUtxowPredFailure $
          AlonzoEra.ShelleyInAlonzoUtxowPredFailure $
            ShelleyEra.UtxoFailure $
              BabbageEra.AlonzoInBabbageUtxoPredFailure $
                AlonzoEra.ExUnitsTooBigUTxO $
                  L.Mismatch
                    { mismatchSupplied = OrdExUnits txsz
                    , mismatchExpected = OrdExUnits limit
                    }

instance ExUnitsTooBigUTxO ConwayEra where
  exUnitsTooBigUTxO txsz limit =
    ConwayApplyTxError . pure $
      ConwayEra.ConwayUtxowFailure $
        ConwayEra.UtxoFailure $
          ConwayEra.ExUnitsTooBigUTxO $
            L.Mismatch
              { mismatchSupplied = OrdExUnits txsz
              , mismatchExpected = OrdExUnits limit
              }

instance ExUnitsTooBigUTxO DijkstraEra where
  exUnitsTooBigUTxO txsz limit =
    DijkstraApplyTxError . pure $
      DijkstraEra.LedgerFailure $
        DijkstraEra.DijkstraUtxowFailure $
          DijkstraEra.UtxoFailure $
            DijkstraEra.ExUnitsTooBigUTxO $
              L.Mismatch
                { mismatchSupplied = OrdExUnits txsz
                , mismatchExpected = OrdExUnits limit
                }

-----

instance
  ShelleyCompatible p AlonzoEra =>
  TxLimits (ShelleyBlock p AlonzoEra)
  where
  type TxMeasurePhase1 (ShelleyBlock p AlonzoEra) = AlonzoMeasure
  type TxMeasurePhase2 (ShelleyBlock p AlonzoEra) = TrivialTxMeasurePhase2
  txWireSize (ShelleyTx _ tx) = wrapCBORinCBOROverhead (tx ^. wireSizeTxF)
  txMeasurePhase1 _cfg st tx = runValidation $ txMeasureAlonzo st tx
  txMeasurePhase2 _cfg _st _tx = pure TrivialTxMeasurePhase2
  blockCapacityTxMeasure _cfg = flip TxMeasure TrivialTxMeasurePhase2 . blockCapacityAlonzoMeasure

  type TxEbMeasure (ShelleyBlock p AlonzoEra) = TxMeasure (ShelleyBlock p AlonzoEra)

  txEbMeasure _ = id

  ebCapacityTxMeasure _cfg _st = zero
  mempoolEbReservation _ = id

-----

newtype RefScriptSize = RefScriptSize {refScriptsSize :: IgnoringOverflow ByteSize32}
  deriving (Eq, Generic, Show)
  deriving newtype (NoThunks, Measure, Semigroup, Monoid)

instance TxMeasurePhase2Metrics RefScriptSize where
  txMeasureMetricRefScriptsSizeBytes = unIgnoringOverflow . refScriptsSize

blockCapacityConwayMeasure ::
  forall proto era mk.
  ( ShelleyCompatible proto era
  , SL.ConwayEraPParams era
  ) =>
  TickedLedgerState (ShelleyBlock proto era) mk ->
  (AlonzoMeasure, RefScriptSize)
blockCapacityConwayMeasure st =
  ( blockCapacityAlonzoMeasure st
  , RefScriptSize $
      IgnoringOverflow $
        ByteSize32 (pparams ^. SL.ppMaxRefScriptSizePerBlockG)
  )
 where
  pparams = getPParams $ tickedShelleyLedgerState st

txMeasureRefScripts ::
  forall proto era.
  ( ShelleyCompatible proto era
  , L.BabbageEraTxBody era
  , TxRefScriptsSizeTooBig era
  , SL.ConwayEraPParams era
  ) =>
  TickedLedgerState (ShelleyBlock proto era) ValuesMK ->
  GenTx (ShelleyBlock proto era) ->
  V.Validation (TxErrorSG era) RefScriptSize
txMeasureRefScripts st (ShelleyTx _txid tx') =
  RefScriptSize <$> refScriptBytes
 where
  ValuesMK utxo = getLedgerTables $ projectLedgerTables st
  txsz = SL.txNonDistinctRefScriptsSize (SL.UTxO $ coerceMapKeys utxo) tx' :: Int

  pparams = getPParams $ tickedShelleyLedgerState st

  limit = fromIntegral @Word32 @Int (pparams ^. SL.ppMaxRefScriptSizePerTxG)

  refScriptBytes =
    validateMaybe (txRefScriptsSizeTooBig txsz limit) $ do
      guard $ txsz <= limit
      Just $ IgnoringOverflow $ ByteSize32 $ fromIntegral txsz

class TxRefScriptsSizeTooBig era where
  txRefScriptsSizeTooBig :: Int -> Int -> SL.ApplyTxError era

instance TxRefScriptsSizeTooBig ConwayEra where
  txRefScriptsSizeTooBig txsz limit =
    ConwayApplyTxError . pure $
      ConwayEra.ConwayTxRefScriptsSizeTooBig $
        L.Mismatch
          { mismatchSupplied = txsz
          , mismatchExpected = limit
          }

instance TxRefScriptsSizeTooBig DijkstraEra where
  txRefScriptsSizeTooBig txsz limit =
    DijkstraApplyTxError . pure $
      DijkstraEra.LedgerFailure $
        DijkstraEra.DijkstraTxRefScriptsSizeTooBig $
          L.Mismatch
            { mismatchSupplied = txsz
            , mismatchExpected = limit
            }

-- | Measure of transactions in a Dijkstra-era Leios endorser block.
--
-- An endorser block carries references to transactions, while the referenced
-- transactions, its closure, must satisfy block-like limits. So this pairs the
-- closure's 'TxMeasure' with the one dimension specific to endorser blocks:
-- the size of the references themselves.
--
-- The closure type names one protocol, 'Praos' 'StandardCrypto'. The phase
-- measures do not depend on the protocol, so 'txEbMeasureDijkstra' and
-- 'mempoolEbReservation' rebuild the 'TxMeasure' for any protocol.
data DijkstraEbMeasure = DijkstraEbMeasure
  { ebClosureMeasure :: !(TxMeasure (ShelleyBlock (Praos StandardCrypto) DijkstraEra))
  , txReferencesSize :: !(IgnoringOverflow ByteSize32)
  -- ^ Size of transaction references _excluding_ any framing overhead: of one
  -- transaction's reference, or summed over whatever is measured (an endorser
  -- block, a run of mempool transactions).
  }
  deriving stock (Eq, Generic, Show)
  deriving anyclass NoThunks
  deriving
    Measure
    via (InstantiatedAt Generic DijkstraEbMeasure)

-- | The cost of one transaction in an endorser block: its closure cost is the
-- transaction's 'TxMeasure', and its reference costs the bytes
-- 'Leios.encodeLeiosEb' writes for it.
txEbMeasureDijkstra :: TxMeasure (ShelleyBlock p DijkstraEra) -> DijkstraEbMeasure
txEbMeasureDijkstra (TxMeasure alonzo refScripts) =
  DijkstraEbMeasure
    { ebClosureMeasure = TxMeasure alonzo refScripts
    , txReferencesSize =
        IgnoringOverflow . Leios.encodeLeiosEbItemSize $
          txMeasureByteSize alonzo
    }

-- | What one Leios endorser block may hold, from the Dijkstra endorser-block
-- protocol parameters.
leiosEndorserBlockCapacity ::
  forall proto mk.
  TickedLedgerState (ShelleyBlock proto DijkstraEra) mk ->
  DijkstraEbMeasure
leiosEndorserBlockCapacity st =
  DijkstraEbMeasure
    { ebClosureMeasure =
        TxMeasure
          AlonzoMeasure
            { byteSize = IgnoringOverflow $ ByteSize32 $ pparams ^. ppMaxEndorserBlockTxsSizeL
            , exUnits = fromExUnits $ unOrdExUnits $ pparams ^. ppMaxEndorserBlockExUnitsL
            }
          ( RefScriptSize $
              IgnoringOverflow $
                ByteSize32 (pparams ^. ppMaxRefScriptSizePerEndorserBlockL)
          )
    , -- Transactions are charged 'Leios.encodeLeiosEbItemSize' for their
      -- reference and nothing else, so the framing 'Leios.encodeLeiosEb' writes
      -- ahead of them comes off the capacity here.
      --
      -- Nothing checks that an endorser block of this size fits one LeiosFetch
      -- message. That check must come with the LeiosFetch protocol.
      txReferencesSize =
        IgnoringOverflow . ByteSize32 . Leios.leiosReferencesCapacity $
          pparams ^. ppMaxEndorserBlockReferencesSizeL
    }
 where
  pparams = getPParams $ tickedShelleyLedgerState st

-- | We anachronistically use 'ConwayMeasure' in Babbage.
instance
  ShelleyCompatible p BabbageEra =>
  TxLimits (ShelleyBlock p BabbageEra)
  where
  type TxMeasurePhase1 (ShelleyBlock p BabbageEra) = AlonzoMeasure
  type TxMeasurePhase2 (ShelleyBlock p BabbageEra) = TrivialTxMeasurePhase2
  txWireSize (ShelleyTx _ tx) = wrapCBORinCBOROverhead (tx ^. wireSizeTxF)
  txMeasurePhase1 _cfg st tx = runValidation $ txMeasureAlonzo st tx
  txMeasurePhase2 _cfg _st _tx = pure TrivialTxMeasurePhase2
  blockCapacityTxMeasure _cfg = flip TxMeasure TrivialTxMeasurePhase2 . blockCapacityAlonzoMeasure

  type TxEbMeasure (ShelleyBlock p BabbageEra) = TxMeasure (ShelleyBlock p BabbageEra)

  txEbMeasure _ = id

  ebCapacityTxMeasure _cfg _st = zero
  mempoolEbReservation _ = id

instance
  ShelleyCompatible p ConwayEra =>
  TxLimits (ShelleyBlock p ConwayEra)
  where
  type TxMeasurePhase1 (ShelleyBlock p ConwayEra) = AlonzoMeasure
  type TxMeasurePhase2 (ShelleyBlock p ConwayEra) = RefScriptSize
  txWireSize (ShelleyTx _ tx) = wrapCBORinCBOROverhead (tx ^. wireSizeTxF)
  txMeasurePhase1 _cfg st tx = runValidation $ txMeasureAlonzo st tx
  txMeasurePhase2 _cfg st tx = runValidation $ txMeasureRefScripts st tx
  blockCapacityTxMeasure _cfg = uncurry TxMeasure . blockCapacityConwayMeasure

  type TxEbMeasure (ShelleyBlock p ConwayEra) = TxMeasure (ShelleyBlock p ConwayEra)

  txEbMeasure _ = id

  ebCapacityTxMeasure _cfg _st = zero
  mempoolEbReservation _ = id

instance
  ShelleyCompatible p DijkstraEra =>
  TxLimits (ShelleyBlock p DijkstraEra)
  where
  type TxMeasurePhase1 (ShelleyBlock p DijkstraEra) = AlonzoMeasure
  type TxMeasurePhase2 (ShelleyBlock p DijkstraEra) = RefScriptSize
  blockCapacityTxMeasure _cfg = uncurry TxMeasure . blockCapacityConwayMeasure
  txMeasurePhase1 _cfg st tx = runValidation $ txMeasureAlonzo st tx
  txMeasurePhase2 _cfg st tx = runValidation $ txMeasureRefScripts st tx
  txWireSize (ShelleyTx _ tx) = wrapCBORinCBOROverhead (tx ^. wireSizeTxF)

  type TxEbMeasure (ShelleyBlock p DijkstraEra) = DijkstraEbMeasure

  txEbMeasure _ = txEbMeasureDijkstra

  ebCapacityTxMeasure _cfg = leiosEndorserBlockCapacity
  mempoolEbReservation _ DijkstraEbMeasure{ebClosureMeasure = TxMeasure alonzo refScripts} =
    TxMeasure alonzo refScripts
