{-# LANGUAGE FlexibleContexts #-}
{-# LANGUAGE NumericUnderscores #-}
{-# LANGUAGE OverloadedLists #-}
{-# LANGUAGE ScopedTypeVariables #-}
{-# LANGUAGE TypeApplications #-}
{-# LANGUAGE TypeFamilies #-}

module Test.Cardano.Api.Experimental
  ( tests
  )
where

import Cardano.Api qualified as Api
import Cardano.Api.Experimental qualified as Exp
import Cardano.Api.Experimental.Era (convert)
import Cardano.Api.Experimental.Tx qualified as Exp
import Cardano.Api.Genesis qualified as Genesis
import Cardano.Api.Ledger qualified as Ledger
import Cardano.Api.Plutus qualified as Script
import Cardano.Api.Tx (Tx (ShelleyTx))

import Cardano.Ledger.Alonzo.Scripts qualified as UnexportedLedger
import Cardano.Ledger.Api qualified as UnexportedLedger
import Cardano.Slotting.EpochInfo qualified as Slotting
import Cardano.Slotting.Slot qualified as Slotting
import Cardano.Slotting.Time qualified as Slotting

import Control.Monad.Identity (Identity)
import Data.Bifunctor (first)
import Data.Maybe (fromMaybe)
import Data.Ratio ((%))
import Data.Text.Encoding qualified as Text
import Data.Time qualified as Time
import Data.Time.Clock.POSIX qualified as Time
import Lens.Micro ((&))

import Test.Gen.Cardano.Api.Typed (genTx)

import Hedgehog (Gen, Property)
import Hedgehog qualified as H
import Hedgehog.Extras qualified as H
import Hedgehog.Gen qualified as Gen
import Hedgehog.Internal.Property qualified as H
import Test.Tasty (TestTree, testGroup)
import Test.Tasty.Hedgehog (testProperty)

-- | Tests in this module can be run by themselves by writing:
-- ```bash
-- cabal test cardano-api-test --test-options="--pattern=Test.Cardano.Api.Experimental"
-- ```
--
-- IMPORTANT NOTE: If this file requires changes, please update the examples in the
-- documentation in 'cardano-api/src/Cardano/Api/Experimental.hs' too.
tests :: TestTree
tests =
  testGroup
    "Test.Cardano.Api.Experimental"
    [ testProperty
        "Created transaction with traditional and experimental APIs are equivalent"
        prop_created_transaction_with_both_apis_are_the_same
    , testProperty
        "Check two methods of balancing transaction are equivalent"
        prop_balance_transaction_two_ways
    , testProperty
        "Roundtrip SerialiseAsRawBytes UnsignedTx"
        prop_roundtrip_serialise_as_raw_bytes_unsigned_tx
    , testProperty
        "Roundtrip SerialiseAsRawBytes SignedTx"
        prop_roundtrip_serialise_as_raw_bytes_signed_tx
    ]

prop_created_transaction_with_both_apis_are_the_same :: Property
prop_created_transaction_with_both_apis_are_the_same = H.propertyOnce $ do
  let era = Exp.ConwayEra
  let sbe = Api.convert era

  signedTxTraditional <- exampleTransactionTraditionalWay sbe
  signedTxExperimental <- exampleTransactionExperimentalWay era

  let oldStyleTx :: Api.Tx Api.ConwayEra = ShelleyTx sbe signedTxExperimental

  oldStyleTx H.=== signedTxTraditional
 where
  exampleTransactionTraditionalWay
    :: H.MonadTest m
    => Api.ShelleyBasedEra Exp.ConwayEra
    -> m (Tx Exp.ConwayEra)
  exampleTransactionTraditionalWay sbe = do
    txBodyContent <- exampleTxBodyContent sbe
    signingKey <- exampleSigningKey

    txBody <- H.evalEither $ Api.createTransactionBody sbe txBodyContent

    let signedTx :: Api.Tx Api.ConwayEra = Api.signShelleyTransaction sbe txBody [Api.WitnessPaymentKey signingKey]

    return signedTx

  exampleTransactionExperimentalWay
    :: H.MonadTest m
    => Exp.Era Exp.ConwayEra
    -> m (Ledger.Tx (Exp.LedgerEra Exp.ConwayEra))
  exampleTransactionExperimentalWay era = do
    txBodyContent <- exampleTxBodyContentExperimental era
    signingKey <- exampleSigningKey

    let unsignedTx = Exp.makeUnsignedTx era txBodyContent
        witness = Exp.makeKeyWitness era unsignedTx (Api.WitnessPaymentKey signingKey)

    let bootstrapWitnesses = []
        keyWitnesses = [witness]

    let Exp.SignedTx (signedTx :: Ledger.Tx (Exp.LedgerEra Exp.ConwayEra)) = Exp.signTx era bootstrapWitnesses keyWitnesses unsignedTx
    return signedTx

prop_balance_transaction_two_ways :: Property
prop_balance_transaction_two_ways = H.propertyOnce $ do
  let era = Exp.ConwayEra
  let sbe = Api.convert era
  let meo = Api.MaryEraOnwardsConway

  changeAddress <- getExampleChangeAddress sbe
  (txBodyContent, newTxBodyContent) <- exampleOldAndNewStyleTxBodyContent era
  txBody <- H.evalEither $ Api.createTransactionBody sbe txBodyContent

  -- Simple way (fee calculation)
  -- Old API
  let oldFees = Api.evaluateTransactionFee sbe exampleProtocolParams txBody 0 1 0
      -- NEW API
      newFees = Exp.evaluateTransactionFee exampleProtocolParams (Exp.makeUnsignedTx era newTxBodyContent) 0 1 0
  H.note_ $ "Fees 1: " <> show oldFees

  oldFees H.=== newFees

  -- Balance without ledger context (other that protocol parameters)
  -- Old api
  Api.BalancedTxBody
    _txBodyContent2
    _txBody2
    _changeOutput2
    fees2 <-
    H.evalEither
      $ Api.estimateBalancedTxBody
        meo
        txBodyContent
        exampleProtocolParams
        mempty
        mempty
        mempty
        mempty
        0
        1
        0
        0
        changeAddress
      $ Api.lovelaceToValue 12_000_000
  -- New api
  balancedTxBodyContent <-
    H.evalEither $
      Exp.estimateBalancedTxBody
        era
        newTxBodyContent
        exampleProtocolParams
        mempty
        mempty
        mempty
        mempty
        0
        1
        0
        0
        changeAddress
        (Ledger.valueFromList 12_000_000 [])

  fees2 H.=== Exp.txFee balancedTxBodyContent
  H.note_ $ "Fees 2: " <> show fees2

  -- H.note_ $ "New TxBody 2: " <> show txBody2
  -- H.note_ $ "New TxBodyContent 2: " <> show txBodyContent2
  -- H.note_ $ "Change output 2: " <> show changeOutput2

  -- Automatically balance the transaction (with ledger context)
  currTime <- Api.liftIO Time.getCurrentTime
  srcTxId <- getExampleSrcTxId
  let startTime = Time.posixSecondsToUTCTime (Time.utcTimeToPOSIXSeconds currTime - Time.nominalDay)
  let epochInfo =
        Api.LedgerEpochInfo $ Slotting.fixedEpochInfo (Slotting.EpochSize 100) (Slotting.mkSlotLength 1000)
  let utxoToUse =
        Api.UTxO
          [
            ( srcTxId
            , Api.TxOut
                changeAddress
                (Api.lovelaceToTxOutValue sbe 12_000_000)
                Api.TxOutDatumNone
                Script.ReferenceScriptNone
            )
          ]

  Api.BalancedTxBody
    _txBodyContent3
    _txBody3
    _changeOutput3
    fees3 <-
    H.evalEither $
      Api.makeTransactionBodyAutoBalance
        sbe
        (Api.SystemStart startTime)
        epochInfo
        (Api.LedgerProtocolParameters exampleProtocolParams)
        mempty
        mempty
        mempty
        utxoToUse
        txBodyContent
        changeAddress
        Nothing

  H.note_ $ "Fees 3: " <> show fees3

  -- Check old and new api serialises a tx the same way

  let newTx = Api.serialiseToRawBytes $ Exp.makeUnsignedTx era newTxBodyContent
      oldTx = Api.serialiseToCBOR $ Api.makeSignedTransaction [] txBody
  newTx H.=== oldTx
  H.success

exampleProtocolParams :: Ledger.PParams UnexportedLedger.ConwayEra
exampleProtocolParams =
  UnexportedLedger.upgradePParams conwayUpgrade $
    UnexportedLedger.upgradePParams () $
      UnexportedLedger.upgradePParams alonzoUpgrade $
        UnexportedLedger.upgradePParams () $
          UnexportedLedger.upgradePParams () $
            Genesis.sgProtocolParams Genesis.shelleyGenesisDefaults
 where
  conwayUpgrade :: Ledger.UpgradeConwayPParams Identity
  conwayUpgrade = Ledger.cgUpgradePParams Genesis.conwayGenesisDefaults

  alonzoUpgrade :: UnexportedLedger.UpgradeAlonzoPParams Identity
  alonzoUpgrade =
    UnexportedLedger.UpgradeAlonzoPParams
      { UnexportedLedger.uappCoinsPerUTxOWord = Ledger.CoinPerWord $ Ledger.Coin 34_482
      , UnexportedLedger.uappCostModels = UnexportedLedger.emptyCostModels -- We are not using scripts for this tests, so this is fine for now
      , UnexportedLedger.uappPrices =
          Ledger.Prices
            { Ledger.prSteps = fromMaybe maxBound $ Ledger.boundRational $ 721 % 10_000_000
            , Ledger.prMem = fromMaybe maxBound $ Ledger.boundRational $ 577 % 10_000
            }
      , UnexportedLedger.uappMaxTxExUnits =
          Ledger.ExUnits
            { Ledger.exUnitsMem = 140_000_000
            , Ledger.exUnitsSteps = 10_000_000_000
            }
      , UnexportedLedger.uappMaxBlockExUnits =
          Ledger.ExUnits
            { Ledger.exUnitsMem = 62_000_000
            , Ledger.exUnitsSteps = 20_000_000_000
            }
      , UnexportedLedger.uappMaxValSize = 5000
      , UnexportedLedger.uappCollateralPercentage = 150
      , UnexportedLedger.uappMaxCollateralInputs = 3
      }

getExampleSrcTxId :: H.MonadTest m => m Api.TxIn
getExampleSrcTxId = do
  srcTxId <-
    H.evalEither $
      Api.deserialiseFromRawBytesHex
        "be6efd42a3d7b9a00d09d77a5d41e55ceaf0bd093a8aa8a893ce70d9caafd978"
  let srcTxIx = Api.TxIx 0
  return $ Api.TxIn srcTxId srcTxIx

getExampleDestAddress
  :: forall era m. (H.MonadTest m, Api.IsCardanoEra era) => m (Api.AddressInEra era)
getExampleDestAddress = do
  H.evalMaybe $
    Api.deserialiseAddress
      (Api.AsAddressInEra (Api.proxyToAsType (Api.Proxy @era)))
      "addr_test1vzpfxhjyjdlgk5c0xt8xw26avqxs52rtf69993j4tajehpcue4v2v"

getExampleDestAddressExp
  :: H.MonadTest m => m Ledger.Addr
getExampleDestAddressExp = do
  Api.toShelleyAddr
    <$> H.evalMaybe
      ( Api.deserialiseAddress
          (Api.AsAddressInEra (Api.proxyToAsType (Api.Proxy @Api.ConwayEra)))
          "addr_test1vzpfxhjyjdlgk5c0xt8xw26avqxs52rtf69993j4tajehpcue4v2v"
      )

getExampleChangeAddress :: H.MonadTest m => Api.ShelleyBasedEra era -> m (Api.AddressInEra era)
getExampleChangeAddress sbe = do
  signingKey <- exampleSigningKey
  return $
    Api.shelleyAddressInEra sbe $
      Api.makeShelleyAddress
        (Api.Testnet $ Api.NetworkMagic 2)
        (Api.PaymentCredentialByKey $ Api.verificationKeyHash $ Api.getVerificationKey signingKey)
        Api.NoStakeAddress

exampleTxBodyContentExperimental
  :: forall era m
   . H.MonadTest m
  => Exp.Era era
  -> m (Exp.TxBodyContent (Exp.LedgerEra era))
exampleTxBodyContentExperimental era = do
  srcTxIn <- getExampleSrcTxId
  addr <- getExampleDestAddressExp
  let value = Ledger.valueFromList 10_000_000 []
      out :: Ledger.TxOut (Exp.LedgerEra era)
      out = Exp.obtainCommonConstraints era $ Ledger.mkBasicTxOut addr value
  let txBodyContent =
        Exp.defaultTxBodyContent
          & Exp.setTxIns
            [
              ( srcTxIn
              , Exp.AnyKeyWitnessPlaceholder
              )
            ]
          & Exp.setTxOuts
            [ Exp.obtainCommonConstraints era $ Exp.TxOut out
            ]
          & Exp.setTxFee 2_000_000
  return txBodyContent

exampleTxBodyContent
  :: forall m era
   . H.MonadTest m
  => Api.IsCardanoEra era
  => Api.ShelleyBasedEra era
  -> m (Api.TxBodyContent Api.BuildTx era)
exampleTxBodyContent sbe = do
  srcTxIn <- getExampleSrcTxId
  destAddress <- getExampleDestAddress @era
  let txBodyContent =
        Api.defaultTxBodyContent sbe
          & Api.setTxIns
            [
              ( srcTxIn
              , Api.BuildTxWith (Api.KeyWitness Api.KeyWitnessForSpending)
              )
            ]
          & Api.setTxOuts
            [ Api.TxOut
                destAddress
                (Api.lovelaceToTxOutValue sbe 10_000_000)
                Api.TxOutDatumNone
                Script.ReferenceScriptNone
            ]
          & Api.setTxFee (Api.TxFeeExplicit sbe 2_000_000)

  return txBodyContent

exampleOldAndNewStyleTxBodyContent
  :: forall m era
   . H.MonadTest m
  => Api.IsCardanoEra era
  => Exp.Era era
  -> m
       ( Api.TxBodyContent Api.BuildTx era
       , Exp.TxBodyContent (Exp.LedgerEra era)
       )
exampleOldAndNewStyleTxBodyContent era = do
  let sbe = convert era
  srcTxIn <- getExampleSrcTxId
  destAddress <- getExampleDestAddress @era
  let txBodyContentOldApi =
        Api.defaultTxBodyContent sbe
          & Api.setTxIns
            [
              ( srcTxIn
              , Api.BuildTxWith (Api.KeyWitness Api.KeyWitnessForSpending)
              )
            ]
          & Api.setTxOuts
            [ Api.TxOut
                destAddress
                (Api.lovelaceToTxOutValue sbe 10_000_000)
                Api.TxOutDatumNone
                Script.ReferenceScriptNone
            ]
          & Api.setTxFee (Api.TxFeeExplicit sbe 2_000_000)

  let txBodyContentNewApi =
        Exp.defaultTxBodyContent
          & Exp.setTxIns
            [
              ( srcTxIn
              , Exp.AnyKeyWitnessPlaceholder
              )
            ]
          & Exp.setTxOuts
            [ Exp.obtainCommonConstraints era $
                Exp.TxOut
                  ( Exp.obtainCommonConstraints era $
                      Ledger.mkBasicTxOut (Api.toShelleyAddr destAddress) (Ledger.valueFromList 10_000_000 [])
                  )
            ]
          & Exp.setTxFee 2_000_000
  return (txBodyContentOldApi, txBodyContentNewApi)

exampleSigningKey :: H.MonadTest m => m (Api.SigningKey Api.PaymentKey)
exampleSigningKey =
  H.evalEither $
    Api.deserialiseFromBech32
      "addr_sk1648253w4tf6fv5fk28dc7crsjsaw7d9ymhztd4favg3cwkhz7x8sl5u3ms"

expEraGen :: Gen (Exp.Some Exp.Era)
expEraGen =
  let eras :: [Exp.Some Exp.Era] = [minBound .. maxBound]
   in Gen.element eras

expTxForEraGen :: Exp.Era era -> Gen (Ledger.Tx (Exp.LedgerEra era))
expTxForEraGen era = do
  Exp.obtainCommonConstraints era $ do
    ShelleyTx _ tx <- genTx (convert era)
    return tx

prop_roundtrip_serialise_as_raw_bytes_unsigned_tx :: Property
prop_roundtrip_serialise_as_raw_bytes_unsigned_tx = H.withTests (H.TestLimit 20) $ H.property $ do
  Exp.Some era <- H.forAll expEraGen
  Exp.obtainCommonConstraints era $ do
    tx <- H.forAll $ expTxForEraGen era
    let signedTx = Exp.UnsignedTx tx
    signedTx H.=== signedTx
    H.tripping
      signedTx
      (Text.decodeUtf8 . Api.serialiseToRawBytesHex)
      (first show . Api.deserialiseFromRawBytesHex . Text.encodeUtf8)

prop_roundtrip_serialise_as_raw_bytes_signed_tx :: Property
prop_roundtrip_serialise_as_raw_bytes_signed_tx = H.withTests (H.TestLimit 20) $ H.property $ do
  Exp.Some era <- H.forAll expEraGen
  Exp.obtainCommonConstraints era $ do
    tx <- H.forAll $ expTxForEraGen era
    let signedTx = Exp.SignedTx tx
    signedTx H.=== signedTx
    H.tripping
      signedTx
      (Text.decodeUtf8 . Api.serialiseToRawBytesHex)
      (first show . Api.deserialiseFromRawBytesHex . Text.encodeUtf8)
