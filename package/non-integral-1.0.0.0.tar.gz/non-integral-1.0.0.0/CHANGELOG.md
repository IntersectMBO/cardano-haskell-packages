# Changelog for `non-integer`

## 1.0.0.0

First properly versioned release
