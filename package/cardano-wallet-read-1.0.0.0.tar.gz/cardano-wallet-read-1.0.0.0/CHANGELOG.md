# Revision history for cardano-wallet-read

## 1.0.0.0 — 2025-02-05

* First version released to [CHaP][].

  [chap]: https://chap.intersectmbo.org/
