## 1.4.0.0

* Remove `Test.Cardano.Binary.Drop` module

## 1.3.0.1

* Initial release

