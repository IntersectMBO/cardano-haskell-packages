# Version history for `small-steps-test`

## 1.0.1.0

* GHC-9.6 compatibility

## 1.0.0.1

*

## 1.0.0.0

*

## 0.1.1.2

*

## 0.1.1.1

*

## 0.1.0.0

* Initial release
