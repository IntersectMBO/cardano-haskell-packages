{-# LANGUAGE DataKinds #-}
{-# LANGUAGE DerivingVia #-}
{-# LANGUAGE FlexibleContexts #-}
{-# LANGUAGE FlexibleInstances #-}
{-# LANGUAGE GADTs #-}
{-# LANGUAGE GeneralizedNewtypeDeriving #-}
{-# LANGUAGE MultiParamTypeClasses #-}
{-# LANGUAGE NamedFieldPuns #-}
{-# LANGUAGE OverloadedStrings #-}
{-# LANGUAGE PatternSynonyms #-}
{-# LANGUAGE RankNTypes #-}
{-# LANGUAGE RecordWildCards #-}
{-# LANGUAGE ScopedTypeVariables #-}
{-# LANGUAGE StandaloneDeriving #-}
{-# LANGUAGE TypeApplications #-}
{-# LANGUAGE TypeFamilies #-}
{-# LANGUAGE UndecidableInstances #-}
{-# LANGUAGE UndecidableSuperClasses #-}
{-# LANGUAGE ViewPatterns #-}
{-# OPTIONS_GHC -Wno-orphans #-}

module Cardano.Ledger.Babbage.TxBody (
  BabbageTxOut (
    BabbageTxOut,
    TxOutCompact,
    TxOutCompactDH,
    TxOutCompactDatum,
    TxOutCompactRefScript
  ),
  TxBody (
    MkBabbageTxBody,
    BabbageTxBody,
    btbInputs,
    btbCollateral,
    btbReferenceInputs,
    btbOutputs,
    btbCollateralReturn,
    btbTotalCollateral,
    btbCerts,
    btbWithdrawals,
    btbTxFee,
    btbValidityInterval,
    btbUpdate,
    btbReqSignerHashes,
    btbMint,
    btbScriptIntegrityHash,
    btbAuxDataHash,
    btbTxNetworkId
  ),
  allSizedOutputsBabbageTxBodyF,
  babbageMinUTxOValue,
  BabbageTxBodyRaw (..),
  babbageAllInputsTxBodyF,
  BabbageEraTxBody (..),
  getEitherAddrBabbageTxOut,
  EraIndependentScriptIntegrity,
  ScriptIntegrityHash,
) where

import Cardano.Ledger.Alonzo.Core
import Cardano.Ledger.Alonzo.TxBody (
  alonzoRedeemerPointer,
  alonzoRedeemerPointerInverse,
  alonzoSpendableInputsTxBodyF,
 )
import Cardano.Ledger.Babbage.Era (BabbageEra)
import Cardano.Ledger.Babbage.Scripts ()
import Cardano.Ledger.Babbage.TxCert ()
import Cardano.Ledger.Babbage.TxOut
import Cardano.Ledger.BaseTypes (
  Network (..),
  StrictMaybe (..),
  ToKeyValuePairs (..),
 )
import Cardano.Ledger.Binary (
  Annotator (..),
  DecCBOR (..),
  EncCBOR (..),
  Sized (..),
  ToCBOR (..),
  mkSized,
 )
import Cardano.Ledger.Binary.Coders
import Cardano.Ledger.Coin (Coin (..))
import Cardano.Ledger.Mary.Value (MultiAsset)
import Cardano.Ledger.MemoBytes (
  EqRaw,
  Mem,
  MemoBytes,
  MemoHashIndex,
  Memoized (..),
  eqRaw,
  getMemoRawType,
  getMemoSafeHash,
  lensMemoRawType,
  mkMemoizedEra,
  zipMemoRawType,
 )
import Cardano.Ledger.Shelley.PParams (Update (..))
import Cardano.Ledger.Shelley.TxBody (getShelleyGenesisKeyHashCountTxBody)
import Cardano.Ledger.TxIn (TxIn (..))
import Control.DeepSeq (NFData (..), deepseq)
import Data.Aeson (FromJSON (..), ToJSON (..), withObject, (.:), (.=))
import qualified Data.Aeson as Aeson
import Data.Foldable as F (foldl', toList)
import Data.Sequence.Strict (StrictSeq, (|>))
import qualified Data.Sequence.Strict as StrictSeq
import Data.Set (Set)
import qualified Data.Set as Set
import Data.Typeable (Typeable)
import GHC.Generics (Generic)
import Lens.Micro
import NoThunks.Class (InspectHeap (..), NoThunks)

class (AlonzoEraTxBody era, BabbageEraTxOut era) => BabbageEraTxBody era where
  sizedOutputsTxBodyL :: Lens' (TxBody l era) (StrictSeq (Sized (TxOut era)))

  referenceInputsTxBodyL :: Lens' (TxBody l era) (Set TxIn)

  totalCollateralTxBodyL :: Lens' (TxBody TopTx era) (StrictMaybe Coin)

  collateralReturnTxBodyL :: Lens' (TxBody TopTx era) (StrictMaybe (TxOut era))

  sizedCollateralReturnTxBodyL :: Lens' (TxBody TopTx era) (StrictMaybe (Sized (TxOut era)))

  allSizedOutputsTxBodyF :: SimpleGetter (TxBody l era) (StrictSeq (Sized (TxOut era)))

-- ======================================

data BabbageTxBodyRaw l era where
  BabbageTxBodyRaw ::
    { btbrInputs :: !(Set TxIn)
    , btbrCollateralInputs :: !(Set TxIn)
    , btbrReferenceInputs :: !(Set TxIn)
    , btbrOutputs :: !(StrictSeq (Sized (TxOut era)))
    , btbrCollateralReturn :: !(StrictMaybe (Sized (TxOut era)))
    , btbrTotalCollateral :: !(StrictMaybe Coin)
    , btbrCerts :: !(StrictSeq (TxCert era))
    , btbrWithdrawals :: !Withdrawals
    , btbrFee :: !Coin
    , btbrValidityInterval :: !ValidityInterval
    , btbrUpdate :: !(StrictMaybe (Update era))
    , btbrReqSignerHashes :: !(Set (KeyHash Guard))
    , btbrMint :: !MultiAsset
    , -- The spec makes it clear that the mint field is a
      -- Cardano.Ledger.Mary.Value.MaryValue, not a Value.
      -- Operations on the TxBody in the BabbageEra depend upon this.
      -- We now store only the MultiAsset part of a Mary.Value.
      btbrScriptIntegrityHash :: !(StrictMaybe ScriptIntegrityHash)
    , btbrAuxDataHash :: !(StrictMaybe TxAuxDataHash)
    , btbrNetworkId :: !(StrictMaybe Network)
    } ->
    BabbageTxBodyRaw TopTx era

deriving instance Eq (BabbageTxBodyRaw l BabbageEra)

deriving instance Show (BabbageTxBodyRaw l BabbageEra)

instance NFData (BabbageTxBodyRaw l BabbageEra) where
  rnf BabbageTxBodyRaw {..} =
    btbrInputs `deepseq`
      btbrCollateralInputs `deepseq`
        btbrReferenceInputs `deepseq`
          btbrOutputs `deepseq`
            btbrCollateralReturn `deepseq`
              btbrTotalCollateral `deepseq`
                btbrCerts `deepseq`
                  btbrWithdrawals `deepseq`
                    btbrFee `deepseq`
                      btbrValidityInterval `deepseq`
                        btbrUpdate `deepseq`
                          btbrReqSignerHashes `deepseq`
                            btbrMint `deepseq`
                              btbrScriptIntegrityHash `deepseq`
                                btbrAuxDataHash `deepseq`
                                  rnf btbrNetworkId

-- We override this instance because the 'Sized' types also reference their
-- serialisation and as such cannot be compared directly. An alternative would
-- be to derive `EqRaw` for `Sized`.
instance EqRaw (BabbageTxBodyRaw l BabbageEra) where
  eqRaw a b =
    case toSTxLevel a of
      STopTxOnly ->
        btbrInputs a == btbrInputs b
          && btbrCollateralInputs a == btbrCollateralInputs b
          && btbrReferenceInputs a == btbrReferenceInputs b
          && btbrOutputs a `eqSeqUnsized` btbrOutputs b
          && btbrCollateralReturn a `eqMbUnsized` btbrCollateralReturn b
          && btbrTotalCollateral a == btbrTotalCollateral b
          && btbrCerts a == btbrCerts b
          && btbrWithdrawals a == btbrWithdrawals b
          && btbrFee a == btbrFee b
          && btbrValidityInterval a == btbrValidityInterval b
          && btbrUpdate a == btbrUpdate b
          && btbrReqSignerHashes a == btbrReqSignerHashes b
          && btbrMint a == btbrMint b
          && btbrScriptIntegrityHash a == btbrScriptIntegrityHash b
          && btbrAuxDataHash a == btbrAuxDataHash b
          && btbrNetworkId a == btbrNetworkId b
        where
          eqMbUnsized x y = case (x, y) of
            (SJust a', SJust b') -> a' `eqUnsized` b'
            (SNothing, SNothing) -> True
            _ -> False
          eqSeqUnsized x y =
            length x == length y
              && F.foldl' (\acc (x', y') -> acc && x' `eqUnsized` y') True (StrictSeq.zip x y)
          eqUnsized x y = sizedValue x == sizedValue y

type instance MemoHashIndex (BabbageTxBodyRaw l era) = EraIndependentTxBody

deriving via
  InspectHeap (BabbageTxBodyRaw l BabbageEra)
  instance
    Typeable l => NoThunks (BabbageTxBodyRaw l BabbageEra)

deriving via
  Mem (BabbageTxBodyRaw l BabbageEra)
  instance
    Typeable l => DecCBOR (Annotator (TxBody l BabbageEra))

instance Memoized (TxBody l BabbageEra) where
  type RawType (TxBody l BabbageEra) = BabbageTxBodyRaw l BabbageEra

deriving newtype instance NFData (TxBody l BabbageEra)

babbageAllInputsTxBodyF ::
  BabbageEraTxBody era => SimpleGetter (TxBody TopTx era) (Set TxIn)
babbageAllInputsTxBodyF =
  to $
    \txBody ->
      (txBody ^. inputsTxBodyL)
        `Set.union` (txBody ^. collateralInputsTxBodyL)
        `Set.union` (txBody ^. referenceInputsTxBodyL)
{-# INLINEABLE babbageAllInputsTxBodyF #-}

allSizedOutputsBabbageTxBodyF ::
  BabbageEraTxBody era =>
  SimpleGetter (TxBody TopTx era) (StrictSeq (Sized (TxOut era)))
allSizedOutputsBabbageTxBodyF =
  to $ \txBody ->
    let txOuts = txBody ^. sizedOutputsTxBodyL
     in case txBody ^. sizedCollateralReturnTxBodyL of
          SNothing -> txOuts
          SJust collTxOut -> txOuts |> collTxOut
{-# INLINEABLE allSizedOutputsBabbageTxBodyF #-}

instance HasEraTxLevel BabbageTxBodyRaw BabbageEra where
  toSTxLevel BabbageTxBodyRaw {} = STopTxOnly

instance HasEraTxLevel TxBody BabbageEra where
  toSTxLevel = toSTxLevel . getMemoRawType

basicBabbageTxBody :: Typeable l => TxBody l BabbageEra
basicBabbageTxBody = mkMemoizedEra @BabbageEra $ asSTxTopLevel basicBabbageTxBodyRaw

instance EraTxBody BabbageEra where
  newtype TxBody l BabbageEra = MkBabbageTxBody (MemoBytes (BabbageTxBodyRaw l BabbageEra))
    deriving newtype (Generic, SafeToHash, ToCBOR, Eq)

  mkBasicTxBody = basicBabbageTxBody

  inputsTxBodyL =
    lensMemoRawType @BabbageEra (\BabbageTxBodyRaw {btbrInputs} -> btbrInputs) $ \txBodyRaw inputs -> txBodyRaw {btbrInputs = inputs}
  {-# INLINE inputsTxBodyL #-}

  outputsTxBodyL =
    lensMemoRawType @BabbageEra (fmap sizedValue . (\BabbageTxBodyRaw {btbrOutputs} -> btbrOutputs)) $ \txBodyRaw outputs ->
      txBodyRaw {btbrOutputs = mkSized (eraProtVerLow @BabbageEra) <$> outputs}
  {-# INLINE outputsTxBodyL #-}

  feeTxBodyL =
    lensMemoRawType @BabbageEra (\BabbageTxBodyRaw {btbrFee} -> btbrFee) $ \txBodyRaw fee -> txBodyRaw {btbrFee = fee}
  {-# INLINE feeTxBodyL #-}

  auxDataHashTxBodyL =
    lensMemoRawType @BabbageEra (\BabbageTxBodyRaw {btbrAuxDataHash} -> btbrAuxDataHash) $ \txBodyRaw auxDataHash ->
      txBodyRaw {btbrAuxDataHash = auxDataHash}
  {-# INLINE auxDataHashTxBodyL #-}

  spendableInputsTxBodyF = to (`withTopTxLevelOnly` (^. alonzoSpendableInputsTxBodyF))
  {-# INLINE spendableInputsTxBodyF #-}

  withdrawalsTxBodyL =
    lensMemoRawType @BabbageEra (\BabbageTxBodyRaw {btbrWithdrawals} -> btbrWithdrawals) $
      \txBodyRaw withdrawals -> txBodyRaw {btbrWithdrawals = withdrawals}
  {-# INLINE withdrawalsTxBodyL #-}

  certsTxBodyL =
    lensMemoRawType @BabbageEra (\BabbageTxBodyRaw {btbrCerts} -> btbrCerts) $ \txBodyRaw certs -> txBodyRaw {btbrCerts = certs}
  {-# INLINE certsTxBodyL #-}

  getGenesisKeyHashCountTxBody = getShelleyGenesisKeyHashCountTxBody

instance ShelleyEraTxBody BabbageEra where
  ttlTxBodyL = notSupportedInThisEraL
  {-# INLINE ttlTxBodyL #-}

  updateTxBodyL =
    lensMemoRawType @BabbageEra btbrUpdate $ \txBodyRaw update -> txBodyRaw {btbrUpdate = update}
  {-# INLINE updateTxBodyL #-}

instance AllegraEraTxBody BabbageEra where
  vldtTxBodyL =
    lensMemoRawType @BabbageEra (\BabbageTxBodyRaw {btbrValidityInterval} -> btbrValidityInterval) $ \txBodyRaw vldt ->
      txBodyRaw {btbrValidityInterval = vldt}
  {-# INLINE vldtTxBodyL #-}

instance MaryEraTxBody BabbageEra where
  mintTxBodyL =
    lensMemoRawType @BabbageEra (\BabbageTxBodyRaw {btbrMint} -> btbrMint) $ \txBodyRaw mint -> txBodyRaw {btbrMint = mint}
  {-# INLINE mintTxBodyL #-}

instance AlonzoEraTxBody BabbageEra where
  collateralInputsTxBodyL =
    lensMemoRawType @BabbageEra (\BabbageTxBodyRaw {btbrCollateralInputs} -> btbrCollateralInputs) $ \txBodyRaw collateral ->
      txBodyRaw {btbrCollateralInputs = collateral}
  {-# INLINE collateralInputsTxBodyL #-}

  reqSignerHashesTxBodyL =
    lensMemoRawType @BabbageEra (\BabbageTxBodyRaw {btbrReqSignerHashes} -> btbrReqSignerHashes) $ \txBodyRaw reqSignerHashes ->
      txBodyRaw {btbrReqSignerHashes = reqSignerHashes}
  {-# INLINE reqSignerHashesTxBodyL #-}

  scriptIntegrityHashTxBodyL =
    lensMemoRawType @BabbageEra (\BabbageTxBodyRaw {btbrScriptIntegrityHash} -> btbrScriptIntegrityHash) $ \txBodyRaw scriptIntegrityHash ->
      txBodyRaw {btbrScriptIntegrityHash = scriptIntegrityHash}
  {-# INLINE scriptIntegrityHashTxBodyL #-}

  networkIdTxBodyL = lensMemoRawType @BabbageEra (\BabbageTxBodyRaw {btbrNetworkId} -> btbrNetworkId) $ \txBodyRaw networkId ->
    txBodyRaw {btbrNetworkId = networkId}
  {-# INLINE networkIdTxBodyL #-}

  redeemerPointer = alonzoRedeemerPointer

  redeemerPointerInverse = alonzoRedeemerPointerInverse

instance BabbageEraTxBody BabbageEra where
  sizedOutputsTxBodyL =
    lensMemoRawType @BabbageEra (\BabbageTxBodyRaw {btbrOutputs} -> btbrOutputs) $ \txBodyRaw outputs -> txBodyRaw {btbrOutputs = outputs}
  {-# INLINE sizedOutputsTxBodyL #-}

  referenceInputsTxBodyL =
    lensMemoRawType @BabbageEra (\BabbageTxBodyRaw {btbrReferenceInputs} -> btbrReferenceInputs) $ \txBodyRaw reference ->
      txBodyRaw {btbrReferenceInputs = reference}
  {-# INLINE referenceInputsTxBodyL #-}

  totalCollateralTxBodyL =
    lensMemoRawType @BabbageEra (\BabbageTxBodyRaw {btbrTotalCollateral} -> btbrTotalCollateral) $ \txBodyRaw totalCollateral ->
      txBodyRaw {btbrTotalCollateral = totalCollateral}
  {-# INLINE totalCollateralTxBodyL #-}

  collateralReturnTxBodyL =
    lensMemoRawType @BabbageEra
      (fmap sizedValue . (\BabbageTxBodyRaw {btbrCollateralReturn} -> btbrCollateralReturn))
      $ \txBodyRaw collateralReturn ->
        txBodyRaw {btbrCollateralReturn = mkSized (eraProtVerLow @BabbageEra) <$> collateralReturn}
  {-# INLINE collateralReturnTxBodyL #-}

  sizedCollateralReturnTxBodyL =
    lensMemoRawType @BabbageEra (\BabbageTxBodyRaw {btbrCollateralReturn} -> btbrCollateralReturn) $ \txBodyRaw collateralReturn ->
      txBodyRaw {btbrCollateralReturn = collateralReturn}
  {-# INLINE sizedCollateralReturnTxBodyL #-}

  allSizedOutputsTxBodyF = to (`withTopTxLevelOnly` (^. allSizedOutputsBabbageTxBodyF))
  {-# INLINE allSizedOutputsTxBodyF #-}

instance EqRaw (TxBody l BabbageEra) where
  eqRaw = zipMemoRawType eqRaw

deriving instance Typeable l => NoThunks (TxBody l BabbageEra)

deriving instance Show (TxBody l BabbageEra)

pattern BabbageTxBody ::
  Set TxIn ->
  Set TxIn ->
  Set TxIn ->
  StrictSeq (Sized (TxOut BabbageEra)) ->
  StrictMaybe (Sized (TxOut BabbageEra)) ->
  StrictMaybe Coin ->
  StrictSeq (TxCert BabbageEra) ->
  Withdrawals ->
  Coin ->
  ValidityInterval ->
  StrictMaybe (Update BabbageEra) ->
  Set (KeyHash Guard) ->
  MultiAsset ->
  StrictMaybe ScriptIntegrityHash ->
  StrictMaybe TxAuxDataHash ->
  StrictMaybe Network ->
  TxBody TopTx BabbageEra
pattern BabbageTxBody
  { btbInputs
  , btbCollateral
  , btbReferenceInputs
  , btbOutputs
  , btbCollateralReturn
  , btbTotalCollateral
  , btbCerts
  , btbWithdrawals
  , btbTxFee
  , btbValidityInterval
  , btbUpdate
  , btbReqSignerHashes
  , btbMint
  , btbScriptIntegrityHash
  , btbAuxDataHash
  , btbTxNetworkId
  } <-
  ( getMemoRawType ->
      BabbageTxBodyRaw
        { btbrInputs = btbInputs
        , btbrCollateralInputs = btbCollateral
        , btbrReferenceInputs = btbReferenceInputs
        , btbrOutputs = btbOutputs
        , btbrCollateralReturn = btbCollateralReturn
        , btbrTotalCollateral = btbTotalCollateral
        , btbrCerts = btbCerts
        , btbrWithdrawals = btbWithdrawals
        , btbrFee = btbTxFee
        , btbrValidityInterval = btbValidityInterval
        , btbrUpdate = btbUpdate
        , btbrReqSignerHashes = btbReqSignerHashes
        , btbrMint = btbMint
        , btbrScriptIntegrityHash = btbScriptIntegrityHash
        , btbrAuxDataHash = btbAuxDataHash
        , btbrNetworkId = btbTxNetworkId
        }
    )
  where
    BabbageTxBody
      inputs
      collateral
      referenceInputs
      outputs
      collateralReturn
      totalCollateral
      certs
      withdrawals
      txFee
      validityInterval
      update
      reqSignerHashes
      mint
      scriptIntegrityHash
      auxDataHash
      txNetworkId =
        mkMemoizedEra @BabbageEra $
          BabbageTxBodyRaw
            { btbrInputs = inputs
            , btbrCollateralInputs = collateral
            , btbrReferenceInputs = referenceInputs
            , btbrOutputs = outputs
            , btbrCollateralReturn = collateralReturn
            , btbrTotalCollateral = totalCollateral
            , btbrCerts = certs
            , btbrWithdrawals = withdrawals
            , btbrFee = txFee
            , btbrValidityInterval = validityInterval
            , btbrUpdate = update
            , btbrReqSignerHashes = reqSignerHashes
            , btbrMint = mint
            , btbrScriptIntegrityHash = scriptIntegrityHash
            , btbrAuxDataHash = auxDataHash
            , btbrNetworkId = txNetworkId
            }

{-# COMPLETE BabbageTxBody #-}

instance HashAnnotated (TxBody l BabbageEra) EraIndependentTxBody where
  hashAnnotated = getMemoSafeHash

--------------------------------------------------------------------------------
-- Serialisation
--------------------------------------------------------------------------------

-- | Encodes memoized bytes created upon construction.
deriving newtype instance EncCBOR (TxBody l BabbageEra)

instance EncCBOR (BabbageTxBodyRaw l BabbageEra) where
  encCBOR
    BabbageTxBodyRaw
      { btbrInputs
      , btbrCollateralInputs
      , btbrReferenceInputs
      , btbrOutputs
      , btbrCollateralReturn
      , btbrTotalCollateral
      , btbrCerts
      , btbrWithdrawals
      , btbrFee
      , btbrValidityInterval = ValidityInterval bot top
      , btbrUpdate
      , btbrReqSignerHashes
      , btbrMint
      , btbrScriptIntegrityHash
      , btbrAuxDataHash
      , btbrNetworkId
      } =
      encode $
        Keyed
          ( \i ifee ri o cr tc f t c w u b rsh mi sh ah ni ->
              BabbageTxBodyRaw i ifee ri o cr tc c w f (ValidityInterval b t) u rsh mi sh ah ni
          )
          !> Key 0 (To btbrInputs)
          !> Omit null (Key 13 (To btbrCollateralInputs))
          !> Omit null (Key 18 (To btbrReferenceInputs))
          !> Key 1 (To btbrOutputs)
          !> encodeKeyedStrictMaybe 16 btbrCollateralReturn
          !> encodeKeyedStrictMaybe 17 btbrTotalCollateral
          !> Key 2 (To btbrFee)
          !> encodeKeyedStrictMaybe 3 top
          !> Omit null (Key 4 (To btbrCerts))
          !> Omit (null . unWithdrawals) (Key 5 (To btbrWithdrawals))
          !> encodeKeyedStrictMaybe 6 btbrUpdate
          !> encodeKeyedStrictMaybe 8 bot
          !> Omit null (Key 14 (To btbrReqSignerHashes))
          !> Omit (== mempty) (Key 9 (To btbrMint))
          !> encodeKeyedStrictMaybe 11 btbrScriptIntegrityHash
          !> encodeKeyedStrictMaybe 7 btbrAuxDataHash
          !> encodeKeyedStrictMaybe 15 btbrNetworkId

instance Typeable l => DecCBOR (BabbageTxBodyRaw l BabbageEra) where
  decCBOR =
    fmap asSTxTopLevel . decode $
      SparseKeyed
        "BabbageTxBodyRaw"
        (asSTxTopLevel basicBabbageTxBodyRaw)
        bodyFields
        requiredFields
    where
      bodyFields :: Word -> Field (BabbageTxBodyRaw TopTx BabbageEra)
      bodyFields 0 = field (\x tx -> tx {btbrInputs = x}) From
      bodyFields 13 = field (\x tx -> tx {btbrCollateralInputs = x}) From
      bodyFields 18 = field (\x tx -> tx {btbrReferenceInputs = x}) From
      bodyFields 1 = field (\x tx -> tx {btbrOutputs = x}) From
      bodyFields 16 = ofield (\x tx -> tx {btbrCollateralReturn = x}) From
      bodyFields 17 = ofield (\x tx -> tx {btbrTotalCollateral = x}) From
      bodyFields 2 = field (\x tx -> tx {btbrFee = x}) From
      bodyFields 3 =
        ofield
          (\x tx -> tx {btbrValidityInterval = (btbrValidityInterval tx) {invalidHereafter = x}})
          From
      bodyFields 4 = field (\x tx -> tx {btbrCerts = x}) From
      bodyFields 5 = field (\x tx -> tx {btbrWithdrawals = x}) From
      bodyFields 6 = ofield (\x tx -> tx {btbrUpdate = x}) From
      bodyFields 7 = ofield (\x tx -> tx {btbrAuxDataHash = x}) From
      bodyFields 8 =
        ofield
          (\x tx -> tx {btbrValidityInterval = (btbrValidityInterval tx) {invalidBefore = x}})
          From
      bodyFields 9 = field (\x tx -> tx {btbrMint = x}) From
      bodyFields 11 = ofield (\x tx -> tx {btbrScriptIntegrityHash = x}) From
      bodyFields 14 = field (\x tx -> tx {btbrReqSignerHashes = x}) From
      bodyFields 15 = ofield (\x tx -> tx {btbrNetworkId = x}) From
      bodyFields n = invalidField n
      {-# INLINE bodyFields #-}
      requiredFields :: [(Word, String)]
      requiredFields =
        [ (0, "inputs")
        , (1, "outputs")
        , (2, "fee")
        ]
  {-# INLINE decCBOR #-}

instance Typeable l => DecCBOR (Annotator (BabbageTxBodyRaw l BabbageEra)) where
  decCBOR = pure <$> decCBOR

basicBabbageTxBodyRaw :: BabbageTxBodyRaw TopTx era
basicBabbageTxBodyRaw =
  BabbageTxBodyRaw
    mempty
    mempty
    mempty
    StrictSeq.empty
    SNothing
    SNothing
    StrictSeq.empty
    (Withdrawals mempty)
    mempty
    (ValidityInterval SNothing SNothing)
    SNothing
    mempty
    mempty
    SNothing
    SNothing
    SNothing

instance
  ToJSON (TxOut BabbageEra) =>
  ToKeyValuePairs (TxBody TopTx BabbageEra)
  where
  toKeyValuePairs
    BabbageTxBody
      { btbInputs
      , btbCollateral
      , btbReferenceInputs
      , btbOutputs
      , btbCollateralReturn
      , btbTotalCollateral
      , btbCerts
      , btbWithdrawals
      , btbTxFee
      , btbValidityInterval
      , btbUpdate
      , btbReqSignerHashes
      , btbMint
      , btbScriptIntegrityHash
      , btbAuxDataHash
      , btbTxNetworkId
      } =
      [ "inputs" .= Set.toList btbInputs
      , "collateral" .= Set.toList btbCollateral
      , "referenceInputs" .= Set.toList btbReferenceInputs
      , "outputs" .= fmap sizedValue (F.toList btbOutputs)
      , "collateralReturn" .= fmap sizedValue btbCollateralReturn
      , "totalCollateral" .= btbTotalCollateral
      , "certs" .= F.toList btbCerts
      , "withdrawals" .= btbWithdrawals
      , "fee" .= btbTxFee
      , "validityInterval" .= btbValidityInterval
      , "update" .= btbUpdate
      , "reqSignerHashes" .= Set.toList btbReqSignerHashes
      , "mint" .= btbMint
      , "scriptIntegrityHash" .= btbScriptIntegrityHash
      , "auxDataHash" .= btbAuxDataHash
      , "networkId" .= btbTxNetworkId
      ]

instance ToJSON (TxOut BabbageEra) => ToJSON (TxBody TopTx BabbageEra) where
  toJSON = Aeson.object . toKeyValuePairs

instance FromJSON (TxOut BabbageEra) => FromJSON (TxBody TopTx BabbageEra) where
  parseJSON = withObject "TxBody BabbageEra" $ \o ->
    BabbageTxBody
      <$> (Set.fromList <$> o .: "inputs")
      <*> (Set.fromList <$> o .: "collateral")
      <*> (Set.fromList <$> o .: "referenceInputs")
      <*> (fmap (mkSized (eraProtVerLow @BabbageEra)) . StrictSeq.fromList <$> o .: "outputs")
      <*> (fmap (mkSized (eraProtVerLow @BabbageEra)) <$> o .: "collateralReturn")
      <*> o .: "totalCollateral"
      <*> (StrictSeq.fromList <$> o .: "certs")
      <*> o .: "withdrawals"
      <*> o .: "fee"
      <*> o .: "validityInterval"
      <*> o .: "update"
      <*> (Set.fromList <$> o .: "reqSignerHashes")
      <*> o .: "mint"
      <*> o .: "scriptIntegrityHash"
      <*> o .: "auxDataHash"
      <*> o .: "networkId"
