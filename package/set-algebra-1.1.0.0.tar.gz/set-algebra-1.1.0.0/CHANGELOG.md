# Version history for `set-algebra`

## 1.1.0.0

- Remove unused instances for `Data.UMap` #3371

## 1.0.0.0

* First properly versioned release.
