{-# LANGUAGE TypeApplications #-}

module Main where

import Cardano.Ledger.Mary (MaryEra)
import qualified Test.Cardano.Ledger.Allegra.Binary.Golden as Golden
import Test.Cardano.Ledger.Common
import Test.Cardano.Ledger.Core.JSON (roundTripJsonEraSpec)
import qualified Test.Cardano.Ledger.Mary.Binary.CddlSpec as CddlSpec
import qualified Test.Cardano.Ledger.Mary.BinarySpec as BinarySpec
import qualified Test.Cardano.Ledger.Mary.Imp as Imp
import Test.Cardano.Ledger.Mary.ImpTest ()
import qualified Test.Cardano.Ledger.Mary.ValueSpec as ValueSpec
import Test.Cardano.Ledger.Shelley.JSON (roundTripJsonShelleyEraSpec)

main :: IO ()
main =
  ledgerTestMain $
    describe "Mary" $ do
      ValueSpec.spec
      BinarySpec.spec
      CddlSpec.spec
      describe "Imp" $ do
        Imp.spec @MaryEra
      roundTripJsonEraSpec @MaryEra
      roundTripJsonShelleyEraSpec @MaryEra
      Golden.spec @MaryEra
