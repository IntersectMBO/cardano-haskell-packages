module Hasql.DynamicSyntax.Ast.Internal where

newtype Param = Param {getParam :: Int}
