# Revision history of strict-checked-vars

## 0.1.0.2

* Make `newTVarWithInvariant`, `newTVarWithInvariantIO` and `newMVarWithInvariant` strict.

## 0.1.0.1

* Export `checkInvariant`.

## 0.1.0.0

* Initial version, not released on Hackage.
