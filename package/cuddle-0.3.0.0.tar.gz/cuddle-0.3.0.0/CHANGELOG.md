# Revision history for cuddle

## 0.1.0.0 -- YYYY-mm-dd

* First version. Released on an unsuspecting world.

## 0.3.0.0 --2024-07-25

* Rationalise the choice operators. Drop (//) and provide detailed comments
  explaining the use of (/).
