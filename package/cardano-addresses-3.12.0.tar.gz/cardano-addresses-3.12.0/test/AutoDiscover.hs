{-# OPTIONS_GHC -F -pgmF hspec-discover -optF --module-name=AutoDiscover #-}
