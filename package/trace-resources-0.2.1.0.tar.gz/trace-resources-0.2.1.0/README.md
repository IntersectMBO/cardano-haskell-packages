trace-resources

Query resource statistics for various platforms for tracing.
