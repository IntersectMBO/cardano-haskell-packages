module Cardano.Ledger.Mary.Core (
  MaryEraTxBody (..),
  module Cardano.Ledger.Allegra.Core,
) where

import Cardano.Ledger.Allegra.Core
import Cardano.Ledger.Mary.Tx ()
import Cardano.Ledger.Mary.TxBody (MaryEraTxBody (..))
