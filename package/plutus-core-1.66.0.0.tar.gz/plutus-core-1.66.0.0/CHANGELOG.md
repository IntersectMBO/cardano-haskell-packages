
<a id='changelog-1.66.0.0'></a>
# 1.66.0.0 — 2026-07-09

## Added

- Add RecInline optimization pass that inlines eligible mutually recursive pir function binds.

## Changed

- The parser for textual Plutus Core in the `uplc` executable now requires all
  keys in a literal built-in `value` to be in strictly ascending lexicographic
  order; furthermore all currency quantities in a literal `value` must be
  non-zero and lie in the range [-2^127, ..., 2^127 -1]. This makes it behave
  in the same way as the `flat` decoder and the `unvalueData` function.

## Fixed

- The UPLC `FloatDelay` compiler pass could produce unsound transformations, this is now fixed.

<a id='changelog-1.65.0.0'></a>
# 1.65.0.0 — 2026-05-21

## Added

- A new UPLC optimization that hoists forced polymorphic builtins, which can reduce
  the number of forces.

<a id='changelog-1.64.0.0'></a>
# 1.64.0.0 — 2026-05-11

## Added

- The UPLC optimizer now also simplifies terms by evaluating builtins.

<a id='changelog-1.63.0.0'></a>
# 1.63.0.0 — 2026-05-01

## Fixed

- Fixed `SrcSpan` annotations on inner `Apply`/`TyInst` nodes from the PLC, PIR, and
  UPLC parsers. Parser error messages and tooling that reads annotations off parsed
  terms will now point to the specific argument involved.

<a id='changelog-1.62.0.0'></a>
# 1.62.0.0 — 2026-04-24

## Added

- A new UPLC optimization pass that floats bindings outwards. This can unlock further
  optimizations, such as case-constr and force-delay cancellation.

- Added a new command line option `--certified-opts-only` which disables those optimization passes which are not certified.

- A new plugin flag `inline-unconditional-growth`, and a new UPLC executable flag
  `opt-inline-unconditional-growth`.
  They control the aggressiveness of unconditional inlining.

## Changed

- Improved the CSE pass to make it see through bindings.

<a id='changelog-1.61.0.0'></a>
# 1.61.0.0 — 2026-04-02

## Added

- Roundtrip and stable byte encoding tests for all Flat instances across
  flat, plutus-core, plutus-ir, and untyped-plutus-core packages.
- Standalone encoding generator executable (`cabal run flat-encoding-generator`)
  for reproducing expected byte constants.

## Fixed

- Fixed `consClose` in the Flat decoder failing to advance the stream pointer past 1 byte, which corrupted decoder state for Generic-derived Flat instances of large enums (>256 constructors) and caused infinite memory consumption during deserialization.

<a id='changelog-1.60.0.0'></a>
# 1.60.0.0 — 2026-03-18

## Added

- A new UPLC optimization pass, turning multi-argument applications into case-constr form.

## Changed

- The `uplc` executable now accepts serialised scripts (in addition to textual
  and flat-encoded). Use `--input-format serialised`.

<a id='changelog-1.59.0.0'></a>
# 1.59.0.0 — 2026-03-02

## Added

- Added certifier hints in Haskell and Agda.
  They are useful for certifying certain UPLC optimizations such as inlining, since their translation relations are otherwise computationally difficult to decide.

## Changed

- Relaxed the upper bound for the `cardano-crypto-class` dependency (< 2.4)

- Added an Agda checking procedure for the inliner, and updated the UPLC inliner to emit certifier hints.

<a id='changelog-1.58.0.0'></a>
# 1.58.0.0 — 2026-02-05

## Changed

- Updated `unValueData` to reject non-canonical input, based on https://github.com/cardano-foundation/CIPs/pull/1134

<a id='changelog-1.57.0.0'></a>
# 1.57.0.0 — 2026-01-20

## Added

- Added cost models for the new `Value` builtins `insertCoin`, `unionValue` and `scaleValue`.

## Changed

- Improved performance of `unionValue` in its edge cases.

- The Plutus Core cost models have been updated to include costs for all of the
  new builtins to be released in Protocol Version 11.

<a id='changelog-1.56.0.0'></a>
# 1.56.0.0 — 2025-11-27

## Changed

- Updated benchmark data and cost model parameters for Value-related builtins (lookupCoin, valueContains, valueData, unValueData) based on fresh benchmark measurements.

- Add support for nothunks == 0.3.*

<a id='changelog-1.55.0.0'></a>
# 1.55.0.0 — 2025-11-11

## Added

- Implementations of `ScaleValue` primitives.

## Changed

- Renamed 'Size' types functions to AstSize

- In #7323 made the `Constr`, `List` and `Map` builtins 7+% faster.

- Updated the Plutus Core specification to allow names with optional numeric suffixes (e.g., `name-42`) in #7396, resolving the discrepancy between the formal grammar and the parser implementation.

<a id='changelog-1.54.0.0'></a>
# 1.54.0.0 — 2025-09-18

## Added

- Built-in type `Value`, and the implementations of `insertCoin` and `unionValue`.

- Added the bls MSM built-in to plutus-core in #4255

- Implementations of `LookupCoin` and `ValueContains` primitives.

- Implementations of `ValueData` and `UnValueData` primitives.

## Changed

- Change default compiler option `datatypes` from `BuiltinCasing` back to `SumsOfProducts`

<a id='changelog-1.53.0.0'></a>
# 1.53.0.0 — 2025-09-04

## Added

- support for constant casing builtin unit and pairs. `Case`ing on the unit expects a single branch or arbitrary value which will get picked everytime. `Case`ing on pairs expects a single branch that takes two arguments for each values of the pair.

## Changed

- The Flat serialisation format for UPLC built-in arrays was changed to use the encoder for lists instead of the encoder for the lazy `Vector` type.

<a id='changelog-1.52.0.0'></a>
# 1.52.0.0 — 2025-08-14

## Changed

- In #7272 made the CEK machine return a `CekReport` and fixed a bug with `dischargeCekValue` not dicharging under `Constr` and `Case`.

<a id='changelog-1.51.0.0'></a>
# 1.51.0.0 — 2025-07-30

## Changed

- When `Case`ing on builtin list with two branches, now the "cons" branch comes first, followed by "nil" branch. Previously, it was "nil" than "cons" branch. This was changed to give better consistency against the one branch casing which will just have "cons" branch.

<a id='changelog-1.50.0.0'></a>
# 1.50.0.0 — 2025-07-22

## Removed

- Removed the `caseList` and `caseData` builtins in preparation for adding direct `Case`ing on lists and `Data`.

## Added

- In #7029 added support for `Case`ing on booleans and integers. For example, `case True a b` now evaluates to `b`.

- Added a new UPLC optimisation which removes `force` when applied to case expressions where each branch contains a `delay` at the top, or if the delay is under any number of lambda abstractions.

- Added a new emitter mode `logWithCallTraceEmitter` which uses trace messages generated by `PlutusTx.Plugin:profile-all` flag of plutus-tx-plugin to create call trace of the functions that led to the evaluation failure. If script passes or script is not compiled with `profile-all` flag, `logWithCallTraceEmitter` will behave as regular `logEmitter`.

- Added support for `Case`ing on builtin lists. When `Case`ing a builtin list, exactly one or two branches are allowed: with a single branch, Case assumes the list is non-empty and applies the head element and the tail to that branch; with two branches, the first branch is selected if the list is empty (and takes no arguments), and the second branch is chosen if the list is non-empty, receiving the head element and the tail as its arguments. Note, the single branch **WILL FAIL** the script evaluation if empty list is given.

## Changed

- Drop `hex-text` package in favor of `base16-bytestring`.

- Disable Plutus executable build for wasm

<a id='changelog-1.49.0.0'></a>
# 1.49.0.0 — 2025-07-08

## Added

- In #7029 added support for `Case`ing on booleans and integers. For example, `case True a b` now evaluates to `b`.

- Added a new UPLC optimisation which removes `force` when applied to case expressions where each branch contains a `delay` at the top, or if the delay is under any number of lambda abstractions.

## Changed

- Drop `hex-text` package in favor of `base16-bytestring`.

<a id='changelog-1.47.0.0'></a>
# 1.47.0.0 — 2025-06-10

## Changed

- In #7106 improved error reporting in the evaluators.

- `StructuralEvaluationError` and `OperationalEvaluationError` were renamed to `StructuralError` and `OperationalError` respectively.
- `_MachineError` was made obsolete in favor of `_StructuralError`.

- The tags for the flat encodings of the as-yet-unreleased `dropList`,
  `lengthOfArray`, `listToArray`, `indexArray`, `caseList` and `caseData`
  built-in functions have been changed pending the possible removal of
  `caseList` and `caseData`.

<a id='changelog-1.46.0.0'></a>
# 1.46.0.0 — 2025-05-09

## Removed

- GHC 8.10 is no longer supported.  The supported GHC versions are 9.6 (primary), 9.8, and 9.10.

## Added

- In #7042 implemented force-delay cancellation when delays appear under ifThenElse

## Changed

- When logs preservation is disabled compiler will inline even "impure" terms
that are determined to be eventually evaluated anyway.

- Enhanced PIR's StrictifyBindings pass with strictness analysis, allowing
  many more non-strict bindings to be strictified, thereby reducing overhead.

<a id='changelog-1.45.0.0'></a>
# 1.45.0.0 — 2025-04-15

## Changed

- Builtin functions are pure when partially applied. Fully applied builtins are impure, as well as incorrectly applied ones (e.g. term argument applied instead of a type argument).

<a id='changelog-1.44.0.0'></a>
# 1.44.0.0 — 2025-04-03

## Fixed

- Fixed a bug in PIR's callsite inliner that caused it to skip valid inlining in certain cases.

<a id='changelog-1.42.0.0'></a>
# 1.42.0.0 — 2025-03-04

## Added

- Switch from `cryptonite` library to `crypton` (a drop in replacement).

- DropList builtin functionality
- Costing model for the DropList builtin

- A new type `BuiltinArray`.
- Three functions for working with `BuiltinArray` values:
  - `listToArray` (converts a list to a `BuiltinArray`)
  - `indexArray` (returns an element of a `BuiltinArray` by index)
  - `lengthOfArray` (returns the length of a `BuiltinArray`)

## Fixed

- Fixed a bug in Plutus IR's dead code elimination pass that could incorrectly remove
  live data constructors or destructors.

<a id='changelog-1.40.0.0'></a>
# 1.40.0.0 — 2025-01-16

## Changed

- In #5265 made `itraverseCounter_` faster increasing overall performance of the evaluator by 2.5%.

- In #6737 made the the CEK creation operation marginally faster by resorting to bit manipulation

## Fixed

- Fix the Steppable CEK machine to correctly "pause/step" in case of SOPs.

<a id='changelog-1.39.0.0'></a>
# 1.39.0.0 — 2024-12-20

## Changed

- Relaxed upper bound for the `cardano-crypto-class` dependency (< 2.3)

<a id='changelog-1.38.0.0'></a>
# 1.38.0.0 — 2024-12-09

## Changed

- In #6702 made variable lookup faster increasing overall performance of the evaluator by 1%.

- In #6705 made the local `spend` function faster increasing overall performance of the evaluator by 1.8%.

<a id='changelog-1.37.0.0'></a>
# 1.37.0.0 — 2024-11-25

## Added

- In #6530 added support for pattern matching builtins: `CaseList` and `CaseData`.

## Changed

- In #6663 made variable lookup significantly faster increasing overall performance of the evaluator by 10+%.

<a id='changelog-1.36.0.0'></a>
# 1.36.0.0 — 2024-10-09

## Changed

- The signature of the `writeBits` PLC builtin has been changed from
```
[bytestring, list integer, list boolean] -> bytestring
```

   to

```
[bytestring, list integer, boolean] -> bytestring
```

   Instead of a list of boolean values to write to bit positions specified in the
   second argument it now takes a single boolean value which is used to update the
   bits at all of the given positions.  If it's necessary to set some bits and
   clear others then the function should be called twice, once with `True` as the
   third argument and once with `False`.

<a id='changelog-1.35.0.0'></a>
# 1.35.0.0 — 2024-10-04

## Removed

- Removed `PlutusIR.Core.Instance.Pretty.Readable.PrettyPir`.
  Use `PlutusCore.Pretty.Readable.PrettyReadable` instead.

## Changed

- Renamed `PlutusIR.Core.Instance.Pretty.Readable.prettyPirReadable`
  to `PlutusCore.Pretty.Readable.prettyReadable`.
- Renamed `PlutusIR.Core.Instance.Pretty.Readable.prettyPirReadableSimple`
  to `PlutusCore.Pretty.Readable.prettyReadableSimple`.

<a id='changelog-1.34.1.0'></a>
# 1.34.1.0 — 2024-09-14

## Removed

- Removed the `uplc`, `plc` and `pir` executables from this package. They are now in the new `plutus-executables` package.

## Fixed

- A bug in the`findFirstSetBit` builtin has been fixed.

<a id='changelog-1.34.0.0'></a>
# 1.34.0.0 — 2024-09-09

## Changed

- Swapped around the type arguments of `EvaluationError` and `EvaluationException`.

<a id='changelog-1.33.0.0'></a>
# 1.33.0.0 — 2024-08-22

## Added

- An initial DRAFT implementation of 'modularExponentiation' builtin

- Builtin function `ripemd_160` implementing RIPEMD-160 hashing.

<a id='changelog-1.32.0.0'></a>
# 1.32.0.0 — 2024-08-06

## Added

- Added costing for the new bitwise builtins (see CIP-0058), which will probably become available at the Plomin HF.

- Support for `Natural` numbers in the default universe, backed by `Integer`.

## Changed

- Updated version boundaries for the `nothunks` dependency (^>=0.2)

<a id='changelog-1.31.0.0'></a>
# 1.31.0.0 — 2024-07-17

## Removed

- Removed `Emitter` and `MonadEmitter` in #6224.

- In #6248 the case-of-case optimization was removed from the compiler due to it causing OOMs.

## Changed

-  All names are printed with their unique suffixes by default.

- Forbade using `EvaluationResult` in the builtins code in favor of `BuiltinResult` in #5926, so that builtins throw errors with more helpful messages.

- Changed the type of `emit` to `Text -> BuiltinResult ()` in #6224.

## Fixed

- In #6272 fixed a bug in `isNormalType`.

<a id='changelog-1.30.0.0'></a>
# 1.30.0.0 — 2024-06-17

## Added

- Logical operations as per [CIP-122](https://github.com/mlabs-haskell/CIPs/blob/koz/logic-ops/CIP-0122/CIP-0122.md).

- Implementation and tests for primitive operations in [this
  CIP](https://github.com/mlabs-haskell/CIPs/blob/koz/bitwise/CIP-XXXX/CIP-XXXX.md)

## Changed

- References to CIP-87 have been corrected to refer to CIP-121.
- Rename `ReplicateByteString` to `ReplicateByte` (and similarly for denotation)
- Renamed decodeViaFlat to decodeViaFlatWith
- Renamed AsSerialize to FlatViaSerialise

<a id='changelog-1.29.0.0'></a>
# 1.29.0.0 — 2024-06-04

## Removed

- `unsafeRunCekNoEmit` and all `unsafeEvaluate*` functions in #6043. To replace e.g. `unsafeEvaluateCek` you can use `evaluateCek` in combination with `unsafeToEvaluationResult`.

- `UnknownBuiltin` and `UnknownBuiltinType` in #6064.

## Added

- Primitives `integerToByteString` and `byteStringToInteger` are added to PlutusV2,
  enabled at protocol version 10.

- A new cost model for PlutusV3.

- Missing `KnownTypeAst`, `ReadKnownIn` and `MakeKnownIn` for integral types (`Int8`, `Word16` etc) in #6036

## Changed

- Renamed `unsafeExtractEvaluationResult` to `unsafeToEvaluationResult`.

- We now have configurable cost models which allow different costs for different Plutus language versions and protocol versions.

- Made unlifting errors a bit more flexible by allowing operational unlifting errors in #6036

- CPU charges reduced for PlutusV1 and PlutusV2 scripts in the Conway era.

<a id='changelog-1.28.0.0'></a>
# 1.28.0.0 — 2024-05-15

## Fixed

- A "stricter" version of `Z`-combinator that allows certain PIR programs not to lose their traces
and yields minor performance gains.

<a id='changelog-1.27.0.0'></a>
# 1.27.0.0 — 2024-04-30

## Removed

- Debugger executable is removed and integrated inside plutus executable.

## Added

- An experimental "plutus" tool that unifies `pir`, `plc`, `uplc`, and `debugger` executables into one.
- `Codec.CBOR.Extras` module is migrated here from `plutus-ledger-api.

## Fixed

- Restrict `eraseTerm`/`eraseProgram` to only work with `TPLC Name` input.

<a id='changelog-1.26.0.0'></a>
# 1.26.0.0 — 2024-04-19

## Changed

- Improvements to costing infrastructure.

- Use `Vector` in the datastructure for `case` terms during evaluation. This speeds
  up evaluation fairly significantly.

- The `flat` encoding of the `Data` type has been modified slightly to make sure that
  the result is always in the canonical format described in the Plutus Core specification.

<a id='changelog-1.25.0.0'></a>
# 1.25.0.0 — 2024-04-03

## Changed

- Partially applied builtins are estimated to be pure and work-free to better inform other optimizations, e.g. common subexpression elimination.

<a id='changelog-1.22.0.0'></a>
# 1.22.0.0 — 2024-02-21

## Added

- Cost modelling code updated for `ByteStringToInteger` and `IntegerToByteString`.
- Preliminary budgeting for `ByteStringToInteger` and `IntegerToByteString`.

<a id='changelog-1.21.0.0'></a>
# 1.21.0.0 — 2024-01-25

## Changed

- #5728 added `BuiltinResult` and leveraged in places where we used to use `Emitter (EvaluationResult Smth)`.

<a id='changelog-1.20.0.0'></a>
# 1.20.0.0 — 2024-01-15

## Added

- Implementations for the primitive operations described in
  [CIP-0087](https://github.com/mlabs-haskell/CIPs/blob/koz/to-from-bytestring/CIP-0087/CIP-0087.md)

<a id='changelog-1.19.0.0'></a>
# 1.19.0.0 — 2023-12-23

## Added

- Common subexpression elimination for Untyped Plutus Core.

## Changed

- The methoods in the `Flat` instances for `PlutusCore.Crypto.BLS12_381.G1.Element` and `PlutusCore.Crypto.BLS12_381.G2.Element` now cause failures: if a user wishes to use a literal constant in a serialised script then they should use the relevant `uncompress` function on a bytestring.  For convenience in experimentation and testing, literal constants are still allowed in textual Plutus Core programs, but any attempt to convert such a program to `flat` format will fail.

- The `zero` and `generator` constants (for use in `plutus-tx`) have been removed from `PlutusCore.Crypto.BLS12_381.G1.Element` and `PlutusCore.Crypto.BLS12_381.G2.Element` and replaced with bytestrings called `compressed_zero` and `compressed_generator`; the original elements can be recovered by applying the appropriate `uncompress` functions to these.
-->

## Fixed

- The `EvaluateBuiltins` pass will no longer produce constants that can't be serialized.

- Fixed a bug in the PIR inliner that causes it to change the order of effects
  in the presence of multi-lets.

<a id='changelog-1.17.0.0'></a>
# 1.17.0.0 — 2023-11-22

## Added

- `Hashable` instances for `Data`, UPLC `Term` and related types.

<a id='changelog-1.16.0.0'></a>
# 1.16.0.0 — 2023-11-10

## Removed

- A `GCompare` instance for `DefaultUni` in #5609.

## Added

- A new pass in the simplifier that rewrites PIR terms given user-provided rules.
  It behaves similar to GHC's RULES, but for the PIR language.
  By default, a pre-defined set of rules are applied when the PIR simplifier is enabled.

- A PIR rewrite rule for optimizing ""(unconstr . constrdata)"

<a id='changelog-1.15.0'></a>
# 1.15.0 — 2023-10-16

## Added

- The Plutus IR optimizer now performs case-of-case.

- Typechecking property tests for all PIR compiler passes.

- The debugger will now track and show traces, live as they are emitted by the CEK machine

## Changed

- Instead of a single `--hs-file`, the debugger now accepts an `--hs-dir DIR` option
to look for (multiple) source PlutusTx modules

<a id='changelog-1.14.0.0'></a>
# 1.14.0.0 — 2023-09-28

## Added

- Optimizer now considers constructor applications to be pure

## Changed

- The ThunkRecursions transformation preserves now the effect order & strictness

<a id='changelog-1.13.0.0'></a>
# 1.13.0.0 — 2023-09-15

## Added

- A `-B`/`--builtin-semantics-variant` option for the `plc` and `uplc` commands to allow the user to select which variant of the builtin semantics to use.

## Changed

- CekMachineCosts changed to use the "higher-kinded data" pattern, like BuiltinCostModel

## Fixed

- The PIR callsite inliner no longer requires that the function is fully applied for inlining.

- Fixed bugs in the inliner relating to inlining terms that are
  immediately evaluated.

<a id='changelog-1.11.0.0'></a>
# 1.11.0.0 — 2023-08-24

## Added

- Optimization pass to strictify bindings

<a id='changelog-1.10.0.0'></a>
# 1.10.0.0 — 2023-08-02

## Added

- `keccak_256` builtin
- `blake2b_224` builtin

## Changed

- Separated the single `Includes` constraint into two constraints, `HasTypeLevel` and `HasTermLevel` (which together form `HasTypeAndTermLevel`) in #5434.

<a id='changelog-1.9.0.0'></a>
# 1.9.0.0 — 2023-07-21

## Changed

- Flat serialization&deserialization of DeBruijn indices go directly via Word64,
instead of the previous indirection via Natural.

## Fixed

- The `FakeNamedDeBruijn`'s `encode`&`size` methods  are fixed to roundtrip its flat format

<a id='changelog-1.8.0.0'></a>
# 1.8.0.0 — 2023-06-22

## Added

- Three new types for BLS12-381 objects (see CIP-0381).
- Seventeen new built-in functions for BLS12-381 operations (see CIP-0381).
- Costing benchmarks for the BLS12-381 builtins.
- R code to infer cost models for the BLS12-381 builtins.
- Property tests for the BLS12-381 builtins.
- Code for Haskell bindings to the`blst` library has been added in `cbits` and
  `plutus-core/src/Crypto/External/`.  These have been copied from PR #266
  in `cardano-base` and will be removed when that is merged.

- A special case of case-of-case optimization for UPLC, where the inner case is
  an `ifThenElse` application.

- Added `PlutusCore.MkPlc.mkIterAppNoAnn`, `PlutusCore.MkPlc.mkIterInstNoAnn` and
  `PlutusCore.MkPlc.mkIterTyAppNoAnn`.

- Callsite inlining for UPLC.

- An `apply-to-data` command was added to the `plc` and `uplc` executables which
  allows a script to be applied to a list of flat-encoded data objects (the
  existing `apply` command requires all inputs to be programs).

- Added `commuteFnWithConst` to the PIR simplifier pass.

## Changed

- The PLC, UPLC, and PIR parsers accept names quoted in backticks. Quoted names may have symbolic characters.

- Costing functions for the BLS12-381 builtins were added to `builtinCostModel.json`.
- Costing benchmark results for the BLS12-381 builtins were added to `benching.csv`.
- Some of the R code in `models.R` was improved.
- The files in `plutus-core/src/crypto` were reorganised to put code relating to
  different sets of crypto functions into separate files.

- Improved the inlining of fully saturated functions such that it measures the size
  differences more accurately, and also performs beta reduction after inlining.

- Changed `PlutusCore.MkPlc.mkIterApp`, `PlutusCore.MkPlc.mkIterInst` and
  `PlutusCore.MkPlc.mkIterTyApp` to require an annotation to be provided
  for each argument.

- Updated the parser and the pretty-printers to the new syntax of `Data` in [#5391](https://github.com/IntersectMBO/plutus/pull/5391) according to [this](https://github.com/IntersectMBO/plutus/issues/4751#issuecomment-1538377273), for example:

```
Constr 1
  [ Map [(B #616263646566, Constr 2 [B #, I 0])]
  , List
      [ List
          [ List [List [I 123456]]
          , B #666666666666666666666666666666666666666666666666666666666666666666666666666666666666 ] ]
  , I 42 ]
```

## Fixed

- The plc and uplc commands were failing to account for the new Constr and Case
  constructors for sums of products.

- Fixed `PlutusIR.Purity.firstEffectfulTerm` and `UntypedPlutusCore.Transform.Inline.firstEffectfulTerm`,
  which were sometimes too conservative and sometimes incorrect.

<a id='changelog-1.7.0.0'></a>
# 1.7.0.0 — 2023-05-22

## Added

- Float Delay optimization for UPLC.

- GHC 9.6 support

## Changed

- Improved "readable" pretty-printing functions by making them insert line breaks properly
- Simplified using "readable" pretty-printing by introducing the `PlutusCore.Pretty.Readable.AsReadable` wrapper

## Fixed

- The PIR executable now actually checks uniqueness when reading a program.

- `applyProgram` and `applyCode` now return `Either` instead of `Maybe` for better error messages.

<a id='changelog-1.6.0.0'></a>
# 1.6.0.0 — 2023-05-04

## Added

- Case-of-known-constructor for Plutus IR.

- The Plutus IR compiler can now compile datatypes using SOPs.

- Generic builtin evaluation pass for PIR (subsumes constant-folding).

## Changed

- Various `intercept` and `slope` constants are now wrapped in `Intercept` and `Slope` `newtype`s

## Fixed

- The inliner now rename before call site inlining to ensure global uniqueness.

<a id='changelog-1.5.0.0'></a>
# 1.5.0.0 — 2023-04-16

## Removed

- `Flat` instances for UPLC terms and programs. These were potentially unsafe as they don't perform the builtin checks that are required on chain, so it is important not to use them by accident.

## Added

- `optimise` options for the `pir`, `plc`, and `uplc` commands.
- A `compile` option for the `pir` command which allows a PIR file to be
  compiled to PLC or UPLC.
- Functions for mapping over names and typenames in the PLC AST.

- Inlining of fully applied functions in the PIR inliner. This only affects non-recursive bindings.

- Plutus Core 1.1.0 now supports sums-of-products via the new `constr` and `case` terms. See CIP-85 for details.

- `UnrestrictedProgram` newtype that performs unchecked serialization/deserialization of programs for when that's appropriate.

- Tests for Steppable CEK against original CEK

## Changed

- Some of the `pir` commands have been extended to allow both `flat` and textual
  input.

- Made costing lazier to speed things up and increase expressiveness. #5239

## Fixed

- Fixed the `safeEncodeBits` assertion to also guard against 1 unsafe case. Does not affect current encoding/decoding.

<a id='changelog-1.4.0.0'></a>
# 1.4.0.0 — 2023-03-23

## Added

- New Plutus Core language version 1.1
- PIR programs now have a version, which corresponds to the underlying Plutus Core language version.

## Changed

- `defaultVersion` renamed to `latestVersion`
- `applyProgram` now merges annotations and requires matching program versions

- Use a primitive array for the step counter; removed the word-array package.

<a id='changelog-1.3.0.0'></a>
# 1.3.0.0 — 2023-03-08

## Added

- The debugger TUI updates live the currently spent CPU&MEM resources of the debugged program.
- The debugger TUI accepts a `--budget` to limit the CPU&MEM resources of the debugged program.

## Changed

- The PIR readable prettyprinter was improved in a number of minor ways.

<a id='changelog-1.2.0.0'></a>
# 1.2.0.0 — 2023-02-24

## Added

- Added `NoThunks` instance for `Data`.

- A float-in compilation pass, capable of floating term bindings inwards in PIR. See Note [Float-in] for more details.

- Tests targeting testing of (1) unconditional inlining of functions (2) call site inlining of fully applied functions (for the upcoming implementation).

- The debugger can now highlight (beside the UPLC expression), the original PlutusTX expression
  currently being evaluated.

- The debugger driver will now capture any error during the stepping of a PLC program and
  display it inside the debugging clients (tui,cli,etc).

- function to track the type and term lambda abstraction order of a term in the PIR inliner.

## Changed

- PIR, TPLC and UPLC parsers now attach `PlutusCore.Annotation.SrcSpan` instead of
  `Text.Megaparsec.Pos.SourcePos` to the parsed programs and terms.

- The float-in pass can now float non-recursive type and datatype bindings.

- The float-in pass now floats bindings inwards more aggressively.
  See Note [Float-in] #5.

- Plutus IR was moved to a public sub-library of `plutus-core`.

- `Version` no longer has an annotation, as this was entirely unused.

- Made `geq` faster in certain cases, -1% of total validation time. [#5061](https://github.com/IntersectMBO/plutus/pull/5061)

- Made the Haskell-Tx file input to the debugger optional.

## Fixed

- The `goldenPIR` function now uses the correct function to print parse errors, so they are now printed in a human-readable way.

- PIR, PLC and UPLC term parsers can now parse comments.
