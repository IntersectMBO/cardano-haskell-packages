# Revision history for trace-dispatcher

## 0.2.0.0 -- May 2023

* Undocumented changes

## 0.1.0.0 -- October 2022

* First version. Released on an unsuspecting world.
