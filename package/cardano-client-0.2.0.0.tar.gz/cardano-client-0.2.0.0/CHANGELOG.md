# Revision history for cardano-client

## 0.2.0.0 -- 2023-04-25

### Breaking changes

* Make `cardano-client` independent of `ouroboros-consensus-diffusion`.  Look
  at haddocks how to upgrade.

## 0.1.0.2 -- 2023-01-25

* Update dependencies after repository restructure

## 0.1.0.0 -- 2020-05-18

* Initial release
