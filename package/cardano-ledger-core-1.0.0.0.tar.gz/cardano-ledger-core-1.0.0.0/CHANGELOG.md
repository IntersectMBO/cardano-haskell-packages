# Version history for `cardano-ledger-core`

## 1.0.0.0

* First properly versioned release.
