# Version history for `cardano-ledger-conway`

## 1.0.0.0

* First properly versioned release.
