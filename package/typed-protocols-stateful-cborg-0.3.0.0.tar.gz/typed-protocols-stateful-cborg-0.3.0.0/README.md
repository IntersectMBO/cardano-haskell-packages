typed-protocols-stateful-cborg
==============================

[CBOR](https://hackage.haskell.org/package/cborg) codecs for
[typed-protocols-stateful](https://input-output-hk.github.io/ouroboros-network/typed-protocols/Network-TypedProtocol-Stateful-Peer.html)
package.
