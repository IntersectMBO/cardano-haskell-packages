{-# LANGUAGE DataKinds #-}
{-# LANGUAGE FlexibleContexts #-}
{-# LANGUAGE LambdaCase #-}
{-# LANGUAGE NumericUnderscores #-}
{-# LANGUAGE OverloadedLists #-}
{-# LANGUAGE PatternSynonyms #-}
{-# LANGUAGE ScopedTypeVariables #-}
{-# LANGUAGE TypeApplications #-}

module Test.Cardano.Ledger.Dijkstra.Imp.SubUtxowSpec (spec) where

import Cardano.Ledger.Address (bootstrapKeyHash)
import Cardano.Ledger.Allegra.Scripts (AllegraEraScript (..))
import Cardano.Ledger.Alonzo.Plutus.Context (CollectError (..))
import Cardano.Ledger.Alonzo.Scripts (eraLanguages)
import Cardano.Ledger.Alonzo.TxWits (unRedeemersL, unTxDatsL)
import Cardano.Ledger.BaseTypes (Inject (..), Mismatch (..), SlotNo (..), StrictMaybe (..))
import Cardano.Ledger.Conway.Governance (
  GovAction (..),
  Vote (..),
  Voter (..),
 )
import qualified Cardano.Ledger.Conway.Rules as Conway
import Cardano.Ledger.Core
import Cardano.Ledger.Credential (Credential (..), StakeReference (..), credKeyHashWitness)
import Cardano.Ledger.Dijkstra.Core
import Cardano.Ledger.Dijkstra.Rules (DijkstraSubUtxowPredFailure (..))
import Cardano.Ledger.Dijkstra.TxInfo (DijkstraContextError (..))
import Cardano.Ledger.Keys (asWitness, witVKeyHash)
import Cardano.Ledger.Plutus (
  Data (..),
  ExUnits (..),
  Language (..),
  SLanguage (..),
  hashData,
  hashPlutusScript,
  plutusBinary,
  withSLanguage,
 )
import Cardano.Ledger.Plutus.Language (asSLanguage)
import Cardano.Ledger.Shelley.Scripts (pattern RequireAllOf)
import Cardano.Ledger.State (StakePoolParams (..))
import qualified Data.List.NonEmpty as NE
import qualified Data.Map.Strict as Map
import qualified Data.OMap.Strict as OMap
import Data.Sequence.Strict (StrictSeq ((:<|)))
import qualified Data.Set as Set
import qualified Data.Set.NonEmpty as NES
import Lens.Micro ((%~), (&), (.~), (^.))
import qualified PlutusLedgerApi.Common as P
import Test.Cardano.Ledger.Core.KeyPair (mkWitnessesVKey)
import Test.Cardano.Ledger.Core.Utils (txInAt)
import Test.Cardano.Ledger.Dijkstra.ImpTest
import Test.Cardano.Ledger.Imp.Common
import Test.Cardano.Ledger.Plutus.Examples (alwaysSucceedsNoDatum, redeemerSameAsDatum)

spec :: forall era. DijkstraEraImp era => SpecWith (ImpInit (LedgerSpec era))
spec = describe "SUBUTXOW" $ do
  -- TODO: `SubUtxoFailure`, which embeds the SUBUTXO rule's failures,
  -- has no test here, and the SUBUTXO rule has no spec of its own, so
  -- nothing exercises the embedding.
  it "SubInvalidWitnessesUTXOW" $ do
    keyHash <- freshKeyHash @Payment
    keyPair <- getKeyPair $ asWitness keyHash
    txIn <- sendCoinTo (mkAddr keyHash StakeRefNull) mempty
    staleBodyHash <- arbitrary
    let subTx :: Tx SubTx era
        subTx = mkBasicTx $ mkBasicTxBody & inputsTxBodyL .~ [txIn]
        plantStaleWitness =
          pure . (witsTxL . addrTxWitsL .~ mkWitnessesVKey staleBodyHash [keyPair])
    withPostFixupSubTxs plantStaleWitness $
      submitFailingTx
        (mkTopTxWithSubTxs [subTx])
        [injectFailure . SubInvalidWitnessesUTXOW @era $ pure (vKey keyPair)]

  describe "SubMissingVKeyWitnessesUTXOW" $ do
    let withheldWitnessFails mkSubTx = do
          (subTx, keyHash) <- mkSubTx
          let dropWitness =
                pure
                  . (witsTxL . addrTxWitsL %~ Set.filter ((/= keyHash) . witVKeyHash))
                  . (witsTxL . bootAddrTxWitsL .~ mempty)
          withPostFixupSubTxs dropWitness $
            submitFailingTx
              (mkTopTxWithSubTxs [subTx])
              [injectFailure . SubMissingVKeyWitnessesUTXOW @era $ NES.singleton keyHash]

    forM_ (missingVKeyWitnessSources @era) $ \(sourceName, mkSubTx) ->
      it sourceName $ withheldWitnessFails mkSubTx

    -- https://github.com/IntersectMBO/formal-ledger-specifications/issues/1280
    -- TODO: Re-enable after issue is resolved, by removing this override
    disableInConformanceIt "spending a bootstrap address input" $
      withheldWitnessFails $ do
        bootAddr <- freshBootstrapAddress
        txIn <- sendCoinTo (AddrBootstrap bootAddr) mempty
        pure
          ( mkBasicTx $ mkBasicTxBody & inputsTxBodyL .~ [txIn]
          , asWitness $ bootstrapKeyHash bootAddr
          )

    it "registering a stake pool with an owner" $
      withheldWitnessFails $ do
        poolKeyHash <- freshKeyHash
        ownerKeyHash <- freshKeyHash
        accountAddress <- registerStakeCredential . KeyHashObj =<< freshKeyHash
        poolParams <- freshPoolParams poolKeyHash accountAddress
        pure
          ( mkBasicTx $
              mkBasicTxBody
                & certsTxBodyL
                  .~ [RegPoolTxCert poolParams {sppOwners = Set.singleton ownerKeyHash}]
          , asWitness ownerKeyHash
          )

  describe "SubScriptWitnessNotValidatingUTXOW" $ do
    let failingScriptFails mkSubTx = do
          (subTx, scriptHash) <- mkSubTx
          submitFailingTx
            (mkTopTxWithSubTxs [subTx])
            [injectFailure . SubScriptWitnessNotValidatingUTXOW @era $ NES.singleton scriptHash]

    forM_ (failingNativeScriptPurposes @era) $ \(purposeName, mkSubTx) ->
      it purposeName $ failingScriptFails mkSubTx

    -- https://github.com/IntersectMBO/formal-ledger-specifications/issues/1279
    -- TODO: Re-enable after issue is resolved, by removing this override
    disableInConformanceIt "minting" $
      failingScriptFails $ do
        scriptHash <- unsatisfiableTimeLock
        subTx <- mkTokenMintingTx scriptHash
        pure (subTx, scriptHash)

  it "SubMissingTxMetadata" $ do
    auxData <- arbitrary @(TxAuxData era)
    let auxDataHash = hashTxAuxData auxData
        subTx :: Tx SubTx era
        subTx = mkBasicTx $ mkBasicTxBody & auxDataHashTxBodyL .~ SJust auxDataHash
    submitFailingTx
      (mkTopTxWithSubTxs [subTx])
      [injectFailure $ SubMissingTxMetadata @era auxDataHash]

  it "SubConflictingMetadataHash" $ do
    auxData <- arbitrary @(TxAuxData era)
    wrongAuxDataHash <- arbitrary @TxAuxDataHash
    let subTx :: Tx SubTx era
        subTx =
          mkBasicTx mkBasicTxBody
            & bodyTxL . auxDataHashTxBodyL .~ SJust wrongAuxDataHash
            & auxDataTxL .~ SJust auxData
    submitFailingTx
      (mkTopTxWithSubTxs [subTx])
      [ injectFailure . SubConflictingMetadataHash @era $
          Mismatch
            { mismatchSupplied = wrongAuxDataHash
            , mismatchExpected = hashTxAuxData auxData
            }
      ]

  it "SubMissingTxBodyMetadataHash" $ do
    auxData <- arbitrary @(TxAuxData era)
    let subTx :: Tx SubTx era
        subTx = mkBasicTx mkBasicTxBody & auxDataTxL .~ SJust auxData
        dropAuxDataHash =
          rederiveAddrTxWits . (bodyTxL . auxDataHashTxBodyL .~ SNothing)
    withPostFixupSubTxs dropAuxDataHash $
      submitFailingTx
        (mkTopTxWithSubTxs [subTx])
        [injectFailure . SubMissingTxBodyMetadataHash @era $ hashTxAuxData auxData]

  describe "SubExtraRedeemers" $ do
    it "for a native script, which takes no redeemer" $ do
      scriptHash <- impAddNativeScript $ RequireAllOf []
      txIn <- produceScript scriptHash
      collateralInput <- makeCollateralInput
      redeemerData <- arbitrary
      let extraPurpose = mkSpendingPurpose $ AsIx 0
          subTx :: Tx SubTx era
          subTx = mkBasicTx $ mkBasicTxBody & inputsTxBodyL .~ [txIn]
          topTx =
            mkTopTxWithSubTxs [subTx]
              & bodyTxL . collateralInputsTxBodyL .~ [collateralInput]
          addExtraRedeemer =
            (fixupPPHash >=> rederiveAddrTxWits)
              . ( witsTxL . rdmrsTxWitsL . unRedeemersL
                    %~ Map.insert extraPurpose (redeemerData, ExUnits 0 0)
                )
      withPostFixupSubTxs addExtraRedeemer $
        submitFailingTx topTx [injectFailure $ SubExtraRedeemers @era [extraPurpose]]

    it "at an index that points at no item" $ do
      keyHash <- freshKeyHash @Payment
      txIn <- sendCoinTo (mkAddr keyHash StakeRefNull) mempty
      collateralInput <- makeCollateralInput
      redeemerData <- arbitrary
      let extraPurpose = mkSpendingPurpose $ AsIx 99
          subTx :: Tx SubTx era
          subTx = mkBasicTx $ mkBasicTxBody & inputsTxBodyL .~ [txIn]
          topTx =
            mkTopTxWithSubTxs [subTx]
              & bodyTxL . collateralInputsTxBodyL .~ [collateralInput]
          addExtraRedeemer =
            (fixupPPHash >=> rederiveAddrTxWits)
              . ( witsTxL . rdmrsTxWitsL . unRedeemersL
                    %~ Map.insert extraPurpose (redeemerData, ExUnits 0 0)
                )
      withPostFixupSubTxs addExtraRedeemer $
        submitFailingTx topTx [injectFailure $ SubExtraRedeemers @era [extraPurpose]]

  -- `SubPPViewHashesDontMatch` is the other failure
  -- `checkScriptIntegrityHash` can raise. It is unreachable in
  -- Dijkstra: it is selected only below protocol version 11, and
  -- Dijkstra is pinned to 12.
  describe "SubScriptIntegrityHashMismatch" $
    it "when no script requires an integrity hash" $ do
      badHash <- arbitrary
      let subTx :: Tx SubTx era
          subTx = mkBasicTx mkBasicTxBody
          supplyIntegrityHash =
            rederiveAddrTxWits . (bodyTxL . scriptIntegrityHashTxBodyL .~ SJust badHash)
      withPostFixupSubTxs supplyIntegrityHash $
        submitFailingTx
          (mkTopTxWithSubTxs [subTx])
          [ injectFailure $
              SubScriptIntegrityHashMismatch @era
                Mismatch {mismatchSupplied = SJust badHash, mismatchExpected = SNothing}
                SNothing
          ]

  describe "SubMalformedGuardDatums" $
    forM_ (malformedGuardDatumCases @era) $ \(caseName, mkGuard) ->
      it caseName $ do
        (guardCred, requiredGuards) <- mkGuard
        let subTx :: Tx SubTx era
            subTx = mkBasicTx $ mkBasicTxBody & requiredTopLevelGuardsL .~ requiredGuards
            topTx =
              mkTopTxWithSubTxs [subTx]
                & bodyTxL . guardsTxBodyL .~ [guardCred]
        submitFailingTx
          topTx
          [injectFailure . SubMalformedGuardDatums @era $ NES.singleton guardCred]

  -- The filter mirrors the rule: `getInputDataHashesTxBody` records
  -- an input as unspendable only when its spending script is below
  -- PlutusV3, since CIP-0069 made spending datums optional from V3 on.
  describe "SubUnspendableUTxONoDatumHash, for languages that require a spending datum" $
    forM_ (filter (< PlutusV3) (eraLanguages @era)) $ \lang ->
      withSLanguage lang $ \slang ->
        it (show lang) $ do
          let scriptHash = hashPlutusScript $ redeemerSameAsDatum slang
          txIn <- impAnn "Produce a script output with no datum hash" $ do
            let addr = mkAddr scriptHash StakeRefNull
                tx =
                  mkBasicTx mkBasicTxBody
                    & bodyTxL . outputsTxBodyL .~ [mkBasicTxOut addr mempty]
                resetTxOutDataHash =
                  bodyTxL . outputsTxBodyL
                    %~ ( \case
                           h :<| r -> (h & dataHashTxOutL .~ SNothing) :<| r
                           _ -> error "Expected non-empty outputs"
                       )
            txInAt 0
              <$> withPostFixup (rederiveAddrTxWits . resetTxOutDataHash) (submitTx tx)
          submitFailingLegacySubTx
            lang
            (mkTopTxWithSubTxs [mkBasicTx $ mkBasicTxBody & inputsTxBodyL .~ [txIn]])
            (SubUnspendableUTxONoDatumHash @era $ NES.singleton txIn)

  forM_ (eraLanguages @era) $ \lang ->
    withSLanguage lang $ \slang ->
      describe (show lang) $ do
        let redeemerSameAsDatumHash = hashPlutusScript $ redeemerSameAsDatum slang
            fixupResetAddrWits = fixupPPHash >=> rederiveAddrTxWits
            scriptSpendingSubTx txIn = mkBasicTx $ mkBasicTxBody & inputsTxBodyL .~ [txIn]

        it "SubMissingRequiredDatums" $ do
          txIn <- produceScript redeemerSameAsDatumHash
          let missingDatum = hashData @era (Data (P.I 3))
          withPostFixupSubTxs (fixupResetAddrWits . (witsTxL . datsTxWitsL .~ mempty)) $
            submitFailingLegacySubTx
              lang
              (mkTopTxWithSubTxs [scriptSpendingSubTx txIn])
              (SubMissingRequiredDatums @era (NES.singleton missingDatum) [])

        it "SubNotAllowedSupplementalDatums" $ do
          txIn <- produceScript redeemerSameAsDatumHash
          let extraDatum = Data (P.I 30)
              extraDatumHash = hashData @era extraDatum
              addExtraDatum =
                fixupResetAddrWits
                  . ( witsTxL . datsTxWitsL . unTxDatsL
                        %~ Map.insert extraDatumHash extraDatum
                    )
          withPostFixupSubTxs addExtraDatum $
            submitFailingLegacySubTx
              lang
              (mkTopTxWithSubTxs [scriptSpendingSubTx txIn])
              (SubNotAllowedSupplementalDatums @era (NES.singleton extraDatumHash) [])

        it "SubMissingRedeemers" $ do
          txIn <- produceScript redeemerSameAsDatumHash
          let missingRedeemer = mkSpendingPurpose $ AsItem txIn
          withPostFixupSubTxs (fixupResetAddrWits . (witsTxL . rdmrsTxWitsL .~ mempty)) $
            submitFailingTx
              (mkTopTxWithSubTxs [scriptSpendingSubTx txIn])
              [ injectFailure $ Conway.CollectErrors [NoRedeemer missingRedeemer]
              , injectFailure $
                  SubMissingRedeemers @era [(missingRedeemer, redeemerSameAsDatumHash)]
              ]

        it "SubExtraRedeemers, alongside a needed redeemer" $ do
          txIn <- produceScript redeemerSameAsDatumHash
          redeemerData <- arbitrary
          let extraPurpose = mkMintingPurpose $ AsIx 2
              addExtraRedeemer =
                fixupResetAddrWits
                  . ( witsTxL . rdmrsTxWitsL . unRedeemersL
                        %~ Map.insert extraPurpose (redeemerData, ExUnits 0 0)
                    )
          withPostFixupSubTxs addExtraRedeemer $
            submitFailingLegacySubTx
              lang
              (mkTopTxWithSubTxs [scriptSpendingSubTx txIn])
              (SubExtraRedeemers @era [extraPurpose])

        describe "SubScriptIntegrityHashMismatch" $ do
          let testHashMismatch badHash = do
                txIn <- produceScript redeemerSameAsDatumHash
                let topTx = mkTopTxWithSubTxs [scriptSpendingSubTx txIn]
                fixedUpTx <- fixupTx topTx
                let fixedUpSubTxs = OMap.elems $ fixedUpTx ^. bodyTxL . subTransactionsTxBodyL
                fixedUpSubTx <- case fixedUpSubTxs of
                  [subTx] -> pure subTx
                  _ -> assertFailure "Expected exactly one sub-transaction"
                let goodHash = fixedUpSubTx ^. bodyTxL . scriptIntegrityHashTxBodyL
                expectedIntegrity <- impComputeScriptIntegrity fixedUpSubTx
                badSubTx <-
                  rederiveAddrTxWits $
                    fixedUpSubTx & bodyTxL . scriptIntegrityHashTxBodyL .~ badHash
                badTopTx <-
                  rederiveAddrTxWits $
                    fixedUpTx & bodyTxL . subTransactionsTxBodyL .~ OMap.singleton badSubTx
                withNoFixup $
                  submitFailingLegacySubTx lang badTopTx $
                    SubScriptIntegrityHashMismatch @era
                      Mismatch {mismatchSupplied = badHash, mismatchExpected = goodHash}
                      (originalBytes <$> expectedIntegrity)
          it "the supplied hash is wrong" $ testHashMismatch . SJust =<< arbitrary
          it "the supplied hash is missing" $ testHashMismatch SNothing

        it "SubMalformedScriptWitnesses" $ do
          let scriptHash = hashPlutusScript $ asSLanguage slang malformedPlutus
          txIn <- produceScript scriptHash
          submitFailingLegacySubTx
            lang
            (mkTopTxWithSubTxs [scriptSpendingSubTx txIn])
            (SubMalformedScriptWitnesses @era $ NES.singleton scriptHash)

        -- https://github.com/IntersectMBO/formal-ledger-specifications/issues/1287
        -- TODO: Re-enable after issue is resolved, by removing this override
        disableInConformanceIt "SubMalformedReferenceScripts" $ do
          script <- fromPlutusScript <$> mkPlutusScript (asSLanguage slang malformedPlutus)
          addr <- freshKeyAddrNoPtr_
          let subTx :: Tx SubTx era
              subTx =
                mkBasicTx $
                  mkBasicTxBody
                    & outputsTxBodyL
                      .~ [mkBasicTxOut addr mempty & referenceScriptTxOutL .~ SJust script]
          submitFailingTx
            (mkTopTxWithSubTxs [subTx])
            [ injectFailure . SubMalformedReferenceScripts @era . NES.singleton $
                hashScript script
            ]

        -- https://github.com/IntersectMBO/formal-ledger-specifications/issues/1323
        -- TODO: Re-enable after issue is resolved, by removing this override
        disableInConformanceIt "SubInvalidMetadata" $ do
          let auxData :: TxAuxData era
              auxData =
                mkBasicTxAuxData
                  & plutusScriptsTxAuxDataL
                    .~ Map.singleton lang (pure . plutusBinary $ asSLanguage slang malformedPlutus)
              subTx :: Tx SubTx era
              subTx = mkBasicTx mkBasicTxBody & auxDataTxL .~ SJust auxData
          submitFailingTx
            (mkTopTxWithSubTxs [subTx])
            [injectFailure $ SubInvalidMetadata @era]

-- Legacy sub-transaction scripts also fail context translation, independently
-- of the SUBUTXOW predicate under test. Fixup can change the sub-transaction id.
submitFailingLegacySubTx ::
  forall era.
  DijkstraEraImp era =>
  Language ->
  Tx TopTx era ->
  DijkstraSubUtxowPredFailure era ->
  ImpTestM era ()
submitFailingLegacySubTx lang tx expectedFailure =
  submitFailingTxM tx $ \fixedUpTx ->
    case OMap.elems $ fixedUpTx ^. bodyTxL . subTransactionsTxBodyL of
      [subTx] ->
        pure
          [ injectFailure $
              Conway.CollectErrors
                [BadTranslation . inject $ UnsupportedScriptInSubTx @era lang (txIdTx subTx)]
          , injectFailure expectedFailure
          ]
      _ -> assertFailure "Expected exactly one sub-transaction"

-- | Every distinct reason a sub-transaction requires a key witness,
-- paired with a sub-transaction that requires it and the key hash whose
-- witness is to be withheld.
missingVKeyWitnessSources ::
  forall era.
  DijkstraEraImp era =>
  [(String, ImpTestM era (Tx SubTx era, KeyHash Witness))]
missingVKeyWitnessSources =
  [
    ( "spending a key hash locked input"
    , do
        keyHash <- freshKeyHash @Payment
        txIn <- sendCoinTo (mkAddr keyHash StakeRefNull) mempty
        pure (mkBasicTx $ mkBasicTxBody & inputsTxBodyL .~ [txIn], asWitness keyHash)
    )
  ,
    ( "unregistering a staking credential"
    , do
        keyHash <- freshKeyHash
        void . registerStakeCredential $ KeyHashObj keyHash
        deposit <- getsPParams ppKeyDepositL
        pure
          ( mkBasicTx $
              mkBasicTxBody
                & certsTxBodyL .~ [UnRegDepositTxCert (KeyHashObj keyHash) deposit]
          , asWitness keyHash
          )
    )
  ,
    ( "withdrawing from an account"
    , do
        keyHash <- freshKeyHash
        accountAddress <- registerStakeCredential $ KeyHashObj keyHash
        pure
          ( mkBasicTx $
              mkBasicTxBody & withdrawalsTxBodyL .~ Withdrawals [(accountAddress, mempty)]
          , asWitness keyHash
          )
    )
  ,
    ( "requiring a key hash guard"
    , do
        keyHash <- freshKeyHash
        pure
          ( mkBasicTx $ mkBasicTxBody & guardsTxBodyL .~ [KeyHashObj keyHash]
          , asWitness keyHash
          )
    )
  ,
    ( "voting as a DRep"
    , do
        (drepCredential, _, _) <- setupSingleDRep 1_000_000
        govActionId <- submitGovAction InfoAction
        keyHash <- expectJust $ credKeyHashWitness drepCredential
        pure (voteSubTx VoteYes (DRepVoter drepCredential) govActionId, keyHash)
    )
  ,
    ( "voting as a committee member"
    , do
        hotCredential <- NE.head <$> registerInitialCommittee
        govActionId <- submitGovAction InfoAction
        keyHash <- expectJust $ credKeyHashWitness hotCredential
        pure (voteSubTx VoteYes (CommitteeVoter hotCredential) govActionId, keyHash)
    )
  ,
    ( "voting as a stake pool"
    , do
        poolKeyHash <- freshKeyHash
        registerPool poolKeyHash
        govActionId <- submitGovAction InfoAction
        pure (voteSubTx VoteYes (StakePoolVoter poolKeyHash) govActionId, asWitness poolKeyHash)
    )
  ]

-- | Every script purpose at which a sub-transaction can require a
-- native script, paired with a sub-transaction that needs a failing
-- script for that purpose and the hash of that script.
failingNativeScriptPurposes ::
  forall era.
  DijkstraEraImp era =>
  [(String, ImpTestM era (Tx SubTx era, ScriptHash))]
failingNativeScriptPurposes =
  [
    ( "spending"
    , do
        scriptHash <- unsatisfiableTimeLock
        txIn <- produceScript scriptHash
        pure (mkBasicTx $ mkBasicTxBody & inputsTxBodyL .~ [txIn], scriptHash)
    )
  ,
    ( "certifying"
    , do
        scriptHash <- unsatisfiableTimeLock
        deposit <- getsPParams ppKeyDepositL
        pure
          ( mkBasicTx $
              mkBasicTxBody
                & certsTxBodyL .~ [RegDepositTxCert (ScriptHashObj scriptHash) deposit]
          , scriptHash
          )
    )
  ,
    ( "guarding"
    , do
        scriptHash <- unsatisfiableTimeLock
        pure
          ( mkBasicTx $ mkBasicTxBody & guardsTxBodyL .~ [ScriptHashObj scriptHash]
          , scriptHash
          )
    )
  ,
    ( "withdrawing"
    , do
        (scriptHash, accountAddress) <- registerLowerBoundTimeLockAccount
        pure
          ( mkBasicTx $
              mkBasicTxBody & withdrawalsTxBodyL .~ Withdrawals [(accountAddress, mempty)]
          , scriptHash
          )
    )
  ,
    ( "voting"
    , do
        scriptHash <- registerLowerBoundTimeLockDRep
        govActionId <- submitGovAction InfoAction
        pure (voteSubTx VoteYes (DRepVoter (ScriptHashObj scriptHash)) govActionId, scriptHash)
    )
  ]

-- | A time lock that no sub-transaction can satisfy.
unsatisfiableTimeLock :: DijkstraEraImp era => ImpTestM era ScriptHash
unsatisfiableTimeLock = impAddNativeScript $ mkTimeStart (SlotNo maxBound)

-- | A time lock that is satisfied only by a transaction that declares a
-- lower bound on its validity interval. Registering the credential that
-- it locks therefore succeeds, while a sub-transaction, which declares
-- no lower bound, fails to satisfy it.
lowerBoundTimeLock :: DijkstraEraImp era => ImpTestM era ScriptHash
lowerBoundTimeLock = impAddNativeScript $ mkTimeStart lowerBoundSlot

lowerBoundSlot :: SlotNo
lowerBoundSlot = SlotNo 1

registerLowerBoundTimeLockAccount ::
  DijkstraEraImp era => ImpTestM era (ScriptHash, AccountAddress)
registerLowerBoundTimeLockAccount = do
  scriptHash <- lowerBoundTimeLock
  deposit <- getsPParams ppKeyDepositL
  submitTx_ $
    mkBasicTx mkBasicTxBody
      & bodyTxL . certsTxBodyL .~ [RegDepositTxCert (ScriptHashObj scriptHash) deposit]
      & bodyTxL . vldtTxBodyL .~ ValidityInterval (SJust lowerBoundSlot) SNothing
  accountAddress <- getAccountAddressFor $ ScriptHashObj scriptHash
  pure (scriptHash, accountAddress)

registerLowerBoundTimeLockDRep :: DijkstraEraImp era => ImpTestM era ScriptHash
registerLowerBoundTimeLockDRep = do
  scriptHash <- lowerBoundTimeLock
  deposit <- getsPParams ppDRepDepositL
  submitTx_ $
    mkBasicTx mkBasicTxBody
      & bodyTxL . certsTxBodyL .~ [RegDRepTxCert (ScriptHashObj scriptHash) deposit SNothing]
      & bodyTxL . vldtTxBodyL .~ ValidityInterval (SJust lowerBoundSlot) SNothing
  pure scriptHash

-- | The ways a guard credential can carry the wrong datum presence,
-- paired with the guard credential and the @requiredTopLevelGuards@
-- entry that makes it malformed.
malformedGuardDatumCases ::
  forall era.
  DijkstraEraImp era =>
  [ ( String
    , ImpTestM era (Credential Guard, Map.Map (Credential Guard) (StrictMaybe (Data era)))
    )
  ]
malformedGuardDatumCases =
  [
    ( "a key hash guard carrying a datum"
    , do
        guardCred <- KeyHashObj <$> freshKeyHash
        datum <- arbitrary @(Data era)
        pure (guardCred, Map.singleton guardCred (SJust datum))
    )
  ,
    ( "a native script guard carrying a datum"
    , do
        guardCred <- ScriptHashObj <$> impAddNativeScript (RequireAllOf [])
        datum <- arbitrary @(Data era)
        pure (guardCred, Map.singleton guardCred (SJust datum))
    )
  ,
    ( "a Plutus script guard without a datum"
    , do
        -- TODO: Plutus guards require PlutusV4, which `eraLanguages`
        -- does not reach while `eraMaxLanguage` is PlutusV3, so this
        -- row names the language directly instead of iterating.
        plutusScript <- mkPlutusScript $ alwaysSucceedsNoDatum SPlutusV4
        let guardScript = fromPlutusScript plutusScript :: Script era
            guardCred = ScriptHashObj $ hashScript guardScript
        pure (guardCred, Map.singleton guardCred SNothing)
    )
  ]
