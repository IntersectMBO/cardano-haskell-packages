{-# LANGUAGE AllowAmbiguousTypes #-}
{-# LANGUAGE DataKinds #-}
{-# LANGUAGE FlexibleContexts #-}
{-# LANGUAGE NumericUnderscores #-}
{-# LANGUAGE OverloadedLists #-}
{-# LANGUAGE ScopedTypeVariables #-}
{-# LANGUAGE TypeApplications #-}

module Test.Cardano.Ledger.Dijkstra.Imp.EntitiesSpec (spec) where

import Cardano.Base.Typeable (Typeable)
import Cardano.Ledger.Address
import Cardano.Ledger.BaseTypes
import Cardano.Ledger.Coin (Coin (..))
import Cardano.Ledger.Credential (Credential (..))
import Cardano.Ledger.Dijkstra.Core
import Cardano.Ledger.Dijkstra.Rules (
  EntitiesPredFailure (..),
  SubEntitiesPredFailure (..),
 )
import Cardano.Ledger.Dijkstra.Scripts (AccountBalanceInterval (..), AccountBalanceIntervals (..))
import Cardano.Ledger.Val (Val (..))
import qualified Data.Map.NonEmpty as NEM
import Data.Maybe (fromJust)
import qualified Data.OMap.Strict as OMap
import qualified Data.Set.NonEmpty as NES
import Lens.Micro
import Test.Cardano.Ledger.Dijkstra.ImpTest
import Test.Cardano.Ledger.Imp.Common

spec :: forall era. DijkstraEraImp era => SpecWith (ImpInit (LedgerSpec era))
spec = describe "ENTITIES" $ do
  it "Batch with successful withdrawals and direct deposits" $ do
    (acc1, balance1, kh1) <- setupAccountAddress
    (acc2, balance2, kh2) <- setupAccountAddress
    (acc3, balance3, kh3) <- setupAccountAddress

    let depositAmount = Coin 50
        partialWithdrawal = balance3 <-> Coin 10
        subDeposit =
          mkBasicTx $
            mkBasicTxBody
              & directDepositsTxBodyL .~ DirectDeposits [(acc1, depositAmount)]
        subWithdraw =
          mkBasicTx $
            mkBasicTxBody
              & withdrawalsTxBodyL .~ Withdrawals [(acc2, balance2)]
        topTx =
          mkBasicTx $
            mkBasicTxBody
              & withdrawalsTxBodyL .~ Withdrawals [(acc3, partialWithdrawal)]
              & subTransactionsTxBodyL .~ [subDeposit, subWithdraw]
    submitTx_ topTx

    finalBalance1 <- getBalance (KeyHashObj kh1)
    finalBalance2 <- getBalance (KeyHashObj kh2)
    finalBalanceD <- getBalance (KeyHashObj kh3)

    finalBalance1 `shouldBe` balance1 <+> depositAmount
    finalBalance2 `shouldBe` mempty
    finalBalanceD `shouldBe` (balance3 <-> partialWithdrawal)

  it "Partial withdrawals" $ do
    (account1, balance1, kh1) <- setupAccountAddress
    (account2, balance2, kh2) <- setupAccountAddress
    lessThanBalance1 <- Coin <$> choose (1, unCoin balance1 - 1)
    atMostBalance2 <- Coin <$> choose (1, unCoin balance2)
    let tx =
          mkTxWithBatchWithdrawals
            (Withdrawals [(account1, lessThanBalance1)])
            [Withdrawals [(account2, atMostBalance2)]]
    submitTx_ tx
    getBalance (KeyHashObj kh1) `shouldReturn` (balance1 <-> lessThanBalance1)
    getBalance (KeyHashObj kh2) `shouldReturn` (balance2 <-> atMostBalance2)

    -- restore balances, to test legacy mode
    submitTx_ $
      mkBasicTx $
        mkBasicTxBody
          & directDepositsTxBodyL .~ DirectDeposits [(account1, lessThanBalance1), (account2, atMostBalance2)]
    legacyTx <- switchTxToLegacyMode tx
    submitFailingTx
      legacyTx
      [ injectFailure . WithdrawalAmountsInexactInLegacyMode @era $
          NEM.singleton account1 $
            Mismatch lessThanBalance1 balance1
      ]

    -- drain top withdrawal
    submitTx_
      =<< switchTxToLegacyMode
        ( mkTxWithBatchWithdrawals
            (Withdrawals [(account1, balance1)])
            [Withdrawals [(account2, atMostBalance2)]]
        )
    getBalance (KeyHashObj kh1) `shouldReturn` zero
    getBalance (KeyHashObj kh2) `shouldReturn` (balance2 <-> atMostBalance2)

  it "Withdrawals from an unregistered staking address" $ do
    account1 <- freshKeyHash >>= getAccountAddressFor . KeyHashObj
    account2 <- freshKeyHash >>= getAccountAddressFor . KeyHashObj
    amountX <- Coin . getPositive <$> arbitrary
    let
      txBody :: forall l. Typeable l => TxBody l era
      txBody =
        mkBasicTxBody
          & withdrawalsTxBodyL .~ Withdrawals [(account1, amountX), (account2, zero)]
    submitFailingTx
      (mkBasicTx txBody)
      [ injectFailure . WithdrawalAccountsMissingFromOriginal @era $
          Withdrawals [(account1, amountX), (account2, zero)]
      ]

    account3 <- freshKeyHash >>= getAccountAddressFor . KeyHashObj
    amountY <- Coin . getPositive <$> arbitrary
    let subTxOnlyWithdrawal =
          mkBasicTx $
            mkBasicTxBody
              & withdrawalsTxBodyL .~ Withdrawals [(account3, amountY)]
    submitFailingTx
      (mkBasicTx $ txBody & subTransactionsTxBodyL .~ [mkBasicTx txBody, subTxOnlyWithdrawal])
      [ injectFailure . WithdrawalAccountsMissingFromOriginal @era $
          Withdrawals [(account1, amountX), (account2, zero)]
      , injectFailure . SubWithdrawalAccountsMissingFromOriginal @era $
          Withdrawals [(account1, amountX), (account2, zero)]
      , injectFailure . SubWithdrawalAccountsMissing @era $
          Withdrawals [(account1, amountX), (account2, zero)]
      , injectFailure . SubWithdrawalAccountsMissingFromOriginal @era $
          Withdrawals [(account3, amountY)]
      , injectFailure . SubWithdrawalAccountsMissing @era $
          Withdrawals [(account3, amountY)]
      ]

  it "Withdrawals from an account unregistered by an earlier sub-transaction" $ do
    stakingCred <- KeyHashObj <$> freshKeyHash
    keyDeposit <- getsPParams ppKeyDepositL
    account <- registerStakeCredential stakingCred
    let subUnregister =
          mkBasicTx $
            mkBasicTxBody
              & certsTxBodyL .~ [UnRegDepositTxCert stakingCred keyDeposit]
        subWithdraw =
          mkBasicTx $
            mkBasicTxBody
              & withdrawalsTxBodyL .~ Withdrawals [(account, zero)]
        tx =
          mkBasicTx $
            mkBasicTxBody
              & subTransactionsTxBodyL .~ [subUnregister, subWithdraw]

    -- the account is still present in the original accounts, so only the check
    -- against the updated accounts fails
    submitFailingTx
      tx
      [ injectFailure . SubWithdrawalAccountsMissing @era $
          Withdrawals [(account, zero)]
      ]

  it "Top-level withdrawal from an account unregistered by a sub-transaction" $ do
    stakingCred <- KeyHashObj <$> freshKeyHash
    keyDeposit <- getsPParams ppKeyDepositL
    account <- registerStakeCredential stakingCred
    let subUnregister =
          mkBasicTx $
            mkBasicTxBody
              & certsTxBodyL .~ [UnRegDepositTxCert stakingCred keyDeposit]
        tx =
          mkBasicTx $
            mkBasicTxBody
              & withdrawalsTxBodyL .~ Withdrawals [(account, zero)]
              & subTransactionsTxBodyL .~ [subUnregister]
        accountMissing =
          injectFailure . WithdrawalAccountsMissing @era $
            Withdrawals [(account, zero)]

    -- the aggregate check against the original accounts passes, since the account
    -- is still there with a zero balance
    submitFailingTx tx [accountMissing]

    legacyTx <- switchTxToLegacyMode tx
    submitFailingTx legacyTx [accountMissing]

  it "Direct deposits to an unregistered account" $ do
    account <- freshKeyHash >>= getAccountAddressFor . KeyHashObj
    amountX <- Coin . getPositive <$> arbitrary
    let
      txBody :: forall l. Typeable l => TxBody l era
      txBody = mkBasicTxBody & directDepositsTxBodyL .~ DirectDeposits [(account, amountX)]
    submitFailingTx
      (mkBasicTx txBody)
      [ injectFailure . DirectDepositAccountsMissing @era $
          DirectDeposits [(account, amountX)]
      ]

    account2 <- freshKeyHash >>= getAccountAddressFor . KeyHashObj
    amountY <- Coin . getPositive <$> arbitrary
    amountZ <- Coin . getPositive <$> arbitrary
    let subTxOnlyDirectDeposit =
          mkBasicTx $
            mkBasicTxBody & directDepositsTxBodyL .~ DirectDeposits [(account, amountY), (account2, amountZ)]
    submitFailingTx
      (mkBasicTx $ txBody & subTransactionsTxBodyL .~ [mkBasicTx txBody, subTxOnlyDirectDeposit])
      [ injectFailure . DirectDepositAccountsMissing @era $
          DirectDeposits [(account, amountX)]
      , injectFailure . SubDirectDepositAccountsMissing @era $
          DirectDeposits [(account, amountX)]
      , injectFailure . SubDirectDepositAccountsMissing @era $
          DirectDeposits [(account, amountY), (account2, amountZ)]
      ]

  it "Withdrawals and direct deposits with wrong network id" $ do
    stakeKey <- freshKeyHash
    accountAddress <- registerStakeCredential (KeyHashObj stakeKey)
    let wrongNetworkAccount = accountAddress & accountAddressNetworkIdL .~ Mainnet
    let dd = DirectDeposits [(wrongNetworkAccount, Coin 50)]
    let txBody :: forall l. Typeable l => TxBody l era
        txBody =
          mkBasicTxBody
            & withdrawalsTxBodyL
              .~ Withdrawals [(wrongNetworkAccount, mempty)]
            & directDepositsTxBodyL .~ dd

    submitFailingTx
      (mkBasicTx txBody)
      [ injectFailure . WithdrawalAddressesWithWrongNetwork @era Testnet $ NES.singleton wrongNetworkAccount
      , injectFailure . DirectDepositAddressesWithWrongNetwork @era Testnet $
          NES.singleton wrongNetworkAccount
      , injectFailure . WithdrawalAccountsMissingFromOriginal @era $
          Withdrawals [(wrongNetworkAccount, mempty)]
      , injectFailure . DirectDepositAccountsMissing @era $ dd
      ]

    submitFailingTx
      (mkBasicTx $ txBody & subTransactionsTxBodyL .~ [mkBasicTx txBody])
      [ injectFailure . WithdrawalAddressesWithWrongNetwork @era Testnet $
          NES.singleton wrongNetworkAccount
      , injectFailure . DirectDepositAddressesWithWrongNetwork @era Testnet $
          NES.singleton wrongNetworkAccount
      , injectFailure . WithdrawalAccountsMissingFromOriginal @era $
          Withdrawals [(wrongNetworkAccount, mempty)]
      , injectFailure . DirectDepositAccountsMissing @era $ dd
      , injectFailure . SubWithdrawalAddressesWithWrongNetwork @era Testnet $
          NES.singleton wrongNetworkAccount
      , injectFailure . SubDirectDepositAddressesWithWrongNetwork @era Testnet $
          NES.singleton wrongNetworkAccount
      , injectFailure . SubWithdrawalAccountsMissingFromOriginal @era $
          Withdrawals [(wrongNetworkAccount, mempty)]
      , injectFailure . SubWithdrawalAccountsMissing @era $
          Withdrawals [(wrongNetworkAccount, mempty)]
      , injectFailure . SubDirectDepositAccountsMissing @era $ dd
      ]

  it "Aggregate of top and sub withdrawals exceeds account balance" $ do
    (account, balance, _) <- setupAccountAddress
    (topAmount, subAmount) <- genCoinPairExceeding balance
    let tx =
          mkTxWithBatchWithdrawals
            (Withdrawals [(account, topAmount)])
            [Withdrawals [(account, subAmount)]]
    submitFailingTx
      tx
      [ injectFailure $
          WithdrawalAmountsExceedingOriginalBalance @era $
            fromJust $
              NEM.fromMap [(account, Mismatch (topAmount <+> subAmount) balance)]
      ]
    -- legacy mode
    legacyTx <- switchTxToLegacyMode tx
    submitFailingTx
      legacyTx
      [ injectFailure . WithdrawalAmountsInexactInLegacyMode @era $
          NEM.singleton account $
            Mismatch topAmount (balance <-> subAmount)
      ]

  it "Aggregate of sub withdrawals exceeds account balance" $ do
    (account, balance, _) <- setupAccountAddress
    (subAmount1, subAmount2) <- genCoinPairExceeding balance
    (subAmount1 <+> subAmount2) `shouldSatisfy` (> balance)

    let tx =
          mkTxWithBatchWithdrawals
            (Withdrawals [(account, zero)])
            [Withdrawals [(account, subAmount1)], Withdrawals [(account, subAmount2)]]
    submitFailingTx
      tx
      [ injectFailure $
          WithdrawalAmountsExceedingOriginalBalance @era $
            fromJust $
              NEM.fromMap [(account, Mismatch (subAmount1 <+> subAmount2) balance)]
      ]
    legacyTx <- switchTxToLegacyMode tx
    submitFailingTx
      legacyTx
      [ injectFailure $
          WithdrawalAmountsExceedingOriginalBalance @era $
            fromJust $
              NEM.fromMap [(account, Mismatch (subAmount1 <+> subAmount2) balance)]
      ]

  it "Individual withdrawal exceeds account balance" $ do
    (account, balance, _) <- setupAccountAddress
    atMostBalance <- Coin <$> choose (1, unCoin balance)
    moreThanBalance <- (balance <+>) . Coin . getPositive <$> arbitrary

    -- A sub-transaction overdraws
    let subTxOverdraws =
          mkTxWithBatchWithdrawals
            (Withdrawals [(account, atMostBalance)])
            [Withdrawals [(account, moreThanBalance)]]
    submitFailingTx
      subTxOverdraws
      [ injectFailure $
          WithdrawalAmountsExceedingOriginalBalance @era $
            fromJust $
              NEM.fromMap [(account, Mismatch (atMostBalance <+> moreThanBalance) balance)]
      ]

    legacySubTxOverdraws <- switchTxToLegacyMode subTxOverdraws

    submitFailingTx
      legacySubTxOverdraws
      [ injectFailure $
          WithdrawalAmountsExceedingOriginalBalance @era $
            fromJust $
              NEM.fromMap [(account, Mismatch moreThanBalance balance)]
      ]

    -- The top transaction overdraws
    let topTxOverdraws =
          mkTxWithBatchWithdrawals
            (Withdrawals [(account, moreThanBalance)])
            [Withdrawals [(account, atMostBalance)]]
    submitFailingTx
      topTxOverdraws
      [ injectFailure $
          WithdrawalAmountsExceedingOriginalBalance @era $
            fromJust $
              NEM.fromMap
                [(account, Mismatch (atMostBalance <+> moreThanBalance) balance)]
      ]
    legacyTopTxOverdraws <- switchTxToLegacyMode topTxOverdraws
    submitFailingTx
      legacyTopTxOverdraws
      [ injectFailure . WithdrawalAmountsInexactInLegacyMode @era $
          NEM.singleton account $
            Mismatch moreThanBalance (balance <-> atMostBalance)
      ]

  it "Direct deposits cannot fund withdrawals in subsequent sub-transactions" $ do
    account <- registerStakeCredential . KeyHashObj =<< freshKeyHash
    depositAmount <- Coin . getPositive <$> arbitrary
    let subDeposit =
          mkBasicTx $
            mkBasicTxBody
              & directDepositsTxBodyL
                .~ DirectDeposits [(account, depositAmount)]
        subWithdraw =
          mkBasicTx $
            mkBasicTxBody
              & withdrawalsTxBodyL
                .~ Withdrawals [(account, depositAmount)]
        tx =
          mkBasicTx $
            mkBasicTxBody
              & subTransactionsTxBodyL .~ [subDeposit, subWithdraw]

    submitFailingTx
      tx
      [ injectFailure $
          WithdrawalAmountsExceedingOriginalBalance @era $
            fromJust $
              NEM.fromMap [(account, Mismatch depositAmount zero)]
      ]

    legacyTx <- switchTxToLegacyMode tx
    submitFailingTx
      legacyTx
      [ injectFailure $
          WithdrawalAmountsExceedingOriginalBalance @era $
            fromJust $
              NEM.fromMap [(account, Mismatch depositAmount zero)]
      ]

  it "Direct deposits cannot fund withdrawals from an account registered in the same batch" $ do
    stakingCred <- KeyHashObj <$> freshKeyHash
    account <- getAccountAddressFor stakingCred
    keyDeposit <- getsPParams ppKeyDepositL
    depositAmount <- Coin . getPositive <$> arbitrary
    let subRegisterAndDeposit =
          mkBasicTx $
            mkBasicTxBody
              & certsTxBodyL .~ [RegDepositTxCert stakingCred keyDeposit]
              & directDepositsTxBodyL .~ DirectDeposits [(account, depositAmount)]
        subWithdraw =
          mkBasicTx $
            mkBasicTxBody
              & withdrawalsTxBodyL .~ Withdrawals [(account, depositAmount)]
        tx =
          mkBasicTx $
            mkBasicTxBody
              & subTransactionsTxBodyL .~ [subRegisterAndDeposit, subWithdraw]
        missingFromOriginal =
          injectFailure . SubWithdrawalAccountsMissingFromOriginal @era $
            Withdrawals [(account, depositAmount)]

    submitFailingTx tx [missingFromOriginal]

    legacyTx <- switchTxToLegacyMode tx
    submitFailingTx legacyTx [missingFromOriginal]

  it "Top transaction can drain an account funded by a sub-transaction direct deposit, in legacy mode" $ do
    account <- registerStakeCredential . KeyHashObj =<< freshKeyHash
    depositAmount <- Coin . getPositive <$> arbitrary
    let subDeposit =
          mkBasicTx $
            mkBasicTxBody
              & directDepositsTxBodyL .~ DirectDeposits [(account, depositAmount)]
        tx =
          mkBasicTx $
            mkBasicTxBody
              & withdrawalsTxBodyL .~ Withdrawals [(account, depositAmount)]
              & subTransactionsTxBodyL .~ [subDeposit]

    submitFailingTx
      tx
      [ injectFailure $
          WithdrawalAmountsExceedingOriginalBalance @era $
            fromJust $
              NEM.fromMap [(account, Mismatch depositAmount zero)]
      ]

    legacyTx <- switchTxToLegacyMode tx
    submitTx_ legacyTx
    getBalance (account ^. accountAddressCredentialL) `shouldReturn` zero

  it
    "Top transaction can drain an account registered by a sub-transaction, in legacy mode"
    $ do
      keyDeposit <- getsPParams ppKeyDepositL
      let drainsInLegacyMode amount = do
            stakingCred <- KeyHashObj <$> freshKeyHash
            account <- getAccountAddressFor stakingCred
            let subRegisterAndFund =
                  mkBasicTx $
                    mkBasicTxBody
                      & certsTxBodyL .~ [RegDepositTxCert stakingCred keyDeposit]
                      & directDepositsTxBodyL .~ DirectDeposits [(account, amount)]
                tx =
                  mkBasicTx $
                    mkBasicTxBody
                      & withdrawalsTxBodyL .~ Withdrawals [(account, amount)]
                      & subTransactionsTxBodyL .~ [subRegisterAndFund]

            -- in normal mode the account must already be present in the original accounts
            submitFailingTx
              tx
              [ injectFailure . WithdrawalAccountsMissingFromOriginal @era $
                  Withdrawals [(account, amount)]
              ]

            submitTx_ =<< switchTxToLegacyMode tx
            expectStakeCredRegistered stakingCred
            getBalance stakingCred `shouldReturn` zero

      -- withdrawing zero from an account the batch itself registered
      drainsInLegacyMode zero
      -- withdrawing exactly what the same sub-transaction direct-deposited
      depositAmount <- Coin . getPositive <$> arbitrary
      drainsInLegacyMode depositAmount

  describe "Account balance intervals" $ do
    it "Account balance intervals for the top-level transaction" $
      accountBalanceIntervalCases
        (submitFailingTopTxBody . (accountBalanceIntervalsTxBodyL .~))
        WrongNetworkInAccountBalanceIntervals
        MissingAccountsInAccountBalanceIntervals
        BalancesOutsideAccountBalanceIntervals

    it "Account balance intervals within each sub-transaction" $
      accountBalanceIntervalCases
        (submitFailingSubTxBody . (accountBalanceIntervalsTxBodyL .~))
        SubWrongNetworkInAccountBalanceIntervals
        SubMissingAccountsInAccountBalanceIntervals
        SubBalancesOutsideAccountBalanceIntervals

    it "Starting account balance intervals for the top-level transaction" $
      accountBalanceIntervalCases
        (submitFailingTopTxBody . (startingAccountBalanceIntervalsTxBodyL .~))
        WrongNetworkInStartingAccountBalanceIntervals
        MissingAccountsInStartingAccountBalanceIntervals
        BalancesOutsideStartingAccountBalanceIntervals

    it "Satisfied intervals are accepted at every level" $ do
      (accountAddr, balance, _) <- setupAccountAddress
      let intervals = AccountBalanceIntervals [(accountAddr, AccountBalanceExact balance)]
      submitTx_ $ mkBasicTx $ mkBasicTxBody & accountBalanceIntervalsTxBodyL .~ intervals
      submitTx_ $ mkBasicTx $ mkBasicTxBody & startingAccountBalanceIntervalsTxBodyL .~ intervals
      submitTx_ $
        mkBasicTx $
          mkBasicTxBody
            & subTransactionsTxBodyL
              .~ [mkBasicTx $ mkBasicTxBody & accountBalanceIntervalsTxBodyL .~ intervals]

    it "Every violating entry of a single interval map is reported" $ do
      (accountAddr, balance, _) <- setupAccountAddress
      unregistered <- freshUnregisteredAccount
      let onWrongNetwork = accountAddr & accountAddressNetworkIdL .~ Mainnet
          violated = AccountBalanceExact (balance <+> Coin 1)
      submitFailingTx
        ( mkBasicTx $
            mkBasicTxBody
              & accountBalanceIntervalsTxBodyL
                .~ AccountBalanceIntervals
                  [ (onWrongNetwork, violated)
                  , (unregistered, violated)
                  , (accountAddr, violated)
                  ]
        )
        [ injectFailure $
            WrongNetworkInAccountBalanceIntervals @era Testnet (NES.singleton onWrongNetwork)
        , injectFailure $
            MissingAccountsInAccountBalanceIntervals @era (NEM.singleton unregistered violated)
        , injectFailure $
            BalancesOutsideAccountBalanceIntervals @era
              (NEM.singleton accountAddr (balance, violated))
        ]

    it
      "Intervals are checked before the withdrawals and direct deposits of their own transaction are applied"
      $ do
        (accountAddr, balance, _) <- setupAccountAddress
        let deposit = Coin 1_000_000
            txWith modifyBody interval =
              mkBasicTx $
                mkBasicTxBody
                  & accountBalanceIntervalsTxBodyL .~ AccountBalanceIntervals [(accountAddr, interval)]
                  & modifyBody
            drains = withdrawalsTxBodyL .~ Withdrawals [(accountAddr, balance)]
            deposits = directDepositsTxBodyL .~ DirectDeposits [(accountAddr, deposit)]
            expectOutside modifyBody interval =
              submitFailingTx
                (txWith modifyBody interval)
                [ injectFailure $
                    BalancesOutsideAccountBalanceIntervals @era
                      (NEM.singleton accountAddr (balance, interval))
                ]
        expectOutside drains (AccountBalanceExact zero)
        expectOutside deposits (AccountBalanceExact (balance <+> deposit))
        submitFailingTx
          ( mkBasicTx $
              mkBasicTxBody
                & subTransactionsTxBodyL
                  .~ [ mkBasicTx $
                         mkBasicTxBody
                           & withdrawalsTxBodyL .~ Withdrawals [(accountAddr, balance)]
                           & accountBalanceIntervalsTxBodyL
                             .~ AccountBalanceIntervals [(accountAddr, AccountBalanceExact zero)]
                     ]
          )
          [ injectFailure $
              SubBalancesOutsideAccountBalanceIntervals @era
                (NEM.singleton accountAddr (balance, AccountBalanceExact zero))
          ]
        submitTx_ $ txWith drains (AccountBalanceExact balance)

    it "Interval bounds are checked at their boundaries" $ do
      (accountAddr, balance, _) <- setupAccountAddress
      let withInterval interval =
            mkBasicTx $
              mkBasicTxBody
                & accountBalanceIntervalsTxBodyL .~ AccountBalanceIntervals [(accountAddr, interval)]
          intervalHolds = submitTx_ . withInterval
          intervalViolated interval =
            submitFailingTx
              (withInterval interval)
              [ injectFailure $
                  BalancesOutsideAccountBalanceIntervals @era
                    (NEM.singleton accountAddr (balance, interval))
              ]
      intervalHolds $ AccountBalanceExact balance
      intervalViolated $ AccountBalanceExact (balance <+> Coin 1)
      intervalHolds $ AccountBalanceLowerBound (Inclusive balance)
      intervalViolated $ AccountBalanceLowerBound (Inclusive (balance <+> Coin 1))
      intervalHolds $ AccountBalanceUpperBound (Exclusive (balance <+> Coin 1))
      intervalViolated $ AccountBalanceUpperBound (Exclusive balance)
      intervalHolds $ AccountBalanceBothBounds (Inclusive balance) (Exclusive (balance <+> Coin 1))
      intervalViolated $
        AccountBalanceBothBounds (Inclusive (balance <+> Coin 1)) (Exclusive (balance <+> Coin 2))

    it
      "Starting intervals see the pre-transaction balance, account balance intervals see the post-sub-transaction balance"
      $ do
        (accountAddr, balance, _) <- setupAccountAddress
        let drainingSubTx :: Tx SubTx era
            drainingSubTx =
              mkBasicTx $ mkBasicTxBody & withdrawalsTxBodyL .~ Withdrawals [(accountAddr, balance)]
            txWithIntervals starting current =
              mkBasicTx $
                mkBasicTxBody
                  & subTransactionsTxBodyL .~ [drainingSubTx]
                  & startingAccountBalanceIntervalsTxBodyL
                    .~ AccountBalanceIntervals [(accountAddr, starting)]
                  & accountBalanceIntervalsTxBodyL
                    .~ AccountBalanceIntervals [(accountAddr, current)]
            original = AccountBalanceExact balance
            drained = AccountBalanceExact zero
        submitFailingTx
          (txWithIntervals drained original)
          [ injectFailure $
              BalancesOutsideAccountBalanceIntervals @era (NEM.singleton accountAddr (zero, original))
          , injectFailure $
              BalancesOutsideStartingAccountBalanceIntervals @era
                (NEM.singleton accountAddr (balance, drained))
          ]
        submitTx_ $ txWithIntervals original drained
  where
    setupAccountAddress :: ImpTestM era (AccountAddress, Coin, KeyHash Staking)
    setupAccountAddress = do
      kh <- freshKeyHash
      let cred = KeyHashObj kh
          balance = Coin 1_000_000
      ra <- registerStakeCredential cred
      submitTx_ $
        mkBasicTx $
          mkBasicTxBody & directDepositsTxBodyL .~ DirectDeposits [(ra, balance)]
      pure (ra, balance, kh)

    mkTxWithBatchWithdrawals :: Withdrawals -> [Withdrawals] -> Tx TopTx era
    mkTxWithBatchWithdrawals topWdrls subs =
      mkBasicTx $
        mkBasicTxBody
          & withdrawalsTxBodyL .~ topWdrls
          & subTransactionsTxBodyL .~ OMap.fromFoldable (fmap mkSubTx subs)
      where
        mkSubTx :: Withdrawals -> Tx SubTx era
        mkSubTx w = mkBasicTx (mkBasicTxBody & withdrawalsTxBodyL .~ w)

    genCoinPairExceeding (Coin maxSum) = do
      a <- choose (1, maxSum)
      b <- choose (maxSum - a + 1, maxSum)
      pure (Coin a, Coin b)

    submitFailingTopTxBody modifyBody failure =
      submitFailingTx (mkBasicTx (mkBasicTxBody & modifyBody)) [injectFailure failure]

    submitFailingSubTxBody modifyBody failure =
      submitFailingTx
        (mkBasicTx (mkBasicTxBody & subTransactionsTxBodyL .~ [mkBasicTx (mkBasicTxBody & modifyBody)]))
        [injectFailure failure]

    accountBalanceIntervalCases ::
      (AccountBalanceIntervals era -> t era -> ImpTestM era ()) ->
      (Network -> NES.NonEmptySet AccountAddress -> t era) ->
      (NEM.NonEmptyMap AccountAddress (AccountBalanceInterval era) -> t era) ->
      (NEM.NonEmptyMap AccountAddress (Coin, AccountBalanceInterval era) -> t era) ->
      ImpTestM era ()
    accountBalanceIntervalCases submitFailing mkWrongNetwork mkMissingAccounts mkBalancesOutside = do
      (accountAddr, balance, _) <- setupAccountAddress
      let onWrongNetwork = accountAddr & accountAddressNetworkIdL .~ Mainnet
          violated = AccountBalanceExact (balance <+> Coin 1)
      submitFailing
        (AccountBalanceIntervals [(onWrongNetwork, violated)])
        (mkWrongNetwork Testnet (NES.singleton onWrongNetwork))
      unregistered <- freshUnregisteredAccount
      submitFailing
        (AccountBalanceIntervals [(unregistered, violated)])
        (mkMissingAccounts (NEM.singleton unregistered violated))
      submitFailing
        (AccountBalanceIntervals [(accountAddr, violated)])
        (mkBalancesOutside (NEM.singleton accountAddr (balance, violated)))
